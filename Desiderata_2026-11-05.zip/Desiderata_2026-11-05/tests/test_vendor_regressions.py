"""Recovered PERSONAL.WIKI Phase 2 controls against the vendored source tree.

The original four suites are retained verbatim as original_* in
 tests/vendor_legacy_scripts. Only module/path imports were adapted; tests
are executed in fresh subprocesses because the upstream tests are standalone.
"""
import ast
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / 'tests' / 'vendor_legacy_scripts'
VENDOR = ROOT / 'scientific_workspace' / 'storage' / 'vendor_pw'


class VendorLegacyRegressions(unittest.TestCase):
    def _suite(self, script):
        cp = subprocess.run([sys.executable, '-B', str(SCRIPTS / script)],
                            cwd=ROOT, text=True, capture_output=True,
                            timeout=25)
        self.assertEqual(cp.returncode, 0, cp.stdout + '\n' + cp.stderr)
        self.assertIn('PASS', cp.stdout)

    def test_workspace_source_contract(self): self._suite('test_workspace.py')
    def test_resolver_source_contract(self): self._suite('test_resolver.py')
    def test_defect_fix_source_contract(self): self._suite('test_defect_fixes.py')
    def test_export_determinism_source_contract(self): self._suite('test_export_determinism.py')

    def test_no_flat_local_imports_even_inside_functions(self):
        """Catches lazily imported pre-vendoring symbols missed by import smoke tests."""
        local = {'db', 'history_db', 'wiki_core', 'exporters', 'resolver',
                 'workspace', 'links', 'renderer', 'schema_migrations'}
        violations = []
        for path in VENDOR.glob('*.py'):
            for node in ast.walk(ast.parse(path.read_text(encoding='utf8'))):
                if isinstance(node, ast.ImportFrom) and not node.level and node.module in local:
                    violations.append(f'{path.name}:{node.lineno} from {node.module}')
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name in local:
                            violations.append(f'{path.name}:{node.lineno} import {alias.name}')
        self.assertEqual(violations, [])

    def test_lazy_export_path_reachable(self):
        """Before the repair, WikiCore.export_bundle raised ModuleNotFoundError."""
        from scientific_workspace.storage.vendor_pw.wiki_core import WikiCore
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'note.db'
            WikiCore.create_database(path)
            with WikiCore(path) as w:
                w.save_tiddler('Original', 'See [[Missing]].', [])
            with WikiCore(path, readonly=True) as w:
                w.export_bundle(Path(d) / 'out')
            self.assertTrue((Path(d) / 'out' / 'MANIFEST.json').exists())


if __name__ == '__main__': unittest.main()
