"""C2 integration tests: real WikiCore SQLite content/history and crash cutpoints."""
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor

from scientific_workspace.demo import SOURCE, WITNESS
from scientific_workspace.engine.r0_core import new_registration, issued_context, propose_witness, object_digest
from scientific_workspace.engine.transition import expected_actor, active_goal
from scientific_workspace.storage.journal import WikiJournal, JournalError, SimulatedCrash
from scientific_workspace.storage.vendor_pw.wiki_core import WikiCore


class JournalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'work'
        self.j = WikiJournal.create(self.root, budget=2)
        self.goal_command = {'type': 'goal', 'principal': 'user',
                             'goal_id': 'p14', 'statement': 'Prove P14 as stated'}

    def goal(self):
        return self.j.submit('goal-1', self.goal_command, {'human_authorized': True})['state']

    def attempt(self, state, request_id, mode):
        reg = new_registration(SOURCE, mode, 'claim-' + mode)
        ctx = issued_context(reg)
        envelope = propose_witness(reg, ctx, WITNESS)
        cmd = {'type': 'attempt', 'principal': expected_actor(state),
               'attempt_id': request_id, 'ordinal': len(state['attempts']) + 1,
               'goal_digest': active_goal(state)['digest'],
               'payload_digest': object_digest(envelope)}
        return cmd, reg, ctx, envelope

    def test_four_pairs_are_real_wikicore_with_verified_history(self):
        for namespace in ('user', 'agent_a', 'agent_b', 'system'):
            file = self.root / namespace / 'wiki.db'
            self.assertTrue(file.is_file())
            self.assertTrue((self.root / namespace / 'wiki.history.sqlite').is_file())
            with WikiCore(file, readonly=True) as w:
                self.assertEqual(w.history_report()['status'], 'ok')

    def test_cold_reopen_replays_same_goal(self):
        state = self.goal()
        reopened = WikiJournal(self.root).inspect()
        self.assertEqual(reopened['state'], state)
        self.assertEqual(reopened['events'], 1)
        self.assertEqual(reopened['pending'], [])
        self.assertEqual(state['status'], 'WAITING_FOR_TURN')

    def test_crash_after_draft_is_named_pending_no_turn_consumed(self):
        with self.assertRaisesRegex(SimulatedCrash, 'AFTER_DRAFT'):
            self.j.submit('goal-1', self.goal_command,
                          {'human_authorized': True}, cutpoint='after_draft')
        pending = WikiJournal(self.root).inspect()
        self.assertEqual(pending['events'], 0)
        self.assertEqual(pending['state']['status'], 'WAITING_FOR_GOAL')
        self.assertEqual(pending['pending'][0]['request_id'], 'goal-1')
        committed = self.j.submit('goal-1', self.goal_command, {'human_authorized': True})
        self.assertEqual(committed['outcome'], 'APPLIED')
        self.assertEqual(WikiJournal(self.root).inspect()['pending'], [])

    def test_crash_after_system_commit_retry_is_idempotent(self):
        with self.assertRaisesRegex(SimulatedCrash, 'AFTER_EVENT'):
            self.j.submit('goal-1', self.goal_command,
                          {'human_authorized': True}, cutpoint='after_event')
        reopened = WikiJournal(self.root)
        self.assertEqual(reopened.inspect()['events'], 1)
        self.assertEqual(reopened.submit('goal-1', self.goal_command)['outcome'], 'NOOP')
        self.assertEqual(reopened.inspect()['events'], 1)

    def test_same_request_different_command_rejected(self):
        self.goal()
        with self.assertRaisesRegex(JournalError, 'REQUEST_ID_CONFLICT'):
            self.j.submit('goal-1', {**self.goal_command, 'statement': 'rewrite'})
        self.assertEqual(self.j.inspect()['events'], 1)

    def test_same_request_different_pending_command_rejected(self):
        with self.assertRaises(SimulatedCrash):
            self.j.submit('goal-1', self.goal_command,
                          {'human_authorized': True}, cutpoint='after_draft')
        with self.assertRaisesRegex(JournalError, 'REQUEST_ID_CONFLICT'):
            self.j.submit('goal-1', {**self.goal_command, 'statement': 'rewrite'})

    def test_attempt_crash_then_retry_charge_once(self):
        state = self.goal()
        cmd, _, _, _ = self.attempt(state, 'turn-1', 'UNEQUAL')
        with self.assertRaises(SimulatedCrash):
            self.j.submit('turn-1', cmd, cutpoint='after_draft')
        self.assertEqual(len(self.j.inspect()['state']['attempts']), 0)
        self.assertEqual(self.j.submit('turn-1', cmd)['outcome'], 'APPLIED')
        self.assertEqual(self.j.submit('turn-1', cmd)['outcome'], 'NOOP')
        self.assertEqual(len(self.j.inspect()['state']['attempts']), 1)

    def test_rejected_admission_one_committed_budget_unit_across_reopen(self):
        s = self.goal()
        cmd, reg, ctx, envelope = self.attempt(s, 'turn-1', 'UNEQUAL')
        envelope['verdict'] = 'CERTIFIED'
        cmd['payload_digest'] = object_digest(envelope)
        self.j.submit('turn-1', cmd)
        self.j.submit('eval-1', {'type': 'evaluate', 'principal': 'system',
                                'attempt_id': 'turn-1', 'registration': reg,
                                'context': ctx, 'envelope': envelope},
                      {'system_authorized': True})
        s = WikiJournal(self.root).inspect()['state']
        self.assertEqual(len(s['attempts']), 1)
        self.assertEqual(s['evaluations'][0]['result']['admission']['admission'], 'REJECTED')
        self.assertEqual(self.j.submit('turn-1', cmd)['outcome'], 'NOOP')
        self.assertEqual(len(WikiJournal(self.root).inspect()['state']['attempts']), 1)

    def test_conflicting_ordinal_named_without_next_turn_guess(self):
        s = self.goal()
        cmd, _, _, _ = self.attempt(s, 'turn-1', 'UNEQUAL')
        s = self.j.submit('turn-1', cmd)['state']
        cmd2, _, _, _ = self.attempt(s, 'turn-2', 'DISJOINT')
        cmd2['ordinal'] = 1
        r = self.j.submit('turn-2', cmd2)
        self.assertEqual(r['reason'], 'ORDINAL_CONFLICT')
        self.assertEqual(len(self.j.inspect()['state']['attempts']), 1)
        self.assertEqual(self.j.inspect()['pending'][0]['request_id'], 'turn-2')

    def test_persisted_formal_result_not_source_verdict(self):
        state = self.goal()
        for mode in ('UNEQUAL', 'DISJOINT'):
            cmd, reg, ctx, envelope = self.attempt(state, 'turn-' + mode, mode)
            state = self.j.submit('turn-' + mode, cmd)['state']
            state = self.j.submit('eval-' + mode, {'type': 'evaluate', 'principal': 'system',
                'attempt_id': 'turn-' + mode, 'registration': reg,
                'context': ctx, 'envelope': envelope}, {'system_authorized': True})['state']
        restored = WikiJournal(self.root).inspect()['state']
        self.assertEqual(state, restored)
        self.assertEqual(restored['source_claim_state'], 'UNRESOLVED')
        self.assertEqual(restored['evaluations'][0]['result']['formal_claim_state'], 'REFUTED')
        self.assertEqual(restored['evaluations'][1]['result']['formal_claim_state'], 'UNRESOLVED')

    def test_one_namespace_unavailable_never_fabricates_absence(self):
        self.goal()
        path = self.root / 'agent_b' / 'wiki.db'
        path.rename(path.with_suffix('.missing'))
        with self.assertRaisesRegex(JournalError, 'NAMESPACE_UNAVAILABLE:agent_b'):
            self.j.inspect()

    def test_content_or_history_corruption_does_not_pass(self):
        self.goal()
        path = self.root / 'user' / 'wiki.history.sqlite'
        path.unlink()
        with self.assertRaisesRegex(JournalError, '(NAMESPACE_UNAVAILABLE|HISTORY_UNVERIFIED):user'):
            self.j.inspect()

    def test_removed_committed_draft_causes_explicit_failure(self):
        self.goal()
        path = self.root / 'user' / 'wiki.db'
        with WikiCore(path) as w:
            w.delete_tiddler('intent/goal-1', reason='mutation probe')
        with self.assertRaisesRegex(JournalError, 'IMMUTABLE_HISTORY_VIOLATION:user'):
            self.j.inspect()

    def test_storage_failure_cannot_durably_abandon(self):
        self.goal()
        cmd = {'type': 'abandon', 'principal': 'user', 'reason': 'leave'}
        r = self.j.submit('abort-1', cmd,
                          {'human_authorized': True, 'storage_writable': False})
        self.assertEqual(r['reason'], 'LOCAL_STOP_UNRECORDED')
        self.assertEqual(self.j.inspect()['state']['status'], 'WAITING_FOR_TURN')
        self.assertEqual(self.j.inspect()['pending'][0]['request_id'], 'abort-1')
        ok = self.j.submit('abort-1', cmd, {'human_authorized': True})
        self.assertEqual(ok['state']['status'], 'ABANDONED')

    def test_authority_is_assumed_not_authenticated(self):
        # C2 intentionally cannot validate that a caller is really the user.
        self.goal()
        self.assertEqual(self.j.inspect()['state']['events'][0]['assumed_authority']['human_authorized'], True)

    def test_unexpected_system_data_blocks_recovery(self):
        self.goal()
        with WikiCore(self.root / 'system' / 'wiki.db') as w:
            w.save_tiddler('event/banana', 'bad', [], reason='negative fixture')
        with self.assertRaisesRegex(JournalError, 'INVALID_EVENT_TITLE'):
            self.j.inspect()

    def test_history_edit_is_rejected_despite_consistent_sidecar(self):
        self.goal()
        with WikiCore(self.root / 'user' / 'wiki.db') as w:
            rec = w.get_tiddler('intent/goal-1')
            w.save_tiddler('intent/goal-1', rec['text'], [],
                           fields=rec['fields'], reason='forbidden rewrite')
        with self.assertRaisesRegex(JournalError, 'IMMUTABLE_HISTORY_VIOLATION:user'):
            self.j.inspect()

    def test_concurrent_submissions_one_turn_only(self):
        s = self.goal()
        one, _, _, _ = self.attempt(s, 'parallel-1', 'UNEQUAL')
        two = {**one, 'attempt_id': 'parallel-2'}
        def submit(pair):
            try:
                r = WikiJournal(self.root).submit(*pair)
                return r['outcome'], r.get('reason')
            except JournalError as e:
                return 'ERROR', str(e)
        with ThreadPoolExecutor(max_workers=2) as pool:
            responses = list(pool.map(submit, [('parallel-1', one), ('parallel-2', two)]))
        self.assertEqual(sum(out == 'APPLIED' for out, _ in responses), 1)
        self.assertEqual(sum(reason == 'ORDINAL_CONFLICT' for _, reason in responses), 1)
        self.assertEqual(len(WikiJournal(self.root).inspect()['state']['attempts']), 1)

    def test_workspace_cannot_reinitialize_over_existing_files(self):
        with self.assertRaisesRegex(JournalError, 'WORKSPACE_EXISTS'):
            WikiJournal.create(self.root)


if __name__ == '__main__':
    unittest.main()
