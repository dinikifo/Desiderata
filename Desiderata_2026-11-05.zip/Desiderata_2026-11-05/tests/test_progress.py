import json
from pathlib import Path
import unittest

from tools.show_progress import report, markdown


class ProgressTests(unittest.TestCase):
    def test_weights_and_estimate_consistent(self):
        cfg, completed, remaining = report()
        self.assertEqual((cfg['current_step'], cfg['total_steps']), (6, 6))
        self.assertAlmostEqual(completed + remaining, 100)
        self.assertAlmostEqual(completed, 92.6)
        self.assertAlmostEqual(remaining, 7.4)

    def test_document_generated_not_hand_retyped(self):
        root = Path(__file__).resolve().parents[1]
        self.assertEqual((root / 'docs/PROGRESS.md').read_text(), markdown() + '\n')

    def test_long_term_agent_work_excluded_from_denominator(self):
        cfg, _, _ = report()
        self.assertIn('LLM', cfg['longer_term'])
        self.assertIn('C3', cfg['target'])


if __name__ == '__main__':
    unittest.main()
