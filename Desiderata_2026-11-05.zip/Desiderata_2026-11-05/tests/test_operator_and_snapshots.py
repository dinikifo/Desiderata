"""C3.1 operator controls and data-only cold restoration regression tests."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from zipfile import ZIP_DEFLATED, ZipFile

from scientific_workspace.interface.checkpoint_io import CheckpointError
from scientific_workspace.interface.project_io import export_project, restore_project, ROOT
from scientific_workspace.storage.journal import WikiJournal, JournalError
from scientific_workspace.engine.transition import active_goal, step, initial_state

PROJECT = Path(__file__).resolve().parents[1]
LAUNCHER = PROJECT / 'bin/scientific-workspace'


class OperatorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.work = self.root / 'run'
        self.run_cli('init', '--workspace', str(self.work), '--budget', '2')

    def run_cli(self, *argv, ok=True):
        cmd = [sys.executable, str(LAUNCHER), *argv]
        out = subprocess.run(cmd, cwd=self.root, text=True, capture_output=True, timeout=20)
        self.assertEqual(out.returncode == 0, ok, f'{cmd}: {out.stdout}\n{out.stderr}')
        return json.loads(out.stdout) if ok else (out.stdout or out.stderr)

    def command(self, name, *args, request='test-one', ok=True, ack=True):
        argv = [name, '--workspace', str(self.work), '--request-id', request, *args]
        if ack:
            argv += ['--local-operator']
        return self.run_cli(*argv, ok=ok)

    def goal(self):
        return self.command('goal', '--goal-id', 'G', '--statement', 'Solve the original task', request='goal-G')

    def test_local_full_cycle_and_restore_are_reconstructible(self):
        goal = self.goal()
        self.assertEqual(goal['goal_version'], 1)
        self.assertEqual(self.command('stop', request='stop-1')['lifecycle'], 'QUIESCED')
        updated = self.command('amend', '--expected-goal-digest', goal['goal_digest'],
                               '--statement', 'Revised task', '--reason', 'Contradiction found', request='amend-1')
        self.assertEqual((updated['goal_version'], updated['lifecycle']), (2, 'QUIESCED'))
        self.assertEqual(self.command('resume', request='resume-1')['lifecycle'], 'WAITING_FOR_TURN')
        before = self.run_cli('inspect', '--workspace', str(self.work), '--json')
        archive = self.root / 'portable.zip'
        exported = self.run_cli('export', '--workspace', str(self.work), '--archive', str(archive))
        self.assertEqual(exported['payload_files'], 8)
        restored = self.root / 'restored'
        self.run_cli('restore', '--archive', str(archive), '--workspace', str(restored),
                     '--expected-sha256', exported['archive_sha256'])
        after = self.run_cli('inspect', '--workspace', str(restored), '--json')
        for key in ('event_count', 'head_digest', 'lifecycle', 'goals', 'timeline', 'corrections', 'evaluations'):
            self.assertEqual(before[key], after[key], key)
        self.assertEqual(after['event_count'], 4)
        self.assertIn('Supersedes:', self.run_cli_text('inspect', '--workspace', str(restored), '--diff-from-initial'))

    def run_cli_text(self, *argv):
        proc = subprocess.run([sys.executable, str(LAUNCHER), *argv], cwd=self.root,
                              text=True, capture_output=True, timeout=20)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        return proc.stdout

    def test_unacknowledged_operator_does_not_stage_draft(self):
        self.command('goal', '--goal-id', 'G', '--statement', 'Original',
                     request='unack', ok=False, ack=False)
        observed = WikiJournal(self.work).inspect()
        self.assertEqual((observed['events'], observed['pending']), (0, []))

    def test_goal_created_while_quiesced_requires_explicit_resume(self):
        self.command('stop', request='early-stop')
        g = self.goal()
        self.assertEqual(g['lifecycle'], 'QUIESCED')
        self.assertEqual(self.command('resume', request='resume-early')['lifecycle'], 'WAITING_FOR_TURN')

    def test_stale_goal_digest_fails_before_stage(self):
        self.goal()
        self.assertIn('STALE_OR_UNKNOWN_GOAL_DIGEST', self.command(
            'amend', '--expected-goal-digest', 'sha256:invalid', '--statement', 'Bad',
            '--reason', 'Outdated', request='stale', ok=False))
        self.assertEqual(WikiJournal(self.work).inspect()['pending'], [])

    def test_idempotent_retry_by_request_id_not_new_timestamp(self):
        first = self.goal()
        retry = self.command('goal', '--goal-id', 'G', '--statement', 'Solve the original task', request='goal-G')
        self.assertEqual((first['event_count'], retry['event_count']), (1, 1))
        self.assertEqual(retry['outcome'], 'NOOP')
        error = self.command('goal', '--goal-id', 'G', '--statement', 'Different', request='goal-G', ok=False)
        self.assertIn('REQUEST_ID_CONFLICT', error)
        self.assertEqual(WikiJournal(self.work).inspect()['events'], 1)

    def test_stop_requires_human_authorization_even_pure_core(self):
        s = initial_state()
        self.assertEqual(step(s, {'type':'stop','principal':'user'})['reason'], 'HUMAN_AUTH_REQUIRED')
        self.assertEqual(len(s['events']), 0)

    def test_stop_double_request_does_not_create_event(self):
        self.goal()
        self.command('stop', request='stop1')
        bad = self.command('stop', request='stop2')
        self.assertEqual((bad['outcome'], bad['reason']), ('NOOP', 'ALREADY_QUIESCED'))
        self.assertEqual(WikiJournal(self.work).inspect()['events'], 2)
        self.assertEqual(len(WikiJournal(self.work).inspect()['pending']), 1)  # rejected staged draft is explicit

    def test_abandon_is_terminal_and_remains_reconstructible(self):
        self.goal()
        r = self.command('abandon', '--reason', 'Insufficient evidence', request='abandon1')
        self.assertEqual(r['lifecycle'], 'ABANDONED')
        self.assertIn('TERMINAL', self.command('resume', request='resume-after-end', ok=False))
        archive = self.root / 'abandoned.zip'
        export_project(self.work, archive)
        restore_project(archive, self.root / 'abandoned-restore')
        self.assertEqual(WikiJournal(self.root / 'abandoned-restore').inspect()['state']['status'], 'ABANDONED')

    def test_export_refuses_overwrite_and_restore_refuses_existing(self):
        self.goal()
        archive = self.root / 'project.zip'
        exported = export_project(self.work, archive)
        self.assertTrue(exported['archive_sha256'])
        with self.assertRaisesRegex(CheckpointError, 'DESTINATION_EXISTS'):
            export_project(self.work, archive)
        dest = self.root / 'keep'
        dest.mkdir()
        (dest/'KEEP').write_text('original')
        with self.assertRaisesRegex(CheckpointError, 'DESTINATION_EXISTS'):
            restore_project(archive, dest)
        self.assertEqual((dest/'KEEP').read_text(), 'original')

    def test_modified_snapshot_content_detected(self):
        self.goal()
        a = self.root / 'project.zip'
        export_project(self.work, a)
        b = self.root / 'changed.zip'
        with ZipFile(a) as z, ZipFile(b, 'w', compression=ZIP_DEFLATED) as out:
            for item in z.infolist():
                content = z.read(item.filename)
                if item.filename.endswith('/user/wiki.db'):
                    content += b'forged'
                out.writestr(item.filename, content)
        with self.assertRaisesRegex(CheckpointError, 'PAYLOAD_MISMATCH'):
            restore_project(b, self.root/'bad')
        self.assertFalse((self.root/'bad').exists())

    def test_self_consistent_but_missing_db_inventory_refused(self):
        self.goal()
        a = self.root / 'project.zip'
        export_project(self.work, a)
        with ZipFile(a) as z:
            content = {n: z.read(n) for n in z.namelist()
                       if not n.endswith('/agent_b/wiki.db')}
        manifest_key = ROOT+'/checkpoints/PACKAGE_MANIFEST.json'
        manifest = json.loads(content[manifest_key])
        manifest['files'] = [f for f in manifest['files'] if f['path'] != 'workspace/agent_b/wiki.db']
        content[manifest_key] = json.dumps(manifest).encode()
        b = self.root / 'missing-but-hashed.zip'
        with ZipFile(b,'w') as out:
            for name, payload in content.items():
                out.writestr(name,payload)
        with self.assertRaisesRegex(CheckpointError, 'INVALID_PROJECT_INVENTORY'):
            restore_project(b, self.root/'missing')

    def test_snapshot_claims_no_external_identity_or_signing(self):
        self.goal()
        archive = self.root / 'snapshot.zip'
        response = export_project(self.work, archive)
        self.assertIn('independently', response['trust'])
        with self.assertRaisesRegex(CheckpointError, 'EXTERNAL_DIGEST_MISMATCH'):
            restore_project(archive, self.root / 'untrusted', expected_sha256='0'*64)

    def test_read_only_inspection_does_not_rewrite_db(self):
        self.goal()
        files = [f for f in self.work.rglob('*') if f.is_file() and f.suffix in ('.db', '.sqlite')]
        before = {str(f): hashlib.sha256(f.read_bytes()).digest() for f in files}
        self.run_cli('verify','--workspace',str(self.work),'--json')
        self.run_cli('inspect','--workspace',str(self.work),'--json')
        after = {str(f): hashlib.sha256(f.read_bytes()).digest() for f in files}
        self.assertEqual(before,after)


if __name__ == '__main__':
    unittest.main()
