"""Source-integrity and pure-import checks; not a sandbox/security boundary."""
import ast
import hashlib
import pathlib
import subprocess
import sys
import unittest
from zipfile import ZipFile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / 'sources/scientific_reasoning_prototype_R0_2026-11-05.zip'
EXPECTED = 'ad8fd86cc3a3aad960a95173c3147a35aae5f989e318ced0c50b81e143c058f4'


class BaselineAndImportTests(unittest.TestCase):
    def test_r0_archive_exact_expected_digest(self):
        self.assertEqual(hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(), EXPECTED)

    def test_imported_r0_core_byte_identical_to_source(self):
        with ZipFile(ARCHIVE) as z:
            old = z.read('scientific_reasoning_prototype_R0_2026-11-05/core.py')
        current = (ROOT / 'scientific_workspace/engine/r0_core.py').read_bytes()
        self.assertEqual(old, current)

    def test_pure_imports_isolated_subprocess(self):
        probe = ('import sys\n'
                 'import scientific_workspace.engine.transition\n'
                 'import scientific_workspace.checkers.finite\n'
                 'for n in sys.modules:\n'
                 "  assert not n.startswith(('sqlite3','PySide','PyQt')) and "
                 "not n.startswith('scientific_workspace.storage'), n\n")
        result = subprocess.run([sys.executable, '-c', probe], cwd=ROOT,
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_ast_guard_catches_forbidden_direct_import_fixture(self):
        tree = ast.parse('import sqlite3\nfrom PySide6 import QtWidgets\n')
        modules = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                modules.extend(n.name for n in node.names)
            elif isinstance(node, ast.ImportFrom):
                modules.append(node.module)
        self.assertTrue(any(n.startswith('sqlite3') for n in modules))
        self.assertTrue(any(n.startswith('PySide6') for n in modules))


if __name__ == '__main__':
    unittest.main()
