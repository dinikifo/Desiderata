#!/usr/bin/env python3
"""Focused fresh mutation checks of vendored PERSONAL.WIKI.

Not a reproduction of the historical 30-mutation harness. Each mutation is
applied exactly once to an isolated disposable source tree. A non-applying
mutation is NOT counted as caught; a broken suite baseline is NOT counted.
"""
from __future__ import annotations
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# (name, module, original snippet, mutated snippet, controlling suite)
MUTATIONS = [
 ('reserved_scheme', 'links.py', "{'file', 'http', 'https', 'mailto', 'tw'}", "{'http', 'https', 'mailto', 'tw'}", 'test_workspace.py'),
 ('local_colon_escape', 'links.py', 'return None, text[1:]', 'return None, text', 'test_resolver.py'),
 ('namespace_whitespace', 'links.py', 'and not tail[:1].isspace()', 'and True', 'test_resolver.py'),
 ('namespace_case', 'links.py', "r'[a-z0-9][a-z0-9_-]{0,62}\\Z'", "r'[A-Za-z0-9][A-Za-z0-9_-]{0,62}\\Z'", 'test_workspace.py'),
 ('collapse_unavailable', 'resolver.py', "NAMESPACE_UNAVAILABLE = 'NAMESPACE_UNAVAILABLE'", "NAMESPACE_UNAVAILABLE = 'NO_SUCH_NAMESPACE'", 'test_resolver.py'),
 ('missing_cross_namespace_count', 'exporters.py', "'cross_namespace_links': sum(len(r['external_links']) for r in rows)", "'cross_namespace_links': 0", 'test_resolver.py'),
 ('flat_export_import', 'exporters.py', 'from .db import parse_tags', 'from db import parse_tags', 'test_export_determinism.py'),
 ('flat_history_import', 'exporters.py', 'from .history_db import post_sha256', 'from history_db import post_sha256', 'test_export_determinism.py'),
 ('unreserved_mailto', 'links.py', "{'file', 'http', 'https', 'mailto', 'tw'}", "{'file', 'http', 'https', 'tw'}", 'test_workspace.py'),
]


def run(root: Path, suite: str, timeout=20):
    try:
        proc = subprocess.run([sys.executable, '-B', str(root/'tests'/'vendor_legacy_scripts'/suite)],
                              cwd=root, text=True, capture_output=True, timeout=timeout)
        return {'status':'PASS' if proc.returncode == 0 else 'FAIL',
                'reason': (proc.stdout+'\n'+proc.stderr)[-1100:]}
    except subprocess.TimeoutExpired:
        return {'status':'TIMEOUT', 'reason':'timeout'}


def main():
    needed = sorted({row[-1] for row in MUTATIONS})
    baselines = {suite:run(ROOT, suite) for suite in needed}
    print('BASELINE:', {k: v['status'] for k,v in baselines.items()}, flush=True)
    rows=[]
    for label, module, before, after, suite in MUTATIONS:
        with tempfile.TemporaryDirectory(prefix='vendor_mut_') as tmp:
            project=Path(tmp)/'project'; project.mkdir()
            shutil.copytree(ROOT/'scientific_workspace', project/'scientific_workspace', ignore=shutil.ignore_patterns('__pycache__'))
            shutil.copytree(ROOT/'tests'/'vendor_legacy_scripts', project/'tests'/'vendor_legacy_scripts', ignore=shutil.ignore_patterns('__pycache__'))
            p=project/'scientific_workspace'/'storage'/'vendor_pw'/module
            src=p.read_text()
            if src.count(before)!=1:
                row={'name':label,'result':'NOT_APPLIED','occurrences':src.count(before)}
            elif baselines[suite]['status']!='PASS':
                row={'name':label,'result':'BASELINE_FAILURE'}
            else:
                p.write_text(src.replace(before,after,1))
                result=run(project,suite)
                row={'name':label,'result':'CAUGHT' if result['status']=='FAIL' else ('SURVIVED' if result['status']=='PASS' else result['status']),
                     'suite':suite,'diagnostic':result['reason'][-420:]}
            rows.append(row)
            print(label, row['result'],flush=True)
    result={'baseline':{k:v['status'] for k,v in baselines.items()},'mutations':rows,
            'applied':sum(r['result']!='NOT_APPLIED' for r in rows),
            'caught':sum(r['result']=='CAUGHT' for r in rows),
            'survived':sum(r['result']=='SURVIVED' for r in rows),
            'note':'Fresh selected mutations, not reconstruction of historical 30.'}
    p=ROOT/'checkpoints'/'C3_3_MUTATIONS.json';p.write_text(json.dumps(result,indent=2)+'\n');return 0 if all(r['result']=='CAUGHT' for r in rows) else 1

if __name__=='__main__': raise SystemExit(main())
