"""Adversarial controls for the function-local import coverage gate itself."""
from pathlib import Path
import tempfile
import unittest

from tools.check_vendor_local_import_coverage import scan_function_imports, summarize


class ImportCoverageGateTests(unittest.TestCase):
    def test_ast_discovers_nested_functions_and_multiple_imports(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'sample.py'
            p.write_text('''import os

def outer():
    from .db import parse_tags
    def inner():
        import decimal
        from .history_db import post_sha256
''', encoding='utf-8')
            sites, digests = scan_function_imports(Path(d))
            self.assertEqual([(s['function'], s['line']) for s in sites],
                             [('outer', 4), ('outer.inner', 6), ('outer.inner', 7)])
            self.assertEqual(len(digests['sample.py']), 64)

    def test_unvisited_extra_import_fails_even_when_existing_imports_are_hit(self):
        sites = [
            {'file': 'one.py', 'line': 5, 'function': 'f', 'import': 'import x'},
            {'file': 'one.py', 'line': 9, 'function': 'g', 'import': 'import y'},
        ]
        actual = [{'name':'baseline','status':'PASS','hits':[{'file':'one.py','line':5}]}]
        verdict = summarize(sites, actual)
        self.assertEqual(verdict['status'], 'FAIL')
        self.assertEqual(verdict['missing'], ['one.py:9:g'])
        self.assertEqual(verdict['sites_visited'], 1)

    def test_multiple_imports_on_one_line_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            source = Path(d) / 'one.py'
            source.write_text('def f():\n    import os; import json\n', encoding='utf-8')
            sites, _ = scan_function_imports(Path(d))
            self.assertEqual(len(sites), 2)
            verdict = summarize(sites, [{'name': 'baseline', 'status': 'PASS',
                'hits': [{'file': 'one.py', 'line': 2}]}])
            self.assertEqual(verdict['status'], 'FAIL')
            self.assertEqual(verdict['ambiguous_same_line_imports'], ['one.py:2'])

    def test_failing_test_job_cannot_discharge_import_site(self):
        sites = [{'file':'one.py','line':10,'function':'f','import':'import x'}]
        runs = [{'name':'failing','status':'FAIL', 'hits':[{'file':'one.py','line':10}]}]
        verdict = summarize(sites, runs)
        self.assertEqual(verdict['sites_visited'], 0)
        self.assertEqual(verdict['failed_jobs'], ['failing'])
        self.assertEqual(verdict['status'], 'FAIL')

    def test_zero_site_or_zero_job_is_not_vacuous_pass(self):
        self.assertEqual(summarize([], [{'name':'test','status':'PASS','hits':[]}])['status'], 'FAIL')
        self.assertEqual(summarize([{'file':'one.py','line':1,'function':'f'}], [])['status'], 'FAIL')


if __name__ == '__main__':
    unittest.main()
