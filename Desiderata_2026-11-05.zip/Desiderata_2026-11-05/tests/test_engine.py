import ast
import copy
import pathlib
import sys
import unittest

from scientific_workspace.demo import SOURCE, WITNESS, demo
from scientific_workspace.engine.r0_core import (
    new_registration, issued_context, propose_witness, object_digest,
)
from scientific_workspace.engine.transition import (
    initial_state, step, expected_actor, active_goal, replay,
    verify_event_chain, classify_continuation,
)


def goal_state(budget=2):
    s = initial_state(budget)
    result = step(s, {'type': 'goal', 'principal': 'user', 'goal_id': 'g1',
                      'statement': 'Prove P14'}, {'human_authorized': True})
    assert result['outcome'] == 'APPLIED'
    return result['state']


def attempt_command(s, aid='att1', payload='sha256:fixture'):
    return {'type': 'attempt', 'principal': expected_actor(s), 'attempt_id': aid,
            'ordinal': len(s['attempts']) + 1, 'goal_digest': active_goal(s)['digest'],
            'payload_digest': payload}


class TransitionTests(unittest.TestCase):
    def test_e1_differential_and_replay(self):
        r = demo()
        self.assertEqual(r['cases']['UNEQUAL']['formal_claim_state'], 'REFUTED')
        self.assertEqual(r['cases']['DISJOINT']['formal_claim_state'], 'UNRESOLVED')
        self.assertEqual(r['cases']['DISJOINT']['verification_receipts'][0]['result'], 'PREMISE_NOT_SATISFIED')
        self.assertEqual(r['source_state'], 'UNRESOLVED')
        self.assertEqual(r['correction_state'], 'PROPOSED')
        self.assertTrue(r['replayed_identically'])
        self.assertEqual(r['lifecycle'], 'EXHAUSTED')

    def test_unauthed_goal_rejected_without_mutation(self):
        s = initial_state()
        before = copy.deepcopy(s)
        r = step(s, {'type': 'goal', 'principal': 'user', 'goal_id': 'x', 'statement': 'X'})
        self.assertEqual(r['reason'], 'HUMAN_AUTH_REQUIRED')
        self.assertEqual(s, before)

    def test_attempt_idempotence_and_conflict(self):
        s = goal_state()
        cmd = attempt_command(s)
        first = step(s, cmd)
        self.assertEqual(first['outcome'], 'APPLIED')
        state = first['state']
        self.assertEqual(step(state, cmd, {'retry_timestamp': 'later'})['outcome'], 'NOOP')
        altered = {**cmd, 'payload_digest': 'sha256:different'}
        self.assertEqual(step(state, altered)['reason'], 'ATTEMPT_ID_CONFLICT')
        self.assertEqual(len(state['attempts']), 1)
        self.assertEqual(step(state, {**cmd, 'attempt_id': 'new'})['reason'], 'ORDINAL_CONFLICT')

    def test_rejected_admission_still_consumes_one_budget_unit(self):
        s = goal_state(budget=1)
        reg = new_registration(SOURCE, 'UNEQUAL', 'c')
        ctx = issued_context(reg)
        env = propose_witness(reg, ctx, WITNESS)
        env['verdict'] = 'CERTIFIED'  # invalid but canonical, should be rejected by R0
        cmd = attempt_command(s, payload=object_digest(env))
        s = step(s, cmd)['state']
        result = step(s, {'type': 'evaluate', 'principal': 'system',
                           'attempt_id': cmd['attempt_id'], 'registration': reg,
                           'context': ctx, 'envelope': env}, {'system_authorized': True})
        self.assertEqual(result['outcome'], 'APPLIED')
        s = result['state']
        self.assertEqual(s['evaluations'][0]['result']['admission']['admission'], 'REJECTED')
        self.assertEqual(len(s['attempts']), 1)
        self.assertEqual(step(s, {'type': 'exhaust', 'principal': 'system'}, {'system_authorized': True})['state']['status'], 'EXHAUSTED')

    def test_no_unverified_source_promotion(self):
        self.assertEqual(demo()['source_state'], 'UNRESOLVED')

    def test_goal_amend_requires_human_and_keeps_history(self):
        s = goal_state()
        cmd = {'type': 'amend', 'principal': 'user', 'goal_id': 'g1',
               'prior_digest': active_goal(s)['digest'], 'statement': 'Corrected P14',
               'reason': 'Premise mismatch'}
        self.assertEqual(step(s, cmd)['reason'], 'HUMAN_AUTH_REQUIRED')
        changed = step(s, cmd, {'human_authorized': True})['state']
        self.assertEqual(len(changed['goals']), 2)
        self.assertEqual(changed['goals'][0]['statement'], 'Prove P14')
        self.assertEqual(changed['goals'][1]['supersedes'], changed['goals'][0]['digest'])

    def test_unrecordable_abandon_does_not_claim_durable_state(self):
        s = goal_state()
        cmd = {'type': 'abandon', 'principal': 'user', 'reason': 'Stop'}
        r = step(s, cmd, {'human_authorized': True, 'storage_writable': False})
        self.assertEqual((r['outcome'], r['reason']), ('BLOCKED', 'LOCAL_STOP_UNRECORDED'))
        self.assertEqual(r['state'], s)

    def test_stop_cycles_do_not_create_progress(self):
        s = goal_state()
        s = step(s, {'type': 'stop', 'principal': 'user'}, {'human_authorized': True})['state']
        self.assertEqual(classify_continuation(s), 'ESCAPE_ONLY')
        again = step(s, {'type': 'stop', 'principal': 'user'}, {'human_authorized': True})
        self.assertEqual(again['outcome'], 'NOOP')
        self.assertEqual(again['state']['events'], s['events'])

    def test_readability_and_storage_are_not_absence(self):
        s = goal_state()
        self.assertEqual(classify_continuation(s, {'item_readable': False}), 'ESCAPE_ONLY')
        self.assertEqual(classify_continuation(s, {'storage_writable': False}), 'RECOVERY_REQUIRED')

    def test_replay_tamper_detected(self):
        s = goal_state()
        self.assertEqual(replay(s['events']), s)
        events = copy.deepcopy(s['events'])
        events[0]['command']['statement'] = 'tampered'
        self.assertFalse(verify_event_chain(events))
        with self.assertRaises(ValueError):
            replay(events)

    def test_unknown_fields_and_floats_rejected(self):
        s = goal_state()
        cmd = attempt_command(s)
        self.assertEqual(step(s, {**cmd, 'verdict': 'CERTIFIED'})['outcome'], 'REJECTED')
        self.assertEqual(step(s, {**cmd, 'extra': 1.2})['outcome'], 'REJECTED')

    def test_pure_import_boundary_ast(self):
        root = pathlib.Path(__file__).resolve().parents[1] / 'scientific_workspace'
        paths = list((root / 'engine').glob('*.py')) + list((root / 'checkers').glob('*.py'))
        forbidden = ('PySide', 'PyQt', 'sqlite3', 'wiki_core', 'storage', 'agents', 'llm', 'openai')
        for p in paths:
            tree = ast.parse(p.read_text(encoding='utf-8'))
            imports = []
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imports.extend(n.name for n in node.names)
                elif isinstance(node, ast.ImportFrom):
                    imports.append(node.module or '')
            for name in imports:
                self.assertFalse(any(x.lower() in name.lower() for x in forbidden), (p, name))
        # sys.modules is process-global: persistence integration tests may have
        # legitimately imported SQLite earlier in the same test runner. Import
        # isolation is tested in a *fresh interpreter* by test_baseline_and_imports.
        # The AST assertion above verifies this module's own direct imports.


if __name__ == '__main__':
    unittest.main()
