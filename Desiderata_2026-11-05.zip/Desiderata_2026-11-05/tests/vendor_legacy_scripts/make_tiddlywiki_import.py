#!/usr/bin/env python3
"""Produce TiddlyWiki JSON import files for one PERSONAL.WIKI notebook.

    python3 -B make_tiddlywiki_import.py NOTEBOOK.db OUTPUT_DIR LABEL

Writes two files into OUTPUT_DIR:

  LABEL.native.json      exactly what this application's own export_json emits.
                         Tags are a JSON array, matching the shape of
                         demo/STARTER_TIDDLERS.json, so it round-trips here.

  LABEL.tiddlywiki.json  TiddlyWiki-canonical. Tags are the space-separated
                         `[[two words]] single` string that TiddlyWiki itself
                         emits, and every link target that does not resolve
                         inside the notebook gets a stub tiddler.

WHY TWO SHAPES
--------------
TiddlyWiki 5 accepts either form for list-type fields, but a file shaped like
what the target emits is the one least likely to surprise anyone. The native
file stays available because it is the faithful round-trip for this app.

WHY STUBS
---------
A notebook exported on its own loses any reference that pointed outside it. A
dangling `[[Title]]` in TiddlyWiki renders as a missing-tiddler link carrying
no information about where it was supposed to go, and in a `file://` tree a
dead reference is the most tedious thing to diagnose months later. A stub
tiddler is a real target that says what the reference pointed at, which
notebook it lived in, and which posts referred to it -- visible rather than
broken, and reversible once the other notebook is available.

The stub carries `pw-external`, `pw-origin-notebook`, `pw-origin-title` and
`pw-referenced-by`. TiddlyWiki preserves unknown fields, so re-importing the
file reconstructs that information exactly.

This is a standalone tool, not an application feature: doing it properly
belongs with namespaces, where an external reference has a real target to name.
Until then this keeps a single-notebook export honest.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from scientific_workspace.storage.vendor_pw.db import encode_tags                      # noqa: E402
from scientific_workspace.storage.vendor_pw.links import extract_links, split_target   # noqa: E402
from scientific_workspace.storage.vendor_pw.wiki_core import WikiCore                  # noqa: E402

STUB_TAG = '$:/pw/external-reference'

#: A cross-namespace reference gets its own tag so it is filterable in
#: TiddlyWiki and distinguishable from a genuinely missing local post. The two
#: were one category before Phase 2, which meant a stub said "this title lives
#: outside this export" about a target that never claimed to be in it.
CROSS_TAG = '$:/pw/cross-namespace-reference'


def build(db_path: str, out_dir: str | Path, label: str) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    native_path = out / f'{label}.native.json'

    with WikiCore(db_path, readonly=True) as wiki:
        exported = wiki.export_json(native_path, overwrite=True)

    records = json.loads(native_path.read_text(encoding='utf-8'))
    titles = {record['title'] for record in records}

    canonical: list[dict] = []
    # Two categories, not one. A missing local title and a target that names
    # another namespace are different facts and deserve different stubs: the
    # first says a post is absent from this notebook, the second says the
    # reference was never pointing here in the first place.
    missing: dict[str, list[str]] = {}
    cross: dict[str, list[str]] = {}
    for record in records:
        entry = dict(record)
        if isinstance(entry.get('tags'), list):
            entry['tags'] = encode_tags(entry['tags'])
        canonical.append(entry)
        for target in extract_links(record.get('text', '')):
            parsed = split_target(target)
            if parsed is None:
                continue                    # an external URL, not a reference
            namespace, link_title = parsed
            if namespace is not None:
                cross.setdefault(target, []).append(record['title'])
            elif link_title not in titles:
                # The PARSED title, so `[[:notes:x]]` is checked against the
                # post `notes:x`. Checking the raw target stubbed a post that
                # was present all along.
                missing.setdefault(link_title, []).append(record['title'])

    notebook = Path(db_path).stem

    def referenced_by(referrers: list[str]) -> str:
        return ', '.join(f'[[{t}]]' for t in sorted(set(referrers)))

    for target, referrers in sorted(missing.items()):
        canonical.append({
            'title': target,
            'tags': encode_tags([STUB_TAG]),
            'pw-external': 'yes',
            'pw-origin-notebook': notebook,
            'pw-origin-title': target,
            'pw-referenced-by': encode_tags(sorted(set(referrers))),
            'text': (
                "! External reference\n\n"
                f"This post is a ''stub''. In the source notebook `{notebook}` "
                f"the title //{target}// lives outside this export, so the "
                "reference had nowhere to resolve.\n\n"
                "Referenced by: " + referenced_by(referrers) + "\n\n"
                "The stub exists so the reference is visible rather than broken. "
                "Replace or remove it once the referenced notebook is available."
            ),
        })

    for target, referrers in sorted(cross.items()):
        namespace, link_title = split_target(target)
        canonical.append({
            'title': target,
            'tags': encode_tags([CROSS_TAG]),
            'pw-external': 'yes',
            # The namespace the reference NAMES, not the one it was written in.
            # Recording the referring notebook here was the old conflation.
            'pw-origin-namespace': namespace,
            'pw-origin-title': link_title,
            'pw-referenced-by': encode_tags(sorted(set(referrers))),
            'text': (
                "! Cross-namespace reference\n\n"
                f"This post is a ''stub''. The reference //{target}// names the "
                f"namespace `{namespace}` and the post //{link_title}// in it. "
                f"That namespace is not part of this export, which covers "
                f"`{notebook}` only.\n\n"
                "This is ''not'' a missing post: the reference was never "
                "pointing into this notebook. Import the `"
                f"{namespace}` namespace alongside this one to resolve it.\n\n"
                "Referenced by: " + referenced_by(referrers)
            ),
        })

    canonical_path = out / f'{label}.tiddlywiki.json'
    canonical_path.write_text(
        json.dumps(canonical, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    return {'native': str(native_path), 'native_records': exported,
            'tiddlywiki': str(canonical_path), 'tiddlywiki_records': len(canonical),
            # Reported separately, for the same reason they are stubbed
            # separately: one count for both would hide which kind the caller
            # actually has, and `stubs` alone could not say.
            'missing_post_stubs': sorted(missing),
            'cross_namespace_stubs': sorted(cross)}


def main(argv: list[str]) -> int:
    if len(argv) != 4:
        print(__doc__.strip().splitlines()[2].strip())
        return 2
    result = build(argv[1], argv[2], argv[3])
    missing = result['missing_post_stubs']
    cross = result['cross_namespace_stubs']
    print(f"{argv[3]}: native={result['native_records']} "
          f"tiddlywiki={result['tiddlywiki_records']} "
          f"missing_posts={len(missing)} cross_namespace={len(cross)}")
    for title in missing:
        print(f'  missing post      {title}')
    for title in cross:
        print(f'  other namespace   {title}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
