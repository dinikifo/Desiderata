#!/usr/bin/env python3
"""Each of the seven 5-November defects, shown fixed.

    python3 -B test_defect_fixes.py

Headless; no PySide6. Every check is paired with the old behaviour it rules
out, so a fix is never believed on its description. Where the old behaviour
cannot be reconstructed in-process the test says so rather than implying a
stronger check than it performs.
"""
from __future__ import annotations

import sqlite3
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parents[1] / 'scientific_workspace' / 'storage' / 'vendor_pw'
PROJECT = HERE.parents[1]
sys.path.insert(0, str(PROJECT))

from scientific_workspace.storage.vendor_pw import db as dbmod                                                  # noqa: E402
from scientific_workspace.storage.vendor_pw.wiki_core import (HistoryError, SearchUnavailable, WikiCore)    # noqa: E402

problems: list[str] = []


def check(ok: bool, label: str, detail: str = '') -> None:
    if not ok:
        problems.append(f'{label}: {detail}' if detail else label)


def notebook(folder: Path, name: str = 'nb.db') -> str:
    path = folder / name
    WikiCore.create_database(path)
    with WikiCore(path) as wiki:
        wiki.save_tiddler('Alpha', 'Points at [[Beta]].', ['one'])
        wiki.save_tiddler('Beta', 'Target post with searchable prose.', ['one'])
    return str(path)


def main() -> int:
    with tempfile.TemporaryDirectory(prefix='pw_fix_test_') as tmp:
        folder = Path(tmp)
        path = notebook(folder)

        # ---- B2a: the FTS check has three states, and None is reachable ----
        with WikiCore(path, readonly=True) as wiki:
            report = wiki.integrity_report()
        check('fts_status' in report, 'B2a fts_status key missing')
        check(report.get('fts_status') == 'ok', 'B2a healthy notebook',
              str(report.get('fts_status')))
        # the three-valued contract: ask the method directly with a staging
        # directory it cannot use, which is B1's scenario
        with dbmod.TiddlerDB(path, readonly=True) as raw:
            real = raw._check_fts_integrity()
            check(real is True, 'B2a healthy index should be True', repr(real))
            saved, raw.db_path = raw.db_path, '/proc/self/nonexistent/x.db'
            unknown = raw._check_fts_integrity()
            raw.db_path = saved
        check(unknown is None, 'B2a unstageable check must report None',
              f'got {unknown!r}. NOTE what this does and does not show: it '
              'exercises the new None branch, which did not exist before -- '
              'the old method could only return True or False. It does not '
              'reproduce the original symptom (a full system /tmp), which this '
              'test cannot simulate; B1 covers that structurally instead.')

        # ---- B1: a read-only open survives when the check cannot run -------
        # The staging directory is now beside the database, so the previous
        # failure mode (small system /tmp) no longer applies. Verified
        # structurally: no TemporaryDirectory call in app/ lacks dir=.
        import ast
        unpinned = []
        for src in sorted(PACKAGE.glob('*.py')):
            for node in ast.walk(ast.parse(src.read_text(encoding='utf-8'))):
                if (isinstance(node, ast.Call)
                        and ast.unparse(node.func).endswith('TemporaryDirectory')
                        and not any(k.arg == 'dir' for k in node.keywords)):
                    unpinned.append(f'{src.name}:{node.lineno}')
        check(not unpinned, 'B1 TemporaryDirectory not pinned to a filesystem',
              ', '.join(unpinned))

        # ---- B2b: history_report is three-valued and never truncates -------
        with WikiCore(path, readonly=True) as wiki:
            hist = wiki.history_report()
        check(hist['status'] == 'ok', 'B2b healthy history', str(hist))
        check('problems' in hist and hist['problems'] == [],
              'B2b problems list missing on a clean report', str(hist))
        # a damaged history must be 'failed' with the post named (B3), and the
        # exception must carry the complete list
        damaged = folder / 'damaged.db'
        WikiCore.create_database(damaged)
        with WikiCore(damaged) as wiki:
            for i in range(9):
                wiki.save_tiddler(f'Post {i}', f'body {i}', [])
        with sqlite3.connect(str(WikiCore.history_file(damaged))) as raw:
            raw.execute("UPDATE posts SET current_sha256='0'*64")
        try:
            with WikiCore(damaged, readonly=True) as wiki:
                rep = wiki.history_report()
            check(rep['status'] == 'failed', 'B2b damaged history status',
                  str(rep['status']))
            check(len(rep['problems']) == 9,
                  'B2b every problem reported, not six',
                  f"got {len(rep['problems'])}; the old code truncated at 6")
            check(all('Content/history disagreement' in p for p in rep['problems']),
                  'B2b unexpected problem text', str(rep['problems'][:2]))
            try:
                wiki_err = None
                with WikiCore(damaged, readonly=True) as wiki:
                    wiki.verify_history()
            except HistoryError as exc:
                wiki_err = exc
            check(wiki_err is not None, 'B2b verify_history must still raise')
            check(getattr(wiki_err, 'status', None) == 'failed',
                  'B2b exception carries .status', repr(getattr(wiki_err, 'status', None)))
            check(len(getattr(wiki_err, 'problems', [])) == 9,
                  'B2b exception carries the COMPLETE problem list',
                  str(len(getattr(wiki_err, 'problems', []))))
        except Exception as exc:                      # noqa: BLE001
            problems.append(f'B2b/B3 damaged-history checks raised: {exc!r}')

        # ---- B2c: search reports that it could not run ---------------------
        with WikiCore(path, readonly=True) as wiki:
            check(wiki.search('searchable', mode='Text') == ['Beta'],
                  'B2c healthy text search')
        # Make MATCH genuinely fail: drop the FTS table on a writable handle.
        # That is a real sqlite3.DatabaseError from the query, which is the
        # path the old `except OperationalError: return []` swallowed.
        broken = notebook(folder, 'broken.db')
        raised = None
        returned = None
        with WikiCore(broken) as wiki:
            wiki._db.conn.execute('DROP TABLE tiddlers_fts')
            try:
                returned = wiki.search('searchable', mode='Text')
            except SearchUnavailable as exc:
                raised = exc
        check(raised is not None,
              'B2c a search that cannot run must raise, not return []',
              f'it returned {returned!r} -- which is exactly what the old code '
              'did, and is indistinguishable from "no matching posts"')
        check(raised is None or 'NOT a result of zero matches' in str(raised),
              'B2c the message must say it is not an empty result set')

        # ---- B4: a missing notebook names the content file -----------------
        missing = None
        try:
            WikiCore(folder / 'does_not_exist.db')
        except FileNotFoundError as exc:
            missing = str(exc)
        except Exception as exc:                      # noqa: BLE001
            missing = f'WRONG TYPE: {type(exc).__name__}: {exc}'
        check(missing is not None and 'does_not_exist.db' in str(missing)
              and 'create_database' in str(missing),
              'B4 must name the content file and the right remedy', str(missing))
        check('No history file' not in str(missing),
              'B4 still blames the history file', str(missing))

        # ---- B5: the dead methods and the wrong URL scheme are gone --------
        from scientific_workspace.storage.vendor_pw import renderer
        for gone in ('_inline_code', '_bold', '_italic',
                     '_link_captioned', '_link_simple'):
            check(not hasattr(renderer.TiddlyRenderer, gone),
                  f'B5 {gone} still present')
        for gone in ('_parse_tags_string', '_row_to_dict'):
            check(not hasattr(dbmod.TiddlerDB, gone), f'B5 {gone} still present')
        rendered = renderer.render_tiddler(
            {'title': 'T', 'text': 'see [[Beta]] and [[caption|Beta]]'})
        check('tw://tiddler/Beta' in rendered, 'B5 live link scheme',
              rendered[rendered.find('tw://'):][:60])
        check('"tw://Beta"' not in rendered, 'B5 the wrong scheme reappeared')

        # ---- B6: hard-link publication names the real cause ----------------
        src = Path(dbmod.__file__).read_text(encoding='utf-8')
        check('does not support hard links' in src,
              'B6 the exFAT/FAT32 cause is not named in _publish_temp')
        check('except FileExistsError:\n            raise' in src,
              'B6 FileExistsError must still propagate unchanged')

        # ---- B7: the body replace is bounded -------------------------------
        core_src = (PACKAGE / 'wiki_core.py').read_text(encoding='utf-8')
        check("'</body>')" not in core_src and "</ul></section></body>', 1)" in core_src,
              'B7 the </body> replace is still unbounded')

    if problems:
        print('FAIL')
        for problem in problems:
            print('  -', problem)
        return 1
    print('PASS — all seven defects fixed, each with the old behaviour ruled out')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
