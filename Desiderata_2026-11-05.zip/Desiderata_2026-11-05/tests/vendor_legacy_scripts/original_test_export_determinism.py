#!/usr/bin/env python3
"""Determinism contract for the markdown bundle export.

    python3 -B test_export_determinism.py

Headless; no PySide6, no network, no writes outside its own temporary folder.
Four checks:

  1. two exports of an unchanged notebook are BYTE-IDENTICAL, both files;
  2. a one-word edit changes the bundle in a LOCALISED way -- the edited post's
     lines, not the whole document -- which is what makes an export directory
     worth committing to version control;
  3. the recorded bundle digest matches the bundle actually written;
  4. an unresolved link is reported as unresolved and a resolved one is not.

Check 1 is the one that breaks silently. Any generation timestamp, unsorted
iteration or dict-order dependence inside either file defeats it, and nothing
else in the application would notice.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'app'))

from wiki_core import WikiCore  # noqa: E402


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def seed(folder: Path) -> str:
    db = folder / 'notebook.db'
    WikiCore.create_database(db)
    with WikiCore(db) as wiki:
        wiki.save_tiddler('Alpha', 'Points at [[Beta]] and at [[Nowhere]].',
                          ['one', 'two words'])
        # TiddlyWiki order is [[Caption|Target]] -- the SECOND half is the
        # target. Written the other way round this reads as a link to a post
        # called "caption", which is how the first draft of this fixture was
        # wrong and the test correctly said so.
        wiki.save_tiddler('Beta', "Body with ''bold'' and a [[see Alpha|Alpha]] link.", ['one'])
        wiki.save_tiddler('Gamma', 'No links here.', [])
    return str(db)


def failures() -> list[str]:
    problems: list[str] = []
    with tempfile.TemporaryDirectory(prefix='pw_export_test_') as tmp:
        folder = Path(tmp)
        db = seed(folder)

        # --- 1. byte-identical repeat export ------------------------------
        with WikiCore(db, readonly=True) as wiki:
            first = wiki.export_bundle(folder / 'export_a')
        with WikiCore(db, readonly=True) as wiki:
            second = wiki.export_bundle(folder / 'export_b')

        for name in ('BUNDLE.md', 'MANIFEST.json'):
            a, b = folder / 'export_a' / name, folder / 'export_b' / name
            if digest(a) != digest(b):
                problems.append(
                    f'{name} differs between two exports of an unchanged notebook '
                    f'({digest(a)[:12]} vs {digest(b)[:12]}) -- something '
                    'time-varying or unordered is being written inside it')

        # --- 3. recorded digest matches the file --------------------------
        manifest = json.loads((folder / 'export_a' / 'MANIFEST.json').read_text(encoding='utf-8'))
        actual = digest(folder / 'export_a' / 'BUNDLE.md')
        if manifest['bundle']['sha256'] != actual:
            problems.append('MANIFEST.json records a bundle digest that does not '
                            'match BUNDLE.md')
        if first['bundle_sha256'] != actual:
            problems.append('export_bundle() returned a digest that does not match '
                            'the bundle it wrote')

        # --- 4. link classification ---------------------------------------
        rows = {row['title']: row for row in manifest['posts']}
        if rows['Alpha']['broken_links'] != ['Nowhere']:
            problems.append(f"Alpha's unresolved link was not reported: "
                            f"{rows['Alpha']['broken_links']}")
        if 'Beta' not in rows['Alpha']['links']:
            problems.append("Alpha's resolved link to Beta was not recorded")
        if rows['Gamma']['links'] or rows['Gamma']['broken_links']:
            problems.append('Gamma has no links but some were reported')
        if rows['Beta']['broken_links']:
            problems.append("Beta's captioned link was misread as unresolved: "
                            f"{rows['Beta']['broken_links']}")

        # --- 2. a one-word edit stays local -------------------------------
        with WikiCore(db) as wiki:
            wiki.save_tiddler('Gamma', 'No links here, revised.', [],
                              reason='Determinism test: localised-diff check')
        with WikiCore(db, readonly=True) as wiki:
            wiki.export_bundle(folder / 'export_c')

        diff = subprocess.run(
            ['diff', '-u', str(folder / 'export_a' / 'BUNDLE.md'),
             str(folder / 'export_c' / 'BUNDLE.md')],
            capture_output=True, text=True)
        changed = [line for line in diff.stdout.splitlines()
                   if line[:1] in '+-' and not line.startswith(('+++', '---'))]
        # Expected: Gamma's body line, its sha256 metadata line, its modified
        # stamp, and the source digest in the header. Generous ceiling; the
        # point is that it is not the whole document.
        if len(changed) > 12:
            problems.append(f'a one-word edit changed {len(changed)} bundle lines; '
                            'the export is not diff-friendly')
        if 'No links here, revised.' not in diff.stdout:
            problems.append('the edited text does not appear in the diff')
    return problems


def main() -> int:
    problems = failures()
    if problems:
        print('FAIL')
        for problem in problems:
            print('  -', problem)
        return 1
    print('PASS — export is byte-deterministic, digests agree, links classify, '
          'and a one-word edit produces a local diff')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
