#!/usr/bin/env python3
"""Phase 2: link parsing and cross-namespace resolution, under control.

    python3 -B test_resolver.py

Headless; no PySide6. Every check is paired with the behaviour it rules out.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parents[1] / 'scientific_workspace' / 'storage' / 'vendor_pw'
PROJECT = HERE.parents[1]
sys.path.insert(0, str(PROJECT))

from scientific_workspace.storage.vendor_pw.links import extract_links, split_target                  # noqa: E402
from scientific_workspace.storage.vendor_pw.resolver import (EXTERNAL, NAMESPACE_UNAVAILABLE,         # noqa: E402
                      NO_SUCH_NAMESPACE, NO_SUCH_POST, RESOLVED, STATES,
                      Resolution, Resolver)
from scientific_workspace.storage.vendor_pw.wiki_core import WikiCore                                 # noqa: E402
from scientific_workspace.storage.vendor_pw.workspace import NOTEBOOK_NAME, Workspace                 # noqa: E402

problems: list[str] = []


def check(ok: bool, label: str, detail: str = '') -> None:
    if not ok:
        problems.append(f'{label}: {detail}' if detail else label)


# ------------------------------------------------------------ R1 parsing --
def test_parsing() -> None:
    cases = [
        # target                      namespace   title
        ('Alpha',                     None,       'Alpha'),
        ('monograph:Alpha',           'monograph', 'Alpha'),
        ('notes_2:Alpha',             'notes_2',  'Alpha'),
        # Only the FIRST colon splits.
        ('monograph:Chapter 1: Intro', 'monograph', 'Chapter 1: Intro'),
        # An uppercase head is not a valid namespace name, so an ordinary
        # English title with a colon stays local.
        ('Chapter 1: Introduction',   None,       'Chapter 1: Introduction'),
        ('Alpha:Beta',                None,       'Alpha:Beta'),
        # A space after the colon keeps it local even with a lowercase head.
        ('notes: see also',           None,       'notes: see also'),
        # Nothing after the colon: not a prefix.
        ('notes:',                    None,       'notes:'),
        # The leading-colon escape forces a local reading.
        (':notes:something',          None,       'notes:something'),
        (':Alpha',                    None,       'Alpha'),
        # A reserved name is not a namespace prefix, so this is a local title.
        ('file:report.pdf',           None,       'file:report.pdf'),
        ('tw:thing',                  None,       'tw:thing'),
    ]
    for target, expect_ns, expect_title in cases:
        got = split_target(target)
        check(got == (expect_ns, expect_title),
              f'R1 split_target({target!r})',
              f'expected {(expect_ns, expect_title)!r}, got {got!r}')

    for url in ('http://example.com', 'https://example.com/x', 'mailto:a@b.c'):
        check(split_target(url) is None,
              f'R1 {url!r} must parse as external, not as a post',
              str(split_target(url)))

    # Whichever way a target is spelled, the parse does not depend on what
    # exists anywhere. This is the §3.2 rule in its purest form.
    check(split_target('notes:x') == ('notes', 'x'),
          'R1 a valid prefix parses as a namespace reference regardless of '
          'whether that namespace exists')


# -------------------------------------------------------- R2-R5 the states --
def test_states(root: Path) -> None:
    workspace = Workspace.create(root)
    workspace.create_namespace('alpha')
    workspace.create_namespace('beta')
    workspace.create_namespace('halfpair')
    workspace.create_namespace('wrecked')

    with workspace.open('alpha') as wiki:
        wiki.save_tiddler('Home', 'see [[Local]] and [[beta:Far]]', [])
        wiki.save_tiddler('Local', 'here', [])
        wiki.save_tiddler('notes:something', 'a title with a colon in it', [])
    with workspace.open('beta') as wiki:
        wiki.save_tiddler('Far', 'over here', [])

    # Two distinct routes to NAMESPACE_UNAVAILABLE.
    WikiCore.history_file(root / 'halfpair' / NOTEBOOK_NAME).unlink()   # disk
    (root / 'wrecked' / NOTEBOOK_NAME).write_bytes(b'not a database')   # open

    with Resolver(workspace) as resolver:
        def state_of(target, source='alpha'):
            return resolver.resolve(target, source)

        # RESOLVED, local and cross-namespace.
        check(state_of('Local').state == RESOLVED, 'R2 local hit',
              str(state_of('Local')))
        far = state_of('beta:Far')
        check(far.state == RESOLVED and far.namespace == 'beta'
              and far.title == 'Far', 'R2 cross-namespace hit', str(far))

        # NO_SUCH_POST keeps the namespace it searched.
        miss = state_of('Nowhere')
        check(miss.state == NO_SUCH_POST and miss.namespace == 'alpha',
              'R2 local miss must name the namespace it searched', str(miss))
        far_miss = state_of('beta:Nowhere')
        check(far_miss.state == NO_SUCH_POST and far_miss.namespace == 'beta',
              'R2 cross-namespace miss', str(far_miss))

        # NO_SUCH_NAMESPACE -- the link is what needs fixing.
        absent = state_of('ghost:Thing')
        check(absent.state == NO_SUCH_NAMESPACE, 'R2 unknown namespace',
              str(absent))
        check('link is what needs changing' in (absent.detail or ''),
              'R3 the advice must point at the LINK', str(absent.detail))

        # NAMESPACE_UNAVAILABLE by disk state, and by failure to open.
        half = state_of('halfpair:Thing')
        check(half.state == NAMESPACE_UNAVAILABLE,
              'R3 an incomplete pair is UNAVAILABLE, not absent',
              f'got {half.state} -- telling the user no such namespace exists '
              'would send them to edit a correct link while a damaged '
              'notebook sits there')
        check('incomplete' in (half.detail or ''),
              'R3 the disk state must be named', str(half.detail))
        wrecked = state_of('wrecked:Thing')
        check(wrecked.state == NAMESPACE_UNAVAILABLE,
              'R3 a notebook that will not open is UNAVAILABLE', str(wrecked))
        check('notebook is what needs attention' in (half.detail or '')
              or 'nothing about whether the post exists' in (wrecked.detail or ''),
              'R3 the advice must point at the NOTEBOOK',
              f'{half.detail!r} / {wrecked.detail!r}')

        # The two states must be genuinely different, not two spellings.
        check(absent.state != half.state,
              'R3 NO_SUCH_NAMESPACE and NAMESPACE_UNAVAILABLE must differ',
              'these carry opposite advice; one word for both is a false '
              'answer in one of the two cases')

        # EXTERNAL.
        ext = state_of('https://example.com')
        check(ext.state == EXTERNAL, 'R2 an external URL', str(ext))

        # R4 -- the lexical rule, demonstrated against a real collision.
        # A post is literally titled `notes:something`. The prefixed form must
        # NOT find it, and the escaped form must.
        prefixed = state_of('notes:something')
        escaped = state_of(':notes:something')
        check(prefixed.state == NO_SUCH_NAMESPACE,
              'R4 a prefixed target must be read as a namespace reference '
              'even when a local post has that exact title', str(prefixed))
        check(escaped.state == RESOLVED and escaped.title == 'notes:something',
              'R4 the escape must reach the local post', str(escaped))

        # R5 -- every state in STATES was exercised above.
        seen = {state_of(t).state for t in
                ('Local', 'Nowhere', 'ghost:X', 'halfpair:X',
                 'https://example.com')}
        check(seen == set(STATES), 'R5 every declared state must be reachable',
              f'reached {sorted(seen)}, declared {sorted(STATES)}')

        # A malformed source namespace is a programming error, not an outcome.
        raised = None
        try:
            resolver.resolve('Local', 'Not A Namespace')
        except ValueError as exc:
            raised = exc
        check(raised is not None,
              'R5 a malformed from_namespace must raise, not resolve',
              'reporting it as a resolution state would hide a caller bug')

        # resolve_post distinguishes "unreadable post" from "no links".
        raised = None
        try:
            resolver.resolve_post('alpha', 'Nonexistent')
        except LookupError as exc:
            raised = exc
        check(raised is not None,
              'R5 resolve_post must raise for a missing post',
              'returning [] would be indistinguishable from a post that has '
              'no links')

        body = resolver.resolve_post('alpha', 'Home')
        check([r.state for r in body] == [RESOLVED, RESOLVED],
              'R5 resolve_post resolves a real body', str(body))


# ------------------------------------------------------------ R6 snapshot --
def test_snapshot(root: Path) -> None:
    workspace = Workspace.create(root)
    workspace.create_namespace('alpha')
    with workspace.open('alpha') as wiki:
        wiki.save_tiddler('Home', 'x', [])

    with Resolver(workspace) as resolver:
        before = resolver.resolve('late:Thing', 'alpha')
        check(before.state == NO_SUCH_NAMESPACE, 'R6 baseline', str(before))

        workspace.create_namespace('late')
        with workspace.open('late') as wiki:
            wiki.save_tiddler('Thing', 'arrived', [])

        after = resolver.resolve('late:Thing', 'alpha')
        check(after.state == NO_SUCH_NAMESPACE,
              'R6 a namespace created mid-pass must stay invisible',
              f'got {after.state} -- a report built from a shifting view is '
              'not a report; two links to one namespace could disagree')

    with Resolver(workspace) as fresh:
        check(fresh.resolve('late:Thing', 'alpha').state == RESOLVED,
              'R6 a NEW resolver must see it',
              'the snapshot must be per-resolver, not permanent')

    # A notebook that opened cleanly and then broke: the query fails, not the
    # open. Found by this test raising sqlite3.DatabaseError out of resolve(),
    # which made resolve() non-total -- a bulk scan would have aborted on the
    # first damaged namespace rather than recording it.
    workspace.create_namespace('broken')
    with Resolver(workspace) as resolver:
        first = resolver.resolve('broken:X', 'alpha')
        check(first.state == NO_SUCH_POST, 'R6 healthy before damage',
              str(first))
        (root / 'broken' / NOTEBOOK_NAME).write_bytes(b'garbage')

        second = resolver.resolve('broken:Y', 'alpha')
        check(second.state == NAMESPACE_UNAVAILABLE,
              'R6 a query failure must be a STATE, not an exception',
              f'got {second.state} -- a raw sqlite3 error escaping resolve() '
              'kills any bulk scan on the first damaged namespace')
        check('could not be queried' in (second.detail or ''),
              'R6 the detail must distinguish a failed query from a failed open',
              str(second.detail))

        # And the verdict is stable for the rest of the pass, which is the
        # invariant the docstring claims.
        third = resolver.resolve('broken:Z', 'alpha')
        check(third.state == NAMESPACE_UNAVAILABLE,
              'R6 one verdict per namespace per pass',
              f'got {third.state} -- a verdict that alternates between calls '
              'makes a report self-contradictory')

        # A healthy namespace is unaffected by its neighbour dying.
        check(resolver.resolve('Home', 'alpha').state == RESOLVED,
              'R6 one damaged namespace must not poison the others')


# ------------------------------------------- R7 the exporter obligation (§5) --
def test_exporter_classifies_cross_namespace(root: Path) -> None:
    workspace = Workspace.create(root)
    workspace.create_namespace('alpha')
    with workspace.open('alpha') as wiki:
        wiki.save_tiddler('Alpha',
                          'local [[Beta]], cross [[monograph:Gamma]], '
                          'missing [[Nowhere]], url [[https://example.com]]',
                          [])
        wiki.save_tiddler('Beta', 'target', [])

    out = root / 'export-1'
    with workspace.open('alpha', readonly=True) as wiki:
        summary = wiki.export_bundle(out)
    manifest = json.loads((out / 'MANIFEST.json').read_text(encoding='utf-8'))
    row = next(p for p in manifest['posts'] if p['title'] == 'Alpha')

    check(row['links'] == ['Beta'], 'R7 local resolved', str(row['links']))
    check(row['external_links'] == ['monograph:Gamma'],
          'R7 a cross-namespace target must be classified external',
          str(row.get('external_links')))
    check(row['broken_links'] == ['Nowhere'],
          'R7 a cross-namespace target must NOT be counted as broken',
          f"got {row['broken_links']} -- before this fix every "
          '[[other:Post]] was reported as an unresolved reference, which was '
          'correct for one notebook and became wrong once namespaces existed')
    check(manifest['totals']['unresolved_links'] == 1
          and manifest['totals']['cross_namespace_links'] == 1,
          'R7 the totals must separate the two', str(manifest['totals']))
    check(manifest['export_format'] == 'pw-markdown-bundle/2',
          'R7 the format identifier must be bumped',
          str(manifest['export_format']))

    bundle = (out / 'BUNDLE.md').read_text(encoding='utf-8')
    check('Unresolved references (1)' in bundle,
          'R7 the unresolved section must count only real misses')
    check('Cross-namespace references (1)' in bundle,
          'R7 cross-namespace targets need their own section')
    check('not unresolved references' in bundle,
          'R7 the bundle must say what the section is not')

    # Determinism survives the new field: still a pure function of ONE
    # notebook, because classification never consulted another one.
    out2 = root / 'export-2'
    with workspace.open('alpha', readonly=True) as wiki:
        wiki.export_bundle(out2)
    for name in ('BUNDLE.md', 'MANIFEST.json'):
        check((out / name).read_bytes() == (out2 / name).read_bytes(),
              f'R7 {name} must still be byte-identical across exports',
              'lexical classification is what preserves this; resolving '
              'cross-namespace targets here would have broken it')

    # And it does not change when the referenced namespace appears.
    workspace.create_namespace('monograph')
    with workspace.open('monograph') as wiki:
        wiki.save_tiddler('Gamma', 'now it exists', [])
    out3 = root / 'export-3'
    with workspace.open('alpha', readonly=True) as wiki:
        wiki.export_bundle(out3)
    check((out / 'BUNDLE.md').read_bytes() == (out3 / 'BUNDLE.md').read_bytes(),
          'R7 the bundle must not change when a neighbour notebook changes',
          'this is the determinism claim that matters: the export is a '
          'function of this notebook alone')


# --------------------------------- R8 the renderer agrees with the parser --
def test_renderer_agrees(root: Path) -> None:
    """Found by the recheck pass: the renderer had its own idea of a target.

    It built hrefs from the raw target text, so Phase 2's syntax left it
    disagreeing with links.split_target — including one case that was not a
    gap but a wrong link.
    """
    from scientific_workspace.storage.vendor_pw.renderer import render_tiddler

    def href_of(target: str, caption: str | None = None) -> str:
        body = f'[[{caption}|{target}]]' if caption else f'[[{target}]]'
        out = render_tiddler({'title': 'T', 'text': body})
        marker = 'tw://tiddler/'
        if marker not in out:
            return ''
        return out[out.find(marker) + len(marker):].split('"')[0]

    check(href_of('Beta') == 'Beta', 'R8 a plain local link is unchanged',
          href_of('Beta'))
    check(href_of('Beta', 'see this') == 'Beta',
          'R8 the captioned form must produce the same href as the plain one',
          href_of('Beta', 'see this'))

    # The wrong link, not merely a gap: the escape colon was baked into the href.
    check(href_of(':notes:x') == 'notes%3Ax',
          'R8 the leading-colon escape must reach the PARSED title',
          f"got {href_of(':notes:x')!r} -- '%3Anotes%3Ax' points at a post "
          "titled ':notes:x', so the escape was silently not honoured and the "
          'link went nowhere real')

    # A cross-namespace target must not masquerade as a local link.
    for target in ('monograph:Gamma', 'beta:Far'):
        check(href_of(target) == '',
              'R8 a cross-namespace target must not render a local href',
              f'got tw://tiddler/{href_of(target)} -- that is a link to a '
              f'local post titled {target!r}, which lands the reader on a '
              'missing-post page and blames the wrong thing')
    rendered = render_tiddler({'title': 'T', 'text': '[[monograph:Gamma]]'})
    check('class="xref"' in rendered,
          'R8 it must be marked rather than silently dropped', rendered[-200:])
    captioned = render_tiddler(
        {'title': 'T', 'text': '[[the other one|monograph:Gamma]]'})
    check('class="xref"' in captioned and 'the other one' in captioned,
          'R8 the captioned cross-namespace form keeps its caption', captioned[-200:])

    # An external URL in the captioned form used to become tw://tiddler/https%3A...
    ext = render_tiddler({'title': 'T', 'text': '[[a site|https://example.com]]'})
    check('href="https://example.com"' in ext and 'tw://' not in ext,
          'R8 a captioned external URL must be an external link',
          ext[-200:])

    # The agreement itself, asserted directly rather than case by case.
    for target in ('Beta', ':notes:x', 'monograph:Gamma', 'Chapter 1: Intro',
                   'notes: see also', 'file:report.pdf'):
        parsed = split_target(target)
        namespace = parsed[0] if parsed else None
        has_local_href = href_of(target) != ''
        check(has_local_href == (parsed is not None and namespace is None),
              f'R8 renderer and parser must agree on {target!r}',
              f'parser={parsed!r}, local href={has_local_href}')


# ------------------------------- R9 the importer separates the two stubs --
def test_importer_separates_stub_kinds(root: Path) -> None:
    import make_tiddlywiki_import as importer

    root.mkdir(parents=True, exist_ok=True)
    notebook = root / 'nb.db'
    WikiCore.create_database(notebook)
    with WikiCore(notebook) as wiki:
        wiki.save_tiddler('notes:x', 'a real post whose title has a colon', [])
        wiki.save_tiddler('Home',
                          'missing [[Nowhere]], cross [[monograph:Gamma]], '
                          'escaped [[:notes:x]]', [])

    importer.build(str(notebook), root / 'out', 'nb')
    records = json.loads((root / 'out' / 'nb.tiddlywiki.json')
                         .read_text(encoding='utf-8'))
    by_title = {r['title']: r for r in records}

    check('Nowhere' in by_title
          and importer.STUB_TAG in by_title['Nowhere']['tags'],
          'R9 a missing local title still gets the missing-post stub',
          str(sorted(by_title)))

    cross = by_title.get('monograph:Gamma')
    check(cross is not None, 'R9 a cross-namespace target needs a stub',
          str(sorted(by_title)))
    check(cross is None or importer.CROSS_TAG in cross['tags'],
          'R9 it must carry its own tag, not the missing-post one',
          str(cross and cross['tags']))
    check(cross is None or cross.get('pw-origin-namespace') == 'monograph',
          'R9 the stub must name the namespace the reference POINTS AT',
          f"got {cross and cross.get('pw-origin-namespace')!r} -- recording "
          'the referring notebook here was the old conflation')
    check(cross is None or cross.get('pw-origin-title') == 'Gamma',
          'R9 and the title within that namespace',
          str(cross and cross.get('pw-origin-title')))
    check(cross is None or 'not'' a missing post' in cross['text']
          or 'not a missing post' in cross['text'].replace("''", ''),
          'R9 the stub text must deny being a missing post',
          str(cross and cross['text'][:160]))

    check(':notes:x' not in by_title,
          'R9 an escaped reference to an EXISTING post must not be stubbed',
          'the old code compared the raw target against the title set, so '
          '`[[:notes:x]]` was stubbed as missing while `notes:x` was present')

    # R9b -- the COMMAND-LINE path, not just build(). Calling build() directly
    # left `main()` untested, and it still referenced the old single `stubs`
    # key: the library worked while the script a user actually runs raised
    # KeyError. An entry point needs exercising as an entry point.
    import subprocess
    result = subprocess.run(
        [sys.executable, '-B', str(HERE / 'make_tiddlywiki_import.py'),
         str(notebook), str(root / 'cli_out'), 'nb'],
        capture_output=True, text=True,
        env={'PYTHONDONTWRITEBYTECODE': '1', 'PATH': '/usr/bin:/bin'})
    check(result.returncode == 0,
          'R9b the CLI entry point must run',
          f'exit={result.returncode}; stderr={result.stderr.strip()[-300:]}')
    check('missing_posts=1' in result.stdout and 'cross_namespace=1' in result.stdout,
          'R9b the CLI must report the two kinds separately',
          f'stdout={result.stdout.strip()!r}')


def main() -> int:
    test_parsing()
    for name, fn in (('states', test_states),
                     ('snapshot', test_snapshot),
                     ('exporter', test_exporter_classifies_cross_namespace),
                     ('renderer', test_renderer_agrees),
                     ('importer', test_importer_separates_stub_kinds)):
        with tempfile.TemporaryDirectory(prefix=f'pw_res_{name}_') as tmp:
            try:
                fn(Path(tmp) / 'WORKSPACE')
            except Exception as exc:                            # noqa: BLE001
                import traceback
                problems.append(f'{name} suite raised: {exc!r}\n'
                                + traceback.format_exc())

    if problems:
        print('FAIL')
        for problem in problems:
            print('  -', problem)
        return 1
    print('PASS — resolver: 5 states all reachable, lexical rule enforced, '
          'export still a function of one notebook')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
