#!/usr/bin/env python3
"""Phase 1 of the namespace roadmap: the workspace layer, under control.

    python3 -B test_workspace.py

Headless; no PySide6. Every check is paired with the behaviour it rules out, so
a contract is never believed on its description. Where a claim cannot be
demonstrated in-process the test says so instead of implying a stronger check
than it performs.
"""
from __future__ import annotations

import json
import sqlite3
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'app'))

from wiki_core import WikiCore                                     # noqa: E402
from workspace import (NOTEBOOK_NAME, REGISTRY_NAME,               # noqa: E402
                       RegistryUnwritable, WORKSPACE_FORMAT,
                       Workspace, WorkspaceError, name_problem)

problems: list[str] = []


def check(ok: bool, label: str, detail: str = '') -> None:
    if not ok:
        problems.append(f'{label}: {detail}' if detail else label)


def row_for(report: dict, name: str) -> dict | None:
    for row in report['namespaces']:
        if row['name'] == name:
            return row
    return None


def refuses(fn, exc_type, label: str) -> Exception | None:
    try:
        fn()
    except exc_type as exc:
        return exc
    except Exception as exc:                                    # noqa: BLE001
        problems.append(f'{label}: wrong exception type '
                        f'{type(exc).__name__}: {exc}')
        return None
    problems.append(f'{label}: it did not refuse at all')
    return None


# ---------------------------------------------------------------- C4 names --
def test_names() -> None:
    cases = [
        ('', 'cannot be empty'),
        ('a' * 64, 'at most 63'),
        ('Alpha', 'lowercase'),
        ('_leading', 'lowercase'),
        ('has space', 'lowercase'),
        ('has/slash', 'lowercase'),
        ('has:colon', 'lowercase'),
        ('..', 'lowercase'),
        ('file', 'reserved'),
        ('http', 'reserved'),
        ('mailto', 'reserved'),
        ('tw', 'reserved'),
        ('con', 'reserved device'),
        ('lpt3', 'reserved device'),
    ]
    for name, expected in cases:
        problem = name_problem(name)
        check(problem is not None, f'C4 {name!r} should be rejected')
        check(problem is None or expected in problem,
              f'C4 {name!r} rejected for the wrong reason',
              f'expected {expected!r} in {problem!r}')
    for name in ('a', 'ok-name_1', 'x9', 'a' * 63):
        check(name_problem(name) is None, f'C4 {name!r} should be accepted',
              str(name_problem(name)))

    # The all-lowercase rule is what makes a case-insensitive folder collision
    # UNREPRESENTABLE rather than merely detected: two valid names cannot
    # differ by case alone. The roadmap listed a separate case-collision check;
    # it is subsumed by the charset rule, and this is the evidence.
    check(name_problem('alpha') is None and name_problem('Alpha') is not None,
          'C4 case collision is not prevented by the charset rule',
          'if both cases were legal, `alpha` and `Alpha` could collide on a '
          'case-insensitive filesystem and a collision check would be needed')


# ------------------------------------------------- C1/C2/C3/C9 disk states --
def test_disk_states(root: Path) -> None:
    workspace = Workspace.create(root)
    workspace.create_namespace('alpha', description='first')
    workspace.create_namespace('beta')

    # A notebook that works: the pair is real, not just two filenames.
    with workspace.open('alpha') as wiki:
        wiki.save_tiddler('Hello', 'Points at [[World]].', ['greeting'])
    with workspace.open('alpha', readonly=True) as wiki:
        got = wiki.get_tiddler('Hello')
    check(got is not None and got['text'] == 'Points at [[World]].',
          'C0 a created namespace must hold a working notebook', str(got))

    # C1 -- registered, folder gone. The registry still names it.
    (root / 'beta' / NOTEBOOK_NAME).unlink()
    WikiCore.history_file(root / 'beta' / NOTEBOOK_NAME).unlink()
    (root / 'beta').rmdir()
    report = workspace.report()
    beta = row_for(report, 'beta')
    check(beta is not None, 'C1 a registered namespace whose folder is gone '
          'must still be reported, not dropped')
    check(beta is None or (beta['disk'] == 'absent'
                           and beta['registry'] == 'registered'),
          'C1 missing namespace must read absent+registered',
          str(beta))
    check('beta' not in workspace.namespaces(),
          'C1 an absent namespace must not be offered as usable')

    # C2 -- on disk, not in the registry. Discovered anyway.
    workspace_b = Workspace(root)
    (root / 'gamma').mkdir()
    WikiCore.create_database(root / 'gamma' / NOTEBOOK_NAME)
    report = workspace_b.report()
    gamma = row_for(report, 'gamma')
    check(gamma is not None and gamma['disk'] == 'complete'
          and gamma['registry'] == 'unregistered',
          'C2 an unregistered folder must be discovered from disk',
          str(gamma))
    check('gamma' in workspace_b.namespaces(),
          'C2 an unregistered but complete namespace is usable',
          'the registry is metadata, not the authority on existence')

    # C3 -- content DB present, history sidecar gone: incomplete, not usable.
    (root / 'delta').mkdir()
    WikiCore.create_database(root / 'delta' / NOTEBOOK_NAME)
    WikiCore.history_file(root / 'delta' / NOTEBOOK_NAME).unlink()
    report = workspace_b.report()
    delta = row_for(report, 'delta')
    check(delta is not None and delta['disk'] == 'incomplete',
          'C3 half a pair must read incomplete, not complete', str(delta))
    check('delta' not in workspace_b.namespaces(),
          'C3 an incomplete pair must not be offered as usable',
          'returning it would hand a caller a notebook that cannot open')

    # C9 -- verify=False must say 'not_checked', never 'ok'.
    alpha = row_for(workspace_b.report(), 'alpha')
    check(alpha is not None and alpha['opens'] == 'not_checked',
          "C9 an unrun check must report 'not_checked'",
          f"got {alpha and alpha['opens']!r} -- reporting 'ok' here would be "
          'a claim about a notebook nobody opened')
    alpha = row_for(workspace_b.report(verify=True), 'alpha')
    check(alpha is not None and alpha['opens'] == 'ok',
          'C9 verify=True must actually open a healthy notebook', str(alpha))

    # The two fields are orthogonal, which is the point of having two.
    pairs = {(r['disk'], r['registry']) for r in workspace_b.report()['namespaces']}
    check(('absent', 'registered') in pairs and ('complete', 'unregistered') in pairs,
          'C1/C2 disk and registry must be independently observable',
          f'observed {sorted(pairs)} -- a single status enum could not '
          'represent both of these at once')


# -------------------------------------------------- C5/C6/C7 the registry --
def test_registry(root: Path) -> None:
    workspace = Workspace.create(root)
    workspace.create_namespace('alpha')

    # C5 -- corrupt registry: data stays reachable, problem stays visible.
    registry = root / REGISTRY_NAME
    registry.write_text('{this is not json', encoding='utf-8')
    corrupt_bytes = registry.read_bytes()
    report = workspace.report()
    check(report['registry_status'] == 'unreadable',
          'C5 a corrupt registry must be reported as unreadable',
          str(report['registry_status']))
    check(report['registry_error'],
          'C5 the parse error must be carried, not discarded')
    check('alpha' in workspace.namespaces(),
          'C5 a corrupt registry must not hide the notebooks',
          'they are discovered from disk; losing metadata must not cost data')

    # C6 -- and a write must not destroy the file it could not read.
    refuses(lambda: workspace.create_namespace('epsilon'),
            RegistryUnwritable, 'C6 create_namespace with a corrupt registry')
    refuses(lambda: workspace.set_description('alpha', 'x'),
            RegistryUnwritable, 'C6 set_description with a corrupt registry')
    check(registry.read_bytes() == corrupt_bytes,
          'C6 the refused write must leave the registry BYTE-IDENTICAL',
          'this is the check that matters: raising while having already '
          'truncated the file would lose its contents anyway')
    check(not (root / 'epsilon').exists(),
          'C6 a refused create must not leave a folder behind')

    # C7 -- a future format is refused distinctly from a corrupt one.
    registry.write_text(json.dumps({'format': 'pw-workspace/2',
                                    'namespaces': {'alpha': {}}}),
                        encoding='utf-8')
    report = workspace.report()
    check(report['registry_status'] == 'unsupported_format',
          "C7 a newer format must read 'unsupported_format'",
          f"got {report['registry_status']!r} -- collapsing it into "
          "'unreadable' would send the user to repair JSON that is fine")
    check('pw-workspace/2' in (report['registry_error'] or ''),
          'C7 the error must name the version found', str(report['registry_error']))
    check('alpha' in workspace.namespaces(),
          'C7 a future registry must not hide the notebooks either')

    # Recovery: a valid registry is accepted again, and writes resume.
    registry.write_text(json.dumps({'format': WORKSPACE_FORMAT,
                                    'namespaces': {}}), encoding='utf-8')
    check(workspace.report()['registry_status'] == 'ok',
          'C7 a repaired registry must be accepted')
    workspace.create_namespace('zeta')
    check('zeta' in workspace.namespaces(),
          'C7 writes must resume once the registry is readable')

    # Workspace.create must not replace an existing registry.
    refuses(lambda: Workspace.create(root), WorkspaceError,
            'create() over an existing registry')
    check(workspace.report()['registry_status'] == 'ok',
          'create() refusal must leave the registry intact')


# ------------------------------------------------------ C8 one bad notebook --
def test_damaged_namespace_is_isolated(root: Path) -> None:
    workspace = Workspace.create(root)
    workspace.create_namespace('healthy')
    workspace.create_namespace('damaged')
    with workspace.open('healthy') as wiki:
        wiki.save_tiddler('Alpha', 'body', [])

    # Make the content database genuinely unopenable.
    (root / 'damaged' / NOTEBOOK_NAME).write_bytes(b'not a database at all')

    report = workspace.report(verify=True)
    bad = row_for(report, 'damaged')
    good = row_for(report, 'healthy')
    check(bad is not None and bad['opens'] == 'failed',
          'C8 a damaged notebook must be reported as failing to open', str(bad))
    check(bad is not None and bad['open_error'],
          'C8 the open error must be carried for the user to act on')
    check(bad is not None and bad['disk'] == 'complete',
          'C8 disk and opens are different questions',
          f"disk={bad and bad['disk']!r} -- the files ARE there; it is the "
          'contents that are wrong, and one field cannot say both')
    check(good is not None and good['opens'] == 'ok',
          'C8 one damaged namespace must not take the others down',
          str(good))

    # Opening the damaged one raises; opening a healthy one still works.
    raised = None
    try:
        workspace.open('damaged', readonly=True)
    except Exception as exc:                                    # noqa: BLE001
        raised = exc
    check(raised is not None, 'C8 opening a damaged notebook must raise')
    with workspace.open('healthy', readonly=True) as wiki:
        check(wiki.get_tiddler('Alpha') is not None,
              'C8 the healthy namespace must still be readable afterwards')


# --------------------------------------------------------------- defaults --
def test_defaults_and_refusals(root: Path) -> None:
    workspace = Workspace.create(root)
    workspace.create_namespace('first')
    workspace.create_namespace('second')
    check(workspace.report()['default_namespace'] == 'first',
          'the first namespace created becomes the default',
          'a create needs a namespace, so one must always be nominated')

    workspace.set_default_namespace('second')
    check(workspace.report()['default_namespace'] == 'second',
          'the default must be changeable')

    refuses(lambda: workspace.set_default_namespace('nonexistent'),
            WorkspaceError, 'default pointing at a missing namespace')
    check(workspace.report()['default_namespace'] == 'second',
          'a refused default change must leave the old one in place')

    refuses(lambda: workspace.create_namespace('first'), WorkspaceError,
            'create_namespace over an existing namespace')
    refuses(lambda: workspace.create_namespace('Bad Name'), WorkspaceError,
            'create_namespace with an invalid name')
    check(not (root / 'Bad Name').exists(),
          'an invalid name must not create a folder',
          'validation has to happen before any filesystem effect')
    refuses(lambda: workspace.open('file'), WorkspaceError,
            'open() with a reserved name')

    # A description round-trips, and is the only thing the registry adds.
    workspace.set_description('second', 'the other one')
    row = row_for(workspace.report(), 'second')
    check(row is not None and row['description'] == 'the other one',
          'a description must round-trip through the registry', str(row))

    # The registry is deterministic and diffable.
    before = (root / REGISTRY_NAME).read_bytes()
    workspace.set_description('second', 'the other one')
    check((root / REGISTRY_NAME).read_bytes() == before,
          'rewriting the same metadata must be byte-identical',
          'a non-deterministic registry would churn in version control')


# ------------------------------------------------- C10/C11 recheck findings --
def test_recheck_findings(root: Path) -> None:
    """Two defects found by re-reading the code after the suite first passed.

    Neither was caught by controls C1-C9, which is the reason the recheck pass
    exists as a separate step rather than being folded into writing the tests.
    """
    workspace = Workspace.create(root)
    workspace.create_namespace('real')

    # C10 -- a plain FILE where a namespace folder would go.
    (root / 'blocked').write_text('I am not a folder', encoding='utf-8')
    row = row_for(workspace.report(), 'blocked')
    check(row is not None,
          'C10 a file occupying a namespace name must be REPORTED',
          "the first draft returned [] here: the report said nothing was "
          "there while a file plainly was")
    check(row is None or row['disk'] == 'not_a_directory',
          'C10 it must read not_a_directory, never absent', str(row))
    check('blocked' not in workspace.namespaces(),
          'C10 an obstructed name is not a usable namespace')
    exc = refuses(lambda: workspace.create_namespace('blocked'),
                  WorkspaceError, 'C10 create over a file')
    check(exc is None or 'not a directory' in str(exc),
          'C10 the refusal must explain the obstruction',
          f'got {exc!r} -- a bare FileExistsError from mkdir, which is what '
          'this guard replaces, explains nothing')

    # A stray file whose name could never be a namespace stays out entirely.
    (root / 'README.md').write_text('notes', encoding='utf-8')
    check(row_for(workspace.report(), 'README.md') is None,
          'C10 a file that could not be a namespace must not be listed',
          'the charset rule is what keeps the report free of ordinary clutter')

    # An empty directory is its own state, distinct from absent.
    (root / 'hollow').mkdir()
    row = row_for(workspace.report(), 'hollow')
    check(row is not None and row['disk'] == 'empty',
          'C10 an empty namespace folder must read empty, not absent',
          str(row))
    check('hollow' not in workspace.namespaces(),
          'C10 an empty folder is not a usable namespace')

    # C11 -- set_description must not manufacture 'absent + registered'.
    registry_before = (root / REGISTRY_NAME).read_bytes()
    refuses(lambda: workspace.set_description('ghost', 'I never existed'),
            WorkspaceError, 'C11 describing a namespace that does not exist')
    check((root / REGISTRY_NAME).read_bytes() == registry_before,
          'C11 the refused description must leave the registry untouched')
    ghost = row_for(workspace.report(), 'ghost')
    check(ghost is None,
          'C11 a phantom registry entry must never be created',
          f'got {ghost} -- this row would read absent+registered, which is '
          'indistinguishable from a namespace whose folder was deleted, i.e. '
          'the API would be manufacturing the C1 state')

    # It must still work for a namespace that exists but is unregistered.
    (root / 'found').mkdir()
    WikiCore.create_database(root / 'found' / NOTEBOOK_NAME)
    workspace.set_description('found', 'discovered, then described')
    row = row_for(workspace.report(), 'found')
    check(row is not None and row['description'] == 'discovered, then described'
          and row['registry'] == 'registered',
          'C11 describing a discovered namespace must work', str(row))


def main() -> int:
    test_names()
    for name, fn in (('disk', test_disk_states),
                     ('registry', test_registry),
                     ('damaged', test_damaged_namespace_is_isolated),
                     ('defaults', test_defaults_and_refusals),
                     ('recheck', test_recheck_findings)):
        with tempfile.TemporaryDirectory(prefix=f'pw_ws_{name}_') as tmp:
            try:
                fn(Path(tmp) / 'WORKSPACE')
            except Exception as exc:                            # noqa: BLE001
                import traceback
                problems.append(f'{name} suite raised: {exc!r}\n'
                                + traceback.format_exc())

    if problems:
        print('FAIL')
        for problem in problems:
            print('  -', problem)
        return 1
    print('PASS — workspace layer: 11 controls, each with its counterexample')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
