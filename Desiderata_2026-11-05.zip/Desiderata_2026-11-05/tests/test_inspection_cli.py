"""C3 cold-read interface tests; fixture ZIP constructed by the test, not executed."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from zipfile import ZIP_DEFLATED, ZipFile

from scientific_workspace.interface.checkpoint_io import CheckpointError, verify_zip, restore_fixture
from scientific_workspace.interface.inspection import summarize, explain
from scientific_workspace.storage.journal import JournalError

ROOT = Path(__file__).resolve().parents[1]
BASE_FIXTURE = ROOT / 'fixtures' / 'E1_PERSISTENT_WORKSPACE'
LAUNCHER = ROOT / 'bin' / 'scientific-workspace'


def sample_zip(path, *, omission=None, extra=None, changes=None):
    prefix = 'self_contained_checkpoint'
    entries = {}
    for file in sorted(BASE_FIXTURE.rglob('*')):
        if file.is_file() and file.name in ('wiki.db', 'wiki.history.sqlite'):
            rel = file.relative_to(ROOT).as_posix()
            if rel != omission:
                entries[rel] = file.read_bytes()
    entries['docs/README.md'] = b'synthetic fixture, no code execution\n'
    if changes:
        entries.update(changes)
    manifest = {
        'schema': 'sw-local-checkpoint-manifest/0.1',
        'files': [{'path': rel, 'sha256': hashlib.sha256(value).hexdigest(), 'bytes': len(value)}
                  for rel, value in sorted(entries.items())],
    }
    with ZipFile(path, 'w', compression=ZIP_DEFLATED) as z:
        for rel, value in entries.items():
            z.writestr(prefix + '/' + rel, value)
        z.writestr(prefix + '/checkpoints/PACKAGE_MANIFEST.json', json.dumps(manifest))
        if extra:
            z.writestr(prefix + '/' + extra, b'extra file')
    return hashlib.sha256(path.read_bytes()).hexdigest()


class InspectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)
        self.archive = self.work / 'checkpoint.zip'
        self.digest = sample_zip(self.archive)

    def run_cli(self, *args, success=True):
        p = subprocess.run([sys.executable, str(LAUNCHER), *args], cwd=self.work,
                           text=True, capture_output=True, timeout=20)
        self.assertEqual(p.returncode == 0, success, f'rc={p.returncode}\n{p.stdout}\n{p.stderr}')
        return p

    def test_three_command_cold_recovery_explains_transaction(self):
        dest = self.work / 'recovered'
        restore = self.run_cli('restore', '--archive', str(self.archive),
                               '--workspace', str(dest), '--expected-sha256', self.digest)
        r = json.loads(restore.stdout)
        self.assertTrue(r['inventory_verified'])
        self.assertTrue(r['independent_digest_supplied'])
        self.assertEqual(r['event_count'], 7)
        verify = json.loads(self.run_cli('verify', '--workspace', str(dest), '--json').stdout)
        self.assertTrue(verify['ok'])
        self.assertEqual(verify['event_count'], 7)
        self.assertEqual(verify['lifecycle'], 'EXHAUSTED')
        before = {(n, f.name): hashlib.sha256(f.read_bytes()).hexdigest()
                  for n in ('user', 'agent_a', 'agent_b', 'system')
                  for f in (dest / n).glob('*.sqlite')}
        output = self.run_cli('inspect', '--workspace', str(dest), '--explain',
                              '--diff-from-initial').stdout
        self.assertIn('FORMAL_COUNTEREXAMPLE_VERIFIED', output)
        self.assertIn('PREMISE_NOT_SATISFIED', output)
        self.assertIn('Source claim: UNRESOLVED', output)
        self.assertIn('Proposed correction COR-P14 (PROPOSED', output)
        self.assertIn('## Changes since the initial state', output)
        after = {(n, f.name): hashlib.sha256(f.read_bytes()).hexdigest()
                 for n in ('user', 'agent_a', 'agent_b', 'system')
                 for f in (dest / n).glob('*.sqlite')}
        self.assertEqual(before, after)
        self.assertEqual(verify['head_digest'], summarize(dest)['head_digest'])

    def test_json_report_is_machine_inspectable_without_extra_authority(self):
        response = summarize(BASE_FIXTURE)
        self.assertEqual(response['source_claim_state'], 'UNRESOLVED')
        self.assertEqual([e['formal_claim_state'] for e in response['evaluations']],
                         ['REFUTED', 'UNRESOLVED'])
        self.assertEqual(len(response['timeline']), 7)
        self.assertIn('source fidelity assessed: False', explain(response).lower().replace('false', 'False'))
        self.assertEqual(response['corrections'][0]['status'], 'PROPOSED')

    def test_external_digest_rejects_mismatch(self):
        with self.assertRaisesRegex(CheckpointError, 'EXTERNAL_DIGEST_MISMATCH'):
            verify_zip(self.archive, '0'*64)

    def test_changed_payload_rejected_before_recovery(self):
        tampered = self.work / 'tampered.zip'
        with ZipFile(self.archive) as src, ZipFile(tampered, 'w') as dst:
            for item in src.infolist():
                data = src.read(item.filename)
                if item.filename.endswith('/user/wiki.db'):
                    data = data + b'tampered'
                dst.writestr(item.filename, data)
        with self.assertRaisesRegex(CheckpointError, 'PAYLOAD_MISMATCH'):
            verify_zip(tampered)
        self.assertFalse((self.work / 'recovered').exists())

    def test_unlisted_payload_rejected(self):
        sample_zip(self.archive, extra='surprise.txt')
        with self.assertRaisesRegex(CheckpointError, 'INVENTORY_MISMATCH'):
            verify_zip(self.archive)

    def test_duplicate_zip_entry_rejected(self):
        duplicated = self.work / 'dup.zip'
        with ZipFile(self.archive) as src, ZipFile(duplicated, 'w') as dst:
            for item in src.infolist():
                dst.writestr(item.filename, src.read(item.filename))
            name = src.infolist()[0].filename
            dst.writestr(name, b'duplicate')
        with self.assertRaisesRegex(CheckpointError, 'DUPLICATE_ARCHIVE_PATH'):
            verify_zip(duplicated)

    def test_path_traversal_rejected(self):
        with ZipFile(self.archive, 'a') as z:
            z.writestr('self_contained_checkpoint/../outside.txt', b'malicious')
        with self.assertRaisesRegex(CheckpointError, 'UNSAFE_ARCHIVE_PATH'):
            verify_zip(self.archive)

    def test_missing_notebook_pair_aborts_and_cleans_staging(self):
        sample_zip(self.archive, omission='fixtures/E1_PERSISTENT_WORKSPACE/agent_b/wiki.db')
        dest = self.work / 'recovered'
        with self.assertRaisesRegex(CheckpointError, 'MISSING_REQUIRED_NOTEBOOK_PAIR'):
            restore_fixture(self.archive, dest)
        self.assertFalse(dest.exists())
        self.assertFalse(list(self.work.glob('.sw_restore_*')))

    def test_refuses_existing_destination_without_mutation(self):
        dest = self.work / 'recovered'
        dest.mkdir()
        keep = dest / 'KEEP'
        keep.write_text('untouched')
        with self.assertRaisesRegex(CheckpointError, 'DESTINATION_EXISTS'):
            restore_fixture(self.archive, dest)
        self.assertEqual(keep.read_text(), 'untouched')

    def test_unavailable_namespace_is_not_absence(self):
        dest = self.work / 'recovered'
        restore_fixture(self.archive, dest)
        (dest / 'agent_a' / 'wiki.db').unlink()
        p = self.run_cli('verify', '--workspace', str(dest), success=False)
        self.assertIn('NAMESPACE_UNAVAILABLE', p.stderr)

    def test_history_mutation_rejected_by_verify_command(self):
        dest = self.work / 'recovered'
        restore_fixture(self.archive, dest)
        from scientific_workspace.storage.vendor_pw.wiki_core import WikiCore
        with WikiCore(dest / 'user' / 'wiki.db') as wiki:
            existing = wiki.get_tiddler('intent/goal-1')
            wiki.save_tiddler('intent/goal-1', existing['text'], [],
                              fields=existing['fields'], reason='attempted history rewrite')
        p = self.run_cli('verify', '--workspace', str(dest), success=False)
        self.assertIn('IMMUTABLE_HISTORY_VIOLATION', p.stderr)

    def test_recovery_reports_uncommitted_draft_not_as_event(self):
        from scientific_workspace.storage.journal import WikiJournal, SimulatedCrash
        root = self.work / 'new_run'
        j = WikiJournal.create(root, budget=2)
        cmd = {'type': 'goal', 'principal': 'user', 'goal_id': 'G1', 'statement': 'Test'}
        with self.assertRaises(SimulatedCrash):
            j.submit('G1', cmd, {'human_authorized': True}, cutpoint='after_draft')
        observed = summarize(root)
        self.assertEqual(observed['event_count'], 0)
        self.assertEqual(len(observed['pending_intents']), 1)
        self.assertEqual(observed['lifecycle'], 'WAITING_FOR_GOAL')
        self.assertIn('Uncommitted drafts', explain(observed, diff_from_initial=True))

    def test_missing_expected_digest_does_not_claim_independent_authentication(self):
        response = verify_zip(self.archive)
        self.assertFalse(response['independent_digest_supplied'])
        self.assertIn('archive_sha256', response)


if __name__ == '__main__':
    unittest.main()
