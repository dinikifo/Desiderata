"""Future C4 gate: agent code must not gain human operator authority.

A passing check before there is an adapter is deliberately NOT evidence of
capability isolation. This check will become mandatory at C4 admission.
"""
import ast
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
AGENTS = ROOT / 'scientific_workspace' / 'agents'

class AgentBoundaryPreflight(unittest.TestCase):
    def test_no_agent_access_to_human_operator_cli(self):
        modules = sorted(AGENTS.rglob('*.py')) if AGENTS.exists() else []
        if not modules:
            self.skipTest('C4_GATE_NOT_EVALUATED: no agent adapter exists')
        violations = []
        for path in modules:
            code = path.read_text(encoding='utf8')
            for node in ast.walk(ast.parse(code)):
                if isinstance(node, ast.ImportFrom) and node.module in (
                    'scientific_workspace.interface.cli',
                    'scientific_workspace.interface.project_io'):
                    violations.append(f'{path}: forbidden import')
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name in ('scientific_workspace.interface.cli',
                                          'scientific_workspace.interface.project_io'):
                            violations.append(f'{path}: forbidden import')
                if isinstance(node, ast.Constant) and node.value in ('--local-operator', 'local_operator'):
                    violations.append(f'{path}: operator flag literal')
        self.assertEqual(violations, [])

if __name__ == '__main__': unittest.main()
