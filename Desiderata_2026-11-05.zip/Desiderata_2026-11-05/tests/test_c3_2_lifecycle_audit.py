"""Conservative bounded audit of implemented D-07-provisional lifecycle guards.

Not a complete reachable-state or future-status proof. In particular, the
proposed WAITING_FOR_INSPECTION/RECOVERY states are not implemented here.
"""
import unittest

from scientific_workspace.engine.transition import (
    active_goal, classify_continuation, initial_state, step,
)

USER = {'principal': 'user'}
AUTH = {'human_authorized': True, 'storage_writable': True}


class ProvisionalLifecycleTests(unittest.TestCase):
    def _applied(self, state, kind, **fields):
        result = step(state, {'type': kind, **USER, **fields}, AUTH)
        self.assertEqual(result['outcome'], 'APPLIED', (kind, result['reason']))
        return result['state']

    def test_pause_is_escape_only_and_not_scientific_progress(self):
        s = self._applied(initial_state(), 'goal', goal_id='G', statement='Prove P')
        paused = self._applied(s, 'stop')
        self.assertEqual(classify_continuation(paused), 'ESCAPE_ONLY')
        self.assertEqual(paused['source_claim_state'], 'UNRESOLVED')
        self.assertEqual(len(paused['attempts']), len(s['attempts']))
        self.assertEqual(self._applied(paused, 'resume')['status'], 'WAITING_FOR_TURN')

    def test_proven_local_escape_for_implemented_nonterminal_statuses_only(self):
        initial = initial_state()
        goal = self._applied(initial, 'goal', goal_id='G', statement='Test')
        paused = self._applied(goal, 'stop')
        for state in (initial, goal, paused):
            self.assertIn(state['status'], ('WAITING_FOR_GOAL', 'WAITING_FOR_TURN', 'QUIESCED'))
            aborted = self._applied(state, 'abandon', reason='Stop safely')
            self.assertEqual(aborted['status'], 'ABANDONED')
            self.assertEqual(classify_continuation(aborted), 'TERMINAL')
            self.assertEqual(step(aborted, {'type': 'resume', **USER}, AUTH)['reason'], 'TERMINAL')

    def test_storage_unavailable_is_recovery_required_not_durable_escape(self):
        state = self._applied(initial_state(), 'goal', goal_id='G', statement='Test')
        self.assertEqual(classify_continuation(state, {'storage_writable': False}), 'RECOVERY_REQUIRED')
        attempt = step(state, {'type': 'abandon', **USER, 'reason': 'exit'},
                       {'human_authorized': True, 'storage_writable': False})
        self.assertEqual(attempt['outcome'], 'BLOCKED')
        self.assertEqual(attempt['state'], state)
        self.assertEqual(attempt['reason'], 'LOCAL_STOP_UNRECORDED')


if __name__ == '__main__':
    unittest.main()
