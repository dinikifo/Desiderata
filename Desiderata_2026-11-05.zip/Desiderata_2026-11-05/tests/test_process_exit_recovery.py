"""C3.2: abrupt real process exit at the two already-durable journal cutpoints.

No assertion about OS power-loss durability or hardware write ordering. These
are process-exit tests that start again from persisted SQLite notebook pairs.
"""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest
from unittest.mock import patch

from scientific_workspace.storage.journal import WikiJournal

ROOT = Path(__file__).resolve().parents[1]
COMMAND = {'type': 'goal', 'principal': 'user', 'goal_id': 'K',
           'statement': 'Inspect a possibly incorrect task'}


class ProcessExitTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.workspace = Path(tmp.name) / 'workspace'
        WikiJournal.create(self.workspace)

    def _child(self, terminate_after):
        code = textwrap.dedent('''
            import os
            from pathlib import Path
            import scientific_workspace.storage.journal as mod
            orig = mod._post
            def exit_after_post(path, title, kind, payload, reason):
                orig(path, title, kind, payload, reason)
                if (title == 'intent/process-cut' and CUT == 'draft') or (title == 'event/00000001' and CUT == 'event'):
                    os._exit(83)
            CUT = %r
            mod._post = exit_after_post
            command = {'type':'goal','principal':'user','goal_id':'K',
                       'statement':'Inspect a possibly incorrect task'}
            mod.WikiJournal(Path(%r)).submit('process-cut', command, {'human_authorized': True})
        ''' % (terminate_after, str(self.workspace)))
        proc = subprocess.run([sys.executable, '-c', code], cwd=ROOT,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              timeout=25, text=True)
        self.assertEqual(proc.returncode, 83, proc.stderr)

    def test_real_process_exit_after_draft_has_pending_intent_no_commit(self):
        self._child('draft')
        observed = WikiJournal(self.workspace).inspect()
        self.assertEqual(observed['events'], 0)
        self.assertEqual([x['request_id'] for x in observed['pending']], ['process-cut'])
        retry = WikiJournal(self.workspace).submit('process-cut', COMMAND, {'human_authorized': True})
        self.assertEqual(retry['outcome'], 'APPLIED')
        self.assertEqual(WikiJournal(self.workspace).inspect()['events'], 1)

    def test_real_process_exit_after_event_has_single_commit(self):
        self._child('event')
        observed = WikiJournal(self.workspace).inspect()
        self.assertEqual(observed['events'], 1)
        self.assertEqual(observed['pending'], [])
        retry = WikiJournal(self.workspace).submit('process-cut', COMMAND, {'human_authorized': True})
        self.assertEqual(retry['outcome'], 'NOOP')
        self.assertEqual(WikiJournal(self.workspace).inspect()['events'], 1)

    def test_simulated_system_io_error_leaves_retryable_pending_intent(self):
        import scientific_workspace.storage.journal as mod
        original = mod._post
        def fail_system(path, title, kind, payload, reason):
            if title.startswith('event/'):
                raise OSError('simulated ENOSPC before event write')
            return original(path, title, kind, payload, reason)
        with patch.object(mod, '_post', side_effect=fail_system):
            with self.assertRaisesRegex(OSError, 'ENOSPC'):
                WikiJournal(self.workspace).submit('process-cut', COMMAND, {'human_authorized': True})
        observed = WikiJournal(self.workspace).inspect()
        self.assertEqual(observed['events'], 0)
        self.assertEqual(len(observed['pending']), 1)
        self.assertEqual(WikiJournal(self.workspace).submit('process-cut', COMMAND, {'human_authorized': True})['outcome'], 'APPLIED')


if __name__ == '__main__':
    unittest.main()
