"""Release editorial structure and backwards-compatible launcher contract."""
import pathlib
import subprocess
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from check_desiderata_docs import check


class DesiderataEditionTests(unittest.TestCase):
    def test_all_required_docs_and_links(self):
        self.assertEqual(check(ROOT), [])

    def test_alias_shows_existing_command_interface(self):
        result = subprocess.run([sys.executable, str(ROOT / 'bin/desiderata'), '--help'],
                                cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        for name in ('init', 'inspect', 'export', 'restore', 'amend'):
            self.assertIn(name, result.stdout)

    def test_license_and_historical_notice_are_distinct(self):
        license_text = (ROOT / 'LICENSE').read_text(encoding='utf-8')
        self.assertIn('CC0 1.0 Universal', license_text)
        notice = ROOT / 'scientific_workspace/storage/vendor_pw/LICENSE'
        self.assertTrue(notice.exists())
        self.assertIn('https://unlicense.org', notice.read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
