"""C3.2: cold reader uses only command-line entry points, never engine imports."""
import ast
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest

from scientific_workspace.interface.project_io import export_project

ROOT = Path(__file__).resolve().parents[1]


class ColdReaderTests(unittest.TestCase):
    def test_black_box_read_of_persisted_e1(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = Path(temp) / 'case.zip'
            target = Path(temp) / 'restored'
            export_project(ROOT / 'fixtures/E1_PERSISTENT_WORKSPACE', archive)
            proc = subprocess.run([sys.executable, 'tools/cold_reader_audit.py',
                '--archive', str(archive), '--workspace', str(target), '--expect-e1'],
                cwd=ROOT, capture_output=True, text=True, timeout=60)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            result = json.loads(proc.stdout)
            self.assertEqual(result['audit'], 'BLACK_BOX_COLD_READ_PASS')
            self.assertEqual(result['events'], 7)
            self.assertEqual(result['reconstruction_commands'], 3)

    def test_audit_script_no_internal_package_imports(self):
        tree = ast.parse((ROOT / 'tools/cold_reader_audit.py').read_text())
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                imports.append(node.module or '')
        self.assertFalse(any(name.startswith('scientific_workspace') for name in imports))


if __name__ == '__main__':
    unittest.main()
