> **CURRENT REVIEW OVERLAY — 2026-11-05:** Read [`consolidated/START_HERE.md`] for current status, source catalog and discussion agenda. The user has **approved D-07 only for the five implemented local lifecycle states**. Older references to D-07 being OPEN below are preserved as **original d-07 proposal (now bounded-approved)**, not the current decision. `HOLD` remains in effect.

---

# D-07 — Lifecycle contract decision sheet (PROPOSED, NOT ACCEPTED)

**Question:** which investigation-control states and transitions are normative? The mathematical claim state and investigation result remain separate.

## Currently implemented (provisional)

| Control status | Meaning | Transitions demonstrated in local tests |
|---|---|---|
| `WAITING_FOR_GOAL` | no committed goal yet | goal, stop, abandon |
| `WAITING_FOR_TURN` | goal exists; work can be proposed | attempt, amend, stop, abandon, exhaust when quota spent |
| `QUIESCED` | paused without progress | goal/amend without resume, explicit resume, abandon |
| `EXHAUSTED` | finite attempt budget spent and named as such | terminal |
| `ABANDONED` | human chose durable abandonment | terminal |

The proposed broader vocabulary includes `WAITING_FOR_INSPECTION`, `WAITING_FOR_AUTHORIZATION`, `BLOCKED_RECOVERABLE`, `COMPLETED`, and `FAILED`; these are **not implemented**. `RECOVERY_REQUIRED` and `ESCAPE_ONLY` are currently classification results, not persisted lifecycle statuses. We must not quietly add them to the truth-state machine.

## Proposed acceptance language

- `stop` yields `QUIESCED`, which is neither resolution nor progress.
- `resume` is explicitly human-directed and can never be inferred from a goal amendment.
- `abandon` records durable termination only if a system event can be committed. Otherwise return a named local-stop/recovery condition.
- terminal statuses reject additional transitions unless a future versioned reopening mechanism is explicitly adopted.
- the current local-trust semantics do not constitute an agent-facing authorization policy.

**Disposition requested:** approve, amend, or reject this limited normative lifecycle, and separately decide whether the unimplemented statuses should be required for C3 acceptance or postponed to C4. This document is a decision proposal, not the decision itself.
