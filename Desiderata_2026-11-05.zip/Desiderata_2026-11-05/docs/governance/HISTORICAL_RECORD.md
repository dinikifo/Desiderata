# Historical documentation and the current reading path

This release **preserves** the previous RFC, errata, project index, notes, test evidence and source references so readers can examine disagreements and corrections. It does not retroactively rewrite those sources into the Desiderata name.

## Document authority

1. `README.md`, `docs/monographs/`, `docs/manual/`, `docs/roadmaps/`, and `docs/governance/` are the **current editorial presentation**, dated 2026-11-05; they do not establish new runtime capabilities.
2. `sources/RFC-0001-v0.2.md`, `sources/ARCHITECTURE_2026-11-05.md` and errata are **historical research/requirements sources**; their universal claims remain subject to their stated caveats.
3. `docs/consolidated/` and the other old `docs/` files are **checkpoint-specific snapshots**; older descriptions of D-07 being open, 72 tests, and implementation paths are not the current release summary.
4. `checkpoints/` contains **test and packaging receipts**. A self-contained file digest proves local consistency, not independent origin or timestamp attestation.
5. `sources/` and `.git` preserve the source lineage; these archives must not be silently rewritten to improve the story.

## Suggested history reading order

`docs/consolidated/HISTORY_AND_DISCUSSION.md` → `sources/ARCHITECTURE_2026-11-05.md` → `sources/ARCHITECTURE_ERRATA_R1.md` → `sources/RFC-0001-v0.2.md` → `docs/TRACEABILITY.md` → `docs/consolidated/FINDINGS_AND_OBJECTIONS.md` → `docs/consolidated/C3_VENDOR_REVIEW.md` → `docs/consolidated/C3_FUNCTION_IMPORT_COVERAGE.md`.

The [DN-0001 proposed design note](../proposals/DN-0001-PROPOSED.md) about human-authorized criteria and protocol strata was drafted outside the current accepted codebase and is included byte-identically for discussion. Its ideas are summarized as **proposals** in M04, without claiming the note was adopted or that protocol strata are implemented.

## Meaning of the rename

**Desiderata is the project's publication/editorial name.** Internal `scientific_workspace` modules, old receipts, test names, and Git history remain untouched for technical compatibility and provenance. `bin/desiderata` is a thin alias only. Historical commit names are not rewritten.
