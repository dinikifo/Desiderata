# Desiderata assembly and verification record

**Date:** 2026-11-05. **Input:** preserved `scientific_workspace_C3_IMPORT_COVERAGE_2026-11-05` C3.4 tree, head `55988cf18542ecf104cf540f224291da1a59a90c`. **Output:** Desiderata publication-oriented documentation edition, with unchanged implementation source.

## Scope of edits

The Python package under `scientific_workspace/` and existing unit-test sources were retained **byte-for-byte** relative to C3.4. Added: root CC0-1.0 legal text; a CLI alias; eight editorial monographs; manual; source-map/functionality and creators' roadmaps; primary/external bibliography; scoped license/provenance; proposed DN-0001 original draft; historical-document index; `unittest` edition checks; documentation link checker; and a draft GitHub Actions workflow. The original Git history was not rewritten.

A1 independent human comprehension is **not** discharged by this documentation. C3 progress remains step 6 of 6, about 90% complete with ~7% remaining by the earlier fixed weights. No live LLM model code or C4 authorization was added. `HOLD` remains.

## Fresh regression receipts

| Group | Result | Evidence |
|---|---|---|
| Core, transition, persistence, process exit, cold reader, progress and new edition tests | 49/49 passed | `checkpoints/desiderata/CORE.txt` |
| Operator and read-only inspection | 26/26 passed | `checkpoints/desiderata/OPERATOR.txt` |
| Vendored regressions, migration, import coverage and future adapter preflight | 14 passed, 1 explicitly skipped (15 total) | `checkpoints/desiderata/STORAGE.txt` |
| Preserved R0 baseline | 44/44 passed | `checkpoints/desiderata/R0.txt` |
| AST + tracing of vendor function-local imports | 5/5 sites reached | `checkpoints/desiderata/IMPORT_COVERAGE.txt` |
| Monograph links, entry points and license notice | Passed | `tools/check_desiderata_docs.py`, `tests/test_desiderata_edition.py` |

**Total new source-tree test run:** 89 passed, 1 future-C4 test skipped, across three separate groups of 49 + 26 + 15. **R0:** 44 passed separately. No monolithic all-suite claim. The package integrity and cold-extraction receipt are produced separately after sealing the ZIP; they cannot be embedded retrospectively without changing its digest.

## Corrections observed during assembly

The first documentation check detected inconsistent M05–M08 filenames. The first release-license test incorrectly expected the literal word `Unlicense` in the preserved upstream notice (which instead contains `https://unlicense.org`). Both checks were corrected and passed on rerun. The vendor import coverage script's default report path can modify an older checkpoint receipt with volatile test timings; this edition directs its CI and manual runs to explicitly named new output paths and restores the earlier receipt unchanged.

## Limitations

All results are local; root licensing policy does not certify third-party rights. The CC0 legal code was copied from the system's standard CC0-1.0 license corpus and checked against the official Creative Commons publication. A test receipt is not a proof of universal scientific correctness. The GitHub workflow was added but has **not** been executed on GitHub. The project has **not** been published to a remote repository by assembling this archive.
