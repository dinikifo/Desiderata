# DN-0001 — Criteria, methods, protocol strata, and the path to a reusable template

**Project:** Scientific Workspace  
**Date:** 2026-11-05  
**Status:** PROPOSED FOR DISCUSSION — NOT ACCEPTED  
**Type:** Design note / review disposition (no code or RFC change)  
**Current implementation baseline:** C3 Vendor Review, ZIP SHA-256 `a3624a998cd8f0c35c105115a15650f9c951c1485836f45eb713507f3733b979`  
**Operational gate:** `HOLD` remains; C4 is NOT authorized by this note.

## 1. Context and the claim under review

The user proposes that the architecture may eventually be made portable as an agentic template whose open questions can change data, goals, and investigative methods. The latest review supports the distinction between *scientific revision* and *protocol revision*, but argues that extracting a general template before a second implemented domain would risk baking the finite-action-set example into what is described as a universal kernel.

This note records that review **without changing the C4 roadmap, changing C3 progress weights, accepting a new architecture, or starting implementation**. Historical source code and review packages remain unchanged.

## 2. Authority boundary: who may change the rules?

**Accepted as the proposed design direction:** There is no autonomous meta-kernel that certifies changes to its own criteria. Human-authorized **policy and criterion records** constitute the authority boundary. Agent-authored protocol-change proposals are ordinary proposals, not permissions. A proposal may be argued, tested, and inspected, but only an appropriately authorized human action activates a change to governing criteria or permissions.

**Important qualification:** “Kernel = records only a human may author” is an authority *policy*, not an enforcement mechanism by itself. The runtime must keep agent capabilities separate from human-authorized operations. If agents and humans share unrestricted filesystem/database credentials, a nominally human-only namespace cannot enforce that policy. The C4 capability split remains an **unimplemented gate** (see the existing C3 vendor review); human authorization is not evidence that a criterion is scientifically correct.

The rule set that verifies human authorization is still implemented software subject to defects. The regress is **terminated institutionally by authority**, not resolved by a theorem showing its implementation cannot be wrong.

## 3. Method versus criterion revisions

| Dimension | Method revision (3a) | Criterion revision (3b) |
|---|---|---|
| Changes | *How* an existing declared standard is checked (e.g., verifier implementation, parser, strategy) | *What counts* as sufficient evidence, acceptable uncertainty, or permitted authority |
| Evidence | Conformance and adversarial tests against **frozen, independent reference criteria**; revalidation of known cases | Impact analysis, explicit comparison of competing criteria, and **human authorization** to adopt a standard |
| Limit | Passing tests does not show the new verifier is correct in untested cases | No conformance test can, by itself, establish the normative rightness of the changed criterion |
| Activation | Within previously granted delegation, or explicit authorization where required | Explicit human-authorized, versioned activation |

This is a **proposed policy**, not an implemented revision API. Some criterion changes can be *informed* by mathematical and empirical evidence, and some internal consistency properties can be tested; tests do not substitute for authority to select the criterion.

## 4. No retroactive self-validation: protocol strata

A newly admitted record should cite the **admission-criterion version**, the **verification-method/checker identity** (and reproducible build/content digest where available), the specific evidence/claim versions, and the authority event authorizing its protocol stratum.

Protocol v2 does not silently rewrite or validate records admitted under v1. Historic claims and receipts remain in their original strata. A *current view* may explicitly re-evaluate an earlier claim under v2, but that yields **another derived assessment**, with its own evidence, scope, and history; it never alters the original admission event.

Cross-stratum disagreements must be queryable and visible. A query used for an audit must identify its selected stratum/view policy (or disclose an explicit, versioned default); “current” must not silently collapse incompatible criteria. The **number of live protocol strata** and the added query/review burden should be reported descriptively as operational costs, **never optimized as a target absent separate justification**.

**Design obligation, not accomplished state:** the present C3 implementation does not yet have a general versioned protocol-strata projection. Adding it is **not** authorized by this note.

## 5. Portability depends on a declared platform contract

The implementation is not platform-neutral by assertion. The current journal imports Unix `fcntl` advisory locking (`scientific_workspace/storage/journal.py`). Storage paths also rely on supported SQLite transactions and filesystem publication behaviors; exclusive writing is an assumption under cooperative local processes, not an established defense against hostile writers.

A future portable profile must document and test at least:

- Exclusive-write capabilities for party and system stores (not merely declared namespaces).
- An atomic/durable local commit mechanism under an explicitly named failure model, including history sidecars and replay assumptions.
- Serialization and locking (currently `fcntl.flock` in the journal); a port must supply an equivalent or fail its preflight rather than silently downgrade.
- Recovery semantics after interrupted writes, unavailable storage, and unsupported filesystem guarantees.

Passing on a Unix-like local configuration cannot establish a generic cross-platform guarantee.

## 6. Second domain before template extraction

**Proposed next *research* step, not an enlargement of the authorized C4 implementation scope:** test the existing accountability architecture on **bounded software debugging** before describing the architecture as a reusable template.

A candidate diagnostic should provide:

1. An independently stated expected behavior and a known defective implementation, with artifact/version hashes.
2. A reproducible baseline that **fails** a specified test under a declared runtime environment.
3. An agent/simulated actor's proposed diagnosis and bounded patch, preserved as a proposal.
4. A trusted checker that verifies the pre-patch failure and post-patch pass, including protection against disabling, altering, or gaming the test itself.
5. Regression and counterexample cases that can expose a superficially passing but invalid repair.
6. An inspectable account of the original task, rejected alternatives, verified bounded change, unresolved obligations, and consumed resources.

A failing-then-passing test is a **mechanically checkable witness of behavior against that test and environment**, not a proof that arbitrary software is correct. Patch execution requires an isolated, explicitly authorized environment; arbitrary submitted code should not be executed in the authority process.

Success means showing which mechanisms carry unchanged from the mathematical domain and which are domain-specific. With one demonstrated domain, a general template claim remains **NOT ESTABLISHED**. A second domain supplies comparative evidence, not universal proof.

## 7. A third, non-decidable domain is a refusal/abstention test

Document-based research lacks a general decidable witness for its central semantic claims. Its success criterion is **no unsupported promotion to verified scientific status**, with accurate attribution of unresolved, insufficient, or uncheckable questions. The requirement is **not literally “zero verified results”**: bounded subclaims may still be mechanically verified using appropriate independent methods. This domain tests restraint, not parity of positive-result counts with mathematical and debugging tasks.

A future evaluation must state this asymmetry before running the tests. It is not part of the current C4 scope.

## 8. Retained acceptance boundaries and priorities

- **A1 independent reader:** still open; a cold CLI replay is evidence of mechanical reconstruction, not uncoached human comprehension.
- **C4 capability boundary:** still open; agent-facing interfaces must not be able to invoke human-authorized local-operator actions, directly or indirectly. An AST rule may complement but does not replace an enforceable capability boundary.
- **C3 progress:** step **6/6**, **about 90%** complete for the bounded local prototype; the prior planning estimate is ~7% remaining. This note earns **zero new implementation credit**. C4 and C5 remain outside this denominator.
- **C4 entry gate:** unchanged. Neither template extraction nor generalized protocol revision is added to C4.
- **C5:** evaluation design and independent baselines remain future work; no performance thresholds are preregistered by this note.

## 9. Open decisions for discussion (not silently resolved)

**DN1-A — Criterion authority:** Which human-authored record type activates a protocol criterion, and how is human identity/capability enforced locally and, eventually, remotely?

**DN1-B — Method delegation:** Which verifier/tool changes may be activated under previously granted delegation, and which require an individual human authorization event?

**DN1-C — Cross-stratum queries:** What must an audit query name explicitly: criterion version, checker version, source version, effective-time selection, or all of them?

**DN1-D — Software debugging diagnostic:** Which narrow debugging fixture, trusted checker, and safe execution environment can be approved without widening C4?

**DN1-E — Portability:** What is the first supported environment, and what behavior must produce `UNSUPPORTED_PLATFORM` rather than a false successful recovery?

**DN1-F — A1:** How will a genuinely uninvolved human cold-reader evaluation be obtained, or explicitly deferred without claiming it has passed?

## 10. Proposed invariant wording for later consideration

> If an independent system encounters a problem for which no suitable verifier exists, it must preserve the question as unresolved rather than manufacture epistemic authority.

**Disposition:** Retain as a candidate normative kernel statement for a *future approved revision*. It is **not** retroactively an implemented/proven invariant or a change to the current RFC. It should be accompanied by an explicit rule that verified **subclaims** may still be recorded at their own bounded scope.

## 11. Evidence and limitations

Grounded in the current project's `docs/consolidated/ROADMAP.md`, `docs/consolidated/DECISIONS_AND_D07.md`, `docs/consolidated/C3_VENDOR_REVIEW.md`, and `scientific_workspace/storage/journal.py`, and in the user's current review text. The supplied C3 Vendor Review archive's SHA-256 was checked against the supplied receipt before writing this note. **No code was modified; no tests were rerun as part of this design-only note.** Any interpretation of the architecture beyond the current RFC is marked as proposed above.
