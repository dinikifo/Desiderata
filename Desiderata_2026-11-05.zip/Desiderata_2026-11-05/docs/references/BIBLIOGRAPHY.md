# Desiderata bibliography and source register

**Scope:** primary documents of the project and external technical/legal references used in the present edition. This is *not* a systematic literature review of scientific reasoning, AI agents or epistemology. Primary project documents are research artifacts; their inclusion does not certify the claims they contain.

## A. Primary sources: project theory and its revisions

| ID | Source available in this repository | Use and authority boundary |
|---|---|---|
| P01 | [`sources/ARCHITECTURE_2026-11-05.md`](../../sources/ARCHITECTURE_2026-11-05.md) | Earlier architecture proposal; consult with later errata |
| P02 | [`sources/ARCHITECTURE_ERRATA_R1.md`](../../sources/ARCHITECTURE_ERRATA_R1.md) | Corrections, especially scope of deadlock/escape claims |
| P03 | [`sources/RFC-0001-v0.2.md`](../../sources/RFC-0001-v0.2.md) | Conditional requirements and acceptance framework, *not* a completed proof |
| P04 | [`docs/TRACEABILITY.md`](../TRACEABILITY.md) | Invariant-to-acceptance evidence statuses; original scope may exceed tested cases |
| P05 | [`docs/consolidated/HISTORY_AND_DISCUSSION.md`](../consolidated/HISTORY_AND_DISCUSSION.md) | Editorial reconstruction of debate, not an authenticated verbatim transcript |
| P06 | [`docs/consolidated/FINDINGS_AND_OBJECTIONS.md`](../consolidated/FINDINGS_AND_OBJECTIONS.md) | 44 objections/observations and dispositions, subject to later repairs |
| P07 | [`docs/consolidated/DECISIONS_AND_D07.md`](../consolidated/DECISIONS_AND_D07.md) | Scoped approval of five local lifecycle states |
| P08 | [`docs/consolidated/C3_VENDOR_REVIEW.md`](../consolidated/C3_VENDOR_REVIEW.md) | Vendored test recovery, lazy-import defect, 9 fresh mutations |
| P09 | [`docs/consolidated/C3_FUNCTION_IMPORT_COVERAGE.md`](../consolidated/C3_FUNCTION_IMPORT_COVERAGE.md) | C3.4 function-local import coverage and v1→v2 migration checks |
| P10 | [`sources/VENDOR_WIKI_PROVENANCE.json`](../../sources/VENDOR_WIKI_PROVENANCE.json) and [`sources/VENDOR_WIKI_REPAIR_RECEIPT.json`](../../sources/VENDOR_WIKI_REPAIR_RECEIPT.json) | Local upstream storage provenance/repair receipts; distinguish digest consistency from independent origin |
| P12 | [`docs/proposals/DN-0001-PROPOSED.md`](../proposals/DN-0001-PROPOSED.md) | Proposed method/criterion and protocol-strata note, **not approved or implemented** |
| P11 | [`sources/scientific_reasoning_prototype_R0_2026-11-05.zip`](../../sources/scientific_reasoning_prototype_R0_2026-11-05.zip) | Preserved bounded formal checker and tests |

For historical research ZIPs not embedded here, see [`docs/consolidated/SOURCE_CATALOG.md`](../consolidated/SOURCE_CATALOG.md) and the previously released full research review package. Archived earlier decisions may disagree with the current status: **use the current README and governance notes to determine what is approved now**.

## B. External technical and legal sources

| ID | Reference | Why relevant |
|---|---|---|
| E01 | Creative Commons, *CC0 1.0 Universal: Legal Code*. https://creativecommons.org/publicdomain/zero/1.0/legalcode.en | Text of current dedication; warranty and patent boundaries |
| E02 | Creative Commons, *CC0 1.0 Universal: Deed*. https://creativecommons.org/publicdomain/zero/1.0/ | Accessible summary, **not** the legal instrument |
| E03 | SPDX, *CC0-1.0 License Identifier*. https://spdx.org/licenses/CC0-1.0.html | Standard machine-readable license identifier |
| E04 | Python documentation, *sqlite3 — DB-API 2.0 interface for SQLite databases*. https://docs.python.org/3/library/sqlite3.html | SQLite integration and transaction details |
| E05 | SQLite, *Atomic Commit in SQLite*. https://www.sqlite.org/atomiccommit.html | Specific hardware and file-system assumptions underlying atomic commits; not proof of this project's multi-file durability |
| E06 | Python documentation, *unittest — Unit testing framework*. https://docs.python.org/3/library/unittest.html | Test execution conventions and fixture concepts |
| E07 | Git, *git-bundle Documentation*. https://git-scm.com/docs/git-bundle | Verifiable portable Git history transport, without independent origin attestation |
| E08 | *python-tidly-wiki*, earlier public repository, owner-provided historical link. https://github.com/dinikifo/python-tidly-wiki | A public ancestor of PERSONAL.WIKI; the current vendored tree is **not identical** to that GitHub revision |

External references were selected for claims made by this implementation. They are not asserted to exhaust relevant peer-reviewed literature. The original monograph and earlier source material may cite additional works, but this edition does not invent or reconstruct missing bibliographic metadata.

## C. Suggested future reading program (not yet a bibliography claim)

For a later research edition, commission a proper literature survey on formal verification and semantics, argumentation and belief revision, event sourcing and concurrency, evaluation of agentic LLM systems, reproducibility and provenance, and the epistemology of negative results. Those literature claims should be sourced and reviewed *before* they are used as technical premises.

## Citation policy

A check receipt is evidence of what a specific program/test did; a bibliography reference identifies intellectual or technical context; a human authorization record changes policy. None substitutes for another. Avoid citing the number of passing tests as proof of scientific efficacy.
