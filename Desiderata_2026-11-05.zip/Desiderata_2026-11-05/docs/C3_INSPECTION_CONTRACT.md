# C3 — cold restore, verify, inspect contract

**Status:** implementation with bounded local tests, not externally authenticated archival proof.
**Source:** sealed C2 checkpoint, whose journal/replay implementation is preserved except for new read-only interface files.

## 3 named commands

```bash
./bin/scientific-workspace restore --archive PATH_TO_C3_ZIP --workspace /tmp/restored-journal --expected-sha256 KNOWN_DIGEST
./bin/scientific-workspace verify --workspace /tmp/restored-journal --json
./bin/scientific-workspace inspect --workspace /tmp/restored-journal --explain --diff-from-initial
```

- **Restore** verifies a whole ZIP inventory, size and SHA-256 for each manifest-listed file; checks the optional separately received whole-ZIP digest; then extracts ONLY the 8 SQLite files of the bundled E1 notebook fixture into a fresh temporary sibling directory. It attempts history validation and deterministic event replay before an atomic rename to the new workspace. No code from the ZIP is executed. The destination must not exist.
- **Verify** opens all four notebook pairs through WikiCore in read-only mode, verifies content/history consistency, rejects rewritten journal entries, enforces committed-event/draft correspondence and replays the whole event chain. A missing namespace halts with `NAMESPACE_UNAVAILABLE`, not a false empty record. No authenticated actor identity is implied.
- **Inspect** reads exactly that validated replay and produces a bounded human summary: original goal and versions, proposals, formal-check receipts, source/formal claim separation, exhaustion, current/pending event counts, event digests, and optional per-event changes. `--json` also provides an inspection projection for external review.

The command count measures invocations needed to reconstruct *the stored E1 fixture*, not the minutes a human needs to understand an arbitrary real-world problem. A release also provides `python -m scientific_workspace ...` if needed. `bin/scientific-workspace` runs locally without installing a package. The inspection transcript is a *derived projection*, never a new scientific authority.

## Externality and limitations

- The ZIP digest is only an independent anchor if supplied from a trusted, separate channel. A `.sha256` beside the ZIP only permits comparison of local bytes, not authentication or chronology.
- A self-consistent attacker with write access to all SQLite databases and manifest may rewrite the full history. This is not tamper-evidence against an administrator.
- The trust model is a single cooperating local sequencer and POSIX advisory locking, not a distributed transaction or authorization architecture.
- The `--explain` output names a finite proof receipt and a formal claim state; it does **not** certify the underlying source text, reviewer intention or empirical efficacy.
- This first `restore` command restores the packaged E1 fixture, not an arbitrary user-selected exported investigation or a complete wiki research corpus. Generalized export and restore are separate work.
- CLI human control of a new goal, amendment, quiescence, resumption and abandonment has not been implemented. Those operations currently exist through the bounded journal API only. D-07 remains open.

## Acceptance evidence

`tests/test_inspection_cli.py` constructs a fresh package and runs three commands in a subprocess from an unrelated working directory; it tests restoration equality, schema and digest integrity, refusal of overwrite, pending drafts, absence of evidence mutation during inspection, malformed ZIP inventory, and incomplete namespaces.

Historical R0 tests must be run separately with `python tools/run_r0_baseline.py`. A passing 3-command test does not resolve all AC-01–AC-19 or prove the whole research system.
