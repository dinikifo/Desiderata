# C2 persistence contract — local, provisional implementation

**Status:** implemented and integration-tested in bounded scenarios; not production-ready, not externally authenticated, D-07 open.

## Four namespaces

`user/`, `agent_a/`, `agent_b/` and `system/` each have a `wiki.db` and `wiki.history.sqlite`. The package vendors the original Qt-free PERSONAL.WIKI substrate, with package-relative import changes; see `sources/VENDOR_WIKI_PROVENANCE.json` and the included source license. Pure `engine/` has no WikiCore imports.

The four notebook pairs are separate SQLite databases. There is **no cross-namespace atomic transaction**. A POSIX `flock` advisory lock serializes calls from cooperating local processes. Nothing prevents an administrator or an independent program that ignores the lock from altering stores. A `principal` string is not an authenticated identity. The `human_authorized` and `system_authorized` environment flags are modeled assumptions inherited from C1, not trusted proof of authorization.

## Two durable writes and their meaning

1. For a user/agent command, create a versioned, digest-covered `intent/<request_id>` in the party notebook. This is a draft. It does **not** consume a turn or authorize conclusions.
2. Evaluate the command with the pure `step()` function, using the reconstructed committed state. If the command passes, save `event/<index>` into `system/`. This **alone** makes the state transition and committed-turn quota authoritative.
3. Recovery reopens all four notebook pairs, checks their history, reads the ordered system events, checks draft bindings, recomputes the pure event hash chain and replays the transition function. The materialized state is derived and never stored as a second authority.

A crash after step 1 produces `PENDING_UNCOMMITTED` (a staged intent in `inspect()['pending']`) and **zero** turn effect. A crash after step 2 is idempotently replayed; re-submitting the same `request_id` and canonical command is `NOOP`. A different command with that ID is an explicit conflict. For an attempt, `request_id == attempt_id`; transport metadata is not part of the canonical command.

A rejected *admission evaluation* after a committed attempt consumes one turn; a rejected pure `step()` before system commit does not. Different attempt IDs competing for an already committed ordinal are refused; no silent max+1 assignment occurs.

## Integrity and limits

- The journal refuses missing or unreadable namespaces with `NAMESPACE_UNAVAILABLE`, and rejects title gaps, duplicate request IDs, altered event/draft bindings and content/history disagreement.
- Revisions or deletion of existing journal posts via WikiCore are rejected on reopen, even if the wiki's own historical edit is internally consistent; this is an append-only *application* invariant.
- No independent external timestamp, certificate, encryption, identity verification, adversarial filesystem control, durability under arbitrary power loss, or filesystem snapshots are established.
- The fixture `fixtures/E1_PERSISTENT_WORKSPACE/` exercises the finite P14 model. Formal `REFUTED` remains scoped to a formalization; the prose claim stays `UNRESOLVED`.
- Not yet included: human-friendly three-command inspection, exact D-07 lifecycle semantics, full recovery on all OSes, a complete proof of concrete-state nonblocking, or live LLM actors.

## Reproduce

```bash
python -m unittest discover -s tests -v
python -m scientific_workspace.persistent_demo NEW_EMPTY_PATH
python tools/show_progress.py
```

`NEW_EMPTY_PATH` must not already exist; creation intentionally refuses overwriting existing storage.
