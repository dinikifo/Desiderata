# Consolidation plan — code, evidence, knowledge and handover

**Plan status:** proposed operational workflow; not a grant of scientific or production authority. **Principle:** consolidate at executable milestones, not after every review turn.

## Common contents of every checkpoint

1. **CODE:** reproducible source tree, dependency declaration, CLI entry points, exact tests; where applicable, one Git commit and portable Git bundle.
2. **EVIDENCE:** execution commands, test stdout/stderr, pass/fail counts, receipts and precise limitations; failed tests and known failures are not erased.
3. **PROJECT MEMORY:** `GOAL`, `STATE`, `DECISIONS`, `OPEN`, a short `CHANGELOG`, and a current contents/inventory map.
4. **DESIGN TRACEABILITY:** relevant RFC version, open review comments, invariant → acceptance-test mapping, and a list of unsupported assertions.
5. **DISCUSSION:** a compact thematic/chronological summary of why requirements changed; not a purported full chat transcript.
6. **RECOVERY:** deterministic file manifest and SHA-256 checksum supplied alongside the ZIP. A digest in the same workspace is a local integrity receipt, not independent chronological proof.
7. **DEPENDENCIES:** source receipts for external sealed archives, with explicit statement of which are **not** in the new package.

Consolidation must preserve the difference among: *implemented*, *tested within a bounded model*, *proposed*, *externally supported*, and *not yet reviewed*.

## C0 — provenance and contract baseline (included here)

**Inputs:** unchanged R0 ZIP; RFC-0001 v0.2; architecture and deadlock erratum.

**Gate:** compare actual hashes of source files with the declared local receipts; verify R0 archive's published digest and rerun its historical tests in a temporary, isolated directory. Do not claim the sources were authenticated independently. Preserve D-07 as open and note the user's separate authorization to begin local coding.

**Output:** `sources/`, `sources/SOURCE_RECEIPTS.json`, project map and summary.

## C1 — pure deterministic core (previous checkpoint, partial Phase 1)

**Code:** copy R0 checker without editing it; add pure transition function, attempt-ID deduplication, provisional event-chain consistency/replay, goal-amendment rules, correction proposals, named nonprogress outcomes, and a deterministic E1 demonstration.

**Gate:** baseline tests pass; new tests include the dual P14 result, nonpromotion to source claim, human-authorization stubs, idempotent retry, rejected-attempt budgeting, no fictitious abandon on storage failure, event tamper detection, and pure-core import isolation.

**Current limitation:** Phase-1 gate is not claimed complete; the code lacks a fully specified lifecycle automaton and authentic capability checks. No integrated RFC invariant is certified from this checkpoint.

**Release contents:** reproducible source ZIP, test receipts, manifest, SHA-256, `STATE`, decisions, open questions and discussion summary.

## C2 — persistent journal and recovery (CURRENT, BOUNDED)

**Implementation (local prototype, partially delivered):** single serialized sequencer; four logical namespaces; WikiCore adapter outside pure engine; committed attempts, system receipts, pending reconciliation, durable event fold, stable ordinals, and collision recovery. Decide D-07 formally before implementing persistent lifecycle transitions.

**Gate:** AC-08/09/10/11/12/16 and concrete state AC-15/17 exercised with crash injection at every durable cutpoint. A rejected committed attempt costs exactly one turn; duplicate logical attempts cost none; unreadable notebook never means no event. Document the assumptions under which a safe escape is possible.

**Consolidate:** source + schema migration and recovery fixtures, failures and counterexamples, complete events history, storage notes, a fresh-process restoration test.

## C3 — inspectable headless MVP (future)

**Implementation:** goal creation/amendment, inspect/diff, resume, stop, abandon, exhaustion and accessible proof/evidence receipts through named commands. No full GUI or live agent.

**Gate:** AC-19: `restore`, `verify`, `inspect --explain --diff-from-initial` in at most three invocations. Demonstrate E1 and negative recovery/exhaustion paths. Source-level claims remain unresolved unless a separate promotion mechanism has been justified.

**Consolidate:** self-contained workspace snapshot, CLI documentation, complete E1 transcript with references, external source map, and cold-read reconstruction notes.

## C4 — bounded LLM participation (future; separate authorization)

**Implementation:** model adapter with explicit per-turn input scopes, no system-notebook write authority, separate agent records, independent deterministic verification. Compare a single critical pass with two-agent dialogue; do not assume independence or superiority.

**Gate:** malformed records and false witness proposals cannot reach verified status; no model-issued `CERTIFIED`; hidden agent rationale is not counted as evidence. Logs must distinguish model output from checker result.

**Consolidate:** pinned prompts/model settings, test fixtures, cost logs, policy for sensitive material, failure and abstention cases.

## C5 — externally meaningful evaluation (future)

**Implementation:** near-miss, valid, invalid, ambiguous and untranslatable task populations with independent reference adjudication where possible.

**Gate:** preregister denominators, false-refutation metrics, abstention and missed-detection metrics, acceptance thresholds, stopping rules and resource constraints **before measured runs**. A P14 known-answer demo alone does not estimate any rate.

**Consolidate:** immutable experiment protocol, data provenance, raw outcomes, evaluation scripts, interpretation, negative findings and next decisions.

## Mandatory progress report at every checkpoint

Every checkpoint records `current_step / total_steps`, estimated completion and estimated remaining percentage in `docs/PROGRESS.json`, with a generated `docs/PROGRESS.md`. The fixed six work-package weights total 100; partial completion fractions are disclosed estimates, not measured elapsed time or demonstrated probabilities. The denominator is the **C3 headless human-inspectable prototype**; C4 live LLM operation and C5 efficacy evaluation are outside it. Changing the target, weights or fractions requires a recorded decision, not a silent edit. The current report is generated with `python tools/show_progress.py`.

## How we checkpoint

A checkpoint is accepted only when (a) it names its precise scope, (b) its tests can be run without conversation context, (c) its source digests can be independently recomputed, (d) its decision ledger records what changed and what stayed open, and (e) its recovery limitations are stated. Do not silently rewrite sealed checkpoints: supersede with a linked version.


### C3.2 consolidation rule

The 2026-11-05 C3.2 checkpoint adds a real process-exit recovery check and a CLI-only cold-reader audit. It must contain: parent C3.1 digest receipt, code and tests, the preserved first failed progress-test output, passing rerun receipts, D-07 proposal, `STATE/DECISIONS/OPEN`, and updated fixed-weight progress scorecard. It must remain labelled **C3 acceptance pending** until an independent human reader and lifecycle adoption are resolved. No C4 live-agent capability or efficacy is implied.
