# C3.2 — Recovery hardening and inspectability audit

**Status:** implemented bounded checks, not general durability certification. 2026-11-05.

## New executable tests

- **PROCESS-01:** a child process commits an agent/user intent and exits using `os._exit(83)` before system admission. A new process sees `PENDING_UNCOMMITTED`, no committed event, and a stable-ID retry succeeds.
- **PROCESS-02:** a child process commits the `system/` event and exits immediately. New-process replay reconstructs one authoritative event, with no pending intent, and retry returns `NOOP` without duplication.
- **PROCESS-03:** an injected `OSError` before the system event write leaves a retryable pending intent. This is an injected error, **not** a real full-disk or power-cut demonstration.
- **READ-01:** a black-box script restores an exported eight-file notebook ZIP and executes the CLI verify and inspect operations; it checks event/head agreement and checks known E1 formal results. It does not import the scientific-workspace engine.
- **READ-02:** AST-based test ensures the audit script imports no internal package modules.
- **LIFE-01..03:** the implemented `WAITING_FOR_GOAL`, `WAITING_FOR_TURN`, and `QUIESCED` states have bounded, testable local escape semantics under assumed writable storage and human authorization. Quiescence is `ESCAPE_ONLY`; failed durable abandonment is `RECOVERY_REQUIRED`.

## How to reproduce

```bash
python -m unittest tests.test_process_exit_recovery tests.test_cold_reader_contract tests.test_c3_2_lifecycle_audit -v
python -m unittest discover -s tests -v
python tools/run_r0_baseline.py
```

The separate cold-reader contract can be run manually:

```bash
./bin/scientific-workspace export --workspace fixtures/E1_PERSISTENT_WORKSPACE --archive /tmp/p14-data.zip
python tools/cold_reader_audit.py --archive /tmp/p14-data.zip --workspace /tmp/p14-recovered --expect-e1
```

The audit invokes four CLI processes to inspect both JSON and narrative views, but the **reconstruction path itself** requires only restore, verify, inspect: **three named commands**. It checks reconstruction, not independent human comprehension. It does not certify scientific conclusions.

## Boundaries intentionally not claimed

1. No independent human cold-reader experiment has yet been conducted; scripted black-box checks cannot substitute for one.
2. `os._exit` happens only **after** successful SQLite persistence; hardware power loss, filesystem reorderings, and hostile writers remain untested.
3. POSIX advisory locking does not exclude adversarial processes. Actor identity remains assumed, not authenticated.
4. Only implemented provisional lifecycle states were checked; D-07 is **OPEN** and no complete finite-state proof is asserted.
5. The pending-intent disposition workflow and authenticated future agent adapter remain open.
6. `HOLD` remains active for consequential use and live autonomous operation.

## Release gate

C3.2 advances local reproducibility and crash-cutpoint coverage, but does **not** promote RFC v0.2 or the complete C3 acceptance gate. A scoped C3 final acceptance requires (a) D-07 decision, (b) a real independent reader attempting an unfamiliar investigation, and (c) an explicit decision about how far to scope untested durability assumptions.
