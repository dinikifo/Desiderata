# C3 tests — local execution receipt

Commands run from the project checkout:

```
python -m unittest discover -s tests -v
python tools/run_r0_baseline.py
```

Results: **51/51 C1–C3 project tests**, **44/44 preserved R0 tests**, without reported failures or errors. Full subprocess output is retained under `checkpoints/C3_TEST_STDERR.txt` and `checkpoints/C3_R0_STDERR.txt`; the normalized results are in `checkpoints/TEST_RUN.json`.

The tests include a **three-command cold recovery from a newly constructed ZIP** in `tests/test_inspection_cli.py`. This tests the interface without relying on an original live Python process. A separate post-package test should use the final sealed release ZIP from a fresh extracted directory before acceptance.

All tests concern a bounded local Python/SQLite program and a known-answer mathematical fixture. They do not show an agent can discover the issue independently, claim scientific efficacy, or establish external provenance.

**Release-package negative finding:** the first generated ZIP lost the launcher executable bit (`0644` instead of `0755`), and an actual cold-extraction attempt failed with `Permission denied`. The release builder has been amended to preserve POSIX file permissions; the final sealed archive must be retested rather than treating this description as proof of repair.
