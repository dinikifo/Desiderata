# Change log

## C1 — 2026-11-05 — derived local prototype (provisional)

- Copied and hash-checked R0's `core.py` without modifying it, retained the original R0 ZIP.
- Added pure `step` transitions, goal/correction records, stable attempt-ID retry semantics, quota use for committed attempts, named suspension and exhaustion outputs, and event-chain replay.
- Added a known-answer E1 in-memory scenario using the minimal P14 witness, preserving source/formalization split.
- Added new unit tests and reran the original R0 suite.
- Added consolidation workflow, project map, thematic discussion summary, decisions, open questions and AC traceability.
- **Not changed:** historical R0 code, RFC v0.2, original architecture, deadlock erratum, M1/P1/P2 source archives.
- **Not claimed:** a completed RFC Phase 1 gate, an accepted D-07 state machine, or durability/operational safety.

## C2 — 2026-11-05 — local persistent journal and recovery tests

- Added an isolated, vendored Qt-free PERSONAL.WIKI substrate with explicit source provenance and relative import changes.
- Implemented four real SQLite content/history notebook pairs and one advisory-locked local sequencer.
- Introduced staged user/agent intents and committed system event records, with explicit cross-store pending recovery and stable request IDs.
- Reconstructed state from system event replay, detecting unavailable notebooks, event gaps, altered intent bindings, and history rewrites.
- Added persistence integration tests, a persistent P14 demonstration fixture, progress scorecard and storage contract.
- Preserved R0 and C1 code; changed one C1 test's process-global import assumption to use the existing fresh-process check.
- **Not claimed:** actual principal authentication, cross-store atomicity, external anchoring, all RFC acceptance criteria, D-07 acceptance, or a human-inspectable MVP.

## C3 — read-only inspection and cold-restore milestone (2026-11-05)

- Added `bin/scientific-workspace` and module CLI with `restore`, `verify`, `inspect` operations.
- Added archive inventory/checksum verification and fixture-only restoration to a fresh staged workspace, without executing archive-supplied code.
- Added derived event/evidence view retaining source/formalization split, proposed corrections, and replay receipts.
- Added 13 targeted C3 regression tests, including three-command cold restore and adversarial bad archives.
- Retained the C2 persistent journal and R0 source as the baseline; CLI cannot authenticate the human or generalize the E1 domain.


## C3.1 — bounded local operator controls and transfer snapshots

- Added operator CLI (`init`, `goal`, `amend`, `stop`, `resume`, `abandon`) and `export` of complete four-pair project journal, with safe general data-only `restore`.
- Enforced assumed-human authorization for pure `stop`; registration and amendment preserve QUIESCED; added explicit goal digest optimistic locking.
- Added 13 subprocess/negative tests; prior 51 tests and 44 R0 baseline cases independently rerun.
- New contract and progress scorecard. `D-07` and security/identity authority remain OPEN; no agent models involved.


## C3.2 — recovery and read-path tests

- Added three subprocess/write-error recovery tests, two black-box cold-read tests and three bounded provisional lifecycle tests.
- Exposed a three-command recovery check using public CLI semantics, with a fourth optional command for cross-checking the narrative projection.
- Kept D-07, unauthenticated local authority, independent human inspection, and sudden-power-loss recovery explicitly unresolved.
- Progress target remains C3; step 6/6, estimate 93% complete and 7% remaining; C4/C5 excluded.
