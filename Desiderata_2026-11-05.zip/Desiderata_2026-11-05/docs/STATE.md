> **C3 vendor review addendum:** four upstream storage suites restored; three late-import corrections; new 9/9 mutation campaign; A1 and C4 authorization boundary still open. See `docs/consolidated/C3_VENDOR_REVIEW.md`. `HOLD` unchanged.

> **CURRENT REVIEW OVERLAY — 2026-11-05:** Read [`consolidated/START_HERE.md`] for current status, source catalog and discussion agenda. The user has **approved D-07 only for the five implemented local lifecycle states**. Older references to D-07 being OPEN below are preserved as **historical c3.2 state snapshot**, not the current decision. `HOLD` remains in effect.

---

# STATE — current checkpoint C3.2

**Current step:** 6/6. **Planning estimate:** 93% complete / 7% remaining toward the C3 accepted local headless prototype. This excludes C4 agent integration and C5 efficacy work. **HOLD remains. D-07 is OPEN.**

The C3.1 local operator CLI and data-only export/restore are retained. C3.2 adds subprocess process-exit cutpoint tests, an injected system-write failure test, and a CLI-only black-box cold-reader audit of the persisted E1 fixture. Those additions strengthen bounded recovery evidence; they do not prove physical power-loss durability, real principal authentication, semantic fidelity, or independent-reader comprehension.

For current evidence and unresolved obligations read `docs/C3_2_RECOVERY_AUDIT.md`, `docs/D07_LIFECYCLE_REVIEW.md`, `docs/OPEN.md` and `docs/PROGRESS.md`.

---

## Preserved C3/C3.1 historical state

# STATE — C3 read-only inspectability milestone

**Gate:** `HOLD` remains. **RFC:** v0.2 conditional. **D-07:** still OPEN. **Authorization:** local test code only, no autonomous agent use.

## Executed scope

- C2's four real WikiCore notebook pairs and deterministic event/draft replay are preserved.
- Three CLI commands `restore`, `verify`, `inspect` now permit cold reading of the packaged E1 fixture without importing the earlier chat. Restore verifies the full manifest, optionally checks an externally supplied ZIP digest, extracts only notebook data, and validates replay before publishing the restored directory.
- Inspection shows the goal, formally verified witness receipt for the unequal-set version, rejected premise for disjoint-set version, proposed correction, remaining source-level uncertainty, exhaustion, and a chain of seven event digests.
- **No claim of human identity authentication, independent timestamp, semantic fidelity, power-loss safety or agent efficacy.**

## Continuing blockers

The human-facing command interface is not yet writable; archive restore currently handles the shipped E1 fixture only; D-07 has not been formally accepted; hostile edits and real power cuts are outside the tested scope; scientific authority remains bounded to the finite checker; C4 LLM participation and C5 efficacy evaluation are not delivered.

## Progress reference

See `docs/PROGRESS.json` and generated `docs/PROGRESS.md`. Current step **5/6**. The scorecard is a disclosed planning estimate for the first headless inspectable prototype, not a measured probability of success or total project percent.


## C3.1 — latest implementation state (supersedes earlier C3 read-only status)

- **Working:** local operator commands for goal/amend/stop/resume/abandon, four-namespace data-only export/restore, read-only verify/inspect. A paused run stays paused across goal creation or amendment.
- **Evidence:** 51 C3 regression tests, 13 C3.1 tests and 44 R0 tests separately passed; see `checkpoints/C3_1_*` receipts. Project progress **step 6/6, estimated 90% complete and 10% remaining** toward the headless C3 acceptance target only.
- **Limit:** commands run under an assumed trusted local operator, not authenticated identities; submitted commands are not independent scientific judgments. General agent collaboration and scientific efficacy remain untested. Operational `HOLD`; D-07 OPEN.
