> **C3 vendor-review update:** Four upstream storage test suites are now packaged and passing against the vendored code. Nine **new** mutation controls caught nine mutants; this does not reproduce the original 30. A1 remains an external comprehension requirement, the C4 authorization capability split remains unimplemented. See [`C3_VENDOR_REVIEW.md`](C3_VENDOR_REVIEW.md).

# Roadmap — gated progression, not a schedule promise

## Present boundary

**C3-REVIEW-1 is a documentation-and-review checkpoint.** It records the user's scoped acceptance of D-07 without claiming that the C3 target has passed every original RFC acceptance criterion. No C4 code is being started. Consequential-use `HOLD` remains.

## C3 final acceptance (remaining 7.4% of the original weighted estimate)

| Work item | Why it matters | Acceptance evidence |
|---|---|---|
| A1. Independent cold-reader review | CLI automation is not human comprehension | Uninvolved reader reconstructs a held-out investigation and correctly distinguishes source claim, formal result, amendment and unresolved status; capture time and errors without coaching |
| A2. D-07 local status audit | Approval must match the five implemented states, transitions and guards | Machine-readable table covering permitted/refused operations, no implicit resume, exhausted/abandoned terminal; test each behavior, plus `ESCAPE_ONLY` classification |
| A3. Reconcile explicit RFC coverage gaps | 72 passing tests do not mean AC-01…AC-19 all discharged | Updated invariant→AC matrix naming proof bounds and `NO_CHECKER` entries rather than generic green status |
| A4. Scope durability exceptions | Process-exit tests ≠ arbitrary power loss | Document supported storage assumptions; tests for missing/corrupt namespace and injected I/O; genuine disk-full/power-loss only if suitable environment is available |
| A5. Rejected/no-op intent policy | Agents might accumulate ambiguous pending records | Approved idempotent retain/cancel/disposition contract with replay regression |

Acceptance can be **scoped and honest**: if unavailable hardware conditions are not tested, say so, and prohibit relying on those properties. Re-estimate the original C3 percentage only when work and gates are actually accepted.

## C4 — controlled LLM participation (future, requires discussion approval)

**Entry gate:** read `DISCUSSION_AGENDA.md`; settle security principals, draft vs admitted authority, formalization review API, and human inspection debt. Freeze a separate C4 AC matrix. **No agent-facing use of `--local-operator` flags.**

1. **C4.0 interface contract:** bounded input/output record schema; turn IDs, issuer, attempt digest and explicit budget; no hidden off-record claims about execution. Test with adversarial static payloads first.
2. **C4.1 deterministic actor adapters:** two simulated participants (not LLMs) use independent workspaces through an orchestrator; valid and invalid witness cases; no self-certification or silent source promotion.
3. **C4.2 live model adapter:** controlled model API calls under separate capabilities, captured versions/context, explicit on/off switch, no background scheduler, restart and cancellation tests. This needs separate permission/credentials and user consent; not part of this checkpoint.
4. **C4.3 agent test on known-answer E1:** preserve claim/falsifier assumptions, detect source/formalization mismatch, propose correction, stop/exhaust with inspectable journal; report costs and failures. Passing E1 is integration evidence, not efficacy proof.
5. **C4 consolidation:** code, model prompts/adapters, tests, new evidence, discussion notes, and old checkpoints; retain `HOLD` for consequential use unless separately reviewed.

The number of LLM actors is an experimental choice; two notebooks provide structural separation but not cognitive independence. An ablation with one model and different verification methods is part of the later evaluation.

## C5 — independent scientific evaluation (future)

- Create near-miss, valid, invalid, disputed/unrepresentable, insufficient-evidence and false-task datasets independently adjudicated where feasible.
- Define **false-refutation rate** over actually valid cases and **missed-discoverable-refutation rate** over independently refutable cases, with explicit denominator rules.
- Preregister sample size, threshold, resource budget, stopping/rejection decision and how `UNRESOLVED`, abstention and attempts affect measurement **before** evaluation.
- Compare one-pass, isolated critique, two actors and checker-based baselines under comparable budgets. Evaluate correctness of formalization crosswalk separately from witness checker accuracy.
- Measure how often verified corrections causally improve subsequent tasks. Inspectable history alone is not learning or convergence.

## Non-negotiable review gate before moving on

The next activity requested by the user is **discussion** of the collected objections. Only a subsequent explicit agreement should authorize C4 code or changes to `HOLD`.
