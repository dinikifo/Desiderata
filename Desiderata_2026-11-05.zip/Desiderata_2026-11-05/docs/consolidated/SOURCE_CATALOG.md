# Supplied source catalog and scope

This table records the exact available source artifacts. The **full** consolidation ZIP contains the historical ZIPs as intact files; the **code-only** ZIP retains the relevant current-source documents and original R0. Digests were computed from the supplied bytes in this runtime. They are not independent origin or timestamp attestations.

| ID | Artifact | Size (bytes) | SHA-256 | Role |
|---|---|---:|---|---|
| `M1` | `research_restore_point_M1_2026-11-05.zip` | 4,386,728 | `1e0eb673817e4b75c5594decf99346c12a2c4e34cf0c7256df60c4ef673db8a4` | Original M1 restore point, with earlier frozen research corpus and wiki materials |
| `ERRATA3` | `research_restore_point_M1_ERRATA_3_2026-11-05.zip` | 4,443,961 | `2de0b4d812bcc7cc0a68833b8bf51c125ff256ab33757296333cbba693fa10db` | Latest M1 erratum chain, including formalization-seam findings |
| `P2` | `research_progress_record_P2_2026-11-05.zip` | 8,903,410 | `cb78831c6aacbb4333a26107e68525c029d4f897e226305c554bc1f6ef1cacb5` | Scientific progress record P2, including prior P1 history |
| `P1_REVIEW` | `research_progress_record_P1_REVIEW_R1_2026-11-05.zip` | 13,378,167 | `e9b0bf248f32d9674f5c589c4a4b3066600ecaf058d1695d3c82e3319b658ab9` | Independent P1 review, edge comparison and receipts |
| `C3_2` | `scientific_workspace_C3_2_2026-11-05.zip` | 256,237 | `2bd2d3edbe8352e0b5ce51bba1a32289dd06ecbcc365288535e2f33e1d183f06` | Exact sealed pre-consolidation implementation baseline |
| `RFC` | `sources/RFC-0001-v0.2.md` | 29,216 | `82a4b65834e8d1228e05c945279df36a051f215ccebb1a1241de6f5401f11ab2` | Reviewed but not fully ratified RFC baseline |
| `ARCH` | `sources/ARCHITECTURE_2026-11-05.md` | 16,608 | `b185513c24cae6400231c3dd63faec90ca3afc23f80da38b7742ab9481230cd8` | Four-party workspace architecture |
| `ARCH_DEADLOCK` | `sources/ARCHITECTURE_ERRATA_R1.md` | 11,305 | `634f02d4c66d79c0a13942b934af0ce3a06e7b022c02e2354a8f6feb53a91021` | Deadlock and safe disposition erratum |
| `R0` | `sources/scientific_reasoning_prototype_R0_2026-11-05.zip` | 27,241 | `ad8fd86cc3a3aad960a95173c3147a35aae5f989e318ced0c50b81e143c058f4` | Preserved runnable deterministic baseline |

## Relationships and nonclaims

- M1-ERRATA-3, P2 and P1-review archives carry historical nested sources, but are **not** a single canonical mathematical proof or verified archival timeline. These outer copies are included for reader convenience and redundancy, not as a new authority.
- The earlier R0 source is included in the codebase and was historically rerun. The current consolidation never rewrites it.
- Original C3.2 source remains separately available as exact ZIP and Git commit; the new code tree is its documentation-only descendant.
- The pasted early conversational exchange is available in a separate supplied text file but is not a complete verbatim transcript of every subsequent turn. The human-readable history here is an editorial summary.

## Evidence definitions

`LOCAL_COPY_HASH_ONLY` means we can reproduce the hash but have no separate supplied external checksum; `EXTERNAL_DIGEST_FILE_AVAILABLE` means an accompanying checksum file was present and matched; neither proves authenticity. Source citation is not equivalent to a successful scientific check.
