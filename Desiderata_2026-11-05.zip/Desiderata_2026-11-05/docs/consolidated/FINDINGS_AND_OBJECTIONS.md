# Findings, observations and objections — complete review register

**44 entries**, aggregated from the discussion and supplied source history through bounded D-07 approval. This is an editorial issue register, not a finding that every point was independently re-tested during this consolidation. The machine-readable counterpart is `FINDINGS.json`.

Status meanings: `IMPLEMENTED_BOUNDED`/`FIXED_AND_TESTED` refer only to reported or separately rerun local tests; `SPEC_CORRECTED` changes a requirement, not necessarily code; `OPEN` needs evidence or a decision; `NOT_PREREGISTERED` means no binding experimental rule exists.

## Register

| ID | Category | Observation / objection | Disposition | Source |
|---|---|---|---|---|
| F-01 | Mechanism | Self-selected game protocol is circular without an exogenous anchor | `QUALIFIED` | M1 |
| F-02 | Mechanism | Original mutual scoring is gameable under explicit payoff assumptions; original universal impossibility claims were too strong | `REPLACED` | M1 |
| F-03 | Mechanism | End-only review plus optional halt creates an accountability escape under particular incentives | `REPLACED` | M1 |
| F-04 | Method | “Follow the scientific method” is not a single finite-checkable predicate | `BOUNDARY_RETAINED` | M1 |
| F-05 | Authority | Original well-being-only human authorization language was underspecified | `REPLACED` | M1 |
| F-06 | Validator | Empty `could_not_check` list does not establish completed check coverage (V5) | `SPEC_CORRECTED` | ERRATA3 |
| F-07 | Evidence | Claimant-selected citation bundle can omit decisive premises or sources | `OPEN` | ERRATA3 |
| F-08 | Evidence | `EVIDENCE_SET_INADEQUATE` is an investigation result, not a truth verdict | `SPEC_CORRECTED` | ERRATA3 |
| F-09 | Certification | Record `ADMITTED` is not scientific `CERTIFIED`; no model-created certification | `IMPLEMENTED_BOUNDED` | ERRATA3 |
| F-10 | Agents | Two same-model actors may share correlated errors; rotation is not independence | `OPEN` | ARCH |
| F-11 | Agents | Two namespaces give attribution and resistance to cross-revision, not epistemic independence | `QUALIFIED` | ARCH |
| F-12 | Verification | Required-check accounting does not prove check-plan adequacy | `OPEN` | ERRATA3 |
| F-13 | Verification | Refutation claim needs a verified witness, not a plausible narrative | `IMPLEMENTED_BOUNDED` | ERRATA3 |
| F-14 | Formalization | Proposition 14 source premise and proof disjointness assumption diverge | `CONFIRMED_BOUNDED` | M1 |
| F-15 | Formalization | Sound proof checker can check the wrong predicate when translation silently changes premises | `OPEN` | ERRATA3 |
| F-16 | Formalization | Source ambiguity and reviewer disagreement are orthogonal | `SPEC_CORRECTED` | ERRATA3 |
| F-17 | Formalization | Author intent of ambiguous P14 prose is not established | `OPEN` | ERRATA3 |
| F-18 | Statistics | Uniform finite-model ratio must condition on the actual premise: 160/210, 750/930 | `CORRECTED` | ERRATA3 |
| F-19 | Correction | Verified formal result must not automatically rewrite or refute original human task | `IMPLEMENTED_BOUNDED` | R0 |
| F-20 | Correction | An active projection must support revisions, dependency invalidation and challenges to earlier corrections | `OPEN` | RFC |
| F-21 | Progress | More notes, turns or agreement cannot be taken as scientific progress; convergence not guaranteed | `OPEN` | RFC |
| F-22 | Export | Markdown `BUNDLE.md` omitted `pw-claim` custom fields and full history | `SPEC_CORRECTED` | ERRATA3 |
| F-23 | Integrity | A locally controlled digest/status receipt does not establish independent chronology or origin | `OPEN` | M1 |
| F-24 | Index | Plural conjunctions/ranges repeatedly lost typed link targets in proposition and progress indexes | `OBSERVED` | P1_REVIEW |
| F-25 | Index | P1/P2 schemas differed; a P1-only checker could miss a live P2 index omission | `CORRECTED_IN_R0` | P1_REVIEW |
| F-26 | Deadlock | Every reachable state having a resume wrongly includes terminal states | `SPEC_CORRECTED` | ARCH_DEADLOCK |
| F-27 | Deadlock | 36 legal type cells do not prove a concrete guarded action is enabled | `OPEN` | ARCH_DEADLOCK |
| F-28 | Deadlock | Safe abandonment/escape is not productive investigation continuation | `SPEC_CORRECTED` | ARCH_DEADLOCK |
| F-29 | Deadlock | “Human minutes, not hours” is not proved by a finite transition table | `OPEN` | ARCH_DEADLOCK |
| F-30 | Journal | Cross-namespace committed party post vs system receipt creates a real crash window | `IMPLEMENTED_BOUNDED` | C3_2 |
| F-31 | Security | Namespace write isolation in software is not sufficient without actual principal capabilities | `OPEN` | C3_2 |
| F-32 | Sequencing | Retry identity belongs to stable attempt ID; payload commitment prevents altered retries | `IMPLEMENTED_BOUNDED` | RFC |
| F-33 | Journal | Rejected/no-op staged drafts lack an approved immutable disposal policy | `OPEN` | C3_2 |
| F-34 | Lifecycle | Goal create/amend while QUIESCED must not auto-resume | `FIXED_AND_TESTED` | C3_2 |
| F-35 | Inspection | Three-command cold reconstruction is not independent human comprehension | `OPEN` | C3_2 |
| F-36 | Durability | Process `os._exit` tests do not establish power-loss, malicious-writer or real disk-full safety | `OPEN` | C3_2 |
| F-37 | Evaluation | False-refutation rate needs valid-case denominator and independently adjudicated reference | `NOT_PREREGISTERED` | ERRATA3 |
| F-38 | Evaluation | Missed discoverable refutations require separate denominator and case definition | `NOT_PREREGISTERED` | ERRATA3 |
| F-39 | Evaluation | R0/C3 tests are deterministic known-answer integration, not evidence two agents outperform one | `OPEN` | R0 |
| F-40 | Governance | Document/erratum proliferation previously outpaced implementation and sometimes asserted unbuilt changes | `ACTIVE_RISK` | M1 |
| F-41 | Approval | D-07 five-state local lifecycle was open in C3.2 and is now bounded-approved by user | `APPROVED_BOUNDED` | C3_2 |
| F-42 | Trust | `--local-operator` is an acknowledgement, never authentication | `OPEN` | C3_2 |
| F-43 | Evidence | A clean archive manifest proves local consistency, not that the source artifact was genuine | `BOUNDARY_RETAINED` | P1_REVIEW |
| F-44 | Completion | A paused/no-progress investigation can satisfy local escape rules forever | `OPEN` | ARCH_DEADLOCK |

## Follow-up obligations keyed to the register

- **F-07** — Permit bounded evidence-set completeness challenge and external-source request.
- **F-10** — Compare separated passes, two agents and independent deterministic checks.
- **F-12** — Evaluate check-plan quality separately from coverage.
- **F-15** — Separate source, candidate reading, formal predicate and promotion gate.
- **F-17** — Keep original source assessment UNRESOLVED absent accepted source mapping.
- **F-20** — Specify versioned supersession and dependency invalidation tests.
- **F-21** — Define bounded knowledge/progress measurements independent of volume.
- **F-23** — Specify external anchor only when preregistration claims need it.
- **F-27** — Derive reachable configurations including payload, storage and gate guards.
- **F-29** — Bound command count separately and test human comprehension time.
- **F-31** — Agent-facing authenticated capabilities before C4.
- **F-33** — Define explicit disposition receipts and turn budget accounting before agent intake.
- **F-35** — Uninvolved reader test with unfamiliar investigation, elapsed time and error report.
- **F-36** — State supported environment and injected vs physical fault boundaries.
- **F-37** — Build near-miss test population; predeclare threshold and sample size.
- **F-38** — Measure against known refutable claims; define discovery budget.
- **F-39** — C5 comparative evaluation with matched budgets.
- **F-40** — Demand a runnable regression or explicit decision before adding new infrastructure.
- **F-42** — Do not expose it as an LLM principal; implement capability controls.
- **F-44** — Quiescence/turn budgets must not be presented as convergence.

## Reading instruction

A relationship in this ledger indicates an *editorial association* with a source or a requirement; it is not mathematical proof of that finding. A historical correction may be closed in the specification but still unimplemented in the software. Do not update dispositions based solely on this summary; use a new verified test or explicit decision receipt.

