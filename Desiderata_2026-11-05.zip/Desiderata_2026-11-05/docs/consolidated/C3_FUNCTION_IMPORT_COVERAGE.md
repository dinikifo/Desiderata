# C3.4 — Function-local import coverage and v1→v2 migration fixture

**Date:** 2026-11-05. **Scope:** C3 storage-layer quality; no C4 agent code. **Operational gate:** `HOLD` unchanged.

## Finding and disposition

The reviewer correctly identified a general blind spot: the prior import AST rule rejected obsolete flat imports but did not establish that every function-local import site was exercised. The migration path's `from .db import TiddlerDB` was textually correct but had no migrated-database fixture.

**Change (implemented):** `tools/check_vendor_local_import_coverage.py` uses Python's AST to discover every `import` / `from ... import ...` nested inside functions in `storage/vendor_pw/*.py`, then invokes named tests in fresh interpreters under standard-library `sys.settrace`. Every discovered site must have a witnessed line event **from a passing test process**, and every named job must pass. The report also contains per-module SHA-256 hashes, per-site test attribution and a separate refusal condition for unknown sites. There is no fixed list of expected sites; a new nested import creates a new coverage obligation. A regression suite proves the gate rejects synthetic missing sites, failed tests offering coverage, empty-site/job sets, **and distinct imports on one source line**, which line tracing cannot distinguish.

This is **executed-line coverage**, not independent evidence that an import resolved successfully, not path coverage for every branch, and not a proof of scientific or storage correctness. For the formerly unexecuted migration site, we added separate behavioral tests of successful migration. We should not describe it as `VERIFIED_WITHIN_MODEL` for RFC invariants I-01/I-08, which are broader than this check.

## Real behavioral fixture

`tests/test_vendor_migration.py` creates a bounded legacy v1 SQLite database from scratch, then verifies:

1. read-only planning identifies a required migration;
2. migration creates a new v2 database and runs the previously unexercised `schema_migrations.migrate()` local import;
3. source-file digest is unchanged, destination digest matches the reported digest;
4. migrated post and search/tag projections work, exercising `db.filtered_title_links()`'s local import;
5. attempting to reuse the output path refuses overwrite;
6. a fault after adding a column fails, does not publish an output, and leaves the source unchanged;
7. `schema_migrations.main(['plan', ...])` runs the local `argparse` import and returns a structured successful plan.

This demonstrates those **specific v1→v2 test cases**. It does not validate every historical schema, malicious or concurrent mutation, physical power loss, or cross-platform hard-link semantics.

## Observed result (fresh C3.4 release candidate)

- 5 of 5 discovered vendored function-local import sites reached in passing traced tests: `db.py:490`, `exporters.py:115–116`, `schema_migrations.py:316` and `schema_migrations.py:349`. Source digests, named tests, and per-site outcomes appear in `checkpoints/C3_4_IMPORT_COVERAGE.json`.
- 8 new regression tests pass, including a deliberately unreachable synthetic import, a failing-job attribution trap and an ambiguous same-line import case.
- Original 72 project tests remain green in separately executed suites; six prior vendor regression tests remain green. Combined project total: **86 passing**, with **one separate C4 preflight skip**.
- Preserved R0 baseline passes **44/44**.
- The black-box negative probe (`tools/negative_import_coverage_probe.py`) copied the project into a disposable directory, inserted an unvisited import, and confirmed that the real coverage gate exited nonzero and identified `_coverage_probe.py:2:never_called`. Receipt: `checkpoints/C3_4_NEGATIVE_IMPORT_PROBE.json`.
- Exact commands and split-suite counts are recorded in `checkpoints/C3_4_TEST_REPORT.json`, including the skipped C4 guard.

## Reproduction

From the extracted release directory:

```bash
python -B -m unittest -v tests.test_vendor_migration tests.test_vendor_local_import_coverage
python -B tools/check_vendor_local_import_coverage.py
python -B tools/negative_import_coverage_probe.py
python -B tools/run_c3_4_tests.py
python -B tools/verify_checkpoint.py
```

The first is eight added tests. The second scans the vendored source afresh and fails if any function-local import is unvisited. The third executes and records the existing split suites; check its JSON receipt for test counts and any skips. The last verifies the entire checkpoint inventory against its self-contained manifest. The manifest proves local consistency, not independent provenance or secure timestamps.

## Review notes / remaining objections

- **The reviewer is correct about the class of defect.** Inspecting only textual changes or syntactic correctness did not establish runtime reachability.
- **Coverage must stay bound to source.** Re-run whenever vendored source changes; report module digests prevent transferring stale coverage to a new version by implication.
- **Execution is weaker than correctness.** A line trace arrives before the import statement executes; only tests asserting observable behavior can confirm the imported API worked. We supplied the missing real migration fixture rather than treating a coverage percentage as the answer.
- **Scope is explicit.** The gate covers function-local imports inside the vendored Python storage subtree, not every lazy import throughout the workspace or every branch of the vendor implementation.
- **Do not convert checks into a project-wide theorem.** Existing `PARTIAL_ONLY` / `NO_INTEGRATED_CHECKER` traceability statuses remain unchanged.
- **A1 is still open.** The external cold reader is not replaced by code coverage or the CLI's mechanical restore test.
- **C4 is still blocked.** Agent capability isolation, new-domain evaluation, and authorization design are separate decisions; none is advanced by this change.
- **Historic mutations remain historic.** Nine fresh selected mutations were caught in C3.3; the earlier 30-case campaign was not reproduced, and this checkpoint does not claim it was.

**Progress:** C3, step **6/6**; **about 90% complete, about 10% remaining** under the previously published C3 planning model. No additional fraction credited for quality control. Live C4 and C5 are excluded.
