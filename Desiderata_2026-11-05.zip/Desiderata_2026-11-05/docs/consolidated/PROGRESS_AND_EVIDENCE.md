# Progress, evidence, and estimate denominator

## Current checkpoint status

- **Implementation baseline:** C3.2, preserved Git commit `e4bc2dec75504a2c8d52552bc3fa65d5a607b94b`.
- **Consolidation stage:** C3-REVIEW-1, documentation and source-catalog only. **No new engine functionality**; no credit for document production.
- **C3 target:** first local headless, persistent, human-inspectable prototype.
- **Progress:** **step 6/6**. Previously published fixed-weight estimate **92.6% complete / 7.4% remaining**, shown rounded **93% / 7%**. This is not a probability of success or measured effort; D-07 approval is recorded but the weights are not quietly adjusted.
- **Separate future scopes:** C4 controlled live LLM participation (not implemented), C5 independent scientific evaluation (not started). **No defensible overall percentage** exists for C3+C4+C5 without a newly agreed denominator.

## Fixed-weight C3 scorecard (unchanged)

| Step | Weight | Planned fraction | Weighted contribution | Current status |
|---|---:|---:|---:|---|
| 1. Source baseline and RFC | 10% | 100% | 10.0 | Done |
| 2. Deterministic core | 20% | 90% | 18.0 | Partial |
| 3. Four-namespace journal/replay | 25% | 92% | 23.0 | Partial |
| 4. Recovery/failure handling | 20% | 86% | 17.2 | Partial |
| 5. Human inspection/control | 15% | 100% | 15.0 | Bounded local MVP |
| 6. Cold restore and acceptance | 10% | 94% | 9.4 | In progress |
| **TOTAL** | **100%** | — | **92.6%** | **7.4% remains** |

The arithmetic and historical scorecard remain in `docs/PROGRESS.json`. The bounded user approval of D-07 does **not** itself discharge independent human comprehension or hard storage durability.

## Evidence ladder

| Evidence | Result supported | Does **not** support |
|---|---|---|
| Sealed R0 runner, historical 44 tests | Finite admission/witness/index behavior | General scientific accuracy |
| C3.2 historical 72 passing tests | Named core/storage/CLI crash and recovery cases | Universal crash safety, security or live-agent quality |
| E1 restore/verify/inspect | Seven-event known-answer reconstructible scenario | Blind scientific discovery |
| Process `os._exit` tests | Recovery from *specified* local crash points | Physical sudden power loss, remote malicious writer |
| ZIP manifest hash verification | In-package file consistency | Independent time or origin |
| D-07 approval in conversation | Local five-state lifecycle contract accepted | Implementation of deferred states or C4 authorization |

A new consolidation test receipt, if produced, is at `checkpoints/C3_REVIEW_BASELINE_TESTS.json`; its `executed` fields distinguish fresh execution from preserved reports.

## Roadmap summary

- **C0:** source and RFC basis, complete in bounded sense.
- **C1:** pure engine and R0, implemented with scoped limitations.
- **C2:** four-namespace persistence, implemented with recovery limits.
- **C3:** inspectable local prototype, working; bounded D-07 now approved; an uninvolved reader's comprehension and broader environmental durability remain open. Progress above applies only here.
- **C4:** LLM adapters and controlled two-actor investigation, **not begun**.
- **C5:** independent scientific performance and comparative evaluation, **not begun**.

## Release checklist going forward

Every later checkpoint states (i) current step/total for its **named scope**, (ii) weighted completed/remaining estimate and denominator, (iii) commit+ZIP digest, (iv) fresh tests and original historical reports separately, (v) new findings and remaining open decisions, and (vi) whether `HOLD` changed (default: unchanged). Do not increase % merely for emitting a new archive.
