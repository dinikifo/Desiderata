# Consolidation verification and explicit limits

**Checkpoint:** C3-REVIEW-1, 2026-11-05. This is a **documentation-only implementation consolidation**, not a new scientific-agent capability.

## Preserved baseline

- Published original C3.2 ZIP SHA-256: `2bd2d3edbe8352e0b5ce51bba1a32289dd06ecbcc365288535e2f33e1d183f06` — recomputed from supplied bytes and matched the separately supplied digest file.
- C3.2 Git baseline commit: `e4bc2dec75504a2c8d52552bc3fa65d5a607b94b`.
- No content changes to `scientific_workspace/` or `tests/` in this documentation-only consolidation. The release-builder metadata and a new documentation concordance verifier are tooling changes, not changes to the engine.
- `sources/historical_archives/` is **not** copied into the development source tree; full review distribution includes original ZIPs outside the tracked code directory for a compact Git lineage. See `SOURCE_CATALOG.md`.

## Fresh execution in consolidation

| Execution | Fresh result | Log | What is demonstrated |
|---|---|---|---|
| Deterministic core, persistence, process exit, lifecycle, cold reader, progress, import boundary | **46/46 PASS** | `checkpoints/consolidation/TARGETED_TESTS.txt` | Named bounded local behavior |
| Human operator and inspection CLI | **26/26 PASS** | `checkpoints/consolidation/OPERATOR_INSPECTION_TESTS.txt` | Existing local CLI control, archive and negative cases |
| Preserved R0 baseline | **44/44 PASS** | `checkpoints/consolidation/R0_BASELINE.txt` | Existing R0 mathematical checker and index regression tests |
| Monolithic 72-test attempt | **INCOMPLETE/TIMED OUT** | `checkpoints/consolidation/PROJECT_TESTS.txt` | Not a passed test run; the suites were subsequently rerun separately |

The 46+26 tests exhaust the current 72-test suite **in two separate processes**; they do not constitute a single invocation. The original C3.2's historical `72/72` and `44/44` receipts remain in `checkpoints/C3_2_*` and are labeled as earlier evidence.

## Package integrity checks

- `tools/verify_checkpoint.py` checks exact file inventory and SHA-256 values, **not independent origin**.
- `tools/verify_consolidation.py` checks the 44 findings' IDs/source refs, agenda refs, unchanged six-step progress arithmetic, scoped D-07, internal code source receipts and the three executed regression logs. It optionally checks historical ZIP digests when given their containing directory.
- A malicious administrator can modify code, receipts and rehash an archive; the package does not include an independent signature, public timestamp or external provenance anchor.

## Explicit untested/unsupported assertions

No live LLM integration; no independent-reader comprehension study; no general claim truth verifier; no source-prose semantic fidelity guarantee; no physical power-cut guarantee; no adversarial principal authentication; no measured scientific efficacy or error-rate threshold; no claim of convergence to objective truth. `HOLD` remains. 
