> **Latest status:** [`C3_4_STATUS.json`](C3_4_STATUS.json). Earlier `CURRENT_STATUS.json` is a preserved pre-C3.4 snapshot.

> **Latest C3.4 quality addendum:** [`C3_FUNCTION_IMPORT_COVERAGE.md`](C3_FUNCTION_IMPORT_COVERAGE.md) — automated vendor function-local import coverage, with a real legacy migration fixture. It does not lift `HOLD` or authorize C4.

> **Latest addendum:** [`C3_VENDOR_REVIEW.md`](C3_VENDOR_REVIEW.md) records recovered vendor tests, the lazy-import defect, the fresh 9-mutation campaign and remaining decisions. Earlier statements in this file are preserved as the prior consolidation checkpoint.

# Scientific Workspace — canonical consolidated handover

**Date:** 2026-11-05. **Checkpoint:** C3-REVIEW-1 (documentation-only consolidation of the C3.2 code baseline). **Status:** bounded local prototype; discussion gate before C4. **Consequential-use HOLD:** unchanged.

## Read this in order

1. [`PROJECT_CHARTER.md`](PROJECT_CHARTER.md) — what we are actually trying to build, limits and criteria.
2. [`PROGRESS_AND_EVIDENCE.md`](PROGRESS_AND_EVIDENCE.md) — step 6/6, 92.6% estimated complete, 7.4% remaining for *C3* only; what the tests establish.
3. [`IMPLEMENTATION_MAP.md`](IMPLEMENTATION_MAP.md) — current runnable code, commands, exact trust boundaries and source hierarchy.
4. [`HISTORY_AND_DISCUSSION.md`](HISTORY_AND_DISCUSSION.md) — chronological account from the original monograph to C3.2 and this approval.
5. [`DECISIONS_AND_D07.md`](DECISIONS_AND_D07.md) — accepted/conditional decisions; D-07 bounded approval is now recorded.
6. [`FINDINGS_AND_OBJECTIONS.md`](FINDINGS_AND_OBJECTIONS.md) plus [`FINDINGS.json`](FINDINGS.json) — issue register, evidence strength and disposition.
7. [`ROADMAP.md`](ROADMAP.md) — what remains, what the next phase would require, and the acceptance gates.
8. [`DISCUSSION_AGENDA.md`](DISCUSSION_AGENDA.md) — questions to settle together **before** any C4 coding.
9. [`VERIFICATION_AND_LIMITS.md`](VERIFICATION_AND_LIMITS.md) — what was freshly rerun, what was only historically reported, and what remains unproved.
10. [`SOURCE_CATALOG.md`](SOURCE_CATALOG.md) and [`SOURCE_CATALOG.json`](SOURCE_CATALOG.json) — supplied evidence and digest references.

## Authority and document interpretation

- The C3.2 source code, tests and archived receipts are the **implementation baseline**, not rewritten by this checkpoint. The documentation here is a derived editorial synthesis. The previous C3.2 ZIP and Git history remain available byte-for-byte.
- `docs/STATE.md`, `docs/OPEN.md`, `docs/DECISIONS.md`, `docs/D07_LIFECYCLE_REVIEW.md` and earlier checkpoints contain **historical as-of statements** (including that D-07 was open). This file and `DECISIONS_AND_D07.md` record the user's subsequent scoped approval; old statements remain legible as history, not current decisions.
- Testing a finite checker is different from validating source interpretation. Passing unit tests is different from measuring LLM scientific efficacy. Recording an event is different from proving it came from an authenticated person.
- Source digests demonstrate byte consistency of supplied files at this checkpoint; they do not authenticate their origin or their creation times.
- The discussion history is an editorial reconstruction, **not a verbatim authenticated transcript**. The historical archives are preserved for independent reading.

## Local code starting point

From this repository directory using Python 3.11+:

```bash
python -m unittest discover -s tests -v
python tools/run_r0_baseline.py
python tools/show_progress.py
./bin/scientific-workspace --help
```

The three existing cold-read operations are `restore`, `verify` and `inspect`. The local operator commands (`init`, `goal`, `amend`, `stop`, `resume`, `abandon`, `export`) require explicit acknowledgement of the local-trust assumption. **This is not authentication.** See the original README and C3.1 operator contract for exact syntax.

## What approval means

The user's message “approved” follows the explicit recommendation to accept **the five implemented D-07 lifecycle states for the bounded local prototype**, postponing advanced inspection/authorization/recovery states and keeping `HOLD`. It is not approval of unimplemented transitions, agents, efficacy claims, or consequential deployment.

**Next action:** review the consolidated objections and decision agenda together. No C4/LLM integration is authorized by this documentation consolidation.
