# Current codebase and implemented boundaries

**Canonical code baseline:** the preserved C3.2 Git commit `e4bc2dec75504a2c8d52552bc3fa65d5a607b94b`. The current consolidation is a **documentation-only descendant**. It does not implement C4, change the reasoning algorithm or claim new recovery correctness.

## Logical source map

| Location | Function | Boundaries |
|---|---|---|
| `scientific_workspace/engine/` | Pure deterministic goal/attempt, admission and scoped formal verification core | Assumes supplied authority flags in bounded tests; not an authentication system |
| `scientific_workspace/storage/` | Four WikiCore notebook pairs, staged intents, system receipts, replay and reconciliation | Local filesystem, cooperative writer model; no cross-DB transaction |
| `scientific_workspace/interface/` | CLI, explanation projection, archival export/restore and validation of snapshots | Three-command cold-read plus local control; not independent human comprehension |
| `scientific_workspace/vendor/` or bundled WikiCore-adapted modules | Existing wiki SQLite content/history primitives | See `sources/VENDOR_WIKI_PROVENANCE.json` for exact provenance; no general production permission model |
| `tests/` | Bounded regression, negative, process-exit and cold-read tests | Test scope is not universal scientific reliability |
| `tools/run_r0_baseline.py` | Re-verify and run sealed R0 tests | Historical R0 evidence preserved |
| `tools/show_progress.py` | Display fixed-weight C3 scorecard | Planning weights, not measured labor |
| `tools/verify_checkpoint.py` | Verify exact file digest inventory | Local consistency only; not independent provenance |
| `fixtures/` | Persistent known-answer Proposition 14 workspace and receipts | Known answer; not blind agent discovery |
| `sources/` | RFC v0.2, related architecture and erratum, R0, local source receipts | Supplied documents are evidence of proposal/history, not automatically current truth |
| `docs/` | Historical milestone docs and current consolidation index | Read `docs/consolidated/START_HERE.md` first for current status |

## Public local operations

- Inspect E1: `restore`, `verify`, `inspect --explain --diff-from-initial`.
- Human controls: `init`, `goal`, `amend`, `stop`, `resume`, `abandon`, `export`.
- Rerun tests: `python -m unittest discover -s tests -v` and `python tools/run_r0_baseline.py`.

**Do not grant LLMs direct access to these local-operator controls.** `--local-operator` acknowledges a test-mode trust assumption but authenticates no one. `HOLD` remains.

## Storage semantics worth preserving

1. One party-local drafted post is not a system-admitted event.
2. A crash between the party write and system write can leave a **pending** record; replay must name it, not silently count a turn.
3. An attempt's logical identity is its stable ID, not byte-for-byte transport equality; its first canonical payload is bound to prevent changed retry semantics.
4. Changing any existing journal post in place is a replay-integrity violation even if the database itself records a formally valid update.
5. `QUIESCED` stays paused after goal creation or amendment; explicit `resume` is a separate operation.
6. Formalization-specific checker results cannot be silently promoted into source-level conclusions.

## What is not implemented

LLM model adapter; two-agent live turn orchestration; authenticated principal isolation; general domain verifier registry; independently verified formalization interpretation; independently measured scientific efficacy; human-comprehension study; physical power-loss guarantees. These are **not** implied by the fact that R0 and C3.2 local tests pass.
