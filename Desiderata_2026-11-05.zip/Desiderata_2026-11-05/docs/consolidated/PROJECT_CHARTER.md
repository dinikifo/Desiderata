# Project charter and scope

## Mission

Build an **auditable scientific reasoning workspace** in which human-defined tasks — correct, wrong, ambiguous, inconsistent, underspecified or unsolvable under declared bounds — can be investigated. LLMs may later propose claims, tests and challenges, but do not confer epistemic authority. The working interpretation can change while preserving original claims, evidence, attempts, verified scoped results and authorized goal amendments.

A useful run may end with (a) a bounded verified formal result, (b) a discovered flaw and proposed repair, (c) blocked investigation with explicit missing evidence, (d) declared exhaustion, or (e) authorized abandonment. None implies general truth convergence.

## Distinct layers and authority

| Layer | What it records | What it cannot establish alone |
|---|---|---|
| User goal | Versioned statement, human amendment, authorization record | Correctness or feasibility of goal |
| Agent workspace | Attributed proposals, objections, candidate explanations | Scientific validity, or authority over other parties |
| Admission validator | Syntax, digest bindings, check-plan coverage, permitted transitions | Adequacy of checks or truth |
| Domain checker | Result over its **formalized predicate** and assumptions | Faithful interpretation of source prose |
| Formalization review | Interpretation candidates and reviewer agreement/disagreement | Author intent by default |
| System event journal | Committed decisions, receipts, progress state | Independent origin attestation or actual real-world truth |
| Active knowledge projection | Current scoped view derived from recorded events | An independent mutable truth oracle |

## Invariants to implement and test (not blanket theorems)

1. Preserve history under the application contract; version every correction or goal amendment.
2. Separate record admission, formal witness result, source-claim assessment, formalization review and investigation lifecycle.
3. Do not permit LLMs to issue `CERTIFIED`; a formal `REFUTED` requires a domain checker receipt and is not automatically promoted to source truth.
4. Make the goal challengeable by agents but amendable only via authorized human control.
5. Distinguish unreadable/unavailable evidence from nonexistent evidence, and unknown from false.
6. Derive current state by replay; identify pending drafts, duplicate attempts, unavailable namespaces, and incomplete writes.
7. Separate *safe escape/disposition* from *productive continuation*; a `QUIESCED` loop is not progress.
8. Preserve enough evidence for a reader to reconstruct what was attempted and why it remains unresolved.
9. Never infer scientific progress from note count, turns, agent agreement or schema validity alone.

## Explicit non-goals at the present checkpoint

No universal theorem of scientific validity; no autonomous goal rewriting; no LLM-controlled namespace access; no external provenance authority; no guaranteed monotonic convergence; no current rate estimate for false refutations; no proof of human-minute comprehension; no industrial power-loss or malicious-writer durability guarantee. The project remains under a `HOLD` gate for consequential use.

## First bounded diagnostic

The Proposition 14 source/proof mismatch is a **known-answer case**. Under the unequal-set reading, sets `{a}` and `{a,b}` are different but permit the same constant adequate action `a`; under the disjoint-set reading, this witness does not satisfy the premise. The finite checker may refute the first formalization while the original prose remains `UNRESOLVED`. The source author's unique intended interpretation was not established.

## Success criteria

**C3 local MVP:** commands create/amend/pause/resume/abandon; persist and restore; reconstruct and explain a bounded E1 investigation without the original chat; name interruptions and uncertainty. **C4:** model-produced, bounded challenges pass through these same boundaries without new authority. **C5:** independently adjudicated performance, error and cost evaluation with preregistered thresholds; reject unsupported efficacy claims.
