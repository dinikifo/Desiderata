# C3 — vendored storage test recovery and new defect (review R2)

**Review stage:** C3 quality consolidation; **not** an authorization to implement C4. `HOLD` remains in effect. D-07 remains accepted only for the five bounded local lifecycle states.

## Verdict and observed evidence

The reviewer was correct that the consolidated code carried the vendored PERSONAL.WIKI implementation without its original four headless regression scripts. The original scripts and helper were recovered from the **unmodified historical M1 nested Phase 2 archive**. Original source bytes are retained in `tests/vendor_legacy_scripts/original_*`, with digests in `sources/VENDOR_WIKI_REPAIR_RECEIPT.json`; the adapted scripts preserve assertions and adjust import/path resolution to the vendored package.

Restoring them found an additional **reproduced runtime defect**: `WikiCore.export_bundle` failed with `ModuleNotFoundError: No module named 'db'`. Three function-local flat imports remained after vendoring. They have been rewritten to relative imports in `exporters.py` (two) and `schema_migrations.py` (one). The export code path is now covered by its upstream deterministic suite and a new regression test. The migration-path import is AST guarded but **has not been independently exercised as a full migration operation**.

### Test results (fresh, separated from old release receipts)

| Run | Result | Evidence |
|---|---|---|
| Original C3.2 core / persistence / recovery | 46 passed | `checkpoints/C3_3_CORE_TESTS.txt` |
| Original operator controls | 13 passed | `checkpoints/C3_3_OPERATOR_DIAGNOSTIC.txt` |
| Original inspection CLI | 13 passed | `checkpoints/C3_3_INSPECTION_TESTS.txt` |
| New vendor regression wrapper + import checks | 6 passed | `checkpoints/C3_3_VENDOR_TESTS.txt` |
| Future agent capability preflight | 1 skipped | no adapter; **not** C4 evidence |
| Preserved R0 baseline | 44 passed | `checkpoints/C3_3_R0_BASELINE.txt` |
| Fresh focused mutation campaign | 9/9 caught | `checkpoints/C3_3_MUTATIONS.json` |

The whole-suite attempt timed out. It is **not counted as passing**; the split runs cover all 72 pre-existing tests and 6 new passing checks. The historical 30 mutations remain **historical claims** because the original mutation runner was not present. A fresh 9-case campaign was constructed and is openly narrower, including two regressions that recreate the lazy import failures.

## Three decisions for discussion before C4

**A1 — Human comprehension.** An uninvolved reader cannot be simulated by a CLI. A real external reviewer can fulfill A1; a fresh context session is only a labeled proxy, and the mechanical 3-command criterion is not equivalent. Recommended status: `BLOCKED_EXTERNAL_REVIEWER` for the comprehension target, with the bounded command criterion recorded separately as achieved for the E1 fixture. Not an excuse to permanently mark A1 passed.

**C4 operator authority.** The command-line `--local-operator` flag is a self-acknowledgment, not identity authentication. `tests/test_c4_future_boundary.py` expresses a syntactic guard but skips with `C4_GATE_NOT_EVALUATED` because no agent adapter exists yet. Before C4 entry, the API must use an actual capability split and test denied attempts, including indirect invocation; a static AST check alone cannot prove authority isolation.

**Estimate.** Retain the pre-existing C3 planning fraction in machine-readable `docs/PROGRESS.json` for comparability. Present it publicly as **about 90% of C3 scope**, with no reestimation credited to restoring tests. That percentage excludes C4/C5 and says nothing about model efficacy.

## Epistemic boundaries

- Recovering upstream tests gives this package tests of *vendored* code, not proof of whole-invariant correctness.
- Passing 9 mutations does not reproduce 30 historical mutations or guarantee mutant coverage.
- No scientific source claim is certified by these tests.
- No independently anchored timestamp or authenticated agent identity has been introduced.
- No C4 agent code was created; consequential-use `HOLD` remains.

## Next review agenda

1. Decide how A1 will be fulfilled (external reviewer) or explicitly deferred without claiming equivalence.
2. Approve the C4 capability design and its negative tests before any agent adapter.
3. Choose whether to exercise the legacy schema-migration path in a dedicated fixture prior to treating the vendored layer as stable.
4. Review which quantified RFC properties remain `PARTIAL_ONLY` / `NO_INTEGRATED_CHECKER` before altering the roadmap.

### Reproducing the checks

```bash
python -B -m unittest -q tests.test_engine tests.test_persistence tests.test_process_exit_recovery tests.test_c3_2_lifecycle_audit tests.test_cold_reader_contract tests.test_progress tests.test_baseline_and_imports
python -B -m unittest -v tests.test_operator_and_snapshots
python -B -m unittest -v tests.test_inspection_cli
python -B -m unittest -v tests.test_vendor_regressions tests.test_c4_future_boundary
python -B tests/mutation_vendor.py
python -B tools/run_r0_baseline.py
```

The last vendor preflight has one deliberate `skip` (no C4 adapter exists); it is not evidence of a passing agent-capability test. The full aggregate suite has a timeout receipt; separate successful runs are recorded instead.

**Progress checkpoint:** C3 step **6 of 6**; mechanically retained planning estimate **92.6% complete / 7.4% remaining** (public interpretation: **about 90% complete**). This is an estimate of work toward accepted *local, inspectable C3*, excluding C4 and C5. No progress weight was awarded for test repair.
