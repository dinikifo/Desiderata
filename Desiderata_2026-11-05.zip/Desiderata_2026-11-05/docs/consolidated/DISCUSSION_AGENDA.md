# Discussion agenda — issues to resolve before C4

**Purpose:** evaluate the consolidated system rather than rush into a sixth documentation layer or premature live-agent integration. User requested discussion before moving on. The prompts below are **open questions**, not assumed decisions.

## Priority A — scientific authority and semantics

1. **What counts as verified progress?** A formal counterexample, a resolved ambiguity, a new observation, or a narrower justified task are different achievements. Should we track them as separate event categories instead of one numeric score? (Findings F-12/F-15/F-20/F-21/F-38.)
2. **How is source→formalization review authorized?** Should the agent propose multiple candidate predicates, an independent reviewer select among them, and the source stay unresolved whenever equivalence cannot be established? What constitutes a recorded review disagreement? (F-14/F-15/F-16/F-17.)
3. **What does source-level `REFUTED` require?** A mechanically valid formal witness plus a separately accepted faithful interpretation? Who/what may accept the latter for each domain? (F-09/F-18.)
4. **How do we test evidence acquisition?** A challenger restricted to claimant-supplied citations cannot identify every omitted premise; do we allow bounded external-source requests and disclose failures? (F-07/F-08.)

## Priority B — operating authority and recoverability

5. **Who can write, run or authorize?** The existing local flag is not authentication. What is the smallest capability model for LLM adapters without giving model-generated text access to `system/` or `user/`? (F-30/F-31/F-42.)
6. **What happens to pending rejected/no-op attempts?** Must each receive a system receipt, count toward a turn budget, stay auditable, or be explicitly cancelled? (F-32/F-33.)
7. **What is an adequate C3 accept/reject test for an independent reader?** We have three commands and machine-only cold-read, but no uninvolved reader study or time bound. (F-35.)
8. **Safe disposition vs meaningful progress:** when storage is unavailable, is non-durable local stop enough, or must the system stay in recovery-required status until an auditable record can be written? (F-27/F-28/F-30.)

## Priority C — architecture and complexity

9. **Two agents or two separated passes?** Structural non-revisability is useful, but what failure would justify dropping the second agent in favor of isolated critique plus a checker? (F-10/F-11.)
10. **How do we constrain governance overhead?** Which checks and metadata demonstrably prevent a costly defect; which merely make the record longer? (F-40.)
11. **How should an active knowledge projection retract prior conclusions?** Preserve history, invalidate dependencies under changed assumptions, challenge prior corrections, and detect oscillation rather than counting version growth as progress. (F-19/F-20/F-21.)
12. **What is the first independent evaluation population?** Proposition 14 is known-answer; it is not a rate dataset. What cases and rejection thresholds would substantiate a C5 efficacy claim? (F-37/F-38.)

## Proposed discussion order

First settle **A2/A3** (semantic authority), then **B5/B6** (capabilities and event authority), then **C9/C11** (agent form and correction dynamics), then **B7** (bounded C3 acceptance). We can postpone the actual metric thresholds until an independently adjudicated evaluation population exists, while recording `NOT_PREREGISTERED` explicitly.

## No silent commitment

Any agreement should become a decision entry with scope and evidence. Objections not agreed remain `OPEN`; accepting a design does not establish its implementation or scientific efficacy. Do **not** begin C4 on the strength of this consolidation alone.
