# Consolidated decisions and authority ledger

**Recorded on 2026-11-05.** This file **supersedes the status** of D-07 as shown in the frozen C3.2-era decision sheet. Historical files are preserved, not erased.

| ID | Decision | Status / authority | Remaining qualification |
|---|---|---|---|
| D-01 | Local Python, standard-library-first reasoning core | **Accepted in RFC review** | Domain checkers may later need audited dependencies |
| D-02 | Four logical namespaces; pure core must not import WikiCore/UI | **Amended in RFC review; implemented in bounded tests** | Exact full RFC ratification not separately asserted; isolation test required |
| D-03 | Single sequencing authority; `attempt_id` is retry identity, with canonical payload commitment; charged once when an attempt commits, even if rejected | **Amended in RFC review; bounded local implementation** | Concurrent and hostile-writer guarantees remain conditional |
| D-04 | No internal `CERTIFIED`; scoped witness checking separate from source validity | **Accepted** | Independent semantic fidelity remains open |
| D-05 | Known-answer Proposition 14 and recovery/exhaustion diagnostics as initial tests | **Accepted** | Not a measured false-refutation rate |
| D-06 | Local deterministic MVP before live LLM work and full wiki UI | **Accepted** | C4 only after a separate discussion/authorization |
| **D-07L** | **Accept the five implemented lifecycle states for the bounded local C3 prototype** | **APPROVED by user in current conversation** | Does not accept proposed advanced lifecycle states or lift `HOLD` |

## D-07L normative local vocabulary

- `WAITING_FOR_GOAL`: no committed goal; goal registration allowed under the local control contract.
- `WAITING_FOR_TURN`: an active goal with bounded investigation attempts.
- `QUIESCED`: durable local pause; neither goal creation nor amendment resumes it; only an explicit authorized `resume` does.
- `EXHAUSTED`: terminal within declared budget; **not** a truth claim.
- `ABANDONED`: terminal following a successfully committed human abandonment event; failed storage write is **not** durable abandonment.

`RECOVERY_REQUIRED` and `ESCAPE_ONLY` are **diagnostic classifications**, not additional truth states. `WAITING_FOR_INSPECTION`, `WAITING_FOR_AUTHORIZATION`, `BLOCKED_RECOVERABLE`, `COMPLETED`, and `FAILED` are **deferred proposals**, not adopted states in the local C3 contract. The normative state is independent of claim truth (`UNRESOLVED`/scoped `REFUTED`) and record admission (`PROPOSED`/`ADMITTED`/`REJECTED`).

## Explicit limits of approval

The user's “approved” followed a proposal to accept these five states while deferring advanced ones. This is **scoped approval**, not blanket ratification of every RFC provision, independent authentication, live-agent execution, or consequential deployment. The earlier `HOLD` remains active.

## Other implementation decisions carried forward

- Party notebook drafts are staged; only `system/` admission events make logical transitions authoritative. Cross-namespace atomicity is **not claimed**.
- Cooperative local locking and stable IDs control supported concurrent retries; non-cooperating writers are outside this trust model.
- Export preserves full SQLite content/history data; Markdown is not automatically lossless. No exported package can certify its own independent time of creation.
- No source-level `REFUTED` or `CERTIFIED` should be inferred solely from agreement of two LLM agents.

## Newly open decisions — discussion required before C4

See `DISCUSSION_AGENDA.md`: agent principal authentication/capability boundary; accepted schema for pending/rejected intents; human inspection obligations and read cost; source-formalization crosswalk authority; and the first independently adjudicated agent evaluation contract. No choice is silently accepted merely because it appears in a roadmap.
