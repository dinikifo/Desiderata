> **CURRENT REVIEW OVERLAY — 2026-11-05:** Read [`consolidated/START_HERE.md`] for current status, source catalog and discussion agenda. The user has **approved D-07 only for the five implemented local lifecycle states**. Older references to D-07 being OPEN below are preserved as **historical c3.2 open-question ledger**, not the current decision. `HOLD` remains in effect.

---

# OPEN — decisions and proof obligations

1. **D-07:** Explicitly approve or refine the lifecycle enum and transition guards before Phase-2 persistence.
2. **Capability authority:** replace caller-supplied `human_authorized`/`system_authorized` flags with actual authenticated or locally controlled principals; do not trust arbitrary user/model strings.
3. **Persistence:** define committed logical event order across four databases; crashes, partial writes, duplicate ordinals, missing namespaces and idempotent retries need a durable reconciliation contract.
4. **Current projection:** C1 derives state in memory, not from externally stored immutable evidence. A changed payload in an event log can be rehashed by its controller; independent anchoring remains open.
5. **Inspectability:** three-command restore/verify/inspect is not implemented; AC-19 remains open.
6. **Formalization:** no system has proved the original P14 author intended one formalization; no automatic source-level refutation is authorized.
7. **Evidence quality:** admission can still accept a superficial `NO_COUNTEREXAMPLE_FOUND` report; this cannot generate formal `REFUTED`, but does not demonstrate competent checking.
8. **Corrective progress:** define, before measured runs, how improvements versus mere note production are assessed. Truth convergence is not guaranteed.
9. **Acceptance mapping:** complete AC-01–AC-19 implementation is not established. C1 tests are limited to named subcases.
10. **Source archival scope:** full M1/P2/monograph/wiki archives remain separate, referenced by hashes, not embedded in the compact C1 code checkpoint.

## C2 additions

11. **D-07 still open:** agree concrete lifecycle control states and transition matrix; existing provisional names are not contractual approval.
12. **Trust boundary:** authenticate principals and ensure a future adapter prevents direct modification of others' namespaces; C2 only names logical authors under a trusted local coordinator.
13. **Durability:** simulate process-kill and actual power-loss cases, disk full, corrupted SQLite pairs, external writers and partial namespace creation; advisory locks are cooperative.
14. **Pending-rejected intent disposition:** rejected pure transitions leave staged drafts for review; define a durable cancel/archive rule before general agent intake.
15. **First working MVP:** implement no-more-than-three-command fresh restoration, verification and inspectable explanation from a self-contained checkpoint (AC-19).
16. **Progress estimate:** weighted figures are rough planning judgments; revisit weights explicitly if scope or gate changes. Do not call 59% a measured work rate.

## C3 open items

17. **Operator commands:** implement a local human-facing goal/amend/stop/resume/abandon interface with explicit local trust warnings; the C3 CLI is currently read-only apart from copying the E1 fixture into a new workspace.
18. **Arbitrary investigation archival:** extend fixture-only restore to an independently verifiable export/restore of user-created projects and entire histories, without silently conflating a readable export with a lossless one.
19. **Cold-read cost:** the three-command bound applies to invocation count, not actual comprehension time. Test comprehension and error recognition with an independent reader before claiming broader inspectability.
20. **C3 trust model:** obtain D-07 approval and real principal authorization before promoting local test code to agent-controlled workflows; account for power-loss, hostile writes and disk-full conditions separately.


## C3.1 updated open-state ledger (supersedes earlier C3 "not implemented" entries)

- **Closed in bounded local tests:** C3 operator commands (previous item 17); general four-namespace data snapshot export and cold restore (previous item 18). This does not mean earlier historical observations were false when written.
- **Still open:** D-07 lifecycle approval, real principal authentication, independent-reader comprehensibility, disk-full/process-kill/power-loss durability, staged rejected/no-op intent disposition, and evaluation criteria for independent scientific improvement.
- **Next:** explicit local acceptance review against RFC and C3.1 receipt, then proceed to C4 design only after the scoped C3 acceptance decision. Live LLM operations remain unauthorized under `HOLD`.

## C3.2 outstanding issues (current)

- **D-07 decision:** choose the normative lifecycle and acceptance criteria. `docs/D07_LIFECYCLE_REVIEW.md` is a proposal, not approval.
- **Independent reader:** ask an actual uninvolved reader to restore an unfamiliar saved investigation and explain the result using the documented commands. A machine-only audit cannot close this.
- **Power failure and environmental hardening:** simulated ENOSPC and process `os._exit` do not establish power-loss durability or behavior under actual full disks; hostile writes are outside the trust model.
- **Pending rejected/no-op intents:** define an immutable disposition/retention policy before accepting agent submissions.
- **Agent-facing authority:** trusted local CLI flags cannot serve as authentication for connected LLMs; review the capability boundary before C4.
- **Research efficacy:** C5 reliability and comparative advantages are unmeasured; `HOLD` stays in force for consequential use.
