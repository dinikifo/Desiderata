> **CURRENT REVIEW OVERLAY — 2026-11-05:** Read [`consolidated/START_HERE.md`] for current status, source catalog and discussion agenda. The user has **approved D-07 only for the five implemented local lifecycle states**. Older references to D-07 being OPEN below are preserved as **historical c3.2 decision ledger**, not the current decision. `HOLD` remains in effect.

---

# DECISIONS — acceptance and implementation boundary

- **D-01:** Local headless Python, stdlib first — accepted in RFC review.
- **D-02:** Four logical namespaces; pure core independent of WikiCore and UI; enforce AC-18 — amended in review, exact RFC adoption pending. Current source contains a bounded AST check.
- **D-03:** Single sequencer; stable `attempt_id` identifies retries; original canonical payload bound; committed rejected attempts consume one unit — amended in review, exact RFC adoption pending. C1 models this without durable sequencing.
- **D-04:** No internal `CERTIFIED`; scoped verifier results never silently promote to source truth — accepted in review.
- **D-05:** Milestone E1 and negative recovery/exhaustion scenarios, not model efficacy — accepted in review.
- **D-06:** Live LLM agents and full wiki UI after deterministic MVP — accepted in review.
- **D-07:** Lifecycle enum in RFC §5.2(4) — **OPEN**, not silently accepted. C1 uses provisional names only.
- **Implementation authorization:** user requested “let's begin” and specifically asked for consolidation and documentation of the project and discussion. This authorizes the limited local code slice and documentation, **not** a declaration that RFC v0.2 is formally adopted or operational `HOLD` lifted.
- **History policy:** preserve R0, RFC v0.2 and prior research checkpoints unchanged; record new code as derived work, not as proof of earlier claims.

## C2 bounded engineering decisions (not adoption of D-07)

- **C2-E01:** Keep system events as the sole authority for committed turns; party notebook posts are staged intents until the system event exists. This avoids a false cross-namespace transaction claim but leaves recoverable pending records.
- **C2-E02:** For the local POSIX prototype, use an advisory `flock` around read/check/write; no capability/security claim against noncooperating writers.
- **C2-E03:** Require journal post version count exactly one. A consistent WikiCore edit does not make rewriting a journal entry legitimate.
- **C2-E04:** Scope progress percentages to the C3 headless inspectable MVP, not to autonomous LLM operation. Fix six weights summing to 100 and publish subjective fractions and remaining work at each code checkpoint.
- **Pending:** RFC exact-adoption and D-07 lifecycle approval. No code state name silently changes their status.

## C3 implementation-scoped decisions (not RFC ratification)

- **C3-01:** Keep `restore`, `verify`, `inspect` as three separate commands. Restore checks the archive's exact inventory and materializes only the packaged E1 journal fixture. Reason: bounded cold-read reconstruction without executing source code from the archive.
- **C3-02:** Human inspection is a *projection* of a checked replay. Store no second mutable explanation state; event/checker receipts remain the provenance. Reason: avoid two competing authorities.
- **C3-03:** Preserve D-07 as OPEN. The existing in-memory provisional lifecycle and C2 storage remain a local test implementation rather than an approved general finite-state contract.
- **C3-04:** C3 is an inspection milestone, not the full writable human operator CLI or C4 live-LLM prototype. Reason: keep the checkpoint claim bound to the tested operations.

## C3.1 implementation-scoped decisions (not RFC adoption)

- **C3.1-01:** Add a local-human control CLI requiring explicit `--local-operator` acknowledgement; this is NOT authentication and is never sufficient for agent-facing access.
- **C3.1-02:** Source goal registration and amendment may occur while QUIESCED, but neither implicitly resumes. `stop` now requires assumed human authorization even in the pure core.
- **C3.1-03:** Keep `--expected-goal-digest` as a mandatory optimistic lock on amendments; preserve earlier versions, and require separate `resume`.
- **C3.1-04:** Export arbitrary local workspace as eight SQLite files and a strict manifest; no executable payload, checked cold restore, no destination overwrite.
- **C3.1-05:** Keep D-07 OPEN and `HOLD` in force. Do not interpret local tests or self-acknowledged commands as authenticated authorization or autonomous research performance.

## C3.2 engineering-scoped decisions (not RFC or D-07 approval)

- **C3.2-E01:** Test durable cutpoints using separate processes and `os._exit`, not only in-process exceptions. Scope excludes OS/hardware power loss.
- **C3.2-E02:** Use a CLI-only reconstruction script to test a three-command recovery contract. The script is not an independent human reader.
- **C3.2-E03:** Audit only *implemented* provisional lifecycle statuses, leaving broader D-07 adoption OPEN.
- **C3.2-E04:** Keep the original six weights for progress estimates. Update completions to 93% / 7% based on disclosed scope and new tests; exclude C4 and C5.
