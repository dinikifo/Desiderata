# Desiderata — creators' working roadmap

**Purpose:** a shared, editable agenda for human-directed design, AI-assisted engineering, independent criticism, and publication. This is not the code functionality roadmap. It records what **we should decide and verify next**, not what a future autonomous system is entitled to decide for us.

## Working relationship

A human directs the objectives, may correct or reject proposals, and authorizes release and policy decisions. Generative AI systems may help draft theories, challenge assumptions, write tests, suggest code, and collect contradictory evidence. A model's contribution is **not an independent human review**, a source of legal authority, or proof of scientific accuracy. The project has relied substantially on AI-assisted work, but does not require a list of model identities for its public account.

Each engineering change should follow: **plan → review → explicit decision → implementation → adversarial tests → source and evidence consolidation**. Negative results remain visible. No historical source or failure receipt is silently overwritten to produce a cleaner narrative.

## Work packages and decisions

| Sequence | Shared work | Human decision | Evidence to retain |
|---|---|---|---|
| G1 — Publication preparation | Edit monographs, clarify navigation, package license, review rights and Git history | Approve public text, license scope and repository visibility | README, `LICENSE`, inventory, test report, source manifest, secrets/privacy review |
| G2 — Reader study | Prepare a held-out investigation and no-coaching instructions | Recruit/authorize an actual uninvolved reader, or openly mark A1 blocked | Command count, comprehension errors, elapsed time, questions asked, full limitations |
| G3 — Close C3 exceptions | Compare AC matrix with tests; specify pending-intent disposition and physical storage limits | Accept or refuse *bounded* C3 completion | Machine-readable AC status, failure injection receipts, revised status |
| G4 — C4 authorization boundary | Design a protocol where LLM adapter cannot reach local human controls | Approve capability policy and resource budget | Attacks/negative controls, static + behavioral guards |
| G5 — First model experiment | One model and one scripted baseline on known-answer cases | Authorize credentials, costs and model use | Captured inputs/outputs, formal checker receipts, failures, costs |
| G6 — Second domain | Software-debugging bounded witness, external specification | Approve domain task and verification contract | Reproducible failing/passing behavior and explicit bounds |
| G7 — Evaluation | Preregister C5 metrics before data collection | Approve dataset design, stopping criteria and release claims | Independent adjudication, negative results, confidence bounds |
| G8 — Generalization decision | Compare E1 and second domain for accidental assumptions | Decide whether a portable template is justified | Cross-domain traceability and platform preconditions |

**Dependencies matter more than dates.** G4 is a security prerequisite for G5. G6 is a prerequisite for claiming reusable generality. G2 is still an independent-reader acceptance condition and cannot be silently replaced with an AI proxy. Public release under G1 is compatible with a documented C3 acceptance gap.

## Current discussion agenda (unresolved)

- For admission criteria, when may a verifier *method* be delegated under previously approved tests, and when does a changed *criterion* require new human authorization?
- What specific capabilities must be structurally inaccessible to an agent adapter, beyond a textual prohibition on `--local-operator`?
- When evidence is nondeterministic, how should receipts identify model version, context, sampling and cost without overstating reproducibility?
- What is the policy for rejected and pending intents after interruption, cancellation, and repeated attempts?
- What evidence would justify treating a correction as a faithful revision of a source claim instead of retaining `UNRESOLVED`?
- What conditions would justify a future operational release while preserving a record of unresolved scientific limitations?

See the historical 44-finding [register](../consolidated/FINDINGS_AND_OBJECTIONS.md) and [discussion agenda](../consolidated/DISCUSSION_AGENDA.md). The [DN-0001 protocol-strata note](../proposals/DN-0001-PROPOSED.md) remains a *review proposal*, not silently approved by this document.

## Publishing practice

Use a short README for newcomers; let monographs carry detailed theory; let the manual say precisely what a user can do; separate checked evidence from human interpretations and proposed architecture; preserve old Git commits and source receipts. Check for secrets and private material **across Git history, not only the latest working tree**. Do not publish a private conversation archive simply to prove a concept's origin.

After every major decision, record `GOAL / STATE / DECISIONS / OPEN`, the current step and honest progress denominator, changed files, exact tests run and their limitations, plus a digest or tagged release. Publication is not a scientific validation event.
