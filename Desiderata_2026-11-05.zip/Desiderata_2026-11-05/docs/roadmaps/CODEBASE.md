# Desiderata — codebase architecture and functionality roadmap

**Purpose:** a source map and a *status-tagged* engineering roadmap. This is not a promise of schedule, efficacy, portability, or future behavior.

## 1. Component map (current C3.4)

```text
Desiderata repository
├── bin/desiderata                   Human-facing alias → existing CLI
├── bin/scientific-workspace        Original compatible launcher
├── scientific_workspace/
│   ├── engine/r0_core.py           Frozen R0 bounded finite checker
│   ├── engine/transition.py        Deterministic state transitions
│   ├── storage/journal.py          Staged intent + committed event replay
│   ├── storage/vendor_pw/          Vendored PERSONAL.WIKI / WikiCore
│   └── interface/
│       ├── cli.py                  Local controls and read-only inspection
│       ├── checkpoint_io.py        Data-only export and restore
│       └── inspection.py           Explanation projections
├── fixtures/E1_PERSISTENT_WORKSPACE/  Known-answer research history
├── tests/                           Unit, regression, storage, negative cases
├── tools/                           Release, evidence and coverage checks
├── checkpoints/                     Historical test and integrity receipts
├── sources/                         RFC, architecture, ancestry receipts
└── docs/
    ├── monographs/                 Theory → practical interpretation
    ├── manual/                      Operator expectations and procedures
    ├── roadmaps/                    This map + creators' roadmap
    ├── references/                  Bibliography
    ├── governance/                  License, scope, history
    └── consolidated/                Preserved historical handover
```

## 2. Functionality by status

| Function | Implementation | Evidence boundary |
|---|---|---|
| Local journal creation, goal registration and amendment | **Implemented** | Trusted local operator, not real authentication |
| Stop, resume, abandon and local lifecycle | **Implemented** | D-07 five-state bounded approval, not an exhaustive distributed-state theorem |
| Staged attempt, commit, replay, deduplication | **Implemented in bounded form** | Assumed sequencer; no malicious concurrent writers |
| Data-only export/restore, CLI inspect | **Implemented** | A1 human comprehension still open |
| Finite P14 checker and E1 case | **Implemented** | Known-answer formalization-specific result |
| Vendored wiki storage test preservation | **Implemented** | Recovered original upstream test scripts plus narrower new controls |
| Function-local import coverage gate | **Implemented** | Five known source sites reached; line tracing not proof of all behavior |
| Actual authenticated human/agent capability separation | **Not implemented** | Human flag is a local acknowledgment only |
| Live LLM actors or model API adapters | **Not implemented** | C4 not authorized |
| Pluggable general evidence checkers | **Not implemented** | Only bounded known-answer checker |
| Protocol-version stratification and controlled criteria changes | **Design proposal** | Not approved as a C3/C4 feature |
| General domain and platform portability | **Unproven** | POSIX and WikiCore format assumptions |
| Independently adjudicated scientific efficacy | **Not evaluated** | C5 preregistration absent |

## 3. C3 — current acceptance boundary

**Status: Step 6 of 6, approximately 90% complete, ~7% remaining by prior fixed-weight planning estimate.** The published calculation of 92.6% is an *estimate*, not earned work-hours or overall framework completeness. The documentation/CC0 packaging phase makes no C3 progress claim.

Outstanding: A1 independent human reconstruction of a held-out case (`BLOCKED_EXTERNAL_REVIEWER`); RFC AC matrix gaps; durable failure assumptions not proven for arbitrary physical faults; rejected/pending-intent disposition contract. D-07 five local lifecycle states have bounded human approval. See [original detailed roadmap](../consolidated/ROADMAP.md) and [traceability](../TRACEABILITY.md); do not infer all ACs are discharged from a passing test count.

## 4. C4 — bounded agent experiment (future, not authorized)

**Entry requirements:** agree an agent API that lacks human/operator control capabilities; add a mechanical forbidden-call guard and adversarial negative tests; freeze an acceptance matrix, spending limits, payload schema and stopping rules. Then:

- C4.0: structured candidate proposal and challenge records, isolated from authority changes.
- C4.1: scripted deterministic actor as a baseline; refusal and recovery tests.
- C4.2: one limited LLM adapter with explicit input/output capture, no hidden tools or privileged commands.
- C4.3: inspect the resulting attempt against E1 without confusing a known-answer run with general efficacy.
- C4.4: only after learning from the one-actor experiment, evaluate whether a second actor contributes anything beyond a checker.

This preserves the prior C4 goal but prefers controlled experiments over a generalized autonomous platform. No C4 implementation is part of this release.

## 5. Second domain before any template claim

Build a bounded **software debugging** problem with an independently specified behavior and an executable failing-then-passing regression. Record what transfers from E1 and what must change. A subsequent document-question trial should test *honest abstention*: no unsupported verified claims. Reusable template extraction can be considered **after** evidence from another domain. These are research proposals, not accepted functionality.

## 6. C5 — preregistered external evaluation

Independent adjudication of samples, denominators for false-refutation and missed-refutation rates, explicit cost budgets, refusal handling, termination conditions, and single-actor/two-actor/checker ablations. None are in the C3 progress denominator and none have been run as an efficacy trial.

## 7. Platform contract and operational restrictions

The sequencer currently requires POSIX advisory locking (`fcntl`) and trusted exclusive-write storage, with SQLite transactions for individual DB files. Cross-namespace write sequences are **not a single atomic multi-file transaction**. Hardware power loss, hostile processes, insecure remote invocation, and network FS anomalies are outside the verified contract.

`HOLD` remains for consequential deployment until separately revisited under meaningful evidence. The project can remain publicly reusable under CC0 while this policy continues to apply to the project's own claims and recommended uses.
