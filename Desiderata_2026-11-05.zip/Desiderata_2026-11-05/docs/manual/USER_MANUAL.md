# Desiderata user manual — local C3 edition

**Audience:** a developer, researcher or critical reader running a *trusted, single-machine, headless prototype*. **Not** a live-agent guide, hosted service manual, or production deployment procedure.

## 1. What Desiderata does

It keeps an ordered investigation journal, lets a local operator register and amend a goal, supports pausing and terminal abandonment, records bounded attempt/verification events through the deterministic engine, and reconstructs state for inspection. Its known-answer E1 fixture demonstrates that a formal counterexample can be valid for one interpretation while the original source question remains unresolved.

The tool's value is **inspectability and explicit limits**, not a promise to produce a true answer. A well-formed entry is not necessarily scientific evidence; a stored result is not a guarantee of its author's identity; a failed attempt is not proof of the opposite proposition.

## 2. What it does *not* do

It does not connect to an LLM, autonomously run two live agents, authenticate operators, guarantee physical power-loss safety, adjudicate the meaning of arbitrary text, discover mathematical truths generally, or certify research. It does not accept arbitrary third-party scripts from an archive for execution. The current E1 case is known in advance. `HOLD` prohibits consequential use as a matter of project policy, not as a security-enforced switch.

## 3. Requirements and trust

- CPython 3.11+ with its standard library (including `sqlite3`), on a tested POSIX-like local environment supporting `fcntl` advisory locks.
- A local filesystem with working SQLite single-file commits and cooperative exclusive writer control. **Do not** assume the same guarantees on arbitrary network filesystems or untrusted shared hosts.
- Python code is installed or copied from a source you have independently reviewed; `--local-operator` does **not** check your identity. Do not run it from an LLM tool or remote request handler.
- Do not treat an internal ZIP manifest as an independent signature. Obtain an expected SHA-256 digest via a separate trusted channel where possible.

Run from the repository root. No external package installation is required for the supplied code.

## 4. First workflow — a new bounded journal

```bash
./bin/desiderata --help
./bin/desiderata init --workspace /tmp/desiderata-demo --budget 2
./bin/desiderata goal --workspace /tmp/desiderata-demo \
  --goal-id G1 --statement 'Investigate a proposition' \
  --request-id g-001 --local-operator
./bin/desiderata inspect --workspace /tmp/desiderata-demo --json
./bin/desiderata stop --workspace /tmp/desiderata-demo \
  --request-id s-001 --local-operator
./bin/desiderata inspect --workspace /tmp/desiderata-demo --explain
./bin/desiderata resume --workspace /tmp/desiderata-demo \
  --request-id r-001 --local-operator
```

These paths are examples; pick fresh, otherwise nonexistent directories. The CLI may refuse operations inconsistent with the current state. **Do not interpret a refused command as consuming a successful scientific turn.** If a command is retried, reuse its request ID only with identical logical parameters.

To revise a goal, get the current `goal_digest` from `inspect --json`, then provide that value literally:

```bash
./bin/desiderata amend --workspace /tmp/desiderata-demo \
  --expected-goal-digest 'sha256:THE_DIGEST_FROM_INSPECT' \
  --statement 'More precise question' --reason 'Assumption needs revision' \
  --request-id a-001 --local-operator
```

The digest is an optimistic concurrency check; don't invent one. Amendments preserve prior records. To durably stop without claiming a scientific result:

```bash
./bin/desiderata abandon --workspace /tmp/desiderata-demo \
  --reason 'No sufficient evidence' --request-id x-001 --local-operator
```

An inability to write durably is *not* successful abandonment. Do not silently resume a paused investigation after changing its goal.

## 5. Export, restore and independently inspect

```bash
./bin/desiderata export --workspace /tmp/desiderata-demo \
  --archive /tmp/desiderata-demo-snapshot.zip
./bin/desiderata restore --archive /tmp/desiderata-demo-snapshot.zip \
  --workspace /tmp/desiderata-demo-restored
./bin/desiderata verify --workspace /tmp/desiderata-demo-restored --json
./bin/desiderata inspect --workspace /tmp/desiderata-demo-restored \
  --explain --diff-from-initial
```

Export is data-only; restoration refuses unsafe or conflicting paths and checks the packaged data and replay constraints. Recovery is bounded to the supported WikiCore notebook format. It does not demonstrate that a new human reader fully understands the investigation; the A1 independent-reader study remains unsatisfied.

## 6. Read the known-answer Proposition 14 fixture

To restore the E1 test workspace from a **complete code checkpoint ZIP**, run (in a new destination, using an independently obtained digest if available):

```bash
./bin/desiderata restore --archive /path/to/Desiderata_2026-11-05.zip \
  --workspace /tmp/desiderata-e1 --expected-sha256 ACTUAL_ARCHIVE_SHA256
./bin/desiderata verify --workspace /tmp/desiderata-e1 --json
./bin/desiderata inspect --workspace /tmp/desiderata-e1 \
  --explain --diff-from-initial
```

Expected interpretation: the **unequal-set** formalization is refuted within the finite submodel, the disjoint-set witness fails its premise, and the **source claim remains unresolved**. This is a scoped known-answer integration, *not* evidence that the system can resolve arbitrary prose.

## 7. Tests and how to interpret them

```bash
python -m unittest tests.test_engine tests.test_persistence -v
python -m unittest tests.test_vendor_migration tests.test_vendor_regressions -v
python tools/check_vendor_local_import_coverage.py --output /tmp/desiderata-import-coverage.json
python tools/run_r0_baseline.py
python tools/verify_checkpoint.py
```

A split suite is described in `.github/workflows/tests.yml`; the historical all-in-one test discovery process sometimes stalled and should not be presented as clean when it has not completed. The latest historical C3.4 test receipt is in `checkpoints/C3_4_TEST_REPORT.json`; an additional assembly receipt is supplied with the Desiderata release. Passing tests cover named cases, **not all quantified RFC invariants**. Some tests of future capability correctly skip.

## 8. Common questions

**Can it act on my behalf?** No model agent or external-service connector exists in this release.

**Is a recorded claim true?** Not necessarily. Check its exact formalization and checker receipt, then separately consider source fidelity.

**Can I run on Windows?** The current sequencer depends on POSIX `fcntl`; no Windows portability claim is made.

**Can I reuse or modify the software?** The original released material is dedicated to CC0-1.0 to the extent the dedicating parties hold its rights; see [`LICENSE`](../../LICENSE) and [scope](../governance/LICENSE_AND_PROVENANCE.md). The old vendored Unlicense notice is retained.

**Where can I report a problem?** Record the exact command, version/commit, fixture and expected/observed outputs. Do not include secrets or personally identifiable investigation records. Refer to [the creators' roadmap](../roadmaps/CREATORS.md).
