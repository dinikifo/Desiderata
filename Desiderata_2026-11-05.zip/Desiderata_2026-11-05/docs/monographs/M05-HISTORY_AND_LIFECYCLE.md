# M05 — History, recovery, and lifecycle

**Status:** implemented within a trusted single-machine storage model; not an adversarial durability guarantee.

## The question

If a process stops between writing an intention and committing a decision, what happened? If a user changes the goal, can the old formulation still be recovered? If a project is paused, should an unrelated edit revive it? These are questions about durable history, not merely about database presence.

## Conceptual position

A committed event differs from a staged intent. A retry must be recognizable as the *same logical action*. A correction should refer to the record it corrects, not overwrite it. A reader should be able to reconstruct the active state from ordered history and identify pending drafts and missing namespaces explicitly.

The bounded lifecycle has five approved local states: `WAITING_FOR_GOAL`, `WAITING_FOR_TURN`, `QUIESCED`, `EXHAUSTED`, and `ABANDONED`. Pausing is a safe disposition, not scientific progress. Storage unavailable at abandonment time is not evidence that abandonment was durably recorded.

## Practical bridge

`scientific_workspace/storage/journal.py` uses four WikiCore notebook namespaces, SQLite, POSIX advisory locking, and a trusted local sequencer. `scientific_workspace/interface/inspection.py` produces human-readable inspection; `checkpoint_io.py` handles data snapshots and fixture restoration. CLI commands `export`, `restore`, `verify`, and `inspect` are described in the user manual.

Real child-process termination tests and selected corruption cases pass. Those tests do **not** establish durability under power failure, disk-full conditions, malicious writers, or environments lacking reliable advisory locks and exclusive-write storage.

## Open objection

An uninvolved reader has not completed the A1 comprehension test. A black-box command sequence is a valuable mechanical proxy, not evidence that a human understood the research decisions. See [M07](M07-LIMITS_AND_GENERALIZATION.md).
