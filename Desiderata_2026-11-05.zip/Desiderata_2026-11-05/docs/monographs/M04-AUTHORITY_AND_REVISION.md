# M04 — Human authority, methods, and criteria

**Status:** current goal controls are bounded and local; protocol strata are design proposals, not implemented.

## The question

A system that proposes changes to its own investigative procedures cannot adjudicate all of those changes by invoking an infinitely nested hierarchy of meta-protocols. The project terminates the authorization chain at a human authority boundary. That does **not** imply that human authorization proves a claim true.

A useful distinction emerged during review:

- **Methods:** *how* a pre-authorized criterion is checked (for example, replacing a brittle prose index reader with a typed generator). A method may be compared against existing conformance cases.
- **Criteria:** *what counts* as acceptable evidence. Changing this standard changes what the tests would mean; it therefore requires a human-authorized policy decision, not a self-certifying test run.

## Conceptual position

The proposed kernel is not a component whose scientific judgments must be accepted. It is an **authority rule about which kinds of records require a human authorizer**. Goals and criterion changes fall inside that boundary. Agents may propose revisions; proposals remain proposals until admitted under the appropriate authority and tests.

A further proposal is **protocol strata**: records retain the criteria version that admitted them, and a new protocol does not retroactively rewrite their past status. A current projection would need to name its stratum and surface disagreements. That machinery is not in C3.4 and is not on the approved C4 implementation scope.

## Practical bridge

Today, `--local-operator` is only a local-trust acknowledgment; no real authentication exists. The CLI and transitions demonstrate how human-directed amendments are represented, **not** a secure authorization boundary against a hostile or agent-controlled process. The future adapter must lack the capability to use privileged controls at all. See `docs/C3_1_OPERATOR_CONTRACT.md`, `docs/consolidated/DECISIONS_AND_D07.md` and the [proposed DN-0001 design note](../proposals/DN-0001-PROPOSED.md), which is included for review but not adopted.

## Open decision

Could a human pre-authorize a bounded class of method substitutions after specific conformance tests, while reserving criterion changes for explicit review? This remains proposed, not adopted. See the [creators' roadmap](../roadmaps/CREATORS.md).
