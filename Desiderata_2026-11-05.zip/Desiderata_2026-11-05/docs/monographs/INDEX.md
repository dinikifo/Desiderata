# Desiderata — a collection of editable monographs

This collection approaches the project **from theory to practice**. Each short monograph has a stable number and separates: (1) the question, (2) the conceptual position, (3) what code demonstrates today, and (4) open objections. Treat proposed future mechanisms as proposed, not deployed.

| Order | Monograph | Central issue |
|---|---|---|
| M01 | [The task may be wrong](M01-TASK_AND_QUESTION.md) | Why an investigation cannot assume the problem statement is true |
| M02 | [Claims, interpretations, and witnesses](M02-CLAIMS_AND_FORMALIZATION.md) | A formal checker does not validate a source interpretation |
| M03 | [Admission, evidence, and knowledge](M03-EVIDENCE_AND_ADMISSION.md) | Why recorded and justified are different statuses |
| M04 | [Authority, methods, and criteria](M04-AUTHORITY_AND_REVISION.md) | Who may change goals and verification standards |
| M05 | [Memory, recovery, and lifecycle](M05-HISTORY_AND_LIFECYCLE.md) | What persistence proves and what it does not |
| M06 | [Actors, budgets, and failure](M06-ACTORS_AND_BUDGETS.md) | Collaboration without self-certification |
| M07 | [Portability, abstention, and evaluation](M07-LIMITS_AND_GENERALIZATION.md) | What a second domain and independent trial would establish |
| M08 | [From concepts to code](M08-IMPLEMENTATION_BRIDGE.md) | A guided walk through the actual source tree |

**Editing contract:** monograph filenames/IDs are editorial identifiers, not runtime schema. Preserve citations and explicit evidence boundaries when editing. New conceptual proposals belong here or in a design note; acceptance decisions belong in `docs/governance/` and must be authorized separately. The archived RFC and review records are not overwritten by editorial changes.

Continue with the [user manual](../manual/USER_MANUAL.md), [codebase roadmap](../roadmaps/CODEBASE.md), [creators' roadmap](../roadmaps/CREATORS.md), or [bibliography](../references/BIBLIOGRAPHY.md).
