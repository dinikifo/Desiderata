# M07 — Portability, abstention, and scientific evaluation

**Status:** one known-answer mathematical domain; generality unproved.

## The question

A framework evaluated on one mathematical proposition can overfit to the structure of that proposition. Releasing reusable code does not establish a generally portable reasoning architecture. A second domain may reveal where a design has assumed decidability, formal syntax, or a trusted verifier.

## Conceptual position

The next meaningful comparison is a **software debugging** task whose declared behavioral requirement and failing-then-passing test form a mechanically inspectable, bounded witness. It can reveal which parts of Desiderata are reusable and which depend on Proposition 14. Only after that instance should general-purpose template extraction be considered.

A document-research task has a different role: it tests whether the workspace correctly avoids unwarranted verification claims. Its success criterion is *no unsupported promotion to verified status*, not a preordained zero count of verified subclaims. Mechanically decidable subclaims might coexist with an unresolved central interpretation.

The platform contract must also be explicit. The current implementation assumes a POSIX environment supporting `fcntl` locks, cooperative exclusive writers, and SQLite single-file transaction semantics. Transporting the ZIP to an arbitrary runtime does not preserve these assumptions.

## Practical bridge

`fixtures/E1_PERSISTENT_WORKSPACE` is known-answer integration evidence. `docs/TRACEABILITY.md` records the RFC acceptance coverage gaps. `docs/consolidated/ROADMAP.md` distinguishes C3 bounded acceptance, C4 controlled model participation, and C5 independently evaluated performance. There is no preregistered C5 dataset or demonstrated scientific accuracy rate.

## Fundamental rule

**If a system encounters a problem for which no suitable verifier exists, it must preserve the question as unresolved rather than manufacture epistemic authority.**

## Open objection

What evidence and external review would justify removing the project's consequential-use `HOLD`? That decision has not been made.
