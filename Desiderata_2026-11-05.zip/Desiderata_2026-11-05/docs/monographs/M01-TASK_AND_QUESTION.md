# M01 — The task may be wrong

**Status:** explanatory; C3 bounded behavior, not a theory of scientific validity.

## The question

Most automated workflows assume the goal is a correct specification and a successful system should satisfy it. A scientific investigation is different. Its initial task may be false, ambiguous, inconsistent, insufficiently precise, or impossible within the available methods and resources. A workflow that silently repairs the task or declares success after many attempts is misleading.

The initial task should therefore be an **immutable historical object**, not an unquestionable description of reality. The system may investigate its truth and meaning. It may propose a better formulation. It must not rewrite the user's original text without retaining both versions and the authority that made the replacement.

## Conceptual position

An investigation's legitimate outcomes include a bounded formal result, a challenge to an assumption, a proposed correction, a documented inability to decide, exhaustion of an explicit budget, or an authorized abandonment. These are different outcomes. None entails that arbitrary research will converge to truth.

We distinguish **the user's goal** from **the system's active working hypothesis** and from **the evidence required to justify a conclusion**. Progress measured in notes, turns, messages, or agreement is not a substitute for warranted discoveries.

## Practical bridge

`scientific_workspace/engine/transition.py` models goal registration and amendment; `storage/journal.py` records durable transitions; the CLI exposes `goal`, `amend`, `stop`, `resume`, and `abandon`. These commands enforce a *bounded local transition protocol* under assumed local authority. They do not prove that a requested task is scientifically possible or correct.

The user manual shows the exact commands. An amended goal has an explicit predecessor digest and reason. If a workspace is quiesced, creating or amending a goal must not silently resume it.

## Unresolved objection

Who decides that a proposed correction faithfully expresses the user's intention? Neither a mathematical witness nor an AI model can settle the meaning of the source text automatically. That requires separate review. See [M02](M02-CLAIMS_AND_FORMALIZATION.md) and the original [RFC](../../sources/RFC-0001-v0.2.md).
