# M06 — Actors, boundaries, budgets, and failure

**Status:** two-actor architecture proposed; no live LLM orchestration exists in this release.

## The question

Two independent notebook namespaces can preserve attribution, but do not make two language models cognitively independent. A model can repeat another model's error; reciprocal approval does not confer scientific validity. A bounded investigation needs a declared budget, a principled stopping rule, and a non-agent check on claims that admit such checks.

## Conceptual position

Participants may propose and challenge. The system should keep provenance, enforce admissible transitions, and consult a domain-specific checker where available. No participant should issue an authoritative `CERTIFIED` verdict for its own work. Exhaustion is a legitimate outcome; endless continuation is not the definition of success.

Attempts are not interchangeable with accepted results. A logically repeated request should not double-charge a budget. Agent proposals should remain distinct from durable admission and human policy authority.

## Practical bridge

The present engine and journal test deterministic actor selection, budget exhaustion, idempotent retries, and constrained state transitions. These are **scaffolding**. There is no live model API, secure capability split, prompt registry, or independently measured multi-agent efficacy.

The C4 roadmap proposes an isolated transaction through a structurally constrained adapter, followed by a scripted-actor baseline and only then broader collaboration. That is future work requiring an explicit decision. See [codebase roadmap](../roadmaps/CODEBASE.md).

## Open objection

What incremental benefit does a second actor add over one actor plus a checker? This is an empirical question requiring preregistered comparison, not a premise of the architecture.
