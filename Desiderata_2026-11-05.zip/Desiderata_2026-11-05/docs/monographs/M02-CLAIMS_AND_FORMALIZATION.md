# M02 — Claims, interpretations, and witnesses

**Status:** explanatory; one decidable finite fixture implemented.

## The question

A formal checker answers a formal question. A sentence in a monograph or a user request may permit multiple formalizations. When a witness refutes one formalization, the result does **not** necessarily refute the original sentence.

Our Proposition 14 fixture exposes this distinction. Under the reading that two permissible-action sets are merely **unequal**, `{a}` and `{a,b}` differ but share action `a`; a constant choice can defeat a universal impossibility assertion in the bounded model. Under the stronger reading that sets are **disjoint**, the same witness violates the premise. It is not a counterexample to that version.

## Conceptual position

At least four layers need separate labels:

1. Source claim, preserved as written.
2. Proposed formalization with assumptions and scope.
3. Checker result over that formalization, with executable receipt.
4. Assessment of whether the formalization captures the source author's intent.

An agent's confidence does not merge those layers. A verified finite witness can support a scoped `REFUTED` result while the original source claim remains `UNRESOLVED`. A disagreement over interpretation is not itself a verdict of falsehood.

## Practical bridge

The frozen finite checker is in `scientific_workspace/engine/r0_core.py`. The E1 fixture stores an inspectable Proposition 14 investigation in `fixtures/E1_PERSISTENT_WORKSPACE/`. Use `restore`, `verify`, and `inspect` to reconstruct its event history and rationale. The CLI's ability to reproduce this one result demonstrates a *known-answer integration*, not independent discovery or general semantic understanding.

## Open objection

What independent evidence and review procedure are needed before promoting a formal result to an assertion about the original claim? That review process is not fully implemented. Do not fill the gap with a new `CERTIFIED` label. See [M03](M03-EVIDENCE_AND_ADMISSION.md) and [M07](M07-LIMITS_AND_GENERALIZATION.md).
