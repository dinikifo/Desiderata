# M08 — From concepts to the running code

**Status:** descriptive map of the C3.4 Python implementation.

## The question

Which part of the theory can another developer actually inspect, run, change, and test today?

## Architecture walk

1. **State transitions** — `scientific_workspace/engine/transition.py` defines the current bounded state machine, attempt registration, admission and authorization assumptions. Test with `tests/test_engine.py`.
2. **Finite checking** — `scientific_workspace/engine/r0_core.py` retains the original R0 mathematical verifier. Run `tools/run_r0_baseline.py`.
3. **Persistence** — `scientific_workspace/storage/journal.py` writes and replays staged and committed records. `storage/vendor_pw/` contains the vendored WikiCore implementation, original upstream tests, and import fixes. Test process cuts and storage contracts.
4. **Human inspection** — `scientific_workspace/interface/inspection.py` projects inspectable explanations without issuing scientific certification.
5. **Local CLI** — `scientific_workspace/interface/cli.py` supports lifecycle, archive and inspection commands. `bin/desiderata` is an alias preserving older invocation paths.
6. **Verification receipts** — `tools/verify_checkpoint.py` verifies the packaged file inventory; `tools/check_vendor_local_import_coverage.py` rejects unexecuted function-local import sites in the vendored subtree (use `--output` for an independent receipt rather than overwriting the earlier checkpoint report). Neither substitutes for behavioral tests.

## Reproduce a bounded workflow

Read the [user manual](../manual/USER_MANUAL.md). Create a new workspace, register a goal, inspect, export and restore. Then examine the E1 source-level `UNRESOLVED` outcome; distinguish it from the checker-specific refutation.

## Common misreadings

- A passing CLI command does not establish human comprehension.
- Four namespaces are not independently authenticated agents.
- SHA-256 over files plus an internal manifest is consistency checking, not signed provenance.
- An AST guard plus executed-line coverage does not prove all storage behavior.
- The present code does not implement a general domain verifier plug-in interface or live LLM participation.

The [codebase roadmap](../roadmaps/CODEBASE.md) is the canonical inventory of what exists and what remains proposed.
