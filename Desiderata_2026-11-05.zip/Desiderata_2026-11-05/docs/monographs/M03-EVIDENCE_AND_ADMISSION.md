# M03 — Admission, evidence, and working knowledge

**Status:** architectural distinction partly tested; no universal verifier.

## The question

A record that is well-formed and persistently admitted is not automatically true. Conversely, a rejected or unavailable record is not automatically false. Scientific accountability requires explicit boundaries among syntactic validity, authorization, evidence, semantic adequacy, and current belief.

The project uses separate *attempts*, *receipts*, and *state projections*. The system should be able to say who proposed a claim, what was checked, which assumptions were used, and which evidence is absent. Failure to prove something under a fixed budget is not proof of its negation.

## Conceptual position

Admission asks whether a record satisfies the current writing and validation contract. A domain verifier asks whether specified evidence proves or refutes a *bounded predicate*. Formalization review asks whether that predicate corresponds to the intended source statement. A projection of current knowledge reads these records under declared criteria; it does not erase their history.

The project does **not** have a general-purpose truth oracle, an independent origin attester, or quantified scientific false-positive guarantees. Its traceability matrix therefore retains `PARTIAL_ONLY` and `NO_INTEGRATED_CHECKER` where warranted, even though many unit and integration tests pass.

## Practical bridge

Inspect `scientific_workspace/engine/transition.py`, `storage/journal.py`, `docs/TRACEABILITY.md`, and `docs/consolidated/VERIFICATION_AND_LIMITS.md`. Tests cover narrow transition, persistence, deduplication and corruption cases. The manifest checker (`tools/verify_checkpoint.py`) verifies packaged bytes against a manifest inside the package; this does not authenticate the manifest independently.

## Open objection

How will later heterogeneous domain verifiers label incomparable evidence without appearing to certify more than they actually check? See [M07](M07-LIMITS_AND_GENERALIZATION.md).
