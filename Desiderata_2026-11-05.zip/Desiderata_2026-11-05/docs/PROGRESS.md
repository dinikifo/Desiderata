# Progress — C3.2

**Current step: 6 of 6.** **Estimated work completed: 93%; remaining: 7%.**

**Target:** First working local headless, persistent, human-inspectable prototype (C3 acceptance); live LLM agents C4 remain excluded

*Method:* Fixed previously published package weights; phase-completion fractions are human planning estimates, not hours or a success probability. C4 and C5 are outside the denominator. C3.2 adjustments reflect stronger process-exit and black-box read tests; no claim of an independent human evaluator.

| Step | Work package | Status | Planning weight | Fraction completed |
|---:|---|---|---:|---:|
| 1/6 | Verified source baseline and RFC trail | DONE | 10% | 100% |
| 2/6 | Deterministic reasoning and witness core | PARTIAL | 20% | 90% |
| 3/6 | Four-namespace journal and durable replay | PARTIAL | 25% | 92% |
| 4/6 | Recovery, conflict and environmental-failure hardening | PARTIAL | 20% | 86% |
| 5/6 | Bounded human inspection and control commands | DONE_BOUNDED | 15% | 100% |
| 6/6 | Self-contained cold restore and E1 acceptance | IN_PROGRESS | 10% | 94% |

## Evidence and blockers

- **Step 1:** R0 and RFC sources checked; D-07 remains an explicit open design decision
- **Step 2:** Pure formal results and regression checks retained; broader claim domains and formalization review remain open
- **Step 3:** Four-notebook journal, restart replay and explicit crash-cutpoint tests; no hostile-writer guarantee
- **Step 4:** Real os._exit after draft/system event and simulated write failure; physical power loss not tested
- **Step 5:** Human CLI goal/amend/stop/resume/abandon; read-only explain; operator flag is NOT authentication
- **Step 6:** Data-only restoration and CLI-only E1 reconstruction tested; D-07 and human cold-reader test remain open

C4 LLM participation and C5 independent efficacy evaluation are expressly excluded from the MVP percentage.

The estimate is revised only with an explicit change to the versioned scorecard. Passing tests does not automatically imply a completed phase or proven scientific efficacy.

