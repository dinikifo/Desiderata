# C3.1 — local operator controls and data-only recovery

**Status:** implemented and locally tested within a trusted POSIX process. RFC-0001 v0.2 conditional, D-07 OPEN, project operational gate `HOLD`. No live LLM agents or authenticated human identity.

## Bounded commands

Run `./bin/scientific-workspace` from the extracted checkpoint (or `python -m scientific_workspace`). Workspace paths are local.

```bash
./bin/scientific-workspace init --workspace /tmp/research-run --budget 2
./bin/scientific-workspace goal --workspace /tmp/research-run --goal-id G1 --statement 'Investigate P14' --request-id goal1 --local-operator
./bin/scientific-workspace inspect --workspace /tmp/research-run --json
./bin/scientific-workspace stop --workspace /tmp/research-run --request-id pause1 --local-operator
./bin/scientific-workspace amend --workspace /tmp/research-run --expected-goal-digest 'sha256:...' --statement 'Revised goal' --reason 'New evidence' --request-id amendment1 --local-operator
./bin/scientific-workspace resume --workspace /tmp/research-run --request-id resume1 --local-operator
./bin/scientific-workspace export --workspace /tmp/research-run --archive /tmp/research-run.zip
./bin/scientific-workspace restore --archive /tmp/research-run.zip --workspace /tmp/recovered-run --expected-sha256 DIGEST_RECEIVED_SEPARATELY
./bin/scientific-workspace verify --workspace /tmp/recovered-run --json
./bin/scientific-workspace inspect --workspace /tmp/recovered-run --diff-from-initial
```

`abandon --reason ... --local-operator` durably terminates a *nonterminal* run. A stopped or quiesced investigation is not completed; `stop` and `resume` are recorded separately. Registration or amendment while quiesced preserves quiescence until explicit resume. Source claim state stays `UNRESOLVED` unless separately established by the appropriate scientific procedure; nothing self-certifies.

`--local-operator` is a **self-declared local acknowledgment**, not a password, identity proof, or capability token. These commands must NOT be exposed to untrusted agents. Programmatic `WikiJournal.submit()` still accepts assumed authorization flags; external identity protection is a separate requirement.

`--request-id` is the durable idempotency key. Retrying the same command and request ID does not add a second committed event; reusing that ID with changed content is refused. If omitted, the CLI generates a new request ID and prints it. A failed/no-op command may leave a staged, uncommitted draft (visible in `inspect`) because the C2 journal stages before pure validation; draft disposal is an open issue. A goal amendment requires the caller to present the **current** goal digest; the CLI rejects a stale value before staging.

## Export contracts

`export` produces a **data-only** archive, containing exactly eight SQLite files (`wiki.db`, `wiki.history.sqlite` for each of four namespaces) and a digest manifest. It acquires the cooperating local sequencer lock, validates history and replay, copies the byte content, and publishes a new archive without overwriting. A pending draft is preserved as pending, not admitted.

`restore` accepts this project snapshot (or the older C3 source checkpoint's bundled E1 fixture), rejects duplicate/traversal/symlink/unlisted/oversized entries and digest mismatches, extracts **only database files** into an unused temporary directory, validates notebook history and event replay, and renames the directory into place. It does **not** execute archive code and will not overwrite a destination.

The ZIP SHA-256 is an independent provenance anchor **only when retained outside the controller's writable trust domain**. A local sidecar hash tests self-consistency, not chronology or author identity. The method does not prove OS-level power-loss atomicity, malicious-admin tamper resistance, or an unreadable database's recoverability.

## Acceptance evidence (bounded)

- C3 tests: 51 regression cases, including original cold E1 restore.
- C3.1 tests: 13 additional cases for operator controls, pause preservation, idempotency, stable goal versioning, snapshot round-trip and negative integrity checks.
- R0: 44 baseline cases, separately rerun.
- Remaining: D-07 approval, independent-reader comprehension test, power-loss/disk-full behavior, actual principal authentication, rejected-intent cleanup and real agent participation.
