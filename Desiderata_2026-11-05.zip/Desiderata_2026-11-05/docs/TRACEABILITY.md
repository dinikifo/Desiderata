# RFC-0001 v0.2 traceability — bounded C1 evidence only

| Invariant | Required ACs from RFC | C1 evidence | Remaining status |
|---|---|---|---|
| I-01 history | AC-06,12 | in-memory event chain/replay; original goal preserved on amendment | `PARTIAL_ONLY`; no persistence or external anchor |
| I-02 no self-certification | AC-04,05,14 | R0 checker, rejection of injected verdict; system evaluation derives result | `PARTIAL_ONLY`; auth flags are assumed |
| I-03 scoped results | AC-01,02,03 | dual P14 checks; source remains UNRESOLVED | `PARTIAL_ONLY`; semantic fidelity not proved |
| I-04 goal authority | AC-06,14 | model refuses amendment absent supplied human-authorized flag | `PARTIAL_ONLY`; not authenticated |
| I-05 correctable active view | AC-06,12 | proposed correction retained; no automatic amendment | `NO_INTEGRATED_CHECKER` for durable view |
| I-06 exhaustion | AC-07 | in-memory budget exhaustion and source UNRESOLVED | `PARTIAL_ONLY`; persistence missing |
| I-07 turns and recovery | AC-08,09,10,16 | stable-ID dedup and rejected-attempt quota test only | `NO_INTEGRATED_CHECKER` for crash recovery |
| I-08 bounded inspection | AC-12,19 | no CLI restore/verify/inspect | `NO_INTEGRATED_CHECKER` |
| I-09 safe disposition | AC-11,15,17 | unrecoverable local abandon not recorded; escape-only stub | `NO_INTEGRATED_CHECKER` for concrete reachability |

## Acceptance-test status

- **C1 directly exercised in a bounded in-memory model:** parts of AC-01, AC-02, AC-03, AC-04, AC-05, AC-06, AC-07, AC-11, AC-14, AC-15, AC-16, AC-18.
- **Source baseline R0 tests rerun separately:** aspects of AC-01–AC-05 and AC-13; R0's 44 tests do not count as integrated persistence tests.
- **Not discharged:** AC-08, AC-09 (durable conflicts), AC-10, AC-12, AC-17 full concrete reachability analysis, AC-19; full Phase 1 gate also remains open.

No invariant is labelled `VERIFIED_WITHIN_MODEL` as a whole. A test of a narrower subcase cannot discharge the original RFC-wide quantified property.

## C2 additional bounded evidence (not entire-AC discharges)

| RFC requirement | New executable C2 evidence | Status |
|---|---|---|
| AC-08 | Draft/event injected cutpoints, pending recovery and idempotent retry | `PARTIAL`: simulated faults, not all process/disk crash states |
| AC-09 | Ordinal conflict, concurrent submit with local file lock | `PARTIAL`: cooperative POSIX local sequencer |
| AC-10 | Missing agent notebook gives `NAMESPACE_UNAVAILABLE` | `PARTIAL`: no exhaustive unavailability taxonomy |
| AC-11 | Storage unavailable during abandon leaves pending, not false terminal state | `PARTIAL`: simulated `storage_writable=False` |
| AC-12 | Cold re-open equals persistent E1 logical state | `PARTIAL`: no portable three-command restore yet |
| AC-16 | Committed rejected admission costs one turn, retry with same ID no extra | `PARTIAL`: exercised with real WikiCore journal |
| AC-17 | No exhaustive concrete reachability enumerator added | `NO_CHECKER` |
| AC-19 | Headless human command workflow not implemented | `NO_CHECKER` |

No entire RFC-wide invariant is certified from these bounded integration tests.

## C3 inspection evidence (partial AC-19)

- `tests/test_inspection_cli.py::InspectionTests.test_three_command_cold_recovery_explains_transaction` exercises `restore → verify → inspect --explain --diff-from-initial`, reopens the four C2 WikiCore pairs, checks E1 evidence and confirms the SQLite history bytes are not mutated during inspection.
- ZIP negative tests cover altered payloads, unlisted files, duplicate entries, unsafe traversal, missing DB/history members and refusal to overwrite existing workspaces.
- `verify` rejects history changes and unavailable namespaces. The test result establishes deterministic cold-read reconstruction for the **packaged E1 fixture** only.
- **AC-19 partial:** generalized user-created investigations, full human controls and human comprehension cost are not established. The command-count bound has been exercised; no independence or validity proof is implied by an internal test.

## C3.1 additions — bounded local checks, not whole-invariant proofs

- **AC-06 / I-04:** CLI goal and optimistic-locked amendment preserve all goal versions; only locally self-acknowledged operators. Authentication remains **NO_CHECKER**.
- **AC-08, AC-12 / I-07, I-08:** Data-only snapshots of arbitrary four-namespace projects pass cold restore with equivalent event head and timeline; broader power-loss recovery remains **NO_CHECKER**.
- **AC-11, AC-15 / I-09:** CLI stop/abandon record a nonterminal disposition; registration and amendment while QUIESCED never implicitly resume. The human-minutes cost and universal reachability remain **NO_CHECKER**.
- **AC-19 / I-08:** Working `init`, `goal`, `amend`, `stop`, `resume`, `abandon`, `export`, `restore`, `verify`, `inspect` path, with CLI subprocess tests. Independent-reader comprehension remains **NO_CHECKER**.
- **AC-16 / I-07:** retry by stable request ID; changed payload with the same ID refused; no duplicate committed event. Rejected/no-op drafts can remain staged, **OPEN**.
- **D-07:** remains unapproved; test coverage of provisional transition names is not acceptance of the full lifecycle model.


## C3.2 supplementary regression mapping

| Test | Targeted obligation | Result scope |
|---|---|---|
| PROCESS-01 / `test_real_process_exit_after_draft_has_pending_intent_no_commit` | I-07, AC-08 | actual process exit after durable draft; no double charge |
| PROCESS-02 / `test_real_process_exit_after_event_has_single_commit` | I-07, AC-08 | actual process exit after durable system event; replay and idempotent retry |
| PROCESS-03 / `test_simulated_system_io_error_leaves_retryable_pending_intent` | I-07, AC-11 | injected pre-event I/O error; **not** real disk exhaustion |
| READ-01 / `test_black_box_read_of_persisted_e1` | I-08, AC-19 | CLI-only reconstruction of known-answer E1, no independent human evaluator |
| READ-02 / `test_audit_script_no_internal_package_imports` | import boundary for reader audit | AST test for direct internal imports |
| LIFE-01..03 / `test_c3_2_lifecycle_audit` | I-09, AC-15, D-07 still open | only existing provisional statuses and explicit assumed guards; no full finite-state theorem |

This supplements, but does not discharge all of, the parent RFC acceptance mapping. Refer to `docs/C3_2_RECOVERY_AUDIT.md` for assumption boundaries.

## C3 vendor-test restoration (latest bounded evidence)

- **I-01 / history, I-08 / export, I-09 / namespace-state taxonomy:** four recovered legacy upstream test suites now run against `scientific_workspace.storage.vendor_pw`; six additional project tests pass. This strengthens component-level checks only; `PARTIAL_ONLY` still applies to the RFC-wide properties.
- **AC-10 / namespace unavailability:** the original resolver suite exercises `NAMESPACE_UNAVAILABLE` in the vendored package; wider failure taxonomy and real unavailability remain partial.
- **I-08 / accessibility:** the three-command CLI reconstruction remains mechanically exercised; A1 independent-human comprehension remains untested.
- **AC-14 / C4 isolation:** AST preflight explicitly skips when no agent adapter exists; **no** C4 authorization gate is discharged.
- **Mutation controls:** 9/9 new selected mutants caught; the original 30-case campaign was not rerun or transferred.
- **Known defect:** function-local `from db` imports in vendored exporter prevented `WikiCore.export_bundle`; corrected with relative imports and regression checks. `schema_migrations.py` import guard is covered syntactically; full migration semantics remain outside this run.

Current result: **no whole RFC-wide invariant promoted to `VERIFIED_WITHIN_MODEL`** by these component tests.
