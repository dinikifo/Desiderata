# Project contents and source map

## This C2 repository (superseding C1 without changing its archived source)

```text
README.md                       entry point and commands
scientific_workspace/
  engine/r0_core.py              byte-identical preserved R0 core code
  engine/transition.py           new pure provisional event/state transitions
  checkers/finite.py             formal-only checker adapter
  demo.py                        known-answer, in-memory E1 exercise
  persistent_demo.py             durable E1 scenario and replay verification
  storage/journal.py             local advisory-locked authority journal
  storage/vendor_pw/             adapted, provenance-hashed Qt-free WikiCore modules
tests/test_engine.py             pure Phase-1 regression tests
tests/test_persistence.py        WikiCore journal and crash-cutpoint tests
tests/test_progress.py           fixed milestone scorecard consistency
tools/run_r0_baseline.py         verifies R0 digest and reruns its existing tests
fixtures/E1_PHASE1_RESULT.json  generated bounded diagnostic
fixtures/E1_PERSISTENT_WORKSPACE/ real SQLite content/history pairs
fixtures/E1_PERSISTENT_RESULT.json replayed persistent E1 result
sources/
  RFC-0001-v0.2.md              reviewed, not finally adopted contract
  ARCHITECTURE_2026-11-05.md     related four-namespace architecture
  ARCHITECTURE_ERRATA_R1.md      safe-disposition/deadlock corrections
  scientific_reasoning_prototype_R0_2026-11-05.zip  sealed baseline
  SOURCE_RECEIPTS.json          local source hash receipts
  VENDOR_WIKI_PROVENANCE.json   original and adapted vendor hashes
docs/
  GOAL.md, STATE.md, DECISIONS.md, OPEN.md       project handover
  CONSOLIDATION_PLAN.md         C0–C5 consolidation and gates
  DISCUSSION_SUMMARY.md          thematic history of this discussion
  TRACEABILITY.md                invariant/AC status
  PROJECT_CONTENTS.md           this map
  CHANGELOG.md                  what changed in this derived checkpoint
  C2_STORAGE_CONTRACT.md         commit authority, crash windows, trust model
  PROGRESS.json / PROGRESS.md    step, total, estimated remaining work
checkpoints/                    packaging receipts and manifest
```

## Existing project material outside this compact code snapshot

| Collection | Function | Present in C2 archive? |
|---|---|---|
| R2 research monograph / M0.2 verified research corpus | Mathematical and methodological propositions, tests, historical issue register | **No**: nested within the separate M1 historical ZIP |
| M1 research restore point | Two-agent game critique, original automation specification, wiki substrate, gate/decision record | **No**: external; selected Qt-free WikiCore modules vendored with modified imports and provenance |
| M1-ERRATA-1/2/3 | Admission correction, false-refutation/evaluation gate, formalization seam | **No**: external sealed derived archives |
| P1/P2 scientific progress records | Zettel progress map, decisions, open questions and evidence index | **No**: external archives |
| P1 review R1 | Reconciled edge diff and a bounded index verification script | **No**: external archive |
| R0 prototype | Actual pure claim/witness checker and index reader | **Yes**: preserved ZIP; its `core.py` also copied byte-identically for use |
| Four-namespace architecture & deadlock erratum | Agent interactions, storage/turn control, suspension and safe-disposition obligations | **Yes**: relevant documents |
| RFC-0001 v0.2 | Proposed work plan, invariants and AC-01…AC-19 | **Yes**: supplied baseline |

**Note:** The table describes roles and packaging, not external authenticity. The full historical document collection is larger than this code checkpoint. Keep the original ZIPs separately; do not treat `DISCUSSION_SUMMARY.md` as a substitute for the historical sources or conversation.

## C1 → C2 checkpoint relation

C1 is preserved in its separately distributed source ZIP and Git commit; this C2 checkpoint is a later Git commit with new modules and tests. All historical research archives remain external as listed. The new progress scorecard explicitly defines the C3 headless, inspectable MVP as its denominator; C4/C5 are separate longer-term goals.

## Source hierarchy / authority

- Original monograph and user goals: source material, not automatically true propositions.
- Human-authorized decisions: project control, not certification.
- Agent posts: attributable proposals and challenges, not trusted findings.
- Validators: admission of structured records, not truth of their content.
- Domain-specific checkers: explicitly scoped formal results, contingent on correct formalization.
- Active view: derived project knowledge, never an independent mutable truth authority.

## C3 addition

`scientific_workspace/interface/` adds a checked, data-only cold-restore reader and an attributed human inspection projection. `bin/scientific-workspace` exposes the three standard commands. `docs/C3_INSPECTION_CONTRACT.md` contains the precise scope and nonclaims; `tests/test_inspection_cli.py` includes the end-to-end and negative tests. These files supplement the prior C0/C1/C2 code; no replacement has been made to the sealed R0 archive, monograph or research source materials.


## C3.1 contents

- `scientific_workspace/interface/project_io.py`: eight-file data-only project export/restore with manifest and checked replay.
- `scientific_workspace/interface/cli.py`: local human goal-control and restoration command surface.
- `tests/test_operator_and_snapshots.py`: new bounded operator, versioning and recovery regressions.
- `docs/C3_1_OPERATOR_CONTRACT.md`: contract, command examples and trust limits.
- `checkpoints/C3_1_*`: test receipts; `docs/PROGRESS.json` remains scorecard authority.
