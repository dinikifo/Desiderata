#!/usr/bin/env python3
"""Compute the bounded planning estimate directly from PROGRESS.json."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def report():
    cfg = json.loads((ROOT / 'docs/PROGRESS.json').read_text(encoding='utf-8'))
    steps = cfg['steps']
    if (len(steps) != cfg['total_steps'] or
        [s['id'] for s in steps] != list(range(1, len(steps) + 1)) or
        sum(s['weight'] for s in steps) != 100 or
        not all(0 <= s['completion'] <= 1 for s in steps) or
        not 1 <= cfg['current_step'] <= len(steps)):
        raise ValueError('INVALID_PROGRESS_SCORECARD')
    completed = sum(s['weight'] * s['completion'] for s in steps)
    remaining = 100 - completed
    return cfg, completed, remaining


def markdown():
    cfg, completed, remaining = report()
    lines = [f'# Progress — {cfg["checkpoint"]}', '',
             f'**Current step: {cfg["current_step"]} of {cfg["total_steps"]}.** '
             f'**Estimated work completed: {completed:.0f}%; remaining: {remaining:.0f}%.**', '',
             f'**Target:** {cfg["target"]}', '',
             f'*Method:* {cfg["estimate_note"]}', '',
             '| Step | Work package | Status | Planning weight | Fraction completed |',
             '|---:|---|---|---:|---:|']
    for s in cfg['steps']:
        lines.append(f'| {s["id"]}/{len(cfg["steps"])} | {s["title"]} | '
                     f'{s["status"]} | {s["weight"]}% | {s["completion"]:.0%} |')
    lines += ['', '## Evidence and blockers', '']
    for s in cfg['steps']:
        lines.append(f'- **Step {s["id"]}:** {s["evidence"]}')
    lines += ['', cfg['longer_term'], '',
              'The estimate is revised only with an explicit change to the versioned scorecard. '
              'Passing tests does not automatically imply a completed phase or proven scientific efficacy.', '']
    return '\n'.join(lines)


if __name__ == '__main__':
    print(markdown())
