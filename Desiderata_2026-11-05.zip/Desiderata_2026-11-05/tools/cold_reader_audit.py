#!/usr/bin/env python3
"""Black-box cold-read audit using ONLY the documented CLI protocol.

No imports from scientific_workspace. This establishes a reproducible command
and reconstruction contract, not successful comprehension by an independent
human, authenticated provenance, or external scientific validity.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def run_cli(launcher, *args):
    proc = subprocess.run([sys.executable, str(launcher), *map(str, args)],
                          capture_output=True, text=True, timeout=60,
                          cwd=launcher.parent.parent)
    if proc.returncode:
        raise RuntimeError(f'CLI failed ({args[0]}): {proc.stderr.strip()}')
    return proc.stdout


def audit(launcher, archive, dest, expected_sha256=None, expect_e1=False):
    params = ['restore', '--archive', archive, '--workspace', dest]
    if expected_sha256:
        params += ['--expected-sha256', expected_sha256]
    restored = json.loads(run_cli(launcher, *params))
    verified = json.loads(run_cli(launcher, 'verify', '--workspace', dest, '--json'))
    inspected = json.loads(run_cli(launcher, 'inspect', '--workspace', dest, '--json'))
    explanation = run_cli(launcher, 'inspect', '--workspace', dest, '--diff-from-initial')
    if (not verified['ok'] or inspected['journal_history_and_replay'] != 'PASS'
            or verified['head_digest'] != inspected['head_digest']
            or verified['event_count'] != inspected['event_count']
            or restored['event_count'] != verified['event_count']
            or len(inspected['timeline']) != inspected['event_count']):
        raise AssertionError('COLD_READ_RECONSTRUCTION_MISMATCH')
    if not all(x in explanation for x in (
        '## Goal and corrections', '## Formal evidence and verification receipts',
        '## Changes since the initial state', 'Source claim:')):
        raise AssertionError('MISSING_READ_PATH_SECTION')
    if expect_e1:
        results = {x['receipts'][0]['result'] for x in inspected['evaluations']}
        if (results != {'FORMAL_COUNTEREXAMPLE_VERIFIED', 'PREMISE_NOT_SATISFIED'}
                or inspected['source_claim_state'] != 'UNRESOLVED'
                or len(inspected['corrections']) != 1
                or inspected['corrections'][0]['status'] != 'PROPOSED'
                or inspected['lifecycle'] != 'EXHAUSTED'):
            raise AssertionError('E1_KNOWN_ANSWER_MISMATCH')
    return {
        'audit': 'BLACK_BOX_COLD_READ_PASS',
        'command_count': 4,  # restore, verify, inspect JSON, inspect explanation
        'reconstruction_commands': 3, # one inspection representation at a time
        'events': verified['event_count'],
        'head_digest': inspected['head_digest'],
        'lifecycle': inspected['lifecycle'],
        'source_claim_state': inspected['source_claim_state'],
        'pending': len(inspected['pending_intents']),
        'e1_known_answer_checked': bool(expect_e1),
        'limits': ('Machine-readable consistency and bounded CLI command count only. '
                   'No independent human reader, power-loss, trusted identity or semantics proof.'),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--launcher', default=str(Path(__file__).resolve().parents[1] / 'bin/scientific-workspace'))
    p.add_argument('--archive', required=True)
    p.add_argument('--workspace', required=True)
    p.add_argument('--expected-sha256')
    p.add_argument('--expect-e1', action='store_true')
    args = p.parse_args()
    result = audit(Path(args.launcher).resolve(), Path(args.archive).resolve(),
                   Path(args.workspace).resolve(), args.expected_sha256, args.expect_e1)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
