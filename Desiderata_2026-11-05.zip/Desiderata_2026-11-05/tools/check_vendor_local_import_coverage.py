#!/usr/bin/env python3
"""Fail-closed executed-line coverage for function-local imports in vendored PERSONAL.WIKI.

Standard-library only. This gate discovers *all* local imports under function
nodes in vendor_pw, then runs explicitly named test modules/scripts in separate
interpreters under sys.settrace. Unvisited sites fail; test failures fail.

Limitations: Python's `line` trace means execution reached the line; it does
not independently establish import success or the downstream API's correctness.
Targeted behavioral assertions (not this gate) establish the latter.
Call graph completeness and line coverage beyond function-local imports are
outside the claim. Source digests bind the report to the scanned code.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys
import tempfile
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / 'scientific_workspace' / 'storage' / 'vendor_pw'
# These are *test commands*, not trusted source claims. Every tested suite must
# succeed, and coverage only counts lines observed in the traced subprocess.
JOBS = (
    ('upstream_workspace', 'script', 'tests/vendor_legacy_scripts/test_workspace.py'),
    ('upstream_resolver', 'script', 'tests/vendor_legacy_scripts/test_resolver.py'),
    ('upstream_defect_fixes', 'script', 'tests/vendor_legacy_scripts/test_defect_fixes.py'),
    ('upstream_export_determinism', 'script', 'tests/vendor_legacy_scripts/test_export_determinism.py'),
    ('legacy_migration', 'module', 'tests.test_vendor_migration'),
)


def scan_function_imports(vendor: Path = VENDOR) -> tuple[list[dict[str, Any]], dict[str, str]]:
    """Find import statements lexically inside functions, including nested scopes.

    Restrict AST traversal to functions so module-level imports do not dilute
    the purpose of this check. New function-local imports are discovered without
    updating a hand-maintained allowlist.
    """
    sites: list[dict[str, Any]] = []
    hashes: dict[str, str] = {}
    for path in sorted(vendor.rglob('*.py')):
        code = path.read_bytes()
        rel = path.relative_to(vendor).as_posix()
        hashes[rel] = hashlib.sha256(code).hexdigest()
        tree = ast.parse(code, filename=str(path))

        def walk(node: ast.AST, function_stack: tuple[str, ...] = ()) -> None:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                function_stack = (*function_stack, node.name)
            elif isinstance(node, ast.Lambda):
                function_stack = (*function_stack, '<lambda>')
            if function_stack and isinstance(node, (ast.Import, ast.ImportFrom)):
                sites.append({
                    'file': rel, 'line': node.lineno,
                    'function': '.'.join(function_stack),
                    'import': ast.unparse(node),
                })
            for _, value in ast.iter_fields(node):
                children = value if isinstance(value, list) else (value,)
                for child in children:
                    if isinstance(child, ast.AST):
                        walk(child, function_stack)
        walk(tree)
    return sorted(sites, key=lambda x: (x['file'], x['line'], x['function'])), hashes


def summarize(sites: list[dict], runs: list[dict]) -> dict[str, Any]:
    """Pure evaluation: neither failed jobs nor missing sites can be ignored."""
    reached: dict[tuple[str, int], list[str]] = {}
    for run in runs:
        if run.get('status') != 'PASS':
            continue
        for hit in run.get('hits', []):
            reached.setdefault((hit['file'], hit['line']), []).append(run['name'])
    site_rows = [dict(site, reached_by=sorted(set(reached.get((site['file'], site['line']), []))),
                      visited=bool(reached.get((site['file'], site['line'])))) for site in sites]
    missing = [f"{s['file']}:{s['line']}:{s['function']}" for s in site_rows if not s['visited']]
    # A line trace cannot distinguish two AST imports on one physical line.
    counts: dict[tuple[str, int], int] = {}
    for site in sites:
        key=(site['file'], site['line'])
        counts[key]=counts.get(key, 0)+1
    ambiguous = [f'{file}:{line}' for (file, line), count in sorted(counts.items()) if count > 1]
    failed = [r['name'] for r in runs if r.get('status') != 'PASS']
    return {
        'status': 'PASS' if not missing and not failed and not ambiguous and sites and runs else 'FAIL',
        'sites_total': len(site_rows), 'sites_visited': len(site_rows)-len(missing),
        'missing': missing, 'ambiguous_same_line_imports': ambiguous, 'failed_jobs': failed, 'sites': site_rows,
    }


def _worker(mode: str, target: str, output: Path) -> int:
    sys.path.insert(0, str(ROOT))
    sites, hashes = scan_function_imports()
    watched = {(str((VENDOR / site['file']).resolve()), site['line']) for site in sites}
    hits: set[tuple[str, int]] = set()
    vendor_prefix = str(VENDOR.resolve()) + '/'

    def vendor_trace(frame, event, arg):
        if event == 'line' and (frame.f_code.co_filename, frame.f_lineno) in watched:
            hits.add((frame.f_code.co_filename, frame.f_lineno))
        return vendor_trace

    def tracer(frame, event, arg):
        if event == 'call' and frame.f_code.co_filename.startswith(vendor_prefix):
            return vendor_trace
        return None

    status = 'PASS'
    detail = ''
    original_argv = sys.argv[:]  # unittest must not see the coverage runner's arguments
    sys.settrace(tracer)
    try:
        if mode == 'script':
            path = ROOT / target
            sys.argv = [str(path)]
            sys.path.insert(0, str(path.parent))  # match `python tests/.../test.py`
            runpy.run_path(str(path), run_name='__main__')
        elif mode == 'module':
            sys.argv = [target]
            runpy.run_module(target, run_name='__main__', alter_sys=True)
        else:
            raise ValueError('invalid worker mode')
    except SystemExit as exc:
        if exc.code not in (0, None):
            status = 'FAIL'
            detail = f'SystemExit({exc.code!r})'
    except BaseException as exc:
        status = 'FAIL'
        detail = f'{type(exc).__name__}: {exc}'
    finally:
        sys.settrace(None)
        sys.argv = original_argv
        output.write_text(json.dumps({
            'status': status, 'detail': detail,
            'source_sha256': hashes,
            'hits': [{'file': Path(file).resolve().relative_to(VENDOR.resolve()).as_posix(), 'line': line}
                     for file, line in sorted(hits)],
        }, indent=2) + '\n', encoding='utf-8')
    return 0 if status == 'PASS' else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'checkpoints/C3_4_IMPORT_COVERAGE.json')
    parser.add_argument('--worker', nargs=3, metavar=('MODE', 'TARGET', 'RESULT'),
                        help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        mode, target, path = args.worker
        return _worker(mode, target, Path(path))
    sites, hashes = scan_function_imports()
    runs: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix='pw_import_trace_') as folder:
        for number, (name, mode, target) in enumerate(JOBS):
            result = Path(folder) / f'{number}.json'
            proc = subprocess.run([sys.executable, '-B', str(Path(__file__).resolve()),
                                   '--worker', mode, target, str(result)],
                                  cwd=ROOT, capture_output=True, text=True, timeout=50)
            payload: dict[str, Any] = {}
            if result.is_file():
                try:
                    payload = json.loads(result.read_text(encoding='utf-8'))
                except (OSError, ValueError):
                    pass
            reported_ok = payload.get('status') == 'PASS'
            digest_ok = payload.get('source_sha256') == hashes
            status = 'PASS' if (proc.returncode == 0 and reported_ok and digest_ok) else 'FAIL'
            runs.append({
                'name': name, 'target': target, 'status': status,
                'returncode': proc.returncode,
                'trace_digest_match': digest_ok,
                'hits': payload.get('hits', []),
                'stderr_tail': proc.stderr[-1200:],
                'stdout_tail': proc.stdout[-500:],
                'error': payload.get('detail', '')
            })
            print(f'{name}: {status}, {len(payload.get("hits", []))} import lines visited', flush=True)
    assessment = summarize(sites, runs)
    report = {
        'tool': 'standard_library_ast_and_line_trace',
        'claim': 'All discovered function-local import statement lines in vendor_pw were reached in a passing named test subprocess',
        'limitation': 'Line execution does not independently prove import success, branch/semantic correctness, or complete module coverage; migration/export behavior has separate assertions.',
        'source_sha256': hashes,
        'jobs': runs,
        **assessment,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(f"{assessment['status']}: {assessment['sites_visited']}/{assessment['sites_total']} import sites visited")
    if assessment['missing']:
        print('MISSING: ' + ', '.join(assessment['missing']), file=sys.stderr)
    if assessment['ambiguous_same_line_imports']:
        print('AMBIGUOUS SAME-LINE IMPORTS: ' + ', '.join(assessment['ambiguous_same_line_imports']), file=sys.stderr)
    return 0 if assessment['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
