#!/usr/bin/env python3
"""Rebuild local digest manifest and compact ZIP source checkpoint.

Checksums accompany an archive but cannot supply an independent time anchor.
"""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'checkpoints/PACKAGE_MANIFEST.json'
SKIP = {'.git', '__pycache__', '.pytest_cache'}


def contents():
    return [p for p in sorted(ROOT.rglob('*'))
            if p.is_file() and not SKIP.intersection(p.relative_to(ROOT).parts)]


def build():
    files = []
    for p in contents():
        if p == MANIFEST:
            continue
        files.append({'path':p.relative_to(ROOT).as_posix(),
                      'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                      'bytes':p.stat().st_size})
    manifest = {
        'schema':'sw-local-checkpoint-manifest/0.1',
        'status':'DESIDERATA_DOCUMENTATION_RELEASE_1 / C3_4_CODEBASE / HOLD / D07_BOUNDED_APPROVED',
        'meaning':'Local file integrity; not independent origin, timestamp, or scientific validity',
        'files':files,
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    archive = ROOT.parent / (ROOT.name + '.zip')
    with ZipFile(archive, 'w', compression=ZIP_DEFLATED, compresslevel=9) as z:
        for p in contents():
            arcname = ROOT.name + '/' + p.relative_to(ROOT).as_posix()
            info = ZipInfo(arcname, date_time=(2026,11,5,0,0,0))
            info.compress_type = ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (0o100000 | (p.stat().st_mode & 0o777)) << 16
            z.writestr(info, p.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    receipt = archive.with_suffix('.sha256')
    receipt.write_text(f'{digest}  {archive.name}\n')
    return archive, digest, len(files)


if __name__ == '__main__':
    archive, digest, count = build()
    print(f'Archive: {archive}\nSHA-256: {digest}\nManifest payloads: {count}')
