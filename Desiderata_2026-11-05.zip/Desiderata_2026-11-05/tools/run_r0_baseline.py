#!/usr/bin/env python3
"""Verify preserved R0 digest then run its historical tests in a temp dir.

Only run code you trust; digest equality is not a software safety guarantee.
"""
import hashlib
import pathlib
import subprocess
import sys
import tempfile
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / 'sources/scientific_reasoning_prototype_R0_2026-11-05.zip'
EXPECTED = 'ad8fd86cc3a3aad960a95173c3147a35aae5f989e318ced0c50b81e143c058f4'


def main():
    actual = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    if actual != EXPECTED:
        print('BASELINE_DIGEST_MISMATCH', file=sys.stderr)
        return 2
    with tempfile.TemporaryDirectory(prefix='sw_r0_') as tmp:
        with zipfile.ZipFile(ARCHIVE) as z:
            for item in z.infolist():
                relative = pathlib.PurePosixPath(item.filename)
                if item.is_dir():
                    continue
                if relative.is_absolute() or '..' in relative.parts:
                    raise ValueError('unsafe archive path')
                target = pathlib.Path(tmp).joinpath(*relative.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(item))
        old = pathlib.Path(tmp) / 'scientific_reasoning_prototype_R0_2026-11-05'
        proc = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'],
                              cwd=old, check=False)
    return proc.returncode


if __name__ == '__main__':
    raise SystemExit(main())
