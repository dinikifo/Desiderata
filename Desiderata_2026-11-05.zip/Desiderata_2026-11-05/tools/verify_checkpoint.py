#!/usr/bin/env python3
"""Verify exact checkpoint file inventory and digests; no bundled code execution.

This is a local consistency tool. It is NOT an independent signed anchor.
"""
import hashlib
import json
import pathlib
import sys

MANIFEST = 'checkpoints/PACKAGE_MANIFEST.json'
IGNORED_DIRS = {'.git', '__pycache__', '.pytest_cache'}


def verify(root):
    root = pathlib.Path(root).resolve()
    try:
        manifest = json.loads((root / MANIFEST).read_text(encoding='utf-8'))
        entries = manifest['files']
        expected = {}
        for record in entries:
            rel = record['path']
            parts = pathlib.PurePosixPath(rel)
            if parts.is_absolute() or '..' in parts.parts or str(parts) != rel or rel == MANIFEST or rel in expected:
                raise ValueError('unsafe, duplicate or self-referencing manifest entry: ' + rel)
            expected[rel] = record['sha256']
        actual = {}
        for path in root.rglob('*'):
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            if set(rel.parts).intersection(IGNORED_DIRS) or rel.as_posix() == MANIFEST:
                continue
            actual[rel.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
        missing = sorted(set(expected)-set(actual))
        extras = sorted(set(actual)-set(expected))
        wrong = sorted(k for k in set(expected)&set(actual) if expected[k] != actual[k])
        return {'ok': not (missing or extras or wrong), 'listed': len(expected),
                'missing': missing, 'extras': extras, 'wrong_digest': wrong}
    except (KeyError, ValueError, OSError, json.JSONDecodeError, TypeError) as exc:
        return {'ok': False, 'error': str(exc)}


if __name__ == '__main__':
    result = verify(sys.argv[1] if len(sys.argv)>1 else pathlib.Path(__file__).resolve().parents[1])
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['ok'] else 1)
