#!/usr/bin/env python3
"""Isolated black-box negative control for the vendor import coverage gate.

Clones the source into a temporary directory, adds a never-called function
containing a new local import, and requires the real gate to fail with a named
missing site. Never modifies the release source tree.
"""
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    with tempfile.TemporaryDirectory(prefix='sw_missing_import_probe_') as folder:
        work=Path(folder)/'project'
        shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns('.git','__pycache__','.pytest_cache'))
        fixture=work/'scientific_workspace/storage/vendor_pw/_coverage_probe.py'
        fixture.write_text('def never_called():\n    import decimal\n', encoding='utf-8')
        report=work/'probe.json'
        proc=subprocess.run([sys.executable,'-B',str(work/'tools/check_vendor_local_import_coverage.py'),
                             '--output', str(report)], cwd=work, text=True,
                            capture_output=True, timeout=90)
        result=json.loads(report.read_text()) if report.is_file() else {}
        expected='_coverage_probe.py:2:never_called'
        passed=(proc.returncode != 0 and result.get('status') == 'FAIL'
                and expected in result.get('missing', [])
                and 'MISSING:' in proc.stderr)
        print(json.dumps({
            'status':'PASS' if passed else 'FAIL', 'test':'new_unvisited_import_is_detected',
            'expected_missing':expected,'gate_exit_code':proc.returncode,
            'missing':result.get('missing', []),
            'scope':'disposable cloned source, no source mutation',
        }, indent=2))
        return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
