#!/usr/bin/env python3
"""Reproduce C3.4 named split test suites and write bounded source-bound receipts."""
from pathlib import Path
import json
import subprocess
import sys
import time
import re

ROOT=Path(__file__).resolve().parents[1]
JOBS=[
 ('core', ['-B','-m','unittest','-q','tests.test_engine','tests.test_persistence','tests.test_process_exit_recovery','tests.test_c3_2_lifecycle_audit','tests.test_cold_reader_contract','tests.test_progress','tests.test_baseline_and_imports']),
 ('operator', ['-B','-m','unittest','-q','tests.test_operator_and_snapshots']),
 ('inspection', ['-B','-m','unittest','-q','tests.test_inspection_cli']),
 ('vendor', ['-B','-m','unittest','-q','tests.test_vendor_regressions']),
 ('local_imports', ['-B','-m','unittest','-q','tests.test_vendor_migration','tests.test_vendor_local_import_coverage']),
 ('future_guard', ['-B','-m','unittest','-q','tests.test_c4_future_boundary']),
 ('import_coverage', ['-B','tools/check_vendor_local_import_coverage.py']),
 ('r0', ['-B','tools/run_r0_baseline.py']),
]

def main() -> int:
    rows=[]
    for name,args in JOBS:
        print('START', name, flush=True)
        t=time.monotonic()
        try:
            proc=subprocess.run([sys.executable,*args],cwd=ROOT,text=True,
                                capture_output=True,timeout=125)
            code,out,err=proc.returncode,proc.stdout,proc.stderr
        except subprocess.TimeoutExpired as exc:
            code=124
            out=(exc.stdout or b'').decode() if isinstance(exc.stdout,bytes) else (exc.stdout or '')
            err=(exc.stderr or b'').decode() if isinstance(exc.stderr,bytes) else (exc.stderr or '')
            err+='\nTIMED_OUT'
        seconds=round(time.monotonic()-t,2)
        receipt=f'checkpoints/C3_4_{name}.txt'
        (ROOT/receipt).write_text(f'COMMAND: python {" ".join(args)}\nRETURN_CODE: {code}\nSECONDS: {seconds}\n=== STDOUT ===\n{out}\n=== STDERR ===\n{err}',encoding='utf-8')
        match=re.search(r'Ran (\d+) tests? in',err)
        row=dict(name=name,returncode=code,seconds=seconds,skipped=('skipped=1' in err),
                 tests_reported=int(match.group(1)) if match else None,
                 receipt=receipt,passed=code==0)
        rows.append(row)
        print('END', name, 'PASS' if code==0 else 'FAIL', seconds,flush=True)
    summary={'status':'PASS' if all(x['passed'] for x in rows) else 'FAIL',
             'caveat':'Split-run tests; future C4 guard is skipped if no agent adapter. No claim that historical 30 mutations were reproduced.',
             'jobs':rows}
    (ROOT/'checkpoints/C3_4_TEST_REPORT.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    return 0 if summary['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
