#!/usr/bin/env python3
"""Check the Desiderata editorial entry points and local document links.

This validates editorial structure and link paths, not the truth of prose claims.
"""
from __future__ import annotations

import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
REQUIRED = [
    'README.md', 'LICENSE', 'bin/desiderata',
    'docs/monographs/INDEX.md',
    'docs/manual/USER_MANUAL.md',
    'docs/roadmaps/CODEBASE.md',
    'docs/roadmaps/CREATORS.md',
    'docs/references/BIBLIOGRAPHY.md',
    'docs/governance/LICENSE_AND_PROVENANCE.md',
    'docs/governance/HISTORICAL_RECORD.md',
    'docs/governance/ASSEMBLY_VERIFICATION.md',
    'docs/proposals/DN-0001-PROPOSED.md',
]
LINK_RE = re.compile(r'(?<!!)\[[^\]]*\]\(([^)]+)\)')


def check(root: pathlib.Path = ROOT) -> list[str]:
    errors = []
    for rel in REQUIRED:
        if not (root / rel).is_file():
            errors.append('missing required file: ' + rel)
    monographs = sorted((root / 'docs/monographs').glob('M[0-9][0-9]-*.md'))
    if len(monographs) != 8:
        errors.append(f'expected eight monographs, found {len(monographs)}')
    for p in [root / 'README.md', *sorted((root / 'docs/monographs').glob('*.md')),
              *sorted((root / 'docs/manual').glob('*.md')),
              *sorted((root / 'docs/roadmaps').glob('*.md')),
              *sorted((root / 'docs/references').glob('*.md')),
              *sorted((root / 'docs/governance').glob('*.md'))]:
        if not p.exists():
            continue
        body = p.read_text(encoding='utf-8')
        if not body.strip():
            errors.append('empty documentation: ' + str(p.relative_to(root)))
        for url in LINK_RE.findall(body):
            url = url.strip().split('#', 1)[0]
            if not url or url.startswith(('https://', 'http://', 'mailto:')):
                continue
            # Markdown path links, not templates or placeholders.
            target = p.parent / url
            if not target.exists():
                errors.append(f'broken local link: {p.relative_to(root)} → {url}')
    if not (root / 'scientific_workspace/engine/transition.py').is_file():
        errors.append('missing underlying implementation')
    if not (root / 'scientific_workspace/storage/vendor_pw/LICENSE').is_file():
        # The upstream historical notice may have a different expected name.
        notices = list((root / 'scientific_workspace/storage/vendor_pw').rglob('*LICENSE*'))
        if not notices:
            errors.append('missing preserved upstream license notice')
    lic = (root / 'LICENSE').read_text(encoding='utf-8') if (root / 'LICENSE').exists() else ''
    if not lic.startswith('Creative Commons Legal Code\n\nCC0 1.0 Universal'):
        errors.append('root license does not contain full CC0 legal code header')
    return errors


if __name__ == '__main__':
    errors = check()
    for error in errors:
        print('ERROR:', error)
    if errors:
        raise SystemExit(1)
    print('PASS: eight monographs, required files, local links, code entry point and license')
