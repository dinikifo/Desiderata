#!/usr/bin/env python3
"""Check document links, source receipts, and separately executed test logs.

A concordance test, not a proof of scientific validity or source authenticity.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/consolidated'


def check(historical_dir=None):
    failures = []
    status = json.loads((DOC/'CURRENT_STATUS.json').read_text())
    findings = json.loads((DOC/'FINDINGS.json').read_text())['entries']
    catalog = json.loads((DOC/'SOURCE_CATALOG.json').read_text())['sources']
    ids = [row['id'] for row in findings]
    if len(ids) != len(set(ids)) or ids != [f'F-{i:02d}' for i in range(1,len(ids)+1)]:
        failures.append('FINDING_IDS_NOT_UNIQUE_CONTIGUOUS')
    sources = {row['id'] for row in catalog}
    for row in findings:
        if row['source_id'] not in sources:
            failures.append('UNKNOWN_SOURCE:'+row['id'])
    agenda = (DOC/'DISCUSSION_AGENDA.md').read_text()
    references = set(re.findall(r'F-\d{2}', agenda))
    if not references or not references <= set(ids):
        failures.append('DANGLING_AGENDA_FINDING_REF')
    if re.search(r'F-\d{2}\s*[–-]\s*F-\d{2}', agenda):
        failures.append('AMBIGUOUS_RANGE_NOT_EXPANDED')
    if status['d07']['status'] != 'APPROVED_BOUNDED' or len(status['d07']['approved_states']) != 5:
        failures.append('D07_SCOPE_NOT_EXPLICIT')
    progress = json.loads((ROOT/'docs/PROGRESS.json').read_text())
    if (progress['current_step'], progress['total_steps']) != (6,6):
        failures.append('PROGRESS_STEP_DRIFT')
    total = sum(float(x['weight'])*float(x['completion']) for x in progress['steps'])
    if abs(total-status['progress']['estimated_complete_pct']) > 0.001:
        failures.append('PROGRESS_ARITHMETIC_DRIFT')
    checked = []
    unavailable = []
    for source in catalog:
        f = None
        if source['location_in_full_bundle'].startswith('codebase/'):
            f = ROOT / source['name']
        elif historical_dir is not None:
            f = historical_dir / source['name']
        if f is None:
            unavailable.append(source['id'])
            continue
        if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest() != source['sha256']:
            failures.append('SOURCE_HASH_MISMATCH_OR_MISSING:'+source['id'])
        else:
            checked.append(source['id'])
    reports = {}
    for n,log in [('targeted','TARGETED_TESTS.txt'),('operator_inspection','OPERATOR_INSPECTION_TESTS.txt'),('r0','R0_BASELINE.txt')]:
        data = (ROOT/'checkpoints/consolidation'/log).read_text()
        match = re.search(r'Ran (\d+) tests? in',data)
        if not match or not re.search(r'(?m)^OK\s*$',data) or 'FAILED (' in data:
            failures.append('TEST_REPORT_NOT_PASSING:'+n)
        else:
            reports[n]=int(match.group(1))
    if reports.get('targeted') != 46 or reports.get('operator_inspection') != 26 or reports.get('r0') != 44:
        failures.append('TEST_COUNTS_NOT_AS_DECLARED')
    return {'ok':not failures,'failed_checks':failures,'findings':len(findings),'agenda_references':len(references),
            'catalog_sources_verified':checked,'optional_historical_sources_not_supplied':unavailable,
            'test_groups':reports,'tests_total_current':reports.get('targeted',0)+reports.get('operator_inspection',0)}


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--historical-dir',type=Path,help='optional source ZIP directory for full-bundle hash checks')
    args=p.parse_args()
    result=check(args.historical_dir)
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result['ok'] else 1)
