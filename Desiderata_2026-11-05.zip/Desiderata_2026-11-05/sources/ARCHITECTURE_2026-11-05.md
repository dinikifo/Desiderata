# Architecture — a three-party scientific-accountability workspace

**Date:** 2026-11-05 · **Status:** architecture, defended. Not implemented, not authorised.
**Gate:** `HOLD` unchanged. `read_only_analysis: PERMITTED` covers this document.

---

## 0. Bounded read path

This document is deliberately short, because the prior round established that a record
nobody can read cheaply has failed regardless of how verifiable it is in principle.

**If you read one paragraph:** four namespaces on disk — `user/`, `agent_a/`, `agent_b/`,
`system/`. Each party writes exactly one and reads all four. A goal is a post in `user/`.
Two agents take strictly alternating turns, each writing only into its own namespace, so
neither can revise the other's position. Claims may be refuted with a machine-checked
witness or left unresolved; **nothing in the system can certify.** A coroutine, persisted
as an append-only event log, controls turn-taking; it halts when nobody is inspecting.

**If you read one section:** §1 and §2. **If you are auditing a claim:** §4 and §6.
**If you are deciding whether to build it:** §7 and §8.

---

## 1. The access matrix

```
WORKSPACE/
  user/      wiki.db + wiki.history.sqlite     written by: the human
  agent_a/   wiki.db + wiki.history.sqlite     written by: agent A
  agent_b/   wiki.db + wiki.history.sqlite     written by: agent B
  system/    wiki.db + wiki.history.sqlite     written by: the coroutine only
```

| | writes | reads |
|---|---|---|
| human | `user/` | all four |
| agent A | `agent_a/` | all four |
| agent B | `agent_b/` | all four |
| coroutine | `system/` | all four |

Exclusive write, universal read. Enforced by the filesystem and by
`WikiCore(path, readonly=True)` — both already built and mutation-tested. **There is no
access-control code**, because a namespace is a notebook and a notebook opened read-only
refuses writes.

`system/` holds what no party authors: verification receipts, gate transitions, the turn
log, exhaustion records. Because it is an ordinary notebook it inherits the history
sidecar, per-post digests and the deterministic export for free.

---

## 2. Two ideas that do most of the work

### 2.1 The goal lives on the user's zettel

The human does not pass a goal as a parameter. He writes a post in `user/`, and the
coroutine finds it by digest diff against last-seen. Three consequences:

- **No off-record channel exists.** Every input — goal, amendment, permission grant,
  read receipt — is a versioned digested post. Nothing steers the argument from outside
  the record, so the transcript cannot be missing the thing that changed the outcome.
- **The issued-context digest becomes automatic.** The context *is* a set of posts with
  digests. There is no separate bundle to assemble, and therefore no way for the context
  to differ from what the record says it was.
- **Steering is attributable.** The user cannot correct an agent mid-argument. If they
  are arguing about the wrong thing his options are *stop* or *amend the goal* — and an
  amendment is a new goal version, visible and digested.

### 2.2 The zettel is not the record

An agent writes freely into its own namespace. The **record** is the *admitted subset*,
and admission is decided by a deterministic validator the agent cannot influence.

This resolves an apparent contradiction in earlier drafts — "the agent never writes to
the record" versus "each agent writes its own zettel." Both hold: the zettel is the
agent's workspace; the record is its admitted projection. Every post carries
`PROPOSED | ADMITTED | REJECTED`, the derived index counts only admitted posts, and the
user interface must render the three distinctly.

The agent cannot be prevented from writing. It can be prevented from having its writes
*count*, which is the only prevention that matters.

---

## 3. Acts, not roles

Neither agent is "the claimant" or "the challenger." Those are **acts**, and the turn
determines which are legal. On its turn an agent may register a claim, or challenge an
existing one, or pass with a full disposition set.

This removes the role-assignment and role-rotation questions entirely, and with them the
temptation to claim that rotation produces independence. Whoever's turn it is may do
either thing; the first mover is derived deterministically from the goal post's digest,
so it is replayable and nobody chooses it.

---

## 4. The coroutine

Persisted, not live: the state is the **fold over an append-only event log** in
`system/`, never stored alongside it. A crash between two stores cannot create a
disagreement because there is only one store.

**Resume means revalidate, then continue** — never "continue from saved state." Gates are
re-evaluated against current conditions, because permissions and budgets are explicitly
not restorable. A coroutine saved before a gate fired must not resume past it.

**Yield types (4):** `yield_turn` · `yield_for_authorization` · `yield_blocked(reason)` ·
`yield_done`.

**Statuses (6):** `waiting_for_goal` · `waiting_for_turn` · `waiting_for_inspection` ·
`waiting_for_authorization` · `dead_completed` · `dead_failed`.

**Human resumes (6):** `goal` · `stop` · `abandon` · `read_receipt` ·
`permission_grant` · `budget_change`.

The yield value declares **which kind of resume is legal**. A coroutine that yielded an
authorization request cannot be resumed with a goal. The 6 × 6 legality table is 36
cells, each permitting or refusing with a reason — small enough to enumerate
exhaustively and pin byte-stable, the same instrument that made authorisation decidable
elsewhere in this programme at 2700× the size.

**The invariant that defines "does not break":**

> Every suspension names its resumption condition, and every reachable state has at
> least one legal resume costing a human minutes, not hours.

This is *checkable over 36 cells*, so deadlock-freedom is a proven property rather than
a hope. A state failing it is a bug, not a surprise.

---

## 5. One restriction on what agents see of each other

Scores are gone, so collusion is not the risk — **correlated error** is. A and B are
likely the same model, and B reading A's *reasoning* before forming its own is exactly
how two models converge.

> **B sees A's claim, not A's argument for it.**

Structured claim travels: statement, scope, assumptions, falsifier, check plan, evidence
references. A's prose justification does not. This uses a split that already exists —
structured content in `fields`, reasoning in the post body — so B's context is fields
plus cited evidence. B challenges the claim, which is the only thing it should be
challenging.

---

## 6. Termination, and what cannot terminate

**No endogenous completion.** The agents cannot declare "we are done." Mutual agreement
is precisely what this architecture does not trust, so "both pass" is not terminal: a
pass must carry a disposition for every registered check, which makes it expensive and
auditable, and it burns a turn.

Legitimate terminal states:

| Terminal state | Reached by |
|---|---|
| `REFUTED` (scoped) | a witness verified by a named checker, with a receipt in `system/` |
| `EXHAUSTED_WITHIN_DECLARED_BOUNDS` | the per-goal turn budget is spent |
| `ABANDONED` | the human abandons, with a recorded reason |
| `dead_failed` | an error the human dispositioned as unrecoverable |

The turn budget is set through `budget_change`. **Exhaustion is a named outcome, not a
failure** — and it is already the monograph's own vocabulary, where it is distinguished
from "proved false." The record states *we stopped because we ran out of declared
search*, which is a scientific result rather than the absence of one.

`UNRESOLVED` is the default and the usual resting state. `CERTIFIED` does not exist.

---

## 7. What the structure gives for free

Each line below was a *rule* in an earlier draft and is now a *consequence*:

| Property | Now guaranteed by |
|---|---|
| no automatic execution | nothing runs unless resumed |
| no background agent | a coroutine has no scheduler of its own |
| no auto-advance | each turn requires a yield and a resume |
| access control | one read-write open per notebook |
| disagreement is additive | exclusive write — no party can edit another's position |
| the context digest | the record *is* the context |
| no off-record steering | the goal is a post |
| no role-rotation claim | roles are acts, selected by turn |
| linear auditable transcript | strict alternation, one goal |
| atomicity per action | one `save_tiddler`, which already writes content + history in one transaction |

And what it **no longer needs at all**: scoring, reward and punishment, game selection,
a certification state, an access-control layer, a message bus, context-bundle assembly,
role assignment, and an inter-agent adjudication protocol.

An architecture is partly defensible by what it removes.

---

## 8. Defence

### Attack 1 — "This is enormous apparatus for a one-person project, and every finding so far came from *reading*, not from the machinery."

**Largely conceded.** Across five review rounds, every defect found — the V5 hole, the
export gap, Proposition 14, the index drift, a range-expansion bug in the reviewer's own
script — was found by a reader. The validator does not exist. The evidence to date is
that reading works and the apparatus is unproven, which inverts where the effort went.

The defence is narrow and should stay narrow: the architecture's justification is not
that it finds things. It is that it makes one specific failure mode — reasoning becoming
its own evidence — **detectable instead of invisible**, and attributable instead of
anonymous. That claim is still unproven, and §9 says so.

### Attack 2 — "Two agents are unnecessary; you conceded they are not independent."

**Independence is conceded and not claimed.** Same model, same sources, correlated
blind spots. Role rotation does not create independence and this document does not say
it does.

Two agents are retained for a different and structural reason: **two write spaces make
each position non-revisable by the other.** With one model arguing with itself, the
claim and the dissent land in one namespace and nothing structurally prevents the
earlier position from being quietly revised once the later one is formed. Exclusive write
makes that impossible rather than discouraged.

So two agents buy **non-revisability of the opposing position**, not independence. That
is a smaller claim, it is true by construction, and it costs one directory.

### Attack 3 — "The human is a bottleneck and will never read it."

**Partly conceded, and the failure mode is intended.** If nobody inspects, the system
stops — a system that keeps producing unread records is the failure this design exists to
prevent, so halting is correct behaviour rather than a defect.

What makes it survivable: at `CRITICAL` the agents' **only** permitted output is
inspection support — diffs, rankings, "the three things you must look at" — so their job
becomes reducing the debt they created. Debt drains **per item**, so there is always a
two-minute action that strictly reduces it. And `not_assessed` is a **free** receipt
verdict, so the honest low-effort path exists and is distinguishable from rubber-stamping,
which is counted separately as *endorsed-with-zero-items-checked*.

### Attack 4 — "'Atomic or inspectable' cannot hold across four namespaces."

**No action spans namespaces**, so no cross-namespace transaction is needed. A turn is
one `save_tiddler` into the agent's own notebook, and `HistoryTiddlerDB` already writes
the content row and the history event in a single transaction. Turn order is *derived*
from events across the notebooks, never stored, so "post written but turn not advanced"
is unrepresentable.

**Conceded:** creating a notebook pair is two filenames and cannot be atomic. That case
is already handled by a named partial state — an incomplete pair is refused on open and
reports `disk: incomplete` — which is the general pattern: where atomicity is impossible,
the partial state is named and reportable. An escaping exception is a state somebody
forgot to name.

### Attack 5 — "A deterministic validator checks structure, not scientific validity."

**Accepted, and the vocabulary reflects it.** Admission yields `ADMITTED` or `REJECTED`
for *records*; it never yields a verdict about the world. `REFUTED` requires a receipt
from a named checker, scoped to the claim version and its assumptions. `CERTIFIED` is not
reachable by any internal transition.

`could_not_check` is **derived** from the locked check plan, never asserted by a model —
which is what closed the hole where an empty self-reported list passed for exhaustive
checking.

### Attack 6 — "A correct checker can still resolve the wrong claim."

**The strongest attack, and only partly answered.** Proposition 14 is the instance: its
author wrote one premise and proved a stronger one, so a sound checker handed the proof's
formalisation would confirm the theorem correctly while the error stayed invisible.

The architecture's answer is that the **formalisation is a reviewable object with its own
finding states** — unique-faithful / ambiguous / unrepresentable / not-yet-reviewed —
kept out of the claim's truth vocabulary, because a problem *investigating* a proposition
is not a fact *about* it. *Disputed* is orthogonal: a fact about reviewers, not about the
source. Proposition 14 is **ambiguous, not disputed** — nobody disagrees; the prose
admits both readings.

What is *not* answered: nothing here establishes that a formalisation review reliably
detects unfaithfulness. A reviewer that passes is not evidence of semantic fidelity, and
treating it as such would recreate the pattern this whole document is about.

---

## 9. What this architecture does not establish

- That any claim is **true**. It can refute with a witness or abstain.
- That a check plan is **adequate** — only that every declared check was dispositioned.
  Completeness is relative to a declared scope and remains challengeable.
- That the agents are **competent**. The contracts make incompetence visible and
  attributable, not absent.
- Any **false-refutation rate**. That needs near-miss fixtures, a sample large enough for
  a rate, and a pre-registered threshold. None exists; status is `NOT_PREREGISTERED`.
- That a hypothesis **preceded** an observation. That needs an independent chronology; a
  digest retained by the party who can rewrite the database is a local consistency check.
- That **two agents beat one**. Retained as a structural convenience (Attack 2), not as a
  performance claim.
- Anything where **no decidable witness exists**. There, this degrades to careful,
  attributed, inspectable bookkeeping — worth having, but not verification, and a green
  validator must never imply otherwise.

**Scope statement:** the architecture's reach is exactly the set of domains where a
witness is mechanically checkable. Finite action sets: strong. Premise/proof mismatches
in a formal corpus: strong. "Is this experiment well designed": bookkeeping.

---

## 10. Cost, and the order to build it

This machinery is **deliberately expensive**. Registration, check plans, receipts,
anchors and separated states are ceremony, and ceremony is the point. It earns its cost
on claims that will still matter in a year and on corpora other people will audit. For
everyday work it is overhead, and using it there would reproduce the hazard two
independent reviewers named: infrastructure for investigating a question outgrowing the
investigation.

Build order, forced by dependency:

1. **Named queries over a derived index** — the read path. Three already exist as scripts
   written during review: the nested digest walk, the four-level citation descent, the
   prose↔index edge diff. They need naming and testing, not inventing.
2. **The 36-cell transition table and the event-log fold** — the coroutine shell. The
   debt gate becomes a *status* rather than a flag, and deadlock-freedom becomes
   checkable.
3. **The envelope and validator V1–V5** with the finite witness checker wired in.
4. Everything else is assembly.

The smallest demonstration that would mean anything: register Proposition 14 as stated
and the corrected form separately, hand both the same witness, and require the system to
accept it against one and reject it against the other. If that works, the core claim is
demonstrated. If it does not, no amount of further architecture helps.
