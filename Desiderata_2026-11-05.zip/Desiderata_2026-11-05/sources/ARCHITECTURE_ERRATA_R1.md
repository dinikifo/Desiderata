# Architecture errata R1 — bounded safe disposition and turn-replay authority

**Source:** `ARCHITECTURE_2026-11-05.md` (2026-11-05), SHA-256 `b185513c24cae6400231c3dd63faec90ca3afc23f80da38b7742ab9481230cd8`.

**Status:** corrective proposal / reviewed claim boundary. **Not implemented, not authorized.** Read-only analysis permitted; operational `HOLD` unchanged. The source document is preserved without edits. This addendum supersedes the specific claims cited below for interpretation, but does not erase them.

## Disposition

**NO:** the source document's §4 proposition that every reachable state has a legal human resume taking minutes, and that checking a 6 × 6 type table *proves deadlock freedom*, is not established. The type table is not supplied; payload guards, resources and terminal states are excluded from its abstraction.

**CONDITIONAL YES (design target only):** if a single sequencer controls submissions, a usable persistent store exists, and minimal operator commands have valid payloads, a nonterminal configuration can offer a bounded safe disposition. This remains a proof obligation until the concrete transition and crash-recovery semantics are implemented and checked. The author's reported 48-configuration experiments support the *distinction* between deadlock and escape-only states, but are not an implementation proof; these exact counts were not independently reproduced for this erratum.

## E-01 — Correct the quantifier and remove time from the theorem (§4)

**Old:** `Every reachable state has at least one legal resume costing a human minutes, not hours.`

**Replace with:**

> For every reachable, nonterminal configuration whose disposition store is available and whose operator is authorized, there exists a valid, enabled operator disposition that safely terminates or explicitly pauses the current run, and whose required interaction count is bounded by the specified interface contract. A recorded disposition is guaranteed only when its commit succeeds. Availability of investigative continuation is a separate, conditional property.

Do not silently equate the permitted *type* `abandon` with an enabled payload-bearing action or with a committed terminal receipt. Define `stop` separately: a stop request that merely leaves the coroutine suspended is not a terminal disposition and must not satisfy a progress theorem by stuttering. If stop means quiesce, specify a named operationally quiescent state and an explicit resumption contract.

`dead_completed` and `dead_failed` are terminal; a theorem about their ability to resume is contradictory. Map the semantic outcomes `REFUTED`, `EXHAUSTED_WITHIN_DECLARED_BOUNDS`, and `ABANDONED` to operational statuses without conflating epistemic outcomes and control state.

## E-02 — Separate local escape, durable disposition and productive continuation (§§4, 6, 8)

Let a **concrete configuration** `c` include at least: active goal version; expected turn; accepted/attempted turns; pending receipt or write; pending item identities; item readability; authorization; budget and gate facts; notebook availability; and stop/abandon commit state.

Let `Reach` be the configurations reachable from declared initial states by the implemented step relation, `Terminal` its terminal subset, and `Enabled(c, a, p)` include all type, guard, payload, and resource checks.

- `EscapeEnabled(c)`: at least one stop/abandon command instance is enabled. This does not imply the event is durably recorded.
- `DurablyDispositionable(c)`: a valid operator command can reach a committed terminal or quiescent disposition with a bounded number of interactions under declared environmental assumptions.
- `ProductivelyContinuable(c)`: a finite permitted continuation exists that does not consist solely of stop/abandon, subject to resource and fairness assumptions.

These predicates **must not** be collapsed into one `legal resume` boolean. The author reports an illustrative table-complete variant with two concrete deadlocks, and a variant with no deadlocks but eight escape-only configurations. Those are evidence against the original proof *method*, not a verified property of an unimplemented runtime.

### External-store limit

If the `system/` database or filesystem is unavailable, a local process can cease execution without necessarily being able to **record** abandonment. The honest state is `LOCAL_STOP_UNRECORDED` or an equivalent observable recovery condition; do not invent a durable receipt or claim a completed audit trail. Define repair/manual recovery for unavailable storage. No unconditional durable-disposition theorem may quantify over irrecoverably unwritable stores.

## E-03 — Retract the claimed 36-cell proof (§4 and §10)

**Withdraw:** `This is checkable over 36 cells, so deadlock-freedom is a proven property rather than a hope.`

**Replace with:**

> A 36-cell table can exhaustively describe allowed *action types* for six named statuses. It cannot establish enabledness over runtime states until all relevant guards are modeled or a sound abstraction theorem demonstrates that omitted facts cannot change enabledness. The table and event-log fold remain unimplemented proof obligations.

Run reachability over the concrete transition function or a proved sound finite abstraction. Report separately: (i) nonterminal states with no enabled action; (ii) escape-only states; (iii) states with productive continuation; and (iv) environmental failures or unavailable records. An allowed command is not proof that a human will issue it: eventual progress requires fairness/participation assumptions.

## E-04 — Make turn identity canonical without introducing a second authority (§§4, 8)

**Accept in principle:** avoid an independently authored `turn_advanced` event if the same information is already derivable from an atomic agent-post history event.

**Reject as sufficient:** `next = max(turn_index) + 1; expected agent = parity` by itself. It fails to settle duplicate indexes, gaps, concurrent writers, invalid or unadmitted posts, absent namespaces, and whether a rejected attempt consumes a turn.

**Proposed authority contract:**

1. A *single sequencer* assigns an expected turn identity `(goal_version_digest, ordinal, expected_actor)` before any agent writes. Agent-supplied `turn_index` is untrusted until reconciled. The first-actor parity is defined by the goal-version digest, and subsequent parity is deterministic.
2. A **turn attempt** commits as one immutable/versioned event in the appropriate agent history. The rule for whether rejected attempts consume turn quota must be specified, not assumed. Content and history atomicity is scoped to that one notebook transaction.
3. `system/` may store verification/admission receipts, but these cannot act as a second independent turn counter. Instead, state reconstruction is a specified deterministic **reconciliation of agent history and system receipts**. Remove §4's assertion that a `system/`-only fold suffices unless all required turn facts are actually mirrored there.
4. A committed attempt without a corresponding system admission receipt becomes `PENDING_ADMISSION`, not silently `ADMITTED` and not an invitation to rerun the same turn. Recovery checks the referenced payload and either attaches an idempotent receipt or records a named failure.
5. An attempt is identified by a stable key (including goal-version, ordinal, actor, and payload or event digest). Retrying that same key must not create a second logical turn. Distinct events claiming the same expected ordinal are **conflicts**, not resolved by `max`.
6. The single-sequencer assumption must be enforced (exclusive process ownership, lock, or equivalent). Separate SQLite notebooks do not provide atomic serialization across all writers merely because each individual `save_tiddler` is atomic.
7. If any required notebook is unreadable, reconciliation produces an explicit `NAMESPACE_UNAVAILABLE`/`RECONCILIATION_BLOCKED` condition, not a guess that a missing turn does not exist.

These are design constraints, not a proof of crash safety. The implementation must inject crashes after *each* durable boundary: issued turn, agent-post commit, admission receipt, disposition receipt. Check recovery for exactly-once logical effects or explicit named partial states.

## E-05 — Change §8's inspection-debt claim

The claim that every inspection-debt state has a *two-minute action* is not formally established. A cheap `not_assessed` receipt may reduce **undispositioned item count** without reducing unread evidence or scientific uncertainty. State those measures separately. Specify a minimal receipt payload and bound its number of required interactions; measure actual human time empirically if it is to appear in any performance claim.

## E-06 — Correct the architecture's assertion/status boundary (§§3, 4, 8, 10)

- **Accepted as a conceptual distinction:** a terminal or suspended run should always be distinguishable from a claim of scientific success; an exhausted search remains `UNRESOLVED` on claim truth unless a separate scoped witness has been verified.
- **Proposed, not proven:** the amended safe-disposition property.
- **Not established:** guaranteed availability of a writable audit store, correctness of reconciliation, cross-notebook crash safety, bounded human minutes, or productive continuation from all reachable states.
- **Historical evidence retained:** the original assertion and the author's reported 48-state / 2-deadlock and escape-only countermodels remain in the record. Do not represent their counts as independently verified by this addendum.

## Required executable acceptance tests (not yet implemented here)

| ID | Test | Required result |
|---|---|---|
| SD-01 | Reach each declared terminal state | It offers no new investigative turn |
| SD-02 | Reach waiting-for-inspection with inaccessible item | No fabricated receipt; explicit blocked or safe exit route |
| SD-03 | Make storage unavailable before abandon commit | Local halt is not mislabeled durable abandonment |
| SD-04 | Allow stop but disable all productive actions | Count as escape-only, not productively continuable |
| TR-01 | Crash after agent-post commit, before system receipt | One pending attempt, recoverable or explicitly blocked |
| TR-02 | Retry same turn identity | No second logical turn |
| TR-03 | Two conflicting posts with same ordinal | Named conflict; no `max + 1` silent reconciliation |
| TR-04 | Namespace unavailable during replay | Unavailability remains distinct from absence |
| TR-05 | Reject an agent post on admission | Explicit rule determines whether it consumes a turn |
| CI-01 | Compare concrete reachability against 36-cell projection | Any lost guard-dependent enabledness rejects proof claim |

**No tests in this table are claimed to have been executed.** The addendum documents what a subsequent implementation must check.

## Next decision

Implement one pure `step(concrete_state, operator_command, payload)` and one deterministic `reconcile(agent_histories, system_receipts)` with crash-cutpoint tests. Only then issue a bounded theorem statement against the resulting reachable configurations. Keep the project-wide `HOLD` in effect until that work is completed and reviewed.
