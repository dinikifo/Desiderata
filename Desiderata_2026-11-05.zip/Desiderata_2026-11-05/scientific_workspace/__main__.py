"""python -m scientific_workspace restore|verify|inspect"""
from scientific_workspace.interface.cli import main

raise SystemExit(main())
