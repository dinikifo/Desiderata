"""Deterministic, in-memory E1 exercise. Does not perform persistence or LLM calls."""
import json
import sys
from scientific_workspace.engine.r0_core import (
    new_registration, issued_context, propose_witness, object_digest,
    compare_p14_formalizations,
)
from scientific_workspace.engine.transition import (
    initial_state, step, expected_actor, active_goal, replay, verify_event_chain,
)

SOURCE = ('Suppose two task realities have identical distributions of all observations '
          'available to a system, including human labels and its proof-game records, '
          'but different adequate actions. Then no policy measurable with respect to '
          'those observations can guarantee selecting the adequate action in both realities.')
WITNESS = {'actions_0': ['a'], 'actions_1': ['a', 'b'],
           'observation_0': 'same', 'observation_1': 'same',
           'candidate_constant_action': 'a'}


def demo():
    state = initial_state(budget=2)
    records = []

    def apply(cmd, env=None):
        nonlocal state
        result = step(state, cmd, env)
        if result['outcome'] != 'APPLIED':
            raise AssertionError(f"{cmd['type']}: {result['outcome']} {result['reason']}")
        state = result['state']
        return result

    apply({'type': 'goal', 'principal': 'user', 'goal_id': 'P14-G1',
           'statement': 'Prove Proposition 14 as originally stated'}, {'human_authorized': True})
    for mode in ('UNEQUAL', 'DISJOINT'):
        registration = new_registration(SOURCE, mode, 'P14-' + mode)
        context = issued_context(registration)
        envelope = propose_witness(registration, context, WITNESS)
        attempt_id = 'ATT-' + mode
        apply({'type': 'attempt', 'principal': expected_actor(state),
               'attempt_id': attempt_id, 'ordinal': len(state['attempts']) + 1,
               'goal_digest': active_goal(state)['digest'],
               'payload_digest': object_digest(envelope)})
        apply({'type': 'evaluate', 'principal': 'system', 'attempt_id': attempt_id,
               'registration': registration, 'context': context,
               'envelope': envelope}, {'system_authorized': True})
        records.append(registration)
    apply({'type': 'correction', 'principal': 'agent_a', 'proposal_id': 'COR-P14',
           'prior_digest': active_goal(state)['digest'],
           'statement': 'Consider the impossibility statement under disjoint adequate sets',
           'reason': 'The unequal-set assumption admits an overlapping-set counterexample'})
    apply({'type': 'exhaust', 'principal': 'system'}, {'system_authorized': True})
    restored = replay(state['events'], budget=2)
    assert restored == state
    assert verify_event_chain(state['events'])
    return {
        'status': 'PHASE1_IN_MEMORY_ONLY', 'events': len(state['events']),
        'event_head': state['events'][-1]['digest'],
        'source_state': state['source_claim_state'],
        'lifecycle': state['status'],
        'goal_versions': len(state['goals']),
        'correction_state': state['corrections'][0]['status'],
        'formalization_comparison': compare_p14_formalizations(*records),
        'cases': {mode: state['evaluations'][i]['result'] for i, mode in enumerate(('UNEQUAL', 'DISJOINT'))},
        'replayed_identically': restored == state,
        'no_llm_calls': True, 'durable_storage': False,
        'operational_gate': 'HOLD', 'd07': 'PROVISIONAL',
    }


if __name__ == '__main__':
    result = demo()
    text = json.dumps(result, indent=2, ensure_ascii=False)
    if len(sys.argv) > 1:
        with open(sys.argv[1], 'w', encoding='utf-8') as f:
            f.write(text + '\n')
    print('UNEQUAL:', result['cases']['UNEQUAL']['formal_claim_state'],
          'DISJOINT:', result['cases']['DISJOINT']['formal_claim_state'],
          'SOURCE:', result['source_state'], 'REPLAY:', result['replayed_identically'])
