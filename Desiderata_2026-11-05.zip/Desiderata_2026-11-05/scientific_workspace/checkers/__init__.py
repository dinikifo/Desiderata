"""Pure checker adapters."""
