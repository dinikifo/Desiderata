"""Scientific Workspace (headless)."""
