"""Human-legible, attributed projection of verified local journal replay.

A projection is not a new source of scientific authority. Its fields are derived
from committed events through the same replay used by the storage layer.
"""
from __future__ import annotations

from scientific_workspace.engine.transition import classify_continuation
from scientific_workspace.storage.journal import WikiJournal


def summarize(workspace):
    observed = WikiJournal(workspace).inspect()
    state = observed['state']
    evaluations = []
    for evaluation in state['evaluations']:
        result = evaluation['result']
        evaluation_row = {
            'attempt_id': evaluation['attempt_id'],
            'admission': result['admission']['admission'],
            'admission_errors': result['admission']['errors'],
            'formal_claim_state': result['formal_claim_state'],
            'source_claim_state': result['source_claim_state'],
            'formalization_review': result['source_review'],
            'receipts': result['verification_receipts'],
        }
        evaluations.append(evaluation_row)
    timeline = []
    for event in state['events']:
        cmd = event['command']
        row = {'index': event['index'], 'kind': cmd['type'], 'principal': cmd['principal'],
               'event_digest': event['digest'], 'assumed_authority': event['assumed_authority']}
        for field in ('goal_id', 'statement', 'reason', 'attempt_id', 'ordinal',
                      'proposal_id', 'prior_digest'):
            if field in cmd:
                row[field] = cmd[field]
        if cmd['type'] == 'evaluate':
            row['registration_digest'] = cmd['registration']['registration_digest']
            row['formalization_id'] = cmd['registration']['formalization_id']
            row['source_digest'] = cmd['registration']['source_digest']
            row['witness'] = [x.get('witness') for x in cmd['envelope']['check_dispositions']
                              if 'witness' in x]
        timeline.append(row)
    goals = state['goals']
    return {
        'schema': 'sw-human-inspection/0.1',
        'workspace': str(workspace),
        'journal_history_and_replay': 'PASS',
        'scope': 'local internal consistency; caller authority not authenticated; no external chronology',
        'event_count': observed['events'],
        'head_digest': state['events'][-1]['digest'] if state['events'] else None,
        'pending_intents': observed['pending'],
        'budget': state['budget'],
        'spent_attempts': len(state['attempts']),
        'lifecycle': state['status'],
        'continuation': classify_continuation(state),
        'source_claim_state': state['source_claim_state'],
        'goals': goals,
        'corrections': state['corrections'],
        'evaluations': evaluations,
        'timeline': timeline,
        'limitations': [
            'A passing record admission does not establish scientific truth.',
            'A finite witness result is scoped to a registered mathematical formalization.',
            'Source text remains unresolved; authorial intent is not determined.',
            'Original and amended goals are distinct versions; corrections are only proposed.',
            'Historical hashes and assumed authorization flags do not prove external authenticity.',
            'The recovery contract assumes a trusted local single sequencer and available SQLite pairs.',
        ],
    }


def explain(report, diff_from_initial=False):
    lines = [
        '# Scientific Workspace — reconstructed investigation',
        'Evidence: four local WikiCore notebook pairs, revalidated and replayed.',
        f'Journal check: {report["journal_history_and_replay"]} (local consistency only)',
        f'Committed events: {report["event_count"]}; pending intents: {len(report["pending_intents"])}',
        f'Lifecycle: {report["lifecycle"]}; continuation class: {report["continuation"]}',
        f'Attempt budget used: {report["spent_attempts"]}/{report["budget"]}',
        f'Source claim: {report["source_claim_state"]}',
        f'Head digest: {report["head_digest"]}',
        '', '## Goal and corrections',
    ]
    if not report['goals']:
        lines.append('No committed human goal.')
    for g in report['goals']:
        lines.append(f'Goal {g["id"]} v{g["version"]} [{g["digest"]}]: {g["statement"]}')
        if 'supersedes' in g:
            lines.append(f'  Supersedes: {g["supersedes"]}; reason: {g.get("reason")}')
    for c in report['corrections']:
        lines.append(f'Proposed correction {c["proposal_id"]} ({c["status"]}, by {c["author"]}): {c["statement"]}')
        lines.append(f'  Why: {c["reason"]}; references goal: {c["prior_digest"]}')
    lines += ['', '## Formal evidence and verification receipts']
    if not report['evaluations']:
        lines.append('No committed evaluations.')
    for ev in report['evaluations']:
        lines.append(f'Attempt {ev["attempt_id"]}: admission={ev["admission"]}, '
                     f'formal={ev["formal_claim_state"]}, source={ev["source_claim_state"]}')
        for problem in ev['admission_errors']:
            lines.append('  Admission issue: ' + problem)
        review = ev['formalization_review']
        lines.append('  Formalization review: ' + review.get('interpretation', 'unspecified')
                     + '; agreement=' + review.get('reviewer_agreement', 'unspecified'))
        for receipt in ev['receipts']:
            lines.append('  Receipt: ' + receipt['result'] + ' via ' + receipt['checker'])
            lines.append('  Formalization: ' + receipt['formalization_id']
                         + '; witness digest: ' + receipt['witness_digest'])
            lines.append('  Registration: ' + receipt['registration_digest'])
            lines.append('  Scope: ' + receipt['scope']
                         + '; source fidelity assessed: ' + str(receipt['source_fidelity_assessed']))
    if diff_from_initial:
        lines.extend(['', '## Changes since the initial state'])
        lines.append('Initial: WAITING_FOR_GOAL; no goal, attempts, evaluations or correction.')
        lines.append(f'Current: {len(report["goals"])} goal versions, {report["spent_attempts"]} attempts, '
                     f'{len(report["evaluations"])} evaluations, {len(report["corrections"])} correction proposals.')
        for event in report['timeline']:
            details = []
            for key in ('attempt_id', 'proposal_id', 'formalization_id', 'reason'):
                if key in event:
                    details.append(f'{key}={event[key]}')
            lines.append(f'  #{event["index"]} {event["principal"]} {event["kind"]}'
                         + (': ' + '; '.join(details) if details else '')
                         + f' [digest={event["event_digest"]}]')
    if report['pending_intents']:
        lines += ['', '## Uncommitted drafts (not authoritative)']
        for item in report['pending_intents']:
            lines.append(f'  {item["namespace"]}/{item["request_id"]}: {item["command_digest"]}')
    lines += ['', '## Boundaries']
    lines.extend('- ' + lim for lim in report['limitations'])
    return '\n'.join(lines) + '\n'
