"""Read-only checkpoint verification and safe fixture-only cold restoration.

Checks package self-consistency; an expected SHA-256 must come from a separate
trusted channel to supply independent identity. No archived code is executed.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import tempfile
from zipfile import ZipFile, BadZipFile

from scientific_workspace.storage.journal import WikiJournal, JournalError, NAMESPACES

MANIFEST_NAME = 'checkpoints/PACKAGE_MANIFEST.json'
FIXTURE_NAME = 'E1_PERSISTENT_WORKSPACE'


class CheckpointError(ValueError):
    pass


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _validate_rel(name: str) -> PurePosixPath:
    p = PurePosixPath(name)
    if not name or name.startswith('/') or '\\' in name or '\x00' in name or any(
            part in ('', '.', '..') for part in name.split('/')) or str(p) != name:
        raise CheckpointError('UNSAFE_ARCHIVE_PATH:' + repr(name))
    return p


def verify_zip(archive: str | Path, expected_sha256: str | None = None):
    """Inspect entire archive with no extraction. Reject extras and unsafe entries."""
    archive = Path(archive)
    digest = _sha(archive.read_bytes())
    if expected_sha256 is not None and digest != expected_sha256.lower().removeprefix('sha256:'):
        raise CheckpointError('EXTERNAL_DIGEST_MISMATCH')
    try:
        with ZipFile(archive) as z:
            items = {}
            roots = set()
            for info in z.infolist():
                if info.is_dir():
                    raise CheckpointError('UNEXPECTED_DIRECTORY_ENTRY:' + info.filename)
                path = _validate_rel(info.filename)
                if len(path.parts) < 2:
                    raise CheckpointError('MISSING_ARCHIVE_ROOT')
                roots.add(path.parts[0])
                if path.as_posix() in items:
                    raise CheckpointError('DUPLICATE_ARCHIVE_PATH:' + info.filename)
                if stat.S_ISLNK(info.external_attr >> 16):
                    raise CheckpointError('SYMLINK_IN_ARCHIVE:' + info.filename)
                if info.file_size > 20_000_000:
                    raise CheckpointError('FILE_EXCEEDS_SIZE_LIMIT')
                items[path.as_posix()] = info
            if len(roots) != 1:
                raise CheckpointError('MULTIPLE_ARCHIVE_ROOTS')
            root = next(iter(roots))
            manifest_path = root + '/' + MANIFEST_NAME
            if manifest_path not in items:
                raise CheckpointError('MISSING_MANIFEST')
            manifest = json.loads(z.read(manifest_path))
            if manifest.get('schema') != 'sw-local-checkpoint-manifest/0.1':
                raise CheckpointError('UNSUPPORTED_MANIFEST_SCHEMA')
            declared = {}
            for row in manifest['files']:
                rel = _validate_rel(row['path']).as_posix()
                if rel == MANIFEST_NAME or rel in declared:
                    raise CheckpointError('MANIFEST_DUPLICATE_OR_SELF')
                if not isinstance(row['sha256'], str) or len(row['sha256']) != 64:
                    raise CheckpointError('INVALID_MANIFEST_DIGEST')
                if type(row['bytes']) is not int or row['bytes'] < 0:
                    raise CheckpointError('INVALID_MANIFEST_LENGTH')
                declared[root + '/' + rel] = row
            actual = set(items) - {manifest_path}
            if actual != set(declared):
                raise CheckpointError('INVENTORY_MISMATCH missing=' + repr(sorted(set(declared)-actual))
                                      + ' extra=' + repr(sorted(actual-set(declared))))
            for name, row in declared.items():
                if items[name].file_size != row['bytes'] or _sha(z.read(name)) != row['sha256']:
                    raise CheckpointError('PAYLOAD_MISMATCH:' + name)
            return {'archive_sha256': digest, 'root': root,
                    'manifest_payloads': len(declared), 'inventory_verified': True,
                    'independent_digest_supplied': expected_sha256 is not None}
    except (BadZipFile, KeyError, TypeError, json.JSONDecodeError, OSError) as exc:
        raise CheckpointError('INVALID_CHECKPOINT:' + str(exc)) from exc


def restore_fixture(archive: str | Path, destination: str | Path, *,
                    expected_sha256: str | None = None):
    """Restore only four WikiCore notebook pairs; no general archive extraction.

    Stages into a new sibling directory and publishes it by rename only after
    replay verification. The destination must not exist, even if empty.
    """
    evidence = verify_zip(archive, expected_sha256)
    destination = Path(destination).absolute()
    if destination.exists() or destination.is_symlink():
        raise CheckpointError('DESTINATION_EXISTS')
    if not destination.parent.is_dir():
        raise CheckpointError('DESTINATION_PARENT_MISSING')
    staging = Path(tempfile.mkdtemp(prefix='.sw_restore_', dir=destination.parent))
    try:
        prefix = evidence['root'] + '/fixtures/' + FIXTURE_NAME + '/'
        with ZipFile(archive) as z:
            names = set(z.namelist())
            required = {prefix + ns + '/' + suffix
                        for ns in NAMESPACES for suffix in ('wiki.db', 'wiki.history.sqlite')}
            if not required.issubset(names):
                raise CheckpointError('MISSING_REQUIRED_NOTEBOOK_PAIR:' + repr(sorted(required - names)))
            for namespace in NAMESPACES:
                folder = staging / namespace
                folder.mkdir()
                for suffix in ('wiki.db', 'wiki.history.sqlite'):
                    with z.open(prefix + namespace + '/' + suffix) as src, \
                         (folder / suffix).open('wb') as dst:
                        shutil.copyfileobj(src, dst)
        inspection = WikiJournal(staging).inspect()
        if not inspection['events']:
            raise CheckpointError('EMPTY_RESTORED_JOURNAL')
        os.rename(staging, destination)
        return {'workspace': str(destination), 'event_count': inspection['events'],
                'pending_intents': len(inspection['pending']), **evidence}
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        raise
