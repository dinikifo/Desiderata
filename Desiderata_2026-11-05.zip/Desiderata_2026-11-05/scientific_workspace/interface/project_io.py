"""Data-only snapshot of a complete four-notebook journal.

This is an integrity-checked local transfer format, NOT a signed provenance
anchor. All workspaces must be owned by the trusted local operator; POSIX
advisory locks do not exclude writers ignoring the lock.
"""
from __future__ import annotations

from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import tempfile
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

from scientific_workspace.interface.checkpoint_io import CheckpointError, verify_zip
from scientific_workspace.storage.journal import NAMESPACES, WikiJournal

ROOT = 'scientific_workspace_project'
DATA = 'workspace'
MANIFEST = 'checkpoints/PACKAGE_MANIFEST.json'


def _required():
    return {f'{DATA}/{ns}/{filename}'
            for ns in NAMESPACES
            for filename in ('wiki.db', 'wiki.history.sqlite')}


def export_project(workspace, archive):
    """Make an exact eight-file transfer after checking history + replay.

    Refuses existing destinations and writes the file only on success.
    """
    workspace, archive = Path(workspace), Path(archive).absolute()
    if archive.exists() or archive.is_symlink():
        raise CheckpointError('DESTINATION_EXISTS')
    if not archive.parent.is_dir():
        raise CheckpointError('DESTINATION_PARENT_MISSING')
    journal = WikiJournal(workspace)
    # One cooperative writer at a time; inspect and snapshot under same lock.
    with journal._locked():
        observed = journal._load()
        payload = {f'{DATA}/{ns}/{filename}':
                   (workspace / ns / filename).read_bytes()
                   for ns in NAMESPACES
                   for filename in ('wiki.db', 'wiki.history.sqlite')}
        head = observed['state']['events'][-1]['digest'] if observed['events'] else None
        event_count = observed['events']
    manifest = {
        'schema': 'sw-local-checkpoint-manifest/0.1',
        'kind': 'scientific-workspace-data-snapshot/0.1',
        'head_digest': head,
        'event_count': event_count,
        'meaning': 'Local integrity and replay only; no authenticated author or external chronology',
        'files': [{'path': p, 'bytes': len(b), 'sha256': sha256(b).hexdigest()}
                  for p, b in sorted(payload.items())],
    }
    fd, staging_name = tempfile.mkstemp(prefix='.sw_snapshot_', suffix='.zip', dir=archive.parent)
    os.close(fd)
    staging = Path(staging_name)
    try:
        with ZipFile(staging, 'w', compression=ZIP_DEFLATED) as z:
            for name, content in sorted(payload.items()):
                z.writestr(ROOT + '/' + name, content)
            z.writestr(ROOT + '/' + MANIFEST,
                       json.dumps(manifest, sort_keys=True, indent=2).encode('utf-8'))
        check = verify_zip(staging)
        if check['manifest_payloads'] != 8:
            raise CheckpointError('UNEXPECTED_SNAPSHOT_INVENTORY')
        # Hard link avoids an overwrite race between the exists check and publish.
        os.link(staging, archive)
        return {'archive': str(archive), 'archive_sha256': check['archive_sha256'],
                'event_count': event_count, 'head_digest': head, 'payload_files': 8,
                'trust': 'local integrity; digest must be anchored independently'}
    finally:
        staging.unlink(missing_ok=True)


def restore_project(archive, destination, *, expected_sha256=None):
    """Restore only eight required database files into a new workspace.

    Never import or execute any source code contained in an archive. Publish
    by rename after the restored data passes WikiJournal's read-only replay.
    """
    info = verify_zip(archive, expected_sha256)
    dest = Path(destination).absolute()
    if dest.exists() or dest.is_symlink():
        raise CheckpointError('DESTINATION_EXISTS')
    if not dest.parent.is_dir():
        raise CheckpointError('DESTINATION_PARENT_MISSING')
    if info['root'] != ROOT:
        raise CheckpointError('NOT_A_PROJECT_SNAPSHOT')
    with ZipFile(archive) as z:
        manifest = json.loads(z.read(ROOT + '/' + MANIFEST))
        if manifest.get('kind') != 'scientific-workspace-data-snapshot/0.1':
            raise CheckpointError('NOT_A_PROJECT_SNAPSHOT')
        if {f['path'] for f in manifest['files']} != _required():
            raise CheckpointError('INVALID_PROJECT_INVENTORY')
        staging = Path(tempfile.mkdtemp(prefix='.sw_project_restore_', dir=dest.parent))
        try:
            for name in sorted(_required()):
                target = staging / name.removeprefix(DATA + '/')
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(ROOT + '/' + name) as src, target.open('xb') as out:
                    shutil.copyfileobj(src, out)
            result = WikiJournal(staging).inspect()
            state = result['state']
            head = state['events'][-1]['digest'] if state['events'] else None
            if head != manifest['head_digest'] or result['events'] != manifest['event_count']:
                raise CheckpointError('SNAPSHOT_REPLAY_MISMATCH')
            os.rename(staging, dest)
            return {'workspace': str(dest), 'event_count': result['events'],
                    'head_digest': head, 'pending_intents': len(result['pending']),
                    **info}
        except BaseException:
            shutil.rmtree(staging, ignore_errors=True)
            raise
