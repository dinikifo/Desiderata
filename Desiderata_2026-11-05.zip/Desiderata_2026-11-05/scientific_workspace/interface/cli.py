"""Local headless scientific workspace: inspection, human controls, snapshots.

`--local-operator` is an explicit local-test acknowledgment, not authentication.
No agent-facing API or live LLM orchestration is provided here.
"""
from __future__ import annotations

import argparse
import json
import sys
from uuid import uuid4

from scientific_workspace.interface.checkpoint_io import (
    CheckpointError, restore_fixture, verify_zip,
)
from scientific_workspace.interface.inspection import summarize, explain
from scientific_workspace.interface.project_io import export_project, restore_project, ROOT as PROJECT_ROOT
from scientific_workspace.storage.journal import WikiJournal, JournalError
from scientific_workspace.engine.transition import active_goal


def parser():
    p = argparse.ArgumentParser(prog='scientific-workspace',
        description='Local scientific journal: inspect, control and restore a bounded run.')
    sub = p.add_subparsers(dest='command', required=True)
    init = sub.add_parser('init', help='create an empty four-namespace project')
    init.add_argument('--workspace', required=True)
    init.add_argument('--budget', type=int, default=2)
    restore = sub.add_parser('restore', help='restore a checked code-fixture or data-only project snapshot')
    restore.add_argument('--archive', required=True)
    restore.add_argument('--workspace', required=True)
    restore.add_argument('--expected-sha256', help='digest obtained independently, if available')
    export = sub.add_parser('export', help='export complete checked journal as data-only ZIP')
    export.add_argument('--workspace', required=True)
    export.add_argument('--archive', required=True)
    verify = sub.add_parser('verify', help='verify journal pairs and reconstruct state without mutation')
    verify.add_argument('--workspace', required=True)
    verify.add_argument('--json', action='store_true')
    inspect = sub.add_parser('inspect', help='explain admitted changes and their check receipts')
    inspect.add_argument('--workspace', required=True)
    inspect.add_argument('--explain', action='store_true')
    inspect.add_argument('--diff-from-initial', action='store_true')
    inspect.add_argument('--json', action='store_true')
    for name, helptext in (
        ('goal', 'register the original human goal'),
        ('amend', 'make a new goal version without overwriting the old goal'),
        ('stop', 'durably quiesce an investigation without claiming progress'),
        ('resume', 'resume a quiesced investigation'),
        ('abandon', 'durably abandon a nonterminal investigation'),
    ):
        cmd = sub.add_parser(name, help=helptext)
        cmd.add_argument('--workspace', required=True)
        cmd.add_argument('--request-id', help='stable logical command ID; reuse for an identical retry')
        cmd.add_argument('--local-operator', action='store_true',
                         help='acknowledge local trusted operator; not identity authentication')
        if name == 'goal':
            cmd.add_argument('--goal-id', required=True)
            cmd.add_argument('--statement', required=True)
        elif name == 'amend':
            cmd.add_argument('--expected-goal-digest', required=True,
                             help='optimistic-lock digest obtained from prior inspect')
            cmd.add_argument('--statement', required=True)
            cmd.add_argument('--reason', required=True)
        elif name == 'abandon':
            cmd.add_argument('--reason', required=True)
    return p


def _human_command(args):
    # This guard precedes staging any draft, so an unacknowledged operation
    # does not leave a misleading uncommitted intent in the journal.
    if not args.local_operator:
        raise JournalError('LOCAL_OPERATOR_ACK_REQUIRED: use --local-operator only in a trusted local session')
    kind = args.command
    command = {'type': kind, 'principal': 'user'}
    if kind == 'goal':
        command.update(goal_id=args.goal_id, statement=args.statement)
    elif kind == 'amend':
        observed = WikiJournal(args.workspace).inspect()['state']
        goal = active_goal(observed)
        if goal is None or args.expected_goal_digest != goal['digest']:
            raise JournalError('STALE_OR_UNKNOWN_GOAL_DIGEST')
        command.update(goal_id=goal['id'], prior_digest=args.expected_goal_digest,
                       statement=args.statement, reason=args.reason)
    elif kind == 'abandon':
        command['reason'] = args.reason
    request_id = args.request_id or ('op-' + uuid4().hex)
    result = WikiJournal(args.workspace).submit(request_id, command, {'human_authorized': True})
    state = result['state']
    goal = active_goal(state)
    response = {'outcome': result['outcome'], 'reason': result.get('reason'),
                'request_id': request_id, 'lifecycle': state['status'],
                'goal_version': goal['version'] if goal else None,
                'goal_digest': goal['digest'] if goal else None,
                'event_count': len(state['events']),
                'pending_intents': len(result.get('pending', [])),
                'trust': 'operator self-acknowledgment; no principal authentication'}
    print(json.dumps(response, ensure_ascii=False, indent=2))
    return 0 if result['outcome'] in ('APPLIED', 'NOOP') else 2


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.command == 'init':
            journal = WikiJournal.create(args.workspace, budget=args.budget)
            report = journal.inspect()
            print(json.dumps({'workspace': str(journal.root), 'budget': report['budget'],
                              'lifecycle': report['state']['status'], 'event_count': 0,
                              'trust': 'local POSIX sequencer; no authenticated operator'}, indent=2))
        elif args.command == 'restore':
            verified = verify_zip(args.archive, args.expected_sha256)
            if verified['root'] == PROJECT_ROOT:
                response = restore_project(args.archive, args.workspace,
                                           expected_sha256=args.expected_sha256)
            else:
                response = restore_fixture(args.archive, args.workspace,
                                           expected_sha256=args.expected_sha256)
            print(json.dumps(response, indent=2, ensure_ascii=False))
        elif args.command == 'export':
            print(json.dumps(export_project(args.workspace, args.archive), indent=2, ensure_ascii=False))
        elif args.command == 'verify':
            r = summarize(args.workspace)
            summary = {'ok': True, 'workspace': r['workspace'], 'event_count': r['event_count'],
                       'pending_intents': len(r['pending_intents']), 'lifecycle': r['lifecycle'],
                       'source_claim_state': r['source_claim_state'],
                       'head_digest': r['head_digest'], 'trust': r['scope']}
            if args.json:
                print(json.dumps(summary, indent=2))
            else:
                print('PASS — local journal history, event-chain and deterministic replay')
                print(json.dumps(summary, indent=2))
        elif args.command == 'inspect':
            r = summarize(args.workspace)
            if args.json:
                print(json.dumps(r, indent=2, ensure_ascii=False))
            else:
                print(explain(r, diff_from_initial=args.diff_from_initial), end='')
        elif args.command in ('goal', 'amend', 'stop', 'resume', 'abandon'):
            return _human_command(args)
        return 0
    except (CheckpointError, JournalError, OSError, ValueError, TypeError) as exc:
        print('BLOCKED: ' + str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
