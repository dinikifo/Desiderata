"""Bounded, read-only human inspection and checkpoint recovery interface."""
