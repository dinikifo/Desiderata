"""Reproduce E1 in four persistent WikiCore namespaces and check cold replay.

Run: python -m scientific_workspace.persistent_demo PATH/TO/EMPTY/WORKSPACE
"""
import json
from pathlib import Path
import sys

from scientific_workspace.demo import SOURCE, WITNESS
from scientific_workspace.engine.r0_core import (
    new_registration, issued_context, propose_witness, object_digest,
)
from scientific_workspace.engine.transition import active_goal, expected_actor
from scientific_workspace.storage.journal import WikiJournal


def demo(root):
    j = WikiJournal.create(root, budget=2)
    state = j.submit('goal-1', {
        'type': 'goal', 'principal': 'user', 'goal_id': 'P14-G1',
        'statement': 'Prove Proposition 14 as originally stated',
    }, {'human_authorized': True})['state']
    for mode in ('UNEQUAL', 'DISJOINT'):
        reg = new_registration(SOURCE, mode, 'P14-' + mode)
        ctx = issued_context(reg)
        env = propose_witness(reg, ctx, WITNESS)
        attempt_id = 'ATT-' + mode
        state = j.submit(attempt_id, {
            'type': 'attempt', 'principal': expected_actor(state),
            'attempt_id': attempt_id, 'ordinal': len(state['attempts']) + 1,
            'goal_digest': active_goal(state)['digest'],
            'payload_digest': object_digest(env),
        })['state']
        state = j.submit('EVAL-' + mode, {
            'type': 'evaluate', 'principal': 'system', 'attempt_id': attempt_id,
            'registration': reg, 'context': ctx, 'envelope': env,
        }, {'system_authorized': True})['state']
    state = j.submit('CORR-P14', {
        'type': 'correction', 'principal': 'agent_a', 'proposal_id': 'COR-P14',
        'prior_digest': active_goal(state)['digest'],
        'statement': 'Consider the strengthened impossibility statement under disjoint adequate sets',
        'reason': 'The unequal-set premise has a verified overlapping-set counterexample',
    })['state']
    state = j.submit('END-BUDGET', {'type': 'exhaust', 'principal': 'system'},
                     {'system_authorized': True})['state']
    restored = WikiJournal(root).inspect()
    assert restored['state'] == state and restored['pending'] == []
    assert state['evaluations'][0]['result']['formal_claim_state'] == 'REFUTED'
    assert state['evaluations'][1]['result']['formal_claim_state'] == 'UNRESOLVED'
    assert state['source_claim_state'] == 'UNRESOLVED'
    return {
        'schema': 'sw-persistent-e1-fixture/0.1',
        'events': restored['events'],
        'pending_intents': len(restored['pending']),
        'source_state': state['source_claim_state'],
        'formal_states': [r['result']['formal_claim_state'] for r in state['evaluations']],
        'lifecycle': state['status'],
        'correction_state': state['corrections'][0]['status'],
        'head_digest': state['events'][-1]['digest'],
        'fresh_open_replay_equal': restored['state'] == state,
        'scope': 'local POSIX single-sequencer only; no LLM; no human authentication',
    }


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python -m scientific_workspace.persistent_demo NEW_WORKSPACE_PATH')
    print(json.dumps(demo(Path(sys.argv[1])), indent=2, ensure_ascii=False))
