#!/usr/bin/env python3
"""Bounded scientific-claim transaction prototype, stdlib only.

NOT a scientific truth oracle. V1-V5 are mechanical admission rules.
The finite checker verifies a countermodel of one specified formal implication.
Source-to-formalization fidelity is a separate review question.
"""
from __future__ import annotations

import hashlib
import json
import unicodedata
from collections.abc import Mapping

REGISTRATION_SCHEMA = 'pw-finite-registration/0.1-prototype'
ENVELOPE_SCHEMA = 'pw-challenge-return/0.2-draft'
CHECKER_VERSION = 'finite-common-action/0.1'
DISPOSITIONS = frozenset({'COUNTEREXAMPLE_PROPOSED', 'NO_COUNTEREXAMPLE_FOUND',
                          'EVIDENCE_SET_INADEQUATE', 'NOT_CHECKABLE'})
MODES = frozenset({'UNEQUAL', 'DISJOINT'})
ALLOWED_ENVELOPE = frozenset({'envelope', 'claim_id', 'claim_version',
                              'issued_context_digest', 'check_plan_digest', 'role',
                              'check_dispositions', 'independent_evidence_requests', 'notes'})
ALLOWED_CHECK = frozenset({'check_id', 'disposition', 'method', 'reason', 'evidence_refs',
                           'witness', 'missing_information', 'capability_limit'})


def canonical(value):
    """Canonical for THIS bounded JSON subset; excludes floats; NFC-normalizes strings.

    Uniqueness is obtained by sorted dictionary keys, no floats/NaN, and UTF-8 NFC.
    This is not a general-purpose international JSON canonicalization standard.
    """
    def norm(x):
        if x is None or type(x) in (bool, int):
            return x
        if isinstance(x, str):
            return unicodedata.normalize('NFC', x)
        if isinstance(x, list):
            return [norm(y) for y in x]
        if isinstance(x, dict):
            if not all(isinstance(k, str) for k in x):
                raise ValueError('JSON object keys must be strings')
            out = {}
            for k, v in x.items():
                nk = unicodedata.normalize('NFC', k)
                if nk in out:
                    raise ValueError('duplicate normalized dictionary keys')
                out[nk] = norm(v)
            return out
        raise ValueError(f'unsupported JSON value {type(x).__name__}')
    return json.dumps(norm(value), sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def sha(data: bytes) -> str:
    return 'sha256:' + hashlib.sha256(data).hexdigest()


def object_digest(value):
    return sha(canonical(value))


def new_registration(source_text, mode, claim_id):
    """Make a locked check plan for one P14 formal candidate, not a source verdict."""
    if mode not in MODES:
        raise ValueError('unsupported formalization mode')
    if not source_text or not claim_id:
        raise ValueError('source_text and claim_id required')
    p = {
        'schema': REGISTRATION_SCHEMA,
        'claim_id': claim_id,
        'claim_version': 1,
        'source_id': 'R2:P14',
        'source_digest': sha(source_text.encode('utf-8')),
        'source_text': source_text,
        'formalization_id': f'F-P14-{mode}',
        'formalization_mode': mode,
        'source_interpretation_finding': 'MULTIPLE_PLAUSIBLE_INEQUIVALENT_CANDIDATES',
        'reviewer_agreement': 'NOT_REVIEWED',
        'source_promotion_authority': 'NONE',
        'assumptions': ['two_worlds', 'common_observation', 'nonempty_finite_action_sets',
                        'deterministic_constant_action'],
        'check_plan': [{
            'check_id': 'K-WITNESS',
            'test': 'common_action_counterexample',
            'relation_to_falsifier': 'a shared adequate action refutes the universal impossibility assertion',
        }],
        'evidence_refs': [],
        'anchor_status': 'ANCHOR_UNVERIFIED',
    }
    p['check_plan_digest'] = object_digest(p['check_plan'])
    p['registration_digest'] = object_digest(p)
    return p


def check_locked_registration(reg):
    """Detect mutation of a purportedly frozen registration independently of challenge."""
    try:
        if reg['schema'] != REGISTRATION_SCHEMA or reg['formalization_mode'] not in MODES:
            return False
        if sha(reg['source_text'].encode('utf-8')) != reg['source_digest']:
            return False
        if object_digest(reg['check_plan']) != reg['check_plan_digest']:
            return False
        frozen = {k: v for k, v in reg.items() if k != 'registration_digest'}
        return object_digest(frozen) == reg['registration_digest']
    except (ValueError, TypeError, KeyError, AttributeError):
        return False


def issued_context(reg):
    """Create context receipt; this digest is local binding, not a trusted timestamp."""
    if not check_locked_registration(reg):
        raise ValueError('registration mutated or malformed')
    c = {'claim_id': reg['claim_id'], 'claim_version': reg['claim_version'],
         'registration_digest': reg['registration_digest'],
         'source_digest': reg['source_digest'],
         'formalization_id': reg['formalization_id'],
         'check_plan_digest': reg['check_plan_digest'],
         'evidence_refs': reg['evidence_refs']}
    return {'context': c, 'digest': object_digest(c)}


def propose_witness(reg, context, witness, evidence_refs=None):
    return {'envelope': ENVELOPE_SCHEMA, 'claim_id': reg['claim_id'],
            'claim_version': reg['claim_version'], 'issued_context_digest': context['digest'],
            'check_plan_digest': reg['check_plan_digest'], 'role': 'challenger',
            'check_dispositions': [{
                'check_id': 'K-WITNESS', 'disposition': 'COUNTEREXAMPLE_PROPOSED',
                'method': 'finite shared-action verification',
                'reason': 'candidate shared action against two-world impossibility',
                'evidence_refs': evidence_refs or [], 'witness': witness,
            }], 'independent_evidence_requests': [],
            'notes': 'Candidate only; admission is not witness verification'}


def validate_v1_v5(reg, context, envelope, evidence_bytes=None):
    """Pure deterministic admission decision; never modifies a claim state.

    `evidence_bytes` is an external immutable byte registry keyed by exact SHA256 ref.
    Validation checks integrity of those bytes, NOT authenticity/relevance.
    """
    evidence_bytes = {} if evidence_bytes is None else evidence_bytes
    errors = []
    if not isinstance(envelope, Mapping):
        return {'admission': 'REJECTED', 'errors': ['envelope must be an object'],
                'coverage': None, 'derived_could_not_check': None}
    if not check_locked_registration(reg):
        errors.append('REGISTRATION_INTEGRITY_FAILURE')
    try:
        expected_ctx = issued_context(reg)
    except ValueError:
        expected_ctx = None
    if (not isinstance(context, Mapping) or expected_ctx is None
            or context.get('digest') != expected_ctx['digest']
            or context.get('context') != expected_ctx['context']):
        errors.append('V1_INVALID_ISSUED_CONTEXT')
    if (envelope.get('envelope') != ENVELOPE_SCHEMA
            or envelope.get('claim_id') != reg.get('claim_id')
            or envelope.get('claim_version') != reg.get('claim_version')
            or envelope.get('issued_context_digest') != (expected_ctx or {}).get('digest')
            or envelope.get('check_plan_digest') != reg.get('check_plan_digest')
            or envelope.get('role') != 'challenger'):
        errors.append('V1_ENVELOPE_BINDING_MISMATCH')
    extra = set(envelope) - ALLOWED_ENVELOPE
    if extra:
        errors.append('V5_AGENT_AUTHORITY_OR_UNKNOWN_FIELDS:' + ','.join(sorted(extra)))
    # V2: resolution to exact bytes, with missing and mismatched bytes distinguished.
    all_refs = reg.get('evidence_refs', [])
    if not isinstance(all_refs, list):
        errors.append('V2_REGISTERED_REFERENCES_NOT_ARRAY')
        all_refs = []
    else:
        all_refs = list(all_refs)
    disp = envelope.get('check_dispositions')
    if not isinstance(disp, list):
        errors.append('V3_DISPOSITIONS_NOT_ARRAY')
        disp = []
    for entry in disp:
        if isinstance(entry, dict):
            if isinstance(entry.get('evidence_refs', []), list):
                all_refs.extend(entry.get('evidence_refs', []))
            else:
                errors.append('V2_EVIDENCE_REFS_NOT_ARRAY')
    for ref in all_refs:
        if not isinstance(ref, str) or not ref.startswith('sha256:') or len(ref) != 71:
            errors.append('V2_INVALID_REFERENCE')
        elif ref not in evidence_bytes:
            errors.append('V2_UNRESOLVED_REFERENCE:' + ref)
        elif not isinstance(evidence_bytes[ref], bytes) or sha(evidence_bytes[ref]) != ref:
            errors.append('V2_BYTE_DIGEST_MISMATCH:' + ref)
    # V3: exact check-ID coverage; empty or duplicated records fail.
    raw_plan = reg.get('check_plan', [])
    planned = [x.get('check_id') if isinstance(x, Mapping) else None for x in raw_plan] if isinstance(raw_plan, list) else []
    returned = [x.get('check_id') if isinstance(x, Mapping) else None for x in disp]
    # Untrusted IDs must not crash through hashability assumptions.
    planned_ok = all(isinstance(k, str) and k for k in planned)
    returned_ok = all(isinstance(k, str) and k for k in returned)
    unique_planned = set(planned) if planned_ok else set()
    unique_returned = set(returned) if returned_ok else set()
    if not planned or not planned_ok or len(planned) != len(unique_planned):
        errors.append('V3_INVALID_LOCKED_CHECK_PLAN')
    if not returned_ok or unique_planned != unique_returned or len(returned) != len(unique_returned) or len(returned) != len(planned):
        errors.append('V3_MISSING_DUPLICATE_OR_EXTRA_CHECK_ID')
    # V4: required fields and disposition-specific evidence.
    for i, item in enumerate(disp):
        tag = f'V4_CHECK_{i}_'
        if not isinstance(item, Mapping):
            errors.append(tag + 'NOT_OBJECT')
            continue
        if set(item) - ALLOWED_CHECK:
            errors.append(tag + 'UNKNOWN_FIELDS')
        if item.get('disposition') not in DISPOSITIONS:
            errors.append(tag + 'INVALID_DISPOSITION')
        if not all(isinstance(item.get(k), str) and item[k].strip() for k in ('method', 'reason')):
            errors.append(tag + 'MISSING_METHOD_OR_REASON')
        if not isinstance(item.get('evidence_refs'), list):
            errors.append(tag + 'MISSING_EVIDENCE_REF_LIST')
        state = item.get('disposition')
        if state == 'COUNTEREXAMPLE_PROPOSED' and not isinstance(item.get('witness'), Mapping):
            errors.append(tag + 'MISSING_WITNESS')
        if state == 'EVIDENCE_SET_INADEQUATE' and not (
                isinstance(item.get('missing_information'), list)
                and item['missing_information']
                and all(isinstance(v, str) and v.strip() for v in item['missing_information'])):
            errors.append(tag + 'MISSING_INFORMATION_NOT_DESCRIBED')
        if state == 'NOT_CHECKABLE' and not (
                isinstance(item.get('capability_limit'), str) and item['capability_limit'].strip()):
            errors.append(tag + 'CAPABILITY_LIMIT_NOT_DESCRIBED')
    if not isinstance(envelope.get('independent_evidence_requests'), list):
        errors.append('V4_REQUESTS_NOT_ARRAY')
    if not isinstance(envelope.get('notes'), str):
        errors.append('V4_NOTES_NOT_TEXT')
    # V5: coverage/limits are computed, not provided by the challenger.
    derived = [i.get('check_id') for i in disp if isinstance(i, Mapping)
               and i.get('disposition') in ('EVIDENCE_SET_INADEQUATE', 'NOT_CHECKABLE')]
    coverage = {'expected_count': len(planned), 'returned_count': len(returned),
                'unique_returned_count': len(unique_returned),
                'all_registered_checks_accounted_for': (
                    planned_ok and returned_ok and unique_planned == unique_returned
                    and len(planned) == len(returned) == len(unique_returned))}
    return {'admission': 'REJECTED' if errors else 'ADMITTED',
            'errors': errors, 'coverage': coverage,
            'derived_could_not_check': derived if not errors else None}


def verify_finite_witness(reg, witness):
    """Formal-only checker for the two-world constant-action countermodel.

    P14 formal claim: if premise holds then no common adequate constant action.
    Returns a deterministic receipt only, no source-level verdict.
    """
    if not check_locked_registration(reg):
        return {'result': 'INVALID_REGISTRATION'}
    mode = reg['formalization_mode']
    if not isinstance(witness, Mapping) or set(witness) != {'actions_0', 'actions_1', 'observation_0', 'observation_1', 'candidate_constant_action'}:
        return {'result': 'MALFORMED_WITNESS'}
    a0, a1 = witness['actions_0'], witness['actions_1']
    if not (isinstance(a0, list) and isinstance(a1, list) and a0 and a1
            and all(isinstance(x, str) and x for x in a0 + a1)
            and len(a0) == len(set(a0)) and len(a1) == len(set(a1))
            and isinstance(witness['candidate_constant_action'], str)
            and isinstance(witness['observation_0'], str)
            and isinstance(witness['observation_1'], str)):
        return {'result': 'MALFORMED_WITNESS'}
    s0, s1 = set(a0), set(a1)
    observations_equal = witness['observation_0'] == witness['observation_1']
    premise = observations_equal and ((s0 != s1) if mode == 'UNEQUAL' else s0.isdisjoint(s1))
    works_in_both = witness['candidate_constant_action'] in s0.intersection(s1)
    if not premise:
        result = 'PREMISE_NOT_SATISFIED'
    elif not works_in_both:
        result = 'INVALID_COUNTEREXAMPLE'
    else:
        result = 'FORMAL_COUNTEREXAMPLE_VERIFIED'
    return {'checker': CHECKER_VERSION, 'result': result,
            'formalization_id': reg['formalization_id'],
            'registration_digest': reg['registration_digest'],
            'assumptions_digest': object_digest(reg['assumptions']),
            'witness_digest': object_digest(witness),
            'scope': 'two-world finite constant-action submodel',
            'source_fidelity_assessed': False}


def run_transaction(reg, context, envelope, evidence_bytes=None):
    """One deterministic transaction. This is NOT an autonomous agent run."""
    admission = validate_v1_v5(reg, context, envelope, evidence_bytes)
    base = {'admission': admission, 'formal_claim_state': 'UNRESOLVED',
            'source_claim_state': 'UNRESOLVED', 'source_review': {
                'interpretation': reg['source_interpretation_finding'],
                'reviewer_agreement': reg['reviewer_agreement']},
            'verification_receipts': []}
    if admission['admission'] != 'ADMITTED':
        return base
    for item in envelope['check_dispositions']:
        if item['disposition'] == 'COUNTEREXAMPLE_PROPOSED':
            receipt = verify_finite_witness(reg, item['witness'])
            base['verification_receipts'].append(receipt)
            if receipt['result'] == 'FORMAL_COUNTEREXAMPLE_VERIFIED':
                base['formal_claim_state'] = 'REFUTED'
    # There is deliberately no source-level promotion in this prototype.
    return base


def compare_p14_formalizations(reg_a, reg_b):
    """Bounded semantic *distinction* only. Does not infer author's intent.

    Under nonempty finite action sets, DISJOINT implies UNEQUAL but not vice
    versa. The fixed witness exhibits the nonconverse. This crosswalk records
    logical non-equivalence, not fidelity of either translation to the prose.
    """
    if not check_locked_registration(reg_a) or not check_locked_registration(reg_b):
        return {'comparison': 'INVALID_REGISTRATION'}
    if reg_a['source_digest'] != reg_b['source_digest']:
        return {'comparison': 'DIFFERENT_SOURCE_VERSIONS'}
    if {reg_a['formalization_mode'], reg_b['formalization_mode']} != MODES:
        return {'comparison': 'NOT_DISTINCT_MODES'}
    witness = {'actions_0': ['a'], 'actions_1': ['a', 'b'],
               'observation_0': 'same', 'observation_1': 'same',
               'candidate_constant_action': 'a'}
    return {'comparison': 'INEQUIVALENT_PREMISES',
            'relation': 'DISJOINT_IMPLIES_UNEQUAL_NOT_CONVERSE_FOR_NONEMPTY_SETS',
            'differential_witness': witness,
            'source_author_intent': 'NOT_ESTABLISHED',
            'source_promotion_authorized': False}
