"""Pure Phase-1 state transitions. D-07 status names are PROVISIONAL.

Input capability flags are assumed facts in this in-memory model, not actual
identity or durability guarantees. The persistence boundary is Phase 2.
"""
from copy import deepcopy
from scientific_workspace.engine.r0_core import (
    object_digest, run_transaction, check_locked_registration,
)

TERMINAL = frozenset({'EXHAUSTED', 'ABANDONED', 'COMPLETED', 'FAILED'})
FIELDS = {
    'goal': {'type', 'principal', 'goal_id', 'statement'},
    'amend': {'type', 'principal', 'goal_id', 'prior_digest', 'statement', 'reason'},
    'attempt': {'type', 'principal', 'attempt_id', 'ordinal', 'goal_digest', 'payload_digest'},
    'evaluate': {'type', 'principal', 'attempt_id', 'registration', 'context', 'envelope'},
    'correction': {'type', 'principal', 'proposal_id', 'prior_digest', 'statement', 'reason'},
    'exhaust': {'type', 'principal'},
    'stop': {'type', 'principal'},
    'resume': {'type', 'principal'},
    'abandon': {'type', 'principal', 'reason'},
}


def initial_state(budget=2):
    if type(budget) is not int or budget < 1:
        raise ValueError('positive integer budget required')
    return {'schema': 'phase1-provisional/0.1', 'budget': budget,
            'status': 'WAITING_FOR_GOAL', 'goals': [], 'attempts': [],
            'evaluations': [], 'corrections': [], 'events': [],
            'source_claim_state': 'UNRESOLVED'}


def active_goal(state):
    return state['goals'][-1] if state['goals'] else None


def expected_actor(state):
    goal = active_goal(state)
    if goal is None:
        return None
    first = int(goal['digest'][-1], 16) % 2
    return ('agent_a', 'agent_b')[(first + len(state['attempts'])) % 2]


def _result(state, outcome, reason=None):
    return {'outcome': outcome, 'reason': reason, 'state': deepcopy(state)}


def _record(state, command, env):
    previous = state['events'][-1]['digest'] if state['events'] else None
    event = {'index': len(state['events']) + 1, 'previous': previous,
             'command': deepcopy(command),
             'assumed_authority': {
                 'human_authorized': bool(env.get('human_authorized', False)),
                 'system_authorized': bool(env.get('system_authorized', False))}}
    event['digest'] = object_digest(event)
    state['events'].append(event)
    return _result(state, 'APPLIED')


def step(state, command, environment=None):
    """Return new state and named result; never mutate caller arguments or do I/O."""
    env = dict(environment or {})
    if not isinstance(command, dict) or command.get('type') not in FIELDS:
        return _result(state, 'REJECTED', 'UNKNOWN_COMMAND')
    kind = command['type']
    if set(command) != FIELDS[kind]:
        return _result(state, 'REJECTED', 'INVALID_COMMAND_FIELDS')
    try:
        object_digest(command)
    except (TypeError, ValueError):
        return _result(state, 'REJECTED', 'NONCANONICAL_COMMAND')
    if state['status'] in TERMINAL:
        return _result(state, 'REJECTED', 'TERMINAL')
    s = deepcopy(state)
    principal = command['principal']
    if kind == 'goal':
        if principal != 'user' or not env.get('human_authorized'):
            return _result(state, 'REJECTED', 'HUMAN_AUTH_REQUIRED')
        if s['goals'] or not isinstance(command['statement'], str) or not command['statement'].strip() or not isinstance(command['goal_id'], str) or not command['goal_id']:
            return _result(state, 'REJECTED', 'INVALID_GOAL')
        goal = {'id': command['goal_id'], 'version': 1, 'statement': command['statement']}
        goal['digest'] = object_digest(goal)
        s['goals'].append(goal)
        if s['status'] != 'QUIESCED':
            s['status'] = 'WAITING_FOR_TURN'
    elif kind == 'amend':
        prev = active_goal(s)
        if principal != 'user' or not env.get('human_authorized'):
            return _result(state, 'REJECTED', 'HUMAN_AUTH_REQUIRED')
        if (prev is None or command['prior_digest'] != prev['digest']
                or command['goal_id'] != prev['id']
                or not isinstance(command['statement'], str) or not command['statement'].strip()
                or not isinstance(command['reason'], str) or not command['reason'].strip()):
            return _result(state, 'REJECTED', 'INVALID_AMENDMENT')
        goal = {'id': prev['id'], 'version': prev['version'] + 1,
                'statement': command['statement'], 'supersedes': prev['digest'],
                'reason': command['reason']}
        goal['digest'] = object_digest(goal)
        s['goals'].append(goal)
        # A goal amendment is not an implicit resume from a deliberate pause.
        if s['status'] != 'QUIESCED':
            s['status'] = 'WAITING_FOR_TURN'
    elif kind == 'attempt':
        if principal not in ('agent_a', 'agent_b') or s['status'] != 'WAITING_FOR_TURN':
            return _result(state, 'REJECTED', 'TURN_UNAVAILABLE')
        if (not isinstance(command['attempt_id'], str) or not command['attempt_id']
                or not isinstance(command['goal_digest'], str) or not isinstance(command['payload_digest'], str)
                or type(command['ordinal']) is not int):
            return _result(state, 'REJECTED', 'INVALID_ATTEMPT')
        binding = {k: command[k] for k in ('principal', 'attempt_id', 'ordinal', 'goal_digest', 'payload_digest')}
        for a in s['attempts']:
            if a['attempt_id'] == command['attempt_id']:
                return _result(state, 'NOOP' if a == binding else 'REJECTED',
                               'IDEMPOTENT_RETRY' if a == binding else 'ATTEMPT_ID_CONFLICT')
        if any(a['ordinal'] == command['ordinal'] for a in s['attempts']):
            return _result(state, 'REJECTED', 'ORDINAL_CONFLICT')
        if len(s['attempts']) == s['budget']:
            return _result(state, 'REJECTED', 'BUDGET_SPENT')
        if (command['ordinal'] != len(s['attempts']) + 1
                or principal != expected_actor(s)
                or command['goal_digest'] != active_goal(s)['digest']):
            return _result(state, 'REJECTED', 'TURN_BINDING_MISMATCH')
        s['attempts'].append(binding)
    elif kind == 'evaluate':
        if principal != 'system' or not env.get('system_authorized'):
            return _result(state, 'REJECTED', 'SYSTEM_AUTH_REQUIRED')
        match = [a for a in s['attempts'] if a['attempt_id'] == command['attempt_id']]
        if len(match) != 1:
            return _result(state, 'REJECTED', 'UNKNOWN_ATTEMPT')
        if any(e['attempt_id'] == command['attempt_id'] for e in s['evaluations']):
            return _result(state, 'NOOP', 'ALREADY_EVALUATED')
        try:
            valid = (object_digest(command['envelope']) == match[0]['payload_digest']
                     and check_locked_registration(command['registration']))
        except (TypeError, ValueError, KeyError):
            valid = False
        if not valid:
            return _result(state, 'REJECTED', 'PAYLOAD_OR_REGISTRATION_MISMATCH')
        # No caller-supplied verdict field exists. R0 performs deterministic
        # admission and formal-only checking. Source state stays unresolved.
        receipt = run_transaction(command['registration'], command['context'], command['envelope'])
        s['evaluations'].append({'attempt_id': command['attempt_id'], 'result': receipt})
    elif kind == 'correction':
        if principal not in ('agent_a', 'agent_b') or active_goal(s) is None:
            return _result(state, 'REJECTED', 'AGENT_AND_GOAL_REQUIRED')
        if (command['prior_digest'] != active_goal(s)['digest']
                or not isinstance(command['statement'], str) or not command['statement'].strip()
                or not isinstance(command['reason'], str) or not command['reason'].strip()):
            return _result(state, 'REJECTED', 'INVALID_CORRECTION')
        if any(c['proposal_id'] == command['proposal_id'] for c in s['corrections']):
            return _result(state, 'REJECTED', 'DUPLICATE_PROPOSAL')
        s['corrections'].append({'proposal_id': command['proposal_id'],
             'author': principal, 'prior_digest': command['prior_digest'],
             'statement': command['statement'], 'reason': command['reason'],
             'status': 'PROPOSED'})
    elif kind == 'exhaust':
        if principal != 'system' or not env.get('system_authorized'):
            return _result(state, 'REJECTED', 'SYSTEM_AUTH_REQUIRED')
        if len(s['attempts']) != s['budget']:
            return _result(state, 'REJECTED', 'BUDGET_NOT_SPENT')
        s['status'] = 'EXHAUSTED'
    elif kind == 'stop':
        if principal != 'user' or not env.get('human_authorized'):
            return _result(state, 'REJECTED', 'HUMAN_AUTH_REQUIRED')
        if s['status'] == 'QUIESCED':
            return _result(state, 'NOOP', 'ALREADY_QUIESCED')
        s['status'] = 'QUIESCED'
    elif kind == 'resume':
        if principal != 'user' or not env.get('human_authorized'):
            return _result(state, 'REJECTED', 'HUMAN_AUTH_REQUIRED')
        if s['status'] != 'QUIESCED':
            return _result(state, 'REJECTED', 'NOT_QUIESCED')
        s['status'] = 'WAITING_FOR_TURN' if active_goal(s) else 'WAITING_FOR_GOAL'
    elif kind == 'abandon':
        if (principal != 'user' or not env.get('human_authorized')
                or not isinstance(command['reason'], str) or not command['reason'].strip()):
            return _result(state, 'REJECTED', 'HUMAN_AUTH_REQUIRED')
        if not env.get('storage_writable', True):
            return _result(state, 'BLOCKED', 'LOCAL_STOP_UNRECORDED')
        s['status'] = 'ABANDONED'
    return _record(s, command, env)


def verify_event_chain(events):
    """Internal consistency only: no independent authenticity or time anchor."""
    previous = None
    try:
        for index, e in enumerate(events, 1):
            if e['index'] != index or e['previous'] != previous:
                return False
            if object_digest({k: v for k, v in e.items() if k != 'digest'}) != e['digest']:
                return False
            previous = e['digest']
    except (KeyError, TypeError, ValueError):
        return False
    return True


def replay(events, budget=2):
    """Recompute from captured command/auth assertions, not a trusted log."""
    if not verify_event_chain(events):
        raise ValueError('INVALID_EVENT_CHAIN')
    state = initial_state(budget)
    for event in events:
        result = step(state, event['command'], event['assumed_authority'])
        if result['outcome'] != 'APPLIED':
            raise ValueError('REPLAY_REJECTED:' + str(result['reason']))
        state = result['state']
        if state['events'][-1]['digest'] != event['digest']:
            raise ValueError('REPLAY_DIGEST_MISMATCH')
    return state


def classify_continuation(state, environment=None):
    """Conservative label, not an exhaustive concrete reachability proof."""
    env = environment or {}
    if state['status'] in TERMINAL:
        return 'TERMINAL'
    if not env.get('storage_writable', True):
        return 'RECOVERY_REQUIRED'
    if (not env.get('item_readable', True) or state['status'] == 'QUIESCED'
            or len(state['attempts']) >= state['budget']):
        return 'ESCAPE_ONLY'
    return 'PRODUCTIVE_POSSIBLE'
