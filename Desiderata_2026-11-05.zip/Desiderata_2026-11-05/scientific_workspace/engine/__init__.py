"""Pure decision logic."""
