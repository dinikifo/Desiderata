"""C2 local, single-sequencer scientific journal on four WikiCore notebook pairs.

The only authoritative committed transaction is a `system/` event. Party posts
are non-authoritative staged intents until that event exists. The gap is named
PENDING_UNCOMMITTED, not incorrectly presented as atomic cross-DB persistence.

Trust boundary: POSIX advisory locks and one trusted local coordinator. Names
in a command are NOT authenticated agent/human identities. No proof of external
chronology, resistance to an administrator editing all stores, or process-level
human authorization is claimed.
"""
from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
import fcntl
import json
import re

from scientific_workspace.engine.r0_core import object_digest
from scientific_workspace.engine.transition import initial_state, replay, step
from scientific_workspace.storage.vendor_pw.wiki_core import WikiCore

NAMESPACES = ('user', 'agent_a', 'agent_b', 'system')
_ID = re.compile(r'^[A-Za-z0-9_-]{1,96}$')
_SCHEMA = 'scientific-workspace-journal/0.1'


class JournalError(RuntimeError):
    """A named persistence, identity or replay failure."""


class SimulatedCrash(RuntimeError):
    """Injected interruption at a durable cutpoint; test-only facility."""


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _post(path: Path, title: str, kind: str, payload: dict, reason: str):
    # post_sha256 in WikiCore's history sidecar also hashes all custom fields.
    data = {'schema': _SCHEMA, 'kind': kind, 'payload': payload}
    with WikiCore(path) as wiki:
        if wiki.get_tiddler(title) is not None:
            raise JournalError('IMMUTABLE_TITLE_EXISTS:' + title)
        wiki.save_tiddler(title, _json(data), [],
                          fields={'sw_kind': kind, 'sw_json': _json(data),
                                  'sw_digest': object_digest(data)}, reason=reason)


def _parse_post(wiki: WikiCore, title: str, kind: str):
    record = wiki.get_tiddler(title)
    if record is None:
        raise JournalError('MISSING_RECORD:' + title)
    f = record.get('fields') or {}
    try:
        data = json.loads(f['sw_json'])
        if (record.get('text') != _json(data) or f['sw_kind'] != kind
                or f['sw_digest'] != object_digest(data)
                or data['schema'] != _SCHEMA or data['kind'] != kind):
            raise ValueError('fields/text disagree')
        return data['payload']
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as e:
        raise JournalError('INVALID_PERSISTED_RECORD:' + title) from e


class WikiJournal:
    def __init__(self, root: str | Path):
        self.root = Path(root)

    def _path(self, namespace: str):
        return self.root / namespace / 'wiki.db'

    @contextmanager
    def _locked(self):
        if not self.root.is_dir():
            raise JournalError('NAMESPACE_UNAVAILABLE:workspace_root')
        # Advisory POSIX lock; external writers that ignore it remain out of scope.
        with (self.root / '.sequencer.lock').open('a+b') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    @classmethod
    def create(cls, root: str | Path, budget: int = 2):
        initial_state(budget)  # validate before touching disk
        path = Path(root)
        if path.exists():
            raise JournalError('WORKSPACE_EXISTS')
        path.mkdir(parents=True)
        journal = cls(path)
        # Failure during creation is left named/incomplete for inspection.
        with journal._locked():
            for namespace in NAMESPACES:
                folder = path / namespace
                folder.mkdir()
                WikiCore.create_database(folder / 'wiki.db')
            _post(journal._path('system'), 'run/config', 'config',
                  {'budget': budget, 'namespaces': list(NAMESPACES)}, 'Create immutable run configuration')
        return journal

    def _open_checked(self):
        opened = {}
        try:
            for namespace in NAMESPACES:
                try:
                    wiki = WikiCore(self._path(namespace), readonly=True)
                    report = wiki.history_report()
                    if report['status'] != 'ok':
                        wiki.close()
                        raise JournalError('HISTORY_UNVERIFIED:' + namespace)
                    # The substrate supports editing; this application journal does not.
                    # An in-place modification, even with a consistent new history, is
                    # an explicitly forbidden event-rewrite operation.
                    for post in wiki.history_posts():
                        versions = wiki.post_history(post['post_id'])
                        if (post['deleted'] or len(versions) != 1
                                or versions[0]['change_type'] != 'first_version'):
                            wiki.close()
                            raise JournalError('IMMUTABLE_HISTORY_VIOLATION:' + namespace)
                    opened[namespace] = wiki
                except (OSError, ValueError, RuntimeError) as e:
                    if isinstance(e, JournalError):
                        raise
                    raise JournalError('NAMESPACE_UNAVAILABLE:' + namespace) from e
            return opened
        except BaseException:
            for wiki in opened.values():
                wiki.close()
            raise

    def _load(self):
        opened = self._open_checked()
        try:
            system = opened['system']
            config = _parse_post(system, 'run/config', 'config')
            if (set(config) != {'budget', 'namespaces'}
                    or config['namespaces'] != list(NAMESPACES)):
                raise JournalError('INVALID_RUN_CONFIG')
            budget = config['budget']
            initial_state(budget)
            titles = []
            for namespace, wiki in opened.items():
                offset = 0
                names = []
                while True:
                    chunk = wiki.all_titles(limit=200, offset=offset)
                    names.extend(chunk)
                    offset += len(chunk)
                    if len(chunk) < 200:
                        break
                titles.append((namespace, names))
            system_titles = dict(titles)['system']
            if any(t != 'run/config' and not t.startswith('event/') for t in system_titles):
                raise JournalError('UNEXPECTED_SYSTEM_RECORD')
            event_names = sorted(t for t in system_titles if t.startswith('event/'))
            if any(not re.fullmatch(r'event/[0-9]{8}', t) for t in event_names):
                raise JournalError('INVALID_EVENT_TITLE')
            events = []
            receipt_by_id = {}
            for i, title in enumerate(event_names, 1):
                if title != f'event/{i:08d}':
                    raise JournalError('EVENT_ORDINAL_GAP')
                data = _parse_post(system, title, 'event')
                if set(data) != {'request_id', 'command_digest', 'event'}:
                    raise JournalError('INVALID_EVENT_ENVELOPE')
                ev = data['event']
                if object_digest(ev['command']) != data['command_digest']:
                    raise JournalError('EVENT_COMMAND_DIGEST_MISMATCH')
                request_id = data['request_id']
                self._validate_id(request_id)
                if request_id in receipt_by_id:
                    raise JournalError('DUPLICATE_REQUEST_ID')
                principal = ev['command']['principal']
                if principal not in NAMESPACES:
                    raise JournalError('UNKNOWN_PRINCIPAL')
                if principal != 'system':
                    draft = _parse_post(opened[principal], 'intent/' + request_id, 'intent')
                    if draft != {'request_id': request_id, 'command': ev['command']}:
                        raise JournalError('DRAFT_COMMIT_DIVERGENCE')
                receipt_by_id[request_id] = data
                events.append(ev)
            try:
                state = replay(events, budget=budget)
            except (ValueError, TypeError, KeyError) as e:
                raise JournalError('JOURNAL_REPLAY_FAILED:' + str(e)) from e
            pending = []
            for namespace, names in titles:
                if namespace == 'system':
                    continue
                for title in names:
                    if not title.startswith('intent/'):
                        raise JournalError('UNEXPECTED_PARTY_RECORD:' + namespace + '/' + title)
                    rid = title[len('intent/'):]
                    self._validate_id(rid)
                    draft = _parse_post(opened[namespace], title, 'intent')
                    if draft.get('request_id') != rid or draft.get('command', {}).get('principal') != namespace:
                        raise JournalError('INVALID_INTENT_BINDING:' + title)
                    if rid not in receipt_by_id:
                        pending.append({'namespace': namespace, 'request_id': rid,
                                        'command_digest': object_digest(draft['command'])})
                    elif receipt_by_id[rid]['event']['command'] != draft['command']:
                        raise JournalError('DRAFT_COMMIT_DIVERGENCE:' + rid)
            return {'state': state, 'pending': sorted(pending, key=lambda p: p['request_id']),
                    'receipts': receipt_by_id, 'budget': budget, 'events': len(events)}
        finally:
            for wiki in opened.values():
                wiki.close()

    @staticmethod
    def _validate_id(request_id: str):
        if not isinstance(request_id, str) or _ID.fullmatch(request_id) is None:
            raise JournalError('INVALID_REQUEST_ID')

    def inspect(self):
        with self._locked():
            return self._load()

    def submit(self, request_id: str, command: dict, environment: dict | None = None,
               *, cutpoint: str | None = None):
        """Stage an immutable party intent then commit one authoritative system event.

        Crash after draft => pending intent, no turn consumed. Crash after event =>
        replay finds committed event; same request_id retries idempotently.
        """
        self._validate_id(request_id)
        if not isinstance(command, dict) or command.get('principal') not in NAMESPACES:
            raise JournalError('UNKNOWN_PRINCIPAL')
        principal = command['principal']
        if command.get('type') == 'attempt' and request_id != command.get('attempt_id'):
            raise JournalError('ATTEMPT_REQUEST_ID_MISMATCH')
        env = dict(environment or {})
        with self._locked():
            data = self._load()
            previous = data['receipts'].get(request_id)
            if previous is not None:
                if previous['command_digest'] != object_digest(command):
                    raise JournalError('REQUEST_ID_CONFLICT')
                return {'outcome': 'NOOP', 'reason': 'ALREADY_COMMITTED',
                        'state': data['state'], 'pending': data['pending']}
            if principal != 'system':
                title = 'intent/' + request_id
                with WikiCore(self._path(principal), readonly=True) as wiki:
                    existing = wiki.get_tiddler(title)
                    if existing is not None:
                        old = _parse_post(wiki, title, 'intent')
                        if old != {'request_id': request_id, 'command': command}:
                            raise JournalError('REQUEST_ID_CONFLICT')
                if existing is None:
                    _post(self._path(principal), title, 'intent',
                          {'request_id': request_id, 'command': command}, 'Stage attributable command')
                if cutpoint == 'after_draft':
                    raise SimulatedCrash('AFTER_DRAFT')
            result = step(data['state'], command, env)
            if result['outcome'] != 'APPLIED':
                return {**result, 'pending': self._load()['pending']}
            event = result['state']['events'][-1]
            record = {'request_id': request_id, 'command_digest': object_digest(command),
                      'event': event}
            _post(self._path('system'), f'event/{event["index"]:08d}', 'event', record,
                  'Commit authoritative validated transition')
            if cutpoint == 'after_event':
                raise SimulatedCrash('AFTER_EVENT')
            return {'outcome': 'APPLIED', 'reason': None, 'state': result['state'],
                    'pending': self._load()['pending']}
