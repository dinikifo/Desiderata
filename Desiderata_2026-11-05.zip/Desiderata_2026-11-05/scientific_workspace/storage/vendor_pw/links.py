"""Link syntax: namespace names, target parsing, link extraction.

Phase 2 of NAMESPACE_ROADMAP_2026-11-05.md. A leaf module: it imports nothing
from this project, by necessity rather than taste. `wiki_core` imports
`exporters`, and `workspace` imports `wiki_core`, so an exporter that needed
the namespace rules from `workspace` would close a cycle. The rules therefore
live here, below both, and `workspace` re-exports `name_problem` so its own
public surface is unchanged.

RESOLUTION IS LEXICAL
---------------------
Whether `[[monograph:Alpha]]` is a cross-namespace reference is decided by the
TEXT ALONE, never by asking which namespaces exist. The tempting rule -- "treat
`x:` as a namespace prefix if a namespace `x` exists" -- is the one §3.2 of the
roadmap forbids, because under it, creating a namespace years from now would
silently re-point existing links, and a link's meaning would depend on what
else happens to be in the workspace. A target that cannot be resolved is a
better outcome than a target that quietly resolves somewhere else.

WHEN IS `name:` A NAMESPACE PREFIX?
-----------------------------------
Exactly when all three hold:

  1. the text before the first colon is a valid namespace name (all-lowercase,
     so `Chapter 1: Introduction` is never mistaken for one);
  2. the character immediately after the colon is not whitespace, which is what
     keeps an ordinary English title like `notes: see also` local; and
  3. something follows the colon.

Only the FIRST colon splits, so `[[monograph:Chapter 1: Intro]]` is the post
`Chapter 1: Intro` in `monograph`.

A leading colon forces a local reading: `[[:notes:something]]` is the local post
titled `notes:something`. That escape exists because rules 1-3 leave one real
ambiguity -- a local title that happens to look like `lowercase:word` -- and an
ambiguity with no way out is a defect rather than a simplification.
"""
from __future__ import annotations

import re

#: Namespace names are simultaneously folder names and tokens in link syntax,
#: so one charset must satisfy both. All-lowercase is what makes a
#: case-insensitive folder collision unrepresentable rather than merely
#: detected: two VALID names cannot differ by case alone, so `alpha` and
#: `Alpha` cannot both exist as namespaces on any filesystem.
_NAME_RE = re.compile(r'[a-z0-9][a-z0-9_-]{0,62}\Z')

#: Reserved because the prefix space is shared with link schemes. A namespace
#: called `file` would make `[[file:report.pdf]]` mean two different things
#: depending on what else exists in the workspace.
_RESERVED_SCHEMES = frozenset({'file', 'http', 'https', 'mailto', 'tw'})

#: Windows opens these as devices regardless of the directory they appear in.
_RESERVED_DEVICES = frozenset(
    {'con', 'prn', 'aux', 'nul'}
    | {f'com{d}' for d in '123456789'}
    | {f'lpt{d}' for d in '123456789'})

#: The same two link forms renderer.py recognises, in the same precedence:
#: captioned first, so `[[Caption|Target]]` is not matched as `[[Target]]`.
_CAPTIONED = re.compile(r'\[\[([^\]|]+)\|([^\]]+)\]\]')
_PLAIN = re.compile(r'\[\[([^\]]+)\]\]')

#: Targets the renderer treats as external rather than as post titles.
_EXTERNAL_PREFIXES = ('http://', 'https://', 'mailto:')


def name_problem(name: str) -> str | None:
    """A specific sentence naming what is wrong with `name`, or None.

    Returns the reason rather than a boolean so a caller can show the user
    which rule was broken. A specific-name-or-None classifier is used here for
    the same reason it is used elsewhere in this project: a boolean would force
    every caller to re-derive the explanation, and they would drift.

    Pure: knows nothing about any workspace, so it cannot report a collision.
    That check belongs to Workspace.create_namespace, which has the context.
    """
    if not isinstance(name, str) or not name:
        return 'A namespace name cannot be empty.'
    if len(name) > 63:
        return (f'A namespace name may be at most 63 characters; this one is '
                f'{len(name)}.')
    if not _NAME_RE.match(name):
        return ('A namespace name may use only lowercase letters, digits, '
                'hyphen and underscore, and must start with a letter or '
                f'digit: {name!r} does not. The name is both a folder name '
                'and a token in link syntax, so it has to be safe for both.')
    if name in _RESERVED_SCHEMES:
        return (f'{name!r} is reserved: it is a link scheme, so a namespace '
                f'of that name would make [[{name}:something]] ambiguous.')
    if name in _RESERVED_DEVICES:
        return (f'{name!r} is a reserved device name on Windows and cannot be '
                'used as a folder name there.')
    return None


def is_external(target: str) -> bool:
    return (target or '').strip().startswith(_EXTERNAL_PREFIXES)


def split_target(target: str) -> tuple[str | None, str] | None:
    """Parse one link target into (namespace_or_None, title).

    Returns None for an external URL, which is not a post reference at all.
    `namespace` is None for a local reference -- the containing namespace,
    always, with no fallback search. See the module docstring for the three
    conditions that make `name:` a prefix, and for the leading-colon escape.
    """
    text = (target or '').strip()
    if not text:
        return None, ''
    if text.startswith(_EXTERNAL_PREFIXES):
        return None
    if text.startswith(':'):
        # Explicitly local, however the rest is shaped.
        return None, text[1:]
    head, separator, tail = text.partition(':')
    if (separator
            and tail
            and not tail[:1].isspace()
            and name_problem(head) is None):
        return head, tail
    return None, text


def extract_links(text: str) -> list[str]:
    """Link targets in one post body, in first-appearance order, deduplicated.

    External targets (http/https/mailto) are excluded: they are not references
    to posts and classifying them as broken would be wrong. Namespace-prefixed
    targets ARE included, as written -- the caller splits them.

    Behaviour is unchanged from the version that lived in exporters.py, which
    re-exports this name so existing callers and the export format are
    unaffected by the move.
    """
    targets: list[str] = []
    for match in _CAPTIONED.finditer(text or ''):
        targets.append(match.group(2))
    # Remove captioned forms before scanning for the plain form, mirroring the
    # renderer's substitution order.
    remaining = _CAPTIONED.sub('', text or '')
    for match in _PLAIN.finditer(remaining):
        targets.append(match.group(1))
    seen: dict[str, None] = {}
    for target in targets:
        target = target.strip()
        if target and not target.startswith(_EXTERNAL_PREFIXES):
            seen.setdefault(target, None)
    return list(seen)


__all__ = ['name_problem', 'split_target', 'extract_links', 'is_external']
