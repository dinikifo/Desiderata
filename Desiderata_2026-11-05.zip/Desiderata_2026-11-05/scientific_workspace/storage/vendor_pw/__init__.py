"""Vendored, Qt-free PERSONAL.WIKI substrate (preserved semantics)."""
