"""PERSONAL.WIKI post versions, held in a separate, per-folder SQLite file.

Content schema v2 is unchanged. The history file is a separate SQLite database;
SQLite ATTACH is connection-local, used only to commit both files together.
"""
from __future__ import annotations

from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import uuid

from .db import TiddlerDB, _valid_record, parse_tags, encode_tags, _utc_stamp, _publish_temp


class HistoryError(RuntimeError):
    pass


class HistoryMissingError(HistoryError):
    pass


def history_path(db_path: str) -> Path:
    p = Path(db_path)
    return p.with_name(p.stem + '.history.sqlite')


def _json(record: dict | None) -> str | None:
    if record is None:
        return None
    return json.dumps(record, ensure_ascii=False, separators=(',', ':'))


def post_sha256(record: dict) -> str:
    """Stable digest of the complete post object, including unknown TW fields."""
    return hashlib.sha256(json.dumps(record, ensure_ascii=False, sort_keys=True,
                             separators=(',', ':')).encode('utf-8')).hexdigest()


def _when() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')


HISTORY_SCHEMA = """
CREATE TABLE posts (
  post_id TEXT PRIMARY KEY,
  current_title TEXT UNIQUE,
  last_title TEXT NOT NULL,
  current_sha256 TEXT,
  deleted INTEGER NOT NULL DEFAULT 0 CHECK(deleted IN (0,1))
);
CREATE TABLE events (
  event_id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id TEXT NOT NULL REFERENCES posts(post_id),
  changed_at TEXT NOT NULL,
  change_type TEXT NOT NULL CHECK(change_type IN
    ('first_version','edit','rename','delete','import_overwrite')),
  reason TEXT NOT NULL CHECK(length(trim(reason)) > 0),
  old_title TEXT,
  title TEXT NOT NULL,
  before_json TEXT,
  before_sha256 TEXT,
  after_json TEXT,
  after_sha256 TEXT
);
CREATE INDEX events_by_post ON events(post_id,event_id);
PRAGMA user_version=1;
"""


def _init_history(conn: sqlite3.Connection) -> None:
    conn.executescript(HISTORY_SCHEMA)
    conn.commit()


def _append(conn: sqlite3.Connection, *, before: dict | None, after: dict | None,
            change_type: str, reason: str, previous_title: str | None = None) -> None:
    """Record an event inside the caller's same cross-file transaction."""
    if not isinstance(reason, str) or not reason.strip():
        raise ValueError('A reason is required for this change')
    if before is None and after is None:
        raise ValueError('History event requires a before or after record')
    old_title = before['title'] if before else None
    new_title = after['title'] if after else old_title
    if before is None:
        if change_type != 'first_version':
            raise HistoryError('New posts must start with a first_version event')
        if conn.execute('SELECT 1 FROM hist.posts WHERE current_title=?', (new_title,)).fetchone():
            raise HistoryError('History already tracks this title')
        post_id = uuid.uuid4().hex
        conn.execute('INSERT INTO hist.posts(post_id,current_title,last_title,current_sha256,deleted) '
                     'VALUES(?,?,?,?,0)', (post_id,new_title,new_title,post_sha256(after)))
    else:
        post = conn.execute('SELECT post_id,current_sha256 FROM hist.posts '
                            'WHERE current_title=? AND deleted=0', (old_title,)).fetchone()
        if post is None or post['current_sha256'] != post_sha256(before):
            raise HistoryError(f'History mismatch for {old_title!r}; refusing change')
        post_id = post['post_id']
        if after is None:
            conn.execute('UPDATE hist.posts SET current_title=NULL,current_sha256=NULL,deleted=1 '
                         'WHERE post_id=?', (post_id,))
        else:
            conn.execute('UPDATE hist.posts SET current_title=?,last_title=?,current_sha256=? '
                         'WHERE post_id=?', (new_title,new_title,post_sha256(after),post_id))
    conn.execute('''INSERT INTO hist.events
        (post_id,changed_at,change_type,reason,old_title,title,
         before_json,before_sha256,after_json,after_sha256)
         VALUES (?,?,?,?,?,?,?,?,?,?)''',
         (post_id,_when(),change_type,reason.strip(),previous_title or old_title,new_title,
          _json(before),post_sha256(before) if before else None,
          _json(after),post_sha256(after) if after else None))


def initialize_history(db_path: str) -> Path:
    """Explicit one-time baseline. No claims about edits predating this snapshot.

    Holds the content writer lock until the complete new sidecar is published.
    Existing history is NEVER replaced (including symlinks).
    """
    db_file = Path(db_path)
    sidecar = history_path(db_path)
    if sidecar.exists() or sidecar.is_symlink():
        raise FileExistsError(f'History already exists: {sidecar}')
    if db_file.is_symlink() or not db_file.is_file():
        raise HistoryError('Content database must be a regular existing file')
    with TiddlerDB(str(db_file),journal_mode='DELETE') as db:
        mode = db.conn.execute('PRAGMA journal_mode=DELETE').fetchone()[0]
        if mode.lower() != 'delete':
            raise HistoryError('Cannot safely initialize history while SQLite WAL is active')
        db.conn.execute('PRAGMA synchronous=EXTRA')
        with tempfile.TemporaryDirectory(prefix='.pw_history_init_', dir=db_file.parent) as tmpdir:
            staged = Path(tmpdir) / 'baseline.history.sqlite'
            with closing(sqlite3.connect(staged)) as hist:
                hist.row_factory=sqlite3.Row
                hist.execute('PRAGMA foreign_keys=ON')
                hist.execute('PRAGMA journal_mode=DELETE')
                hist.execute('PRAGMA synchronous=EXTRA')
                _init_history(hist)
                db.conn.execute('BEGIN IMMEDIATE')
                try:
                    # Do not create a schema relation to the content database.
                    # This is a one-time independent inventory of complete objects.
                    rows = db.conn.execute('SELECT title FROM tiddlers ORDER BY title').fetchall()
                    hist.execute('BEGIN IMMEDIATE')
                    try:
                        for (title,) in rows:
                            obj=db._get_raw(title)
                            pid=uuid.uuid4().hex
                            digest=post_sha256(obj)
                            hist.execute('INSERT INTO posts VALUES(?,?,?,?,0)',
                                         (pid,title,title,digest))
                            hist.execute('''INSERT INTO events
                                (post_id,changed_at,change_type,reason,old_title,title,
                                 before_json,before_sha256,after_json,after_sha256)
                                 VALUES(?,?,?,?,?,?,?,?,?,?)''',
                                (pid,_when(),'first_version',
                                 'First recorded version (history enabled; earlier edits unknown)',
                                 None,title,None,None,_json(obj),digest))
                        hist.commit()
                    except BaseException:
                        hist.rollback()
                        raise
                    if hist.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                        raise HistoryError('History baseline failed integrity check')
                    if os.name=='posix': os.chmod(staged, 0o600)
                    _publish_temp(str(staged),sidecar,overwrite=False)
                finally:
                    db.conn.rollback()  # release writer lock; no main content changes
    return sidecar


class HistoryTiddlerDB(TiddlerDB):
    """TiddlerDB with atomic, per-post audit history for write operations."""
    def __init__(self, db_path: str='tiddlers.db', readonly: bool=False):
        self.history_file=history_path(db_path)
        # Check the CONTENT database first. Previously a missing content file
        # produced "No history file ... initialize a first snapshot", which
        # names the wrong file and recommends the wrong action: what the caller
        # actually wants is WikiCore.create_database().
        content=Path(db_path)
        if not content.exists() and not content.is_symlink():
            raise FileNotFoundError(
                f'No notebook at {db_path}. To make a new one use '
                'WikiCore.create_database(path), which creates the content and '
                'history pair together; initializing a history alone will not '
                'help here.')
        if not readonly and (not self.history_file.is_file() or self.history_file.is_symlink()):
            raise HistoryMissingError(
                f'Notebook {db_path} exists but has no history file '
                f'({self.history_file.name}). Initialize a first snapshot '
                'explicitly before editing.')
        super().__init__(db_path,readonly=readonly,journal_mode='DELETE')
        try:
            if (not self.history_file.is_file() or self.history_file.is_symlink()):
                raise HistoryMissingError(
                    f'No history file for {db_path}. Initialize the first snapshot explicitly.')
            if readonly:
                # An existing history file is attached read-only. URI mode=ro
                # refuses to create a missing file and does not need Qt.
                uri = self.history_file.resolve().as_uri() + '?mode=ro'
                self.conn.execute('ATTACH DATABASE ? AS hist', (uri,))
                if self.conn.execute('PRAGMA hist.user_version').fetchone()[0] != 1:
                    raise HistoryError('Unsupported history schema; refusing read-only history access')
                return
            # SQLite multi-file commit is crash-atomic only if main is a disk DB
            # and rollback journaling is used, not WAL.
            mode=self.conn.execute('PRAGMA main.journal_mode=DELETE').fetchone()[0]
            if mode.lower()!='delete':
                raise HistoryError('History requires rollback-journal mode (DELETE); close other connections')
            self.conn.execute('PRAGMA main.synchronous=EXTRA')
            self.conn.execute('ATTACH DATABASE ? AS hist', (str(self.history_file),))
            if self.conn.execute('PRAGMA hist.user_version').fetchone()[0]!=1:
                raise HistoryError('Unsupported history schema; refusing writable open')
            if self.conn.execute('PRAGMA hist.journal_mode=DELETE').fetchone()[0].lower()!='delete':
                raise HistoryError('History is not in rollback-journal mode')
            self.conn.execute('PRAGMA hist.synchronous=EXTRA')
            self.verify_history()
        except BaseException:
            self.close()
            raise

    def _projection_matches(self, title: str, raw: dict) -> bool:
        """Audit searchable columns and tag index, not only raw_json."""
        row=self.conn.execute('SELECT title,text,created,modified,tags_json,fields_json '
            'FROM tiddlers WHERE title=?',(title,)).fetchone()
        if row is None:return False
        tags=parse_tags(raw.get('tags',[]))
        custom={k:v for k,v in raw.items()
                if k not in {'title','text','created','modified','tags'}}
        actual_tags={r[0] for r in self.conn.execute('SELECT tag FROM tiddler_tags WHERE title=?',(title,))}
        return (row['title']==title and row['text']==raw.get('text','') and
                row['created']==raw.get('created') and
                row['modified']==raw.get('modified') and
                json.loads(row['tags_json'])==tags and
                json.loads(row['fields_json'])==custom and
                actual_tags==set(tags))

    def verify_history(self) -> dict:
        """Check every event digest and the exact current-post inventory.

        Raises HistoryError on anything but a clean result, so existing callers
        are unaffected. The exception now carries the COMPLETE problem list on
        `.problems` and its status on `.status`; use `history_report()` when you
        want the three-valued answer as data rather than as an exception.
        """
        report=self.history_report()
        if report['status']!='ok':
            error=HistoryError(
                'History verification '
                + ('could not be completed' if report['status']=='unknown'
                   else 'failed')
                + '; changes refused: ' + '; '.join(report['problems'][:6])
                + (f" (+{len(report['problems'])-6} more)"
                   if len(report['problems'])>6 else ''))
            error.problems=report['problems']
            error.status=report['status']
            raise error
        return {'active_posts':report['active_posts'],'events':report['events'],
                'verified':True}

    def history_report(self) -> dict:
        """The three-valued verification result, as data.

            {'status': 'ok' | 'failed' | 'unknown',
             'problems': [...],            # COMPLETE, never truncated
             'active_posts': int, 'events': int}

        'failed' means a digest, sequence or inventory disagreement was found.
        'unknown' means the check could not be completed -- a locked database,
        an I/O error -- which is NOT evidence of a problem and must not be
        reported as one. The previous single method could express neither:
        `verified` was a hardcoded True, and a query that could not run raised
        the same exception as a genuine hash mismatch.
        """
        problems=[]
        unavailable=False
        tracked=0          # bound before the try: an early failure below would
                           # otherwise leave it undefined at the return
        try:
            if self.conn.execute('PRAGMA hist.integrity_check').fetchone()[0]!='ok':
                problems.append('History SQLite integrity failure')
            if self.conn.execute('PRAGMA hist.foreign_key_check').fetchone():
                problems.append('History foreign-key failure')
            for row in self.conn.execute('SELECT event_id,before_json,before_sha256,after_json,after_sha256 '
                                         'FROM hist.events'):
                for field in ('before','after'):
                    raw=row[field+'_json']; digest=row[field+'_sha256']
                    if (raw is None) != (digest is None):
                        problems.append(f'Event {row["event_id"]}: incomplete {field} snapshot')
                    elif raw is not None:
                        try:
                            if post_sha256(json.loads(raw)) != digest:
                                problems.append(f'Event {row["event_id"]}: invalid {field} hash')
                        except (ValueError,TypeError):
                            problems.append(f'Event {row["event_id"]}: unreadable {field} snapshot')
            tracked=0
            for row in self.conn.execute('SELECT post_id,current_title,current_sha256,deleted FROM hist.posts'):
                sequence=self.conn.execute('SELECT change_type,before_sha256,after_sha256,old_title,title '
                    'FROM hist.events WHERE post_id=? ORDER BY event_id',
                    (row['post_id'],)).fetchall()
                label=f"{row['post_id']} ({row['current_title'] or row['post_id']})"
                if not sequence:
                    problems.append(f'Post without recorded first version: {label}')
                    continue
                first=sequence[0]
                if (first['change_type'] != 'first_version' or
                        first['before_sha256'] is not None or first['after_sha256'] is None):
                    problems.append(f'Post missing a valid first_version snapshot: {label}')
                for previous,current in zip(sequence,sequence[1:]):
                    if (previous['after_sha256'] is None or
                            current['before_sha256']!=previous['after_sha256'] or
                            current['old_title']!=previous['title'] or
                            current['change_type']=='first_version'):
                        problems.append('Broken version sequence for post '+row['post_id'])
                last=sequence[-1]
                if row['deleted']:
                    if row['current_title'] is not None or row['current_sha256'] is not None or last['change_type']!='delete':
                        problems.append(f'Inconsistent deletion in history: {label}')
                    continue
                tracked+=1
                title=row['current_title']
                raw=self._get_raw(title)
                if (raw is None or post_sha256(raw)!=row['current_sha256'] or
                        not self._projection_matches(title,raw) or
                        last['after_sha256']!=row['current_sha256'] or
                        last['title']!=title):
                    problems.append('Content/history disagreement: '+str(title))
            if tracked!=self.count():
                problems.append(f'History tracks {tracked} active posts; content has {self.count()}')
        except sqlite3.OperationalError as exc:
            # Locked, busy, I/O error: the history is not implicated and must
            # not be reported as damaged.
            unavailable=True
            problems.append('History could not be read: '+str(exc))
        except (sqlite3.DatabaseError,ValueError,TypeError) as exc:
            problems.append('History query failed: '+str(exc))
        try:
            events=self.conn.execute('SELECT COUNT(*) FROM hist.events').fetchone()[0]
        except sqlite3.DatabaseError:
            events=-1
        status='ok' if not problems else ('unknown' if unavailable else 'failed')
        return {'status':status,'problems':problems,
                'active_posts':tracked if status=='ok' else -1,'events':events}

    def save_tiddler(self, title: str, text: str, tags: list[str], fields: dict | None=None,
                     created: str | None=None, reason: str | None=None) -> None:
        if self.readonly: raise PermissionError('Read-only database')
        if not title: raise ValueError('Title required')
        with self.conn:
            if self.is_protected(title): raise PermissionError('Historical source is protected')
            before=self._get_raw(title)
            if before is not None and not (reason or '').strip():
                raise ValueError('A reason is required to change an existing post')
            item=dict(before) if before else {'title':title}
            item.update(fields or {})
            item['title']=title;item['text']=text
            item['tags']=encode_tags(tags) if isinstance(item.get('tags'),str) else list(tags)
            item['created']=created or item.get('created') or _utc_stamp()
            item['modified']=_utc_stamp()
            self._store(item)
            _append(self.conn,before=before,after=item,
                    change_type='edit' if before else 'first_version',
                    reason=reason or 'First version — new post created')

    def update_tiddler(self,old_title: str,new_title: str,text: str,tags: list[str],
                       reason: str | None=None) -> bool:
        if self.readonly:raise PermissionError('Read-only database')
        if not new_title: raise ValueError('Title required')
        if not (reason or '').strip(): raise ValueError('A reason is required for editing')
        with self.conn:
            before=self._get_raw(old_title)
            if before is None:return False
            if self.is_protected(old_title):raise PermissionError('Historical record is protected')
            if old_title!=new_title and self._get_raw(new_title) is not None:
                raise ValueError('Destination title already exists')
            after=dict(before)
            after['title']=new_title;after['text']=text
            after['tags']=encode_tags(tags) if isinstance(after.get('tags'),str) else list(tags)
            after['modified']=_utc_stamp()
            if old_title!=new_title:
                self.conn.execute('DELETE FROM tiddlers WHERE title=?',(old_title,))
            self._store(after)
            _append(self.conn,before=before,after=after,
                    change_type='rename' if old_title!=new_title else 'edit',reason=reason)
        return True

    def rename_tiddler(self, old_title: str,new_title: str, reason: str | None=None) -> bool:
        if self.readonly:raise PermissionError('Read-only database')
        if old_title==new_title:return self._get_raw(old_title) is not None
        before=self._get_raw(old_title)
        if before is None:return False
        return self.update_tiddler(old_title,new_title,before.get('text',''),
                                   parse_tags(before.get('tags',[])), reason=reason)

    def delete_tiddler(self,title: str,reason: str | None=None) -> bool:
        if self.readonly:raise PermissionError('Read-only database')
        if not (reason or '').strip():raise ValueError('A reason is required to delete a post')
        with self.conn:
            before=self._get_raw(title)
            if before is None:return False
            if self.is_protected(title):raise PermissionError('Historical record is protected')
            self.conn.execute('DELETE FROM tiddlers WHERE title=?',(title,))
            _append(self.conn,before=before,after=None,change_type='delete',reason=reason)
        return True

    def import_json(self,json_path: str,on_conflict: str='reject',
                    protect_imported: bool=False,reason: str | None=None) -> int:
        if self.readonly:raise PermissionError('Read-only database')
        if on_conflict not in ('reject','overwrite'):raise ValueError('Unknown conflict policy')
        with open(json_path,'r',encoding='utf-8') as f:payload=json.load(f)
        if not isinstance(payload,list):raise ValueError('Expected JSON array')
        seen=set()
        for obj in payload:
            _valid_record(obj)
            if obj['title'] in seen:raise ValueError('Duplicate source title '+obj['title'])
            seen.add(obj['title'])
        changed=0
        with self.conn:
            for obj in payload:
                before=self._get_raw(obj['title'])
                if before==obj:
                    if protect_imported:self._protect(obj)
                    continue
                if before is not None and self.is_protected(obj['title']):
                    raise PermissionError('Protected historical record '+repr(obj['title']))
                if before is not None and on_conflict=='reject':
                    raise ValueError('Import conflict for '+repr(obj['title'])+'; rolled back')
                if before is not None and not (reason or '').strip():
                    raise ValueError('A reason is required to overwrite imported posts')
                self._store(obj)
                _append(self.conn,before=before,after=obj,
                        change_type='import_overwrite' if before else 'first_version',
                        reason=(reason if before else 'First version — imported from TiddlyWiki JSON'))
                if protect_imported:self._protect(obj)
                changed+=1
        return changed

    def history_posts(self):
        return [dict(row) for row in self.conn.execute('SELECT post_id,last_title,deleted FROM hist.posts '
                                                    'ORDER BY last_title,post_id')]

    def post_history(self, post_id: str) -> list[dict]:
        return [dict(row) for row in self.conn.execute('SELECT event_id,changed_at,change_type,reason,'
                     'old_title,title,before_json,before_sha256,after_json,after_sha256 '
                     'FROM hist.events WHERE post_id=? ORDER BY event_id', (post_id,))]

    def snapshot_pair(self,path: str) -> dict:
        """Publish a verified, no-overwrite backup of the matching SQLite pair.

        Verify under an immediate SQLite writer lock before copying. Reopen and
        independently verify the staged pair before publishing either file.
        This is not an alternative to an external/offline backup.
        """
        if self.readonly: raise PermissionError('Read-only database')
        dest=Path(path); other=history_path(str(dest))
        if dest.resolve() == Path(self.db_path).resolve() or other.resolve() == self.history_file.resolve():
            raise ValueError('Choose a different backup filename')
        if dest.exists() or dest.is_symlink() or other.exists() or other.is_symlink():
            raise FileExistsError('One of the backup filenames already exists')
        if not dest.parent.is_dir(): raise FileNotFoundError('Backup folder does not exist')
        made=[]
        with tempfile.TemporaryDirectory(prefix='.pw_pair_backup_',dir=dest.parent) as work:
            # Naming the staged files as a normal pair permits exactly the same
            # read-only verification used for any ordinary wiki folder.
            main_tmp=Path(work)/'pair.db'
            hist_tmp=history_path(str(main_tmp))
            self.conn.execute('BEGIN IMMEDIATE')
            try:
                # Reject an externally modified content file rather than
                # certifying a pair whose history no longer matches its posts.
                self.verify_history()
                for original,staged in [(self.db_path,main_tmp),(str(self.history_file),hist_tmp)]:
                    uri=Path(original).resolve().as_uri()+'?mode=ro'
                    with closing(sqlite3.connect(uri,uri=True,timeout=15)) as source:
                        with closing(sqlite3.connect(str(staged))) as copy:
                            source.backup(copy,pages=256,sleep=.01)
                    if os.name=='posix': os.chmod(staged,0o600)
                # A pair of individually sound databases can still disagree.
                # Validate their relationship before making either visible.
                with HistoryTiddlerDB(str(main_tmp),readonly=True) as checked:
                    integrity=checked.integrity_report()
                    if (integrity['integrity']!='ok' or
                            integrity['foreign_key_violations'] or
                            not integrity['fts_matches']):
                        raise HistoryError('Backup content integrity failed')
                    protection=checked.protection_report()
                    if protection['violation_count']:
                        raise HistoryError('Backup protected-record audit failed')
                    checked.verify_history()
                content_hash=hashlib.sha256(main_tmp.read_bytes()).hexdigest()
                history_hash=hashlib.sha256(hist_tmp.read_bytes()).hexdigest()
                for staged,out in [(main_tmp,dest),(hist_tmp,other)]:
                    # Track identity before attempting publication, because
                    # _publish_temp can link successfully and then fail fsync.
                    identity = staged.stat()
                    made.append((out, identity.st_dev, identity.st_ino))
                    _publish_temp(str(staged),out,overwrite=False)
            except BaseException:
                for out,device,inode in reversed(made):
                    try:
                        published = out.stat(follow_symlinks=False)
                        if (published.st_dev,published.st_ino)==(device,inode):
                            out.unlink()
                    except FileNotFoundError:
                        pass
                raise
            finally:
                self.conn.rollback()
        return {'content':str(dest),'history':str(other),
                'content_sha256':content_hash,'history_sha256':history_hash}
