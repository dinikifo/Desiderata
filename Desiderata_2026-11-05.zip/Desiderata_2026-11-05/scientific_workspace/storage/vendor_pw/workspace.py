"""A workspace of namespaces: several notebooks under one roof.

Phase 1 of NAMESPACE_ROADMAP_2026-11-05.md. Qt-free, like wiki_core.py and
renderer.py; no PySide6 import is permitted here.

ONE NAMESPACE IS ONE NOTEBOOK
-----------------------------
Route (a) of the roadmap. A namespace is a folder holding one content/history
pair, so title uniqueness inside a namespace is the `UNIQUE(title)` constraint
the content schema already enforces, and isolation between namespaces is the
filesystem rather than a `WHERE` clause repeated in every query. Nothing in
db.py, history_db.py or wiki_core.py changes to support this module.

    WORKSPACE/
      WORKSPACE.json          registry -- metadata only, NOT the authority
      monograph/
        wiki.db
        wiki.history.sqlite

THE FILESYSTEM IS THE AUTHORITY, NOT THE REGISTRY
-------------------------------------------------
`WORKSPACE.json` holds only what cannot be derived from disk: a description, a
default namespace, the format identifier. Existence is determined by scanning
for subfolders that contain a notebook.

This is not a stylistic choice. A registry that also recorded *what exists*
would create two fields that can disagree, and the disagreement would be
silent. So:

  * a folder with no registry entry is DISCOVERED and reported, not ignored;
  * a registry entry with no folder is REPORTED MISSING, not dropped;
  * the two are distinguishable in the report, because they are different
    fields rather than two values of one enum.

TWO ORTHOGONAL FIELDS, NEVER ONE STATUS
---------------------------------------
`disk` answers "what is on the filesystem" and `registry` answers "does the
registry mention it". Merging them into a single `status` would be the same
error as a boolean that has three reachable outcomes: "missing" and
"unregistered" are not points on one scale, they are values of two different
questions. `opens` is a third question and has a third state, `not_checked`,
because a check that was not run must never be reported as a check that
passed.

    disk:      complete | incomplete | empty | not_a_directory | absent
               | unreadable
    registry:  registered | unregistered
    opens:     ok | failed | not_checked

`not_a_directory` is the state a first draft of this module omitted: a plain
file sitting where a namespace folder would go was reported as `absent`, so
the report said nothing was there while something plainly was, and
create_namespace then failed with a bare FileExistsError. `unreadable` is
defensive and is not exercised by the suite -- see the comment at its branch.

READS DEGRADE, WRITES FAIL CLOSED
---------------------------------
A corrupt or future-versioned registry does NOT prevent the workspace from
opening -- the notebooks are intact and the point of filesystem authority is
that metadata loss cannot cost you data. But writing the registry in that
state would overwrite the unreadable file and destroy whatever it held, so
every write refuses while `registry_status` is not 'ok' or 'absent'.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from .db import _write_atomic
from .links import name_problem
from .wiki_core import WikiCore

#: Registry format identifier. A consumer refuses a shape it does not
#: understand rather than guessing, as with BUNDLE_FORMAT in exporters.py.
WORKSPACE_FORMAT = 'pw-workspace/1'

REGISTRY_NAME = 'WORKSPACE.json'

#: Fixed notebook filename inside a namespace folder. The folder name carries
#: the namespace identity, so the file inside it needs no distinguishing name,
#: and a fixed name means discovery is a single stat rather than a glob.
NOTEBOOK_NAME = 'wiki.db'

#: The namespace-name rules moved to links.py in Phase 2 and are re-exported
#: here so this module's public surface is unchanged. They had to move: the
#: link parser needs them, and `wiki_core` imports `exporters`, so an exporter
#: reaching into `workspace` for them would close an import cycle.


class WorkspaceError(Exception):
    """A workspace-level problem. Never raised for one bad namespace."""


class RegistryUnwritable(WorkspaceError):
    """The registry cannot be written without destroying unread content."""


class Workspace:
    """A root folder holding namespace folders and an optional registry.

    Construction does not touch the filesystem beyond recording the path;
    nothing is scanned until it is asked for. Each `open()` returns a fresh
    WikiCore that the caller owns and closes, per WikiCore's own contract.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root)

    # ---- creation ------------------------------------------------------

    @staticmethod
    def create(root: str | Path) -> 'Workspace':
        """Create an empty workspace: the folder and a registry with no entries.

        Refuses an existing registry rather than replacing it, so pointing this
        at a populated folder by mistake cannot discard one.
        """
        path = Path(root)
        registry = path / REGISTRY_NAME
        if registry.exists() or registry.is_symlink():
            raise WorkspaceError(
                f'A workspace registry already exists at {registry}; refusing '
                'to replace it. Open the workspace instead of creating it.')
        path.mkdir(parents=True, exist_ok=True)
        workspace = Workspace(path)
        workspace._write_registry({'format': WORKSPACE_FORMAT,
                                   'namespaces': {},
                                   'default_namespace': None},
                                  overwrite=False)
        return workspace

    def create_namespace(self, name: str, *, description: str = '') -> Path:
        """Create one namespace: validate the name, make the folder, make the pair.

        Cleans up a folder it created if the notebook could not be created in
        it, and only if that folder is empty -- a pre-existing folder with
        content in it is never removed on this path.
        """
        problem = name_problem(name)
        if problem is not None:
            raise WorkspaceError(problem)

        folder = self.root / name
        notebook = folder / NOTEBOOK_NAME
        if (folder.exists() or folder.is_symlink()) and not folder.is_dir():
            # Caught here so the caller sees a WorkspaceError explaining the
            # obstruction, rather than the bare FileExistsError that mkdir
            # would raise three lines later.
            raise WorkspaceError(
                f'Cannot create namespace {name!r}: {folder} already exists '
                'and is not a directory. Move or remove it first.')
        if notebook.exists() or notebook.is_symlink():
            raise WorkspaceError(
                f'Namespace {name!r} already exists at {folder}.')

        # Refuse before creating anything if the registry cannot be updated
        # afterwards; a namespace whose description could not be recorded is
        # not a failure worth leaving half-done on disk.
        self._require_writable_registry()

        created_folder = not folder.exists()
        folder.mkdir(parents=True, exist_ok=True)
        try:
            WikiCore.create_database(notebook)
        except BaseException:
            if created_folder:
                try:
                    folder.rmdir()      # only ever removes an EMPTY directory
                except OSError:
                    pass
            raise

        registry, status, _error = self._read_registry()
        if status == 'absent':
            registry = {'format': WORKSPACE_FORMAT, 'namespaces': {},
                        'default_namespace': None}
        entries = dict(registry.get('namespaces') or {})
        entries[name] = {'description': description}
        registry['namespaces'] = entries
        registry.setdefault('format', WORKSPACE_FORMAT)
        if not registry.get('default_namespace'):
            registry['default_namespace'] = name
        self._write_registry(registry, overwrite=True)
        return folder

    # ---- discovery -----------------------------------------------------

    def notebook_path(self, name: str) -> Path:
        return self.root / name / NOTEBOOK_NAME

    def namespaces(self) -> list[str]:
        """Usable namespaces, from DISK, sorted. Never from the registry.

        A folder whose name could not be referenced in link syntax is not
        usable and is excluded here; it still appears in report(), where its
        name_problem is stated, so it is never silently dropped.
        """
        return sorted(
            row['name'] for row in self.report()['namespaces']
            if row['disk'] == 'complete' and row['name_problem'] is None)

    def report(self, *, verify: bool = False) -> dict:
        """Every namespace the disk or the registry knows about, as data.

        `verify=False` (the default) stats files only. `verify=True` opens each
        notebook read-only, which is the only way to learn whether it actually
        works -- and is slow, so it is opt-in. A namespace that fails to open
        is recorded and the scan continues: one damaged notebook must not take
        the workspace down with it.
        """
        registry, registry_status, registry_error = self._read_registry()
        registered = dict(registry.get('namespaces') or {})

        names: set[str] = set(registered)
        scan_error = None
        try:
            for child in self.root.iterdir():
                if child.name.startswith('.') or child.name == REGISTRY_NAME:
                    continue
                if child.is_dir():
                    names.add(child.name)
                elif name_problem(child.name) is None:
                    # A non-directory occupying a name a namespace could use.
                    # It would block create_namespace, so it has to be visible:
                    # reporting 'absent' for a path where something plainly
                    # exists is the silent disagreement this module exists to
                    # avoid. A stray README.md is excluded by the charset rule,
                    # so only genuine obstructions are listed.
                    names.add(child.name)
        except OSError as exc:
            scan_error = str(exc)

        rows = []
        for name in sorted(names):
            folder = self.root / name
            notebook = self.notebook_path(name)
            sidecar = WikiCore.history_file(notebook)

            # Five states, asked in order: is it a directory; if not, is
            # anything there at all; if it is a directory, is the pair whole.
            try:
                if folder.is_dir():
                    if notebook.is_file() and sidecar.is_file():
                        disk = 'complete'
                    elif notebook.is_file() or sidecar.is_file():
                        disk = 'incomplete'
                    else:
                        disk = 'empty'
                elif folder.exists() or folder.is_symlink():
                    disk = 'not_a_directory'
                else:
                    disk = 'absent'
            except OSError:
                # Defensive and correct if it fires, but NOT covered by a test:
                # the suite runs as uid 0 in this environment, where mode bits
                # are bypassed, so an unreadable path cannot be staged. Stated
                # rather than implied to be tested.
                disk = 'unreadable'

            # 'not_checked' is a state, not a stand-in for failure. Reporting
            # an unrun check as 'ok' is the defect this spells out to avoid.
            opens = 'not_checked'
            open_error = None
            if verify and disk == 'complete':
                try:
                    with WikiCore(notebook, readonly=True):
                        opens = 'ok'
                except Exception as exc:            # noqa: BLE001
                    opens = 'failed'
                    open_error = f'{type(exc).__name__}: {exc}'

            rows.append({
                'name': name,
                'disk': disk,
                'registry': 'registered' if name in registered else 'unregistered',
                'name_problem': name_problem(name),
                'opens': opens,
                'open_error': open_error,
                'description': (registered.get(name) or {}).get('description', ''),
                'path': str(folder),
            })

        return {
            'root': str(self.root),
            'registry_status': registry_status,
            'registry_error': registry_error,
            'scan_error': scan_error,
            'default_namespace': registry.get('default_namespace'),
            'namespaces': rows,
        }

    # ---- opening -------------------------------------------------------

    def open(self, name: str, *, readonly: bool = False) -> WikiCore:
        """Open one namespace. The caller owns and closes the returned core.

        DEVIATION from the roadmap, which said "cached". A cache without a
        lifecycle policy raises questions this phase cannot answer -- who
        closes a shared handle, and what happens when one caller wants
        read-only and another wants write. WikiCore's own contract is that a
        caller owns each instance, so Phase 1 honours it and the resolver in
        Phase 2 can add a cache with a policy of its own.
        """
        problem = name_problem(name)
        if problem is not None:
            raise WorkspaceError(problem)
        notebook = self.notebook_path(name)
        if not notebook.is_file():
            raise WorkspaceError(
                f'Namespace {name!r} has no notebook at {notebook}. '
                f'Use create_namespace({name!r}) to make one.')
        return WikiCore(notebook, readonly=readonly)

    # ---- registry ------------------------------------------------------

    @property
    def registry_file(self) -> Path:
        return self.root / REGISTRY_NAME

    def _read_registry(self) -> tuple[dict, str, str | None]:
        """(contents, status, error). Four states, each with its own remedy.

        'absent'            -- no registry yet; everything is unregistered and
                               that is a normal state, not a problem.
        'unreadable'        -- unparseable or not an object. Data is intact;
                               writes refuse so the file is not destroyed.
        'unsupported_format'-- parsed, but written by a newer version. Distinct
                               from 'unreadable' because the remedy differs:
                               upgrade the application rather than repair JSON.
        'ok'                -- usable.
        """
        path = self.registry_file
        if not path.exists():
            return {}, 'absent', None
        try:
            raw = path.read_text(encoding='utf-8')
            parsed = json.loads(raw)
        except (OSError, ValueError) as exc:
            return {}, 'unreadable', f'{type(exc).__name__}: {exc}'
        if not isinstance(parsed, dict):
            return {}, 'unreadable', (
                f'{REGISTRY_NAME} must contain a JSON object, found '
                f'{type(parsed).__name__}.')
        found = parsed.get('format')
        if found != WORKSPACE_FORMAT:
            return {}, 'unsupported_format', (
                f'{REGISTRY_NAME} declares format {found!r}; this version '
                f'understands {WORKSPACE_FORMAT!r} only. Refusing to guess at '
                'its contents.')
        return parsed, 'ok', None

    def _require_writable_registry(self) -> None:
        _registry, status, error = self._read_registry()
        if status in ('ok', 'absent'):
            return
        raise RegistryUnwritable(
            f'Refusing to write {self.registry_file}: it is {status} '
            f'({error}). Writing would replace a file whose contents could '
            'not be read, losing them. Your notebooks are unaffected -- they '
            'are discovered from the folders on disk, not from this file.')

    def _write_registry(self, registry: dict, *, overwrite: bool) -> None:
        """Atomically, with the same canonicalisation the exporters use.

        Sorted keys and a trailing newline so the registry is git-diffable for
        the same reason the markdown bundle is.
        """
        payload = json.dumps(registry, sort_keys=True, ensure_ascii=False,
                             indent=2) + '\n'
        _write_atomic(self.registry_file, payload.encode('utf-8'),
                      overwrite=overwrite)

    def set_description(self, name: str, description: str) -> None:
        """Record a description for an existing namespace.

        Refuses an unknown name. Accepting one would write a registry entry
        with no folder behind it -- which reads back as 'absent + registered',
        indistinguishable from a namespace whose folder was deleted. An API
        that can manufacture that state defeats the point of keeping disk and
        registry as separate observations.
        """
        if name not in self.namespaces():
            raise WorkspaceError(
                f'Cannot describe {name!r}: it is not a usable namespace in '
                f'this workspace. Recording a description for it would leave '
                f'a registry entry with nothing behind it, which is '
                f'indistinguishable from a namespace whose folder was lost.')
        self._require_writable_registry()
        registry, status, _error = self._read_registry()
        if status == 'absent':
            registry = {'format': WORKSPACE_FORMAT, 'namespaces': {},
                        'default_namespace': None}
        entries = dict(registry.get('namespaces') or {})
        entries.setdefault(name, {})['description'] = description
        registry['namespaces'] = entries
        registry.setdefault('format', WORKSPACE_FORMAT)
        self._write_registry(registry, overwrite=True)

    def set_default_namespace(self, name: str | None) -> None:
        """Record which namespace a new post defaults to.

        Accepts None to clear. A name that is not a usable namespace is
        refused: a default pointing at nothing would be discovered at the
        moment of creating a post, which is the worst time to find out.
        """
        self._require_writable_registry()
        if name is not None and name not in self.namespaces():
            raise WorkspaceError(
                f'Cannot default to {name!r}: it is not a usable namespace in '
                f'this workspace.')
        registry, status, _error = self._read_registry()
        if status == 'absent':
            registry = {'format': WORKSPACE_FORMAT, 'namespaces': {},
                        'default_namespace': None}
        registry['default_namespace'] = name
        registry.setdefault('format', WORKSPACE_FORMAT)
        registry.setdefault('namespaces', {})
        self._write_registry(registry, overwrite=True)


__all__ = ['Workspace', 'WorkspaceError', 'RegistryUnwritable',
           'name_problem', 'WORKSPACE_FORMAT', 'REGISTRY_NAME',
           'NOTEBOOK_NAME']
