"""Resolve link targets across the namespaces of one workspace.

Phase 2 of NAMESPACE_ROADMAP_2026-11-05.md. Qt-free. Parsing is in links.py and
is purely lexical; this module is the part that touches notebooks.

FIVE STATES, NOT A BOOLEAN
--------------------------
    RESOLVED              the post exists; namespace and title are filled in
    NO_SUCH_POST          that namespace is readable, the title is not in it
    NO_SUCH_NAMESPACE     nothing in this workspace is called that
    NAMESPACE_UNAVAILABLE it exists but could not be read
    EXTERNAL              an http/https/mailto URL: not a post reference

The roadmap named four. `EXTERNAL` is the fifth, and it is reachable the moment
a caller hands this function a raw link target rather than pre-filtering, which
is what every caller actually wants to do.

`NAMESPACE_UNAVAILABLE` is the state that must never be folded into
`NO_SUCH_NAMESPACE`, and the reason is the advice each one implies. "No such
namespace" tells the user to fix the link. "Unavailable" tells the user to fix
the notebook and leave the link alone. Collapsing them would send someone to
edit a perfectly correct reference because a notebook was locked, a sidecar was
missing, or a folder was half-copied. This is the same distinction as
`fts_status: unknown` in db.py and `disk` in workspace.py: the third state is
always "the check could not run", and omitting it turns a non-answer into a
false answer.

A namespace whose folder is `incomplete`, `empty`, `not_a_directory` or
`unreadable` is UNAVAILABLE, not absent -- something is there and it is
damaged. Only a name the workspace has never heard of is `NO_SUCH_NAMESPACE`.

WHAT IS SNAPSHOTTED, AND WHY
----------------------------
A Resolver takes one scan of the workspace at construction and resolves every
target against it. Two reasons:

  * a report built from a shifting view is not a report -- two links to the same
    namespace must not disagree because something changed mid-pass;
  * `Workspace.report()` walks the directory, and calling it once per link
    would make a 200-post scan do 200 directory walks.

A namespace created after construction is therefore invisible until a new
Resolver is made. Open failures are cached too, for the same consistency
reason: one pass gives one verdict per namespace. A new Resolver retries.

The caller owns the Resolver and closes it; `close()` closes every notebook it
opened. Notebooks are opened READ-ONLY, always -- a resolver has no business
writing, and read-only is also what lets it open a notebook whose search index
could not be verified (see WikiCore.__init__).
"""
from __future__ import annotations

from typing import NamedTuple

from .links import extract_links, name_problem, split_target

RESOLVED = 'RESOLVED'
NO_SUCH_POST = 'NO_SUCH_POST'
NO_SUCH_NAMESPACE = 'NO_SUCH_NAMESPACE'
NAMESPACE_UNAVAILABLE = 'NAMESPACE_UNAVAILABLE'
EXTERNAL = 'EXTERNAL'

#: Every state this module can return. A caller that wants exhaustiveness can
#: assert against this rather than hardcoding a list that will drift.
STATES = (RESOLVED, NO_SUCH_POST, NO_SUCH_NAMESPACE, NAMESPACE_UNAVAILABLE,
          EXTERNAL)


class Resolution(NamedTuple):
    """One target's outcome.

    A NamedTuple rather than a dict: this is read in loops, where a mistyped
    key would be silently None instead of an AttributeError.

    `namespace` and `title` are the place the target POINTS AT, filled in
    wherever they are known -- so NO_SUCH_POST still tells you which namespace
    was searched, and NAMESPACE_UNAVAILABLE still tells you which namespace
    could not be read.
    """
    state: str
    target: str
    namespace: str | None = None
    title: str | None = None
    detail: str | None = None

    @property
    def ok(self) -> bool:
        return self.state == RESOLVED


class Resolver:
    """Resolves targets for one workspace against one snapshot of it."""

    def __init__(self, workspace):
        self.workspace = workspace
        report = workspace.report()
        #: name -> disk state, from Phase 1's five-valued `disk` field.
        self._disk: dict[str, str] = {row['name']: row['disk']
                                      for row in report['namespaces']}
        #: name -> (core, error). A cached None core with an error means the
        #: namespace was tried once this pass and could not be opened.
        self._cores: dict[str, tuple[object | None, str | None]] = {}

    # ---- lifecycle -----------------------------------------------------

    def close(self) -> None:
        for core, _error in self._cores.values():
            if core is not None:
                try:
                    core.close()
                except Exception:                               # noqa: BLE001
                    pass        # closing is best-effort; never mask the caller
        self._cores.clear()

    def __enter__(self) -> 'Resolver':
        return self

    def __exit__(self, *_args) -> None:
        self.close()

    # ---- namespace access ----------------------------------------------

    def namespaces(self) -> list[str]:
        """Namespaces in this snapshot whose folder holds a complete pair."""
        return sorted(name for name, disk in self._disk.items()
                      if disk == 'complete')

    def _core(self, name: str) -> tuple[object | None, str | None]:
        """(core, error) for one namespace, opened read-only at most once."""
        if name in self._cores:
            return self._cores[name]
        try:
            core = self.workspace.open(name, readonly=True)
        except Exception as exc:                                # noqa: BLE001
            entry: tuple[object | None, str | None] = (
                None, f'{type(exc).__name__}: {exc}')
        else:
            entry = (core, None)
        self._cores[name] = entry
        return entry

    # ---- resolution ----------------------------------------------------

    def resolve(self, target: str, from_namespace: str) -> Resolution:
        """Resolve one link target as written inside `from_namespace`.

        A malformed `from_namespace` raises: that is the caller's own context,
        not data being examined, so getting it wrong is a programming error
        rather than a resolution outcome. A well-formed name that is absent or
        damaged is reported, not raised.
        """
        problem = name_problem(from_namespace)
        if problem is not None:
            raise ValueError(f'from_namespace is not a namespace name: {problem}')

        parsed = split_target(target)
        if parsed is None:
            return Resolution(EXTERNAL, target,
                              detail='An external URL, not a post reference.')
        namespace, title = parsed
        if namespace is None:
            namespace = from_namespace
        if not title:
            return Resolution(NO_SUCH_POST, target, namespace=namespace,
                              title='',
                              detail='The target names no post title.')

        disk = self._disk.get(namespace)
        if disk is None:
            return Resolution(
                NO_SUCH_NAMESPACE, target, namespace=namespace, title=title,
                detail=f'No namespace {namespace!r} in this workspace. The '
                       'link names a namespace that does not exist; the link '
                       'is what needs changing.')
        if disk != 'complete':
            return Resolution(
                NAMESPACE_UNAVAILABLE, target, namespace=namespace,
                title=title,
                detail=f'Namespace {namespace!r} exists but its folder is '
                       f'{disk}, so it could not be read. The link may well '
                       'be correct; the notebook is what needs attention.')

        core, error = self._core(namespace)
        if core is None:
            return Resolution(
                NAMESPACE_UNAVAILABLE, target, namespace=namespace,
                title=title,
                detail=f'Namespace {namespace!r} could not be opened ({error}). '
                       'This says nothing about whether the post exists.')

        record, query_error = self._fetch(namespace, title)
        if query_error is not None:
            return Resolution(
                NAMESPACE_UNAVAILABLE, target, namespace=namespace,
                title=title,
                detail=f'Namespace {namespace!r} opened but could not be '
                       f'queried ({query_error}). This says nothing about '
                       'whether the post exists.')
        if record is None:
            return Resolution(
                NO_SUCH_POST, target, namespace=namespace, title=title,
                detail=f'Namespace {namespace!r} is readable and has no post '
                       f'titled {title!r}.')
        return Resolution(RESOLVED, target, namespace=namespace, title=title)

    def _fetch(self, namespace: str, title: str) -> tuple[dict | None, str | None]:
        """(record, error). A query can fail on a handle that opened cleanly.

        Opening a notebook proves it was readable at that instant, not that it
        stays readable: the file can be replaced, a USB disk pulled, a network
        share dropped. SQLite reads pages lazily, so the failure surfaces here
        rather than at open.

        A first draft of this module called get_tiddler directly and let the
        sqlite3 error escape, which made `resolve` non-total: a bulk scan --
        the consistency report, an export -- would abort on the first damaged
        namespace instead of recording it and carrying on. The state this maps
        to already exists and already carries the right advice: the namespace
        exists and could not be read.

        The dead handle is closed and the cache entry replaced with the
        failure so that later lookups do not re-enter a connection known to be
        dead. The stable-verdict property does not depend on that line -- a
        repeated failure would be caught and mapped the same way either -- so
        it is robustness, not the mechanism the test relies on. Said plainly
        because a comment claiming to be load-bearing when it is not is how a
        line survives long after its reason stops being true.
        """
        core, error = self._cores.get(namespace, (None, None))
        if core is None:
            return None, error or 'not open'
        try:
            return core.get_tiddler(title), None
        except Exception as exc:                                # noqa: BLE001
            message = f'{type(exc).__name__}: {exc}'
            try:
                core.close()
            except Exception:                                   # noqa: BLE001
                pass
            self._cores[namespace] = (None, message)
            return None, message

    def resolve_body(self, text: str, from_namespace: str) -> list[Resolution]:
        """Resolve every link in one post body, in first-appearance order.

        Deduplicated by target, as `extract_links` deduplicates. Note that
        external URLs are dropped by `extract_links`, so EXTERNAL will not
        appear here -- it appears when `resolve` is called with a raw target.
        """
        return [self.resolve(target, from_namespace)
                for target in extract_links(text)]

    def resolve_post(self, namespace: str, title: str) -> list[Resolution]:
        """Resolve the outbound links of one stored post.

        Raises LookupError if the post itself cannot be read, which is a
        different thing from its links not resolving and must not be reported
        as an empty link list.
        """
        core, error = self._core(namespace)
        if core is None:
            raise LookupError(
                f'Cannot read namespace {namespace!r}: '
                f'{error or self._disk.get(namespace, "absent")}')
        record, query_error = self._fetch(namespace, title)
        if query_error is not None:
            raise LookupError(
                f'Namespace {namespace!r} could not be queried: {query_error}')
        if record is None:
            raise LookupError(f'No post {title!r} in namespace {namespace!r}.')
        return self.resolve_body(record.get('text', ''), namespace)


__all__ = ['Resolver', 'Resolution', 'STATES', 'RESOLVED', 'NO_SUCH_POST',
           'NO_SUCH_NAMESPACE', 'NAMESPACE_UNAVAILABLE', 'EXTERNAL']
