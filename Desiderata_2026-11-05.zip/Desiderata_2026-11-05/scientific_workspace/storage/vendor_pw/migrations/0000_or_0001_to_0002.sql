-- PERSONAL.WIKI schema transition v0/v1 -> v2 (legacy schemas only).
-- Applied to a SQLite online snapshot by app/schema_migrations.py inside one
-- BEGIN IMMEDIATE transaction. Never execute directly on a source workspace.
-- Existing tiddlers.raw_json is checked in Python; if absent, ALTER TABLE is
-- executed within the same transaction before this SQL runs.
-- Rebuild of the FTS external-content index and setting PRAGMA user_version=2
-- are explicit final steps in the Python coordinator, also transactional.
CREATE TABLE IF NOT EXISTS tiddler_tags (
  title TEXT NOT NULL, tag TEXT NOT NULL,
  PRIMARY KEY(title, tag),
  FOREIGN KEY(title) REFERENCES tiddlers(title) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tiddler_tags_tag ON tiddler_tags(tag);
CREATE TABLE IF NOT EXISTS protected_titles (
  title TEXT PRIMARY KEY, record_sha256 TEXT NOT NULL,
  FOREIGN KEY(title) REFERENCES tiddlers(title) ON DELETE RESTRICT
);
CREATE VIRTUAL TABLE IF NOT EXISTS tiddlers_fts USING fts5(
  title, text, content='tiddlers', content_rowid='rowid'
);
CREATE TRIGGER IF NOT EXISTS tiddlers_ai AFTER INSERT ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(rowid,title,text) VALUES (new.rowid,new.title,new.text);
END;
CREATE TRIGGER IF NOT EXISTS tiddlers_ad AFTER DELETE ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(tiddlers_fts,rowid,title,text)
  VALUES ('delete',old.rowid,old.title,old.text);
END;
CREATE TRIGGER IF NOT EXISTS tiddlers_au AFTER UPDATE ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(tiddlers_fts,rowid,title,text)
  VALUES ('delete',old.rowid,old.title,old.text);
  INSERT INTO tiddlers_fts(rowid,title,text)
  VALUES (new.rowid,new.title,new.text);
END;
