"""
Lightweight TiddlyWiki markup renderer.

Supports:
- Headings: ! through !!!!!!
- Lists: * (unordered), # (ordered), nested
- Code blocks: ``` fenced and {{{ TW-style }}}
- Horizontal rule: ----
- Tables: |a|b|, |!header|, caption/class pseudo-rows
- Bold: ''bold''
- Italic: //italic//
- Inline code: `code`
- Links: [[Title]], [[Caption|Title]]
"""

import re
import html
from typing import Optional
from urllib.parse import quote, unquote

from .links import split_target


class TiddlyRenderer:
    def __init__(self):
        pass

    def render(self, text: str) -> str:
        """Render TiddlyWiki markup to HTML."""
        lines = text.split("\n")
        html_parts = []
        i = 0

        while i < len(lines):
            line = lines[i]

            # Check for code blocks first
            if line.strip().startswith("```"):
                block, consumed = self._parse_fenced_code(lines, i)
                html_parts.append(block)
                i += consumed
                continue

            if line.strip().startswith("{{{"):
                block, consumed = self._parse_tw_code(lines, i)
                html_parts.append(block)
                i += consumed
                continue

            # Horizontal rule
            if line.strip().startswith("----"):
                html_parts.append("<hr>")
                i += 1
                continue

            # Headings
            heading_match = re.match(r"^(!{1,6})\s*(.+)$", line)
            if heading_match:
                level = len(heading_match.group(1))
                content = self._render_inline(heading_match.group(2))
                html_parts.append(f"<h{level}>{content}</h{level}>")
                i += 1
                continue

            # Lists
            if line and line[0] in "*#":
                block, consumed = self._parse_list(lines, i)
                html_parts.append(block)
                i += consumed
                continue

            # Tables
            if line.strip().startswith("|"):
                block, consumed = self._parse_table(lines, i)
                html_parts.append(block)
                i += consumed
                continue

            # A bare ! is text, not a heading.  Do not spin forever when a
            # nonempty line looks like a block opener but parses as no block.
            if line.lstrip().startswith('!') and not heading_match:
                html_parts.append(f"<p>{self._render_inline(line)}</p>")
                i += 1
                continue

            # Regular paragraph
            if line.strip():
                para, consumed = self._parse_paragraph(lines, i)
                html_parts.append(para)
                i += consumed
            else:
                i += 1

        return "\n".join(html_parts)

    # --- Block parsers ---

    def _parse_fenced_code(self, lines: list[str], start: int) -> tuple[str, int]:
        """Parse ``` fenced code block."""
        first_line = lines[start].strip()
        # Extract language hint if present
        lang = first_line[3:].strip()

        code_lines = []
        i = start + 1
        while i < len(lines):
            if lines[i].strip() == "```":
                i += 1
                break
            code_lines.append(lines[i])
            i += 1

        code = html.escape("\n".join(code_lines))
        lang_attr = f' class="language-{html.escape(lang)}"' if lang else ""
        return f"<pre><code{lang_attr}>{code}</code></pre>", i - start

    def _parse_tw_code(self, lines: list[str], start: int) -> tuple[str, int]:
        """Parse {{{ ... }}} TW-style code block."""
        first_line = lines[start].strip()

        # Single-line case: {{{ code }}}
        if first_line.endswith("}}}") and len(first_line) > 6:
            code = html.escape(first_line[3:-3].strip())
            return f"<pre><code>{code}</code></pre>", 1

        # Multi-line
        code_lines = []
        # Content after {{{ on first line
        after_open = first_line[3:].strip()
        if after_open:
            code_lines.append(after_open)

        i = start + 1
        while i < len(lines):
            line = lines[i]
            if line.strip().endswith("}}}"):
                before_close = line.strip()[:-3].strip()
                if before_close:
                    code_lines.append(before_close)
                i += 1
                break
            code_lines.append(line)
            i += 1

        code = html.escape("\n".join(code_lines))
        return f"<pre><code>{code}</code></pre>", i - start

    def _parse_list(self, lines: list[str], start: int) -> tuple[str, int]:
        """Parse nested ordered/unordered lists."""
        items = []
        i = start

        while i < len(lines):
            line = lines[i]
            match = re.match(r"^([*#]+)\s*(.*)$", line)
            if not match:
                break
            marker = match.group(1)
            content = self._render_inline(match.group(2))
            items.append((marker, content))
            i += 1

        # Build nested list structure
        html_out = self._build_nested_list(items)
        return html_out, i - start

    def _build_nested_list(self, items: list[tuple[str, str]]) -> str:
        """Build HTML for nested list from (marker, content) pairs."""
        if not items:
            return ""

        result = []
        stack = []  # Stack of (marker_prefix, tag_type)

        for marker, content in items:
            depth = len(marker)
            list_type = "ol" if marker[-1] == "#" else "ul"

            # Close lists that are deeper than current
            while stack and len(stack) > depth:
                _, prev_type = stack.pop()
                result.append(f"</li></{prev_type}>")

            # Close list if same depth but different type
            while stack and len(stack) == depth:
                _, prev_type = stack[-1]
                if prev_type != list_type:
                    stack.pop()
                    result.append(f"</li></{prev_type}>")
                else:
                    # Same type, just close the li
                    result.append("</li>")
                    break

            # Open new lists to reach current depth
            while len(stack) < depth:
                lt = "ol" if marker[len(stack)] == "#" else "ul"
                result.append(f"<{lt}>")
                stack.append((marker[: len(stack) + 1], lt))

            result.append(f"<li>{content}")

        # Close remaining
        while stack:
            _, prev_type = stack.pop()
            result.append(f"</li></{prev_type}>")

        return "".join(result)

    def _parse_table(self, lines: list[str], start: int) -> tuple[str, int]:
        """Parse TW table syntax."""
        rows = []
        caption = None
        table_class = None
        header_rows = []
        footer_rows = []
        body_rows = []
        i = start

        while i < len(lines):
            line = lines[i].strip()
            if not line.startswith("|"):
                break

            # Check for pseudo-row markers at end
            if line.endswith("|c"):
                # Caption
                caption = self._extract_cells(line[:-2])[0] if line[:-2].strip("|") else None
                i += 1
                continue
            elif line.endswith("|k"):
                # Class
                table_class = self._extract_cells(line[:-2])[0] if line[:-2].strip("|") else None
                i += 1
                continue
            elif line.endswith("|h"):
                # Header row
                cells = self._extract_cells(line[:-2])
                header_rows.append(cells)
                i += 1
                continue
            elif line.endswith("|f"):
                # Footer row
                cells = self._extract_cells(line[:-2])
                footer_rows.append(cells)
                i += 1
                continue

            # Regular row
            cells = self._extract_cells(line)
            body_rows.append(cells)
            i += 1

        # Build HTML
        class_attr = f' class="{html.escape(table_class)}"' if table_class else ""
        parts = [f"<table{class_attr}>"]

        if caption:
            parts.append(f"<caption>{self._render_inline(caption)}</caption>")

        if header_rows:
            parts.append("<thead>")
            for row in header_rows:
                parts.append(self._render_table_row(row, is_header=True))
            parts.append("</thead>")

        if body_rows:
            parts.append("<tbody>")
            for row in body_rows:
                parts.append(self._render_table_row(row))
            parts.append("</tbody>")

        if footer_rows:
            parts.append("<tfoot>")
            for row in footer_rows:
                parts.append(self._render_table_row(row))
            parts.append("</tfoot>")

        parts.append("</table>")
        return "\n".join(parts), i - start

    def _extract_cells(self, line: str) -> list[str]:
        """Extract cells from a table row like |a|b|c|"""
        # Remove leading/trailing |
        line = line.strip("|")
        return line.split("|")

    def _render_table_row(self, cells: list[str], is_header: bool = False) -> str:
        """Render a table row."""
        parts = ["<tr>"]
        for cell in cells:
            cell = cell.strip()
            # Check for header cell marker !
            if cell.startswith("!"):
                tag = "th"
                cell = cell[1:].strip()
            elif is_header:
                tag = "th"
            else:
                tag = "td"

            # Skip merge markers (just render as empty)
            if cell in ("~", ">", "<", "^"):
                cell = ""

            content = self._render_inline(cell)
            parts.append(f"<{tag}>{content}</{tag}>")
        parts.append("</tr>")
        return "".join(parts)

    def _parse_paragraph(self, lines: list[str], start: int) -> tuple[str, int]:
        """Parse a paragraph (consecutive non-empty, non-block lines)."""
        para_lines = []
        i = start

        while i < len(lines):
            line = lines[i]

            # End paragraph on empty line
            if not line.strip():
                break

            # End on block-level elements
            if (
                line.strip().startswith("!")
                or line.strip().startswith("----")
                or line.strip().startswith("```")
                or line.strip().startswith("{{{")
                or line.strip().startswith("|")
                or (line and line[0] in "*#")
            ):
                break

            para_lines.append(line)
            i += 1

        if i == start:  # defensive forward progress on an unrecognized block
            return f"<p>{self._render_inline(lines[start])}</p>", 1
        content = self._render_inline(" ".join(para_lines))
        return f"<p>{content}</p>", i - start

    # --- Inline rendering ---

    def _render_inline(self, text: str) -> str:
        """Apply inline formatting to text."""
        # Process patterns first, then escape remaining text
        # Use placeholder tokens to protect already-processed HTML
        tokens = []

        def tokenize(match_html: str) -> str:
            idx = len(tokens)
            tokens.append(match_html)
            return f"\x00{idx}\x00"

        # Process inline code first (to protect code content)
        text = re.sub(r"`([^`]+)`", lambda m: tokenize(f"<code>{html.escape(m.group(1))}</code>"), text)

        # Bold
        text = re.sub(r"''(.+?)''", lambda m: tokenize(f"<strong>{self._render_inline_inner(m.group(1), tokens, tokenize)}</strong>"), text)

        # Italic
        text = re.sub(r"//(.+?)//", lambda m: tokenize(f"<em>{self._render_inline_inner(m.group(1), tokens, tokenize)}</em>"), text)

        # Links: [[Caption|Title]] or [[Title]]
        text = re.sub(
            r"\[\[([^\]|]+)\|([^\]]+)\]\]",
            # Both link forms go through _make_link, so the captioned form
            # cannot drift from the plain one. It used to build its href
            # inline, which is how it came to mis-handle external URLs and,
            # once Phase 2 added the syntax, namespace prefixes.
            lambda m: tokenize(self._make_link(m.group(2), m.group(1))),
            text
        )
        text = re.sub(
            r"\[\[([^\]]+)\]\]",
            lambda m: tokenize(self._make_link(m.group(1))),
            text
        )

        # Escape remaining text
        text = html.escape(text)

        # Restore tokens
        for i, token in enumerate(tokens):
            text = text.replace(f"\x00{i}\x00", token)

        return text

    def _render_inline_inner(self, text: str, tokens: list, tokenize) -> str:
        """Render inline for nested content (already inside bold/italic)."""
        # Handle nested inline code
        text = re.sub(r"`([^`]+)`", lambda m: tokenize(f"<code>{html.escape(m.group(1))}</code>"), text)
        return html.escape(text)

    def _make_link(self, target: str, caption: Optional[str] = None) -> str:
        """Render one link target, agreeing with links.split_target by construction.

        Three outcomes, because the parser has three:

        * an external URL -- an ordinary external link, unchanged;
        * a local reference -- `tw://tiddler/<title>` where <title> is the
          PARSED title. Rendering the raw target made the leading-colon escape
          silently wrong: `[[:notes:x]]` produced a link to a post titled
          `:notes:x` rather than to `notes:x`;
        * a cross-namespace reference -- deliberately NOT a link. This view
          resolves one notebook, so `tw://tiddler/monograph%3AGamma` would be a
          link to a local post titled `monograph:Gamma`: a false statement
          dressed as a working link, which lands the reader on a
          missing-post page and blames the wrong thing. A marked non-link is
          true. Phase 3 gives the UI a namespace-aware URL and this becomes a
          real link; until then it says what it is.
        """
        parsed = split_target(target)
        label = html.escape(caption if caption is not None else target)
        if parsed is None:
            return (f'<a href="{html.escape(target)}" target="_blank">'
                    f'{label}</a>')
        namespace, title = parsed
        if namespace is not None:
            return ('<span class="xref" title="In another namespace: '
                    f'{html.escape(namespace)}">{label}</span>')
        return f'<a href="tw://tiddler/{quote(title, safe="")}">{label}</a>'


def render_tiddler(tiddler: dict) -> str:
    """Render a tiddler dict to full HTML document."""
    renderer = TiddlyRenderer()
    title = html.escape(tiddler.get("title", "Untitled"))
    text = tiddler.get("text", "")
    tags = tiddler.get("tags", [])
    modified = tiddler.get("modified", "")

    body = renderer.render(text)

    # Format tags
    tags_html = ""
    if tags:
        tag_links = " ".join(
            f'<span class="tag">{html.escape(t)}</span>' for t in tags
        )
        tags_html = f'<div class="tags">{tag_links}</div>'

    # Format modified date
    meta_html = ""
    if modified:
        # TW dates are like 20231215120000000
        if len(modified) >= 8:
            formatted = f"{modified[:4]}-{modified[4:6]}-{modified[6:8]}"
            meta_html = f'<div class="meta">Modified: {formatted}</div>'

    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'; object-src 'none'">
<style>
body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    line-height: 1.6;
    color: #333;
    background: #fff;
}}
h1 {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }}
h2, h3, h4, h5, h6 {{ color: #34495e; margin-top: 1.5em; }}
a {{ color: #3498db; text-decoration: none; }}
a:hover {{ text-decoration: underline; }}
pre {{
    background: #f4f4f4;
    padding: 15px;
    border-radius: 5px;
    overflow-x: auto;
    border-left: 3px solid #3498db;
}}
code {{
    background: #f4f4f4;
    padding: 2px 6px;
    border-radius: 3px;
    font-family: "SF Mono", Monaco, "Courier New", monospace;
}}
pre code {{ background: none; padding: 0; }}
table {{
    border-collapse: collapse;
    width: 100%;
    margin: 1em 0;
}}
th, td {{
    border: 1px solid #ddd;
    padding: 8px 12px;
    text-align: left;
}}
th {{ background: #f8f9fa; font-weight: 600; }}
tr:nth-child(even) {{ background: #f8f9fa; }}
hr {{ border: none; border-top: 2px solid #eee; margin: 2em 0; }}
.xref {{
  border-bottom: 1px dotted currentColor; opacity: 0.75; cursor: help;
}}
.tags {{ margin: 10px 0; }}
.tag {{
    display: inline-block;
    background: #e8f4f8;
    color: #2980b9;
    padding: 2px 8px;
    border-radius: 3px;
    margin-right: 5px;
    font-size: 0.85em;
}}
.meta {{ color: #888; font-size: 0.85em; margin-bottom: 1em; }}
blockquote {{
    border-left: 4px solid #3498db;
    margin: 1em 0;
    padding-left: 1em;
    color: #666;
}}
</style>
</head>
<body>
<h1>{title}</h1>
{tags_html}
{meta_html}
<div class="content">
{body}
</div>
</body>
</html>"""
