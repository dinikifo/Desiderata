"""Reliable TiddlyWiki-compatible SQLite storage (portable JSON is canonical).

Compatibility: TiddlerDB public methods of the supplied PERSONAL.WIKI application.
Round-trip preservation: original JSON dictionaries, including tags representation and
unknown fields, survive unedited imports/exports. This does not implement TW runtime.
"""
from __future__ import annotations
from contextlib import closing
import hashlib
import json
import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from .schema_migrations import TARGET_VERSION, SchemaCompatibilityError, inspect_connection, _connect_existing


class SearchUnavailable(RuntimeError):
    """The search could not be performed -- which is not the same as no matches.

    Raised instead of returning an empty list, so a caller cannot mistake a
    locked or damaged index for an empty result set.
    """

SCHEMA = """
CREATE TABLE IF NOT EXISTS tiddlers (
  title TEXT PRIMARY KEY, text TEXT NOT NULL DEFAULT '', created TEXT,
  modified TEXT, tags_json TEXT NOT NULL DEFAULT '[]',
  fields_json TEXT NOT NULL DEFAULT '{}', raw_json TEXT
);
CREATE TABLE IF NOT EXISTS tiddler_tags (
  title TEXT NOT NULL, tag TEXT NOT NULL,
  PRIMARY KEY(title, tag),
  FOREIGN KEY(title) REFERENCES tiddlers(title) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tiddler_tags_tag ON tiddler_tags(tag);
CREATE TABLE IF NOT EXISTS protected_titles (
  title TEXT PRIMARY KEY, record_sha256 TEXT NOT NULL,
  FOREIGN KEY(title) REFERENCES tiddlers(title) ON DELETE RESTRICT
);
CREATE VIRTUAL TABLE IF NOT EXISTS tiddlers_fts USING fts5(
  title, text, content='tiddlers', content_rowid='rowid'
);
CREATE TRIGGER IF NOT EXISTS tiddlers_ai AFTER INSERT ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(rowid,title,text) VALUES (new.rowid,new.title,new.text);
END;
CREATE TRIGGER IF NOT EXISTS tiddlers_ad AFTER DELETE ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(tiddlers_fts,rowid,title,text)
  VALUES ('delete',old.rowid,old.title,old.text);
END;
CREATE TRIGGER IF NOT EXISTS tiddlers_au AFTER UPDATE ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(tiddlers_fts,rowid,title,text)
  VALUES ('delete',old.rowid,old.title,old.text);
  INSERT INTO tiddlers_fts(rowid,title,text)
  VALUES (new.rowid,new.title,new.text);
END;
"""

def parse_tags(value) -> list[str]:
    if value is None: return []
    if isinstance(value,list):
        return [v for v in value if isinstance(v,str)]
    if not isinstance(value,str): raise ValueError('tags must be list or string')
    result=[]; i=0
    while i < len(value):
        if value[i].isspace():i+=1;continue
        if value.startswith('[[',i):
            end=value.find(']]',i+2)
            if end!=-1:result.append(value[i+2:end]);i=end+2;continue
        end=i+1
        while end<len(value) and not value[end].isspace():end+=1
        result.append(value[i:end]);i=end
    return result

def encode_tags(tags:list[str]) -> str:
    return ' '.join(f'[[{t}]]' if any(c.isspace() for c in t) else t for t in tags)

def _valid_record(record: dict) -> dict:
    if not isinstance(record,dict) or not isinstance(record.get('title'),str) or not record['title']:
        raise ValueError('Every tiddler must be an object with a nonempty string title')
    for field in ('text','created','modified'):
        if field in record and not isinstance(record[field],str):
            raise ValueError(f'{record["title"]}: {field} must be text')
    parse_tags(record.get('tags',[]))
    return record

def _utc_stamp():return datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')[:17]

def _publish_temp(tmp: str, path: Path, overwrite: bool) -> None:
    # Hard-link publication is an atomic create-if-absent on local APFS/ext4.
    # Never turn 'no overwrite' into a check-then-replace race.
    if overwrite:
        os.replace(tmp, path)
    else:
        try:
            os.link(tmp, path)  # raises FileExistsError if a concurrent writer won
        except FileExistsError:
            raise
        except OSError as exc:
            # Hard links are unavailable on exFAT/FAT32 -- a USB stick is a
            # plausible home for a portable notebook. The generic OSError says
            # nothing about the real cause, so name it rather than leaving the
            # user to guess. Refusing is deliberate: the alternative is an
            # open(O_CREAT|O_EXCL)+copy fallback whose crash window this
            # function exists to avoid.
            raise OSError(
                f'Cannot publish {path.name} atomically: the destination '
                f'filesystem does not support hard links ({exc.strerror}). '
                'exFAT and FAT32 cannot do this; use a local ext4/APFS/NTFS '
                'disk for an active notebook.') from exc
        os.unlink(tmp)
    if hasattr(os, 'O_DIRECTORY'):
        dfd = os.open(str(path.parent), os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(dfd)
        finally: os.close(dfd)


def _write_atomic(path:Path, content: bytes, overwrite:bool=False) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() and not overwrite:raise FileExistsError(f'Refusing to replace {path}')
    fd, tmp=tempfile.mkstemp(prefix='.'+path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(content);f.flush();os.fsync(f.fileno())
        _publish_temp(tmp,path,overwrite)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def create_new_database(path: str) -> None:
    """Create a fresh v2 database without overwriting an existing file.

    Build and validate the DB in a private directory on the destination's
    filesystem, close/checkpoint its WAL, then publish with atomic no-clobber
    hard-link. A failed create cannot leave a half-initialized destination.
    """
    destination = Path(path)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f'Database already exists; refusing to replace: {destination}')
    if not destination.parent.is_dir():
        raise FileNotFoundError(f'Database destination folder does not exist: {destination.parent}')
    with tempfile.TemporaryDirectory(prefix='.pw_new_db_', dir=destination.parent) as folder:
        staging = Path(folder) / 'fresh.db'
        with TiddlerDB(str(staging)) as fresh:
            report = fresh.integrity_report()
            if (report['integrity'] != 'ok' or report['foreign_key_violations']
                    or not report['fts_matches'] or report['records'] != 0):
                raise ValueError(f'Fresh database failed validation: {report}')
        # A user-selected location can have permissive parent permissions.
        # Restrict the database file itself on POSIX before publishing it.
        if os.name == 'posix':
            os.chmod(staging, 0o600)
        # The connection is closed and the WAL checkpointed before publication.
        _publish_temp(str(staging), destination, overwrite=False)


class TiddlerDB:
    def __init__(self,db_path:str='tiddlers.db',readonly:bool=False, journal_mode:str='WAL'):
        self.db_path=str(db_path);self.readonly=readonly
        if journal_mode not in ('WAL','DELETE'):
            raise ValueError('Unsupported journal mode')
        path=Path(db_path)
        new=not path.exists()
        if not new:
            # The compatibility gate is deliberately before *any* writable
            # connection, journal-mode switch or implicit DDL execution.
            with closing(_connect_existing(path)) as probe:
                status=inspect_connection(probe)
            if status['schema_version'] != TARGET_VERSION and not (readonly and status['schema_version'] == 0 and
                    status['readable_v2_layout']):
                raise SchemaCompatibilityError(
                    f'Existing database is schema v{status["schema_version"]}; '
                    f'requires an EXPLICIT side-by-side migration to v{TARGET_VERSION}. '
                    'Use: python3 app/schema_migrations.py plan SOURCE; '
                    'python3 app/schema_migrations.py migrate SOURCE NEW_DESTINATION')
            if not readonly:
                # An existing DB must pass the preservation audit BEFORE a
                # writable connection, WAL switch, or any implicit mutation.
                with TiddlerDB(str(path), readonly=True) as audit:
                    protected = audit.protection_report()
                    if protected['violation_count']:
                        raise SchemaCompatibilityError(
                            f'Protected records inconsistent; writable open refused: {protected["violations"]}')
        elif readonly:
            raise FileNotFoundError(str(path))
        if readonly:
            self.conn=_connect_existing(path)
        else:
            self.conn=sqlite3.connect(db_path,timeout=15) if new else _connect_existing(path,readonly=False)
        try:
            self.conn.row_factory=sqlite3.Row
            self.conn.execute('PRAGMA busy_timeout=15000')
            self.conn.execute('PRAGMA foreign_keys=ON')
            if not readonly:
                if not new:
                    # Re-check on the actual writable handle (not just its
                    # read-only preflight), before changing journal settings.
                    live = inspect_connection(self.conn)
                    if live['schema_version'] != TARGET_VERSION:
                        raise SchemaCompatibilityError('Schema version changed during open; refusing write')
                if new:
                    # New empty workspace creation is NOT an upgrade of old data.
                    self.conn.executescript(SCHEMA)
                    self.conn.execute(f'PRAGMA user_version={TARGET_VERSION}')
                    self.conn.commit()
                if not new:
                    # Recheck on the actual handle to narrow the time-of-check
                    # race with independent writers before journal changes.
                    protected = self.protection_report()
                    if protected['violation_count']:
                        raise SchemaCompatibilityError(
                            f'Protected records changed during open: {protected["violations"]}')
                actual=self.conn.execute(f'PRAGMA journal_mode={journal_mode}').fetchone()[0]
                if actual.lower()!=journal_mode.lower():
                    raise sqlite3.OperationalError('Cannot set required SQLite journal mode')
                self.conn.execute('PRAGMA synchronous='+('EXTRA' if journal_mode=='DELETE' else 'FULL'))
                if not self._check_fts_integrity():
                    raise SchemaCompatibilityError('FTS external-content integrity check failed; original left unmodified')
        except BaseException:
            self.conn.close()
            raise

    def _check_fts_integrity(self) -> Optional[bool]:
        """True = index consistent, False = inconsistent, **None = not checked**.

        The three states are not interchangeable and the None was previously
        declared and never produced: every failure, including a full temp disk,
        was reported as an inconsistent index. That turned an environment
        problem into a corruption report and refused healthy notebooks.

        The split used below is SQLite's own: a corrupt FTS index surfaces as
        ``sqlite3.DatabaseError`` (SQLITE_CORRUPT), while "locked", "disk full"
        and friends surface as ``sqlite3.OperationalError``. The latter say
        nothing about the index, so they yield None. An OSError from staging is
        likewise an environment failure, not a verdict.
        """
        # FTS5's external-content integrity-check is a write-style command.
        # In readonly mode, execute it against a PRIVATE online SQLite snapshot:
        # never attempt a write or a journal-mode change on the source database.
        if self.readonly:
            # Stage on the DESTINATION filesystem, which already holds a
            # database this size. The system temp directory may be a small
            # tmpfs -- on a Raspberry Pi it routinely is -- and this was the
            # only one of five TemporaryDirectory call sites not pinned.
            try:
                staging = tempfile.TemporaryDirectory(
                    prefix='.pw_fts_readonly_', dir=Path(self.db_path).resolve().parent)
            except OSError:
                return None
            try:
                with staging as folder:
                    with closing(sqlite3.connect(str(Path(folder) / 'validation.db'))) as copy:
                        try:
                            self.conn.backup(copy, pages=256, sleep=0.01)
                        except (sqlite3.OperationalError, OSError):
                            return None          # could not take the snapshot
                        try:
                            copy.execute("INSERT INTO tiddlers_fts(tiddlers_fts,rank) "
                                         "VALUES('integrity-check',1)")
                        except sqlite3.OperationalError:
                            return None          # check could not run
                        except sqlite3.DatabaseError:
                            return False         # the index really is bad
                return True
            except OSError:
                return None
        # The FTS5 command is syntactically an INSERT. Python's sqlite3 opens
        # an implicit transaction for it, even when it only checks integrity.
        # Leaving that transaction open holds the SQLite writer lock, making
        # the GUI's separate JSON-import worker fail with "database is locked".
        # Roll back ONLY the transaction initiated by this check. Never end a
        # transaction already belonging to the caller.
        was_in_transaction = self.conn.in_transaction
        try:
            self.conn.execute("INSERT INTO tiddlers_fts(tiddlers_fts,rank) VALUES('integrity-check',1)")
            return True
        except sqlite3.OperationalError:
            return None             # locked, full: the index is not implicated
        except sqlite3.DatabaseError:
            return False
        finally:
            if not was_in_transaction and self.conn.in_transaction:
                self.conn.rollback()

    def close(self):self.conn.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

    def _store(self,t:dict):
        t=_valid_record(t);title=t['title'];tags=parse_tags(t.get('tags',[]))
        fields={k:v for k,v in t.items() if k not in {'title','text','created','modified','tags'}}
        self.conn.execute('''INSERT INTO tiddlers
          (title,text,created,modified,tags_json,fields_json,raw_json)
          VALUES (?,?,?,?,?,?,?)
          ON CONFLICT(title) DO UPDATE SET text=excluded.text,created=excluded.created,
          modified=excluded.modified,tags_json=excluded.tags_json,
          fields_json=excluded.fields_json,raw_json=excluded.raw_json''',
          (title,t.get('text',''),t.get('created'),t.get('modified'),
           json.dumps(tags,ensure_ascii=False),json.dumps(fields,ensure_ascii=False),
           json.dumps(t,ensure_ascii=False,separators=(',',':'))))
        self.conn.execute('DELETE FROM tiddler_tags WHERE title=?',(title,))
        self.conn.executemany('INSERT INTO tiddler_tags(title,tag) VALUES (?,?)',
                              ((title,tag) for tag in dict.fromkeys(tags)))

    def import_json(self,json_path:str,on_conflict:str='reject',protect_imported:bool=False)->int:
        """Atomic import; reject differing titles by default; allow 'overwrite' explicitly.
        Returns number of new or changed records (identical records are skipped).
        """
        if self.readonly:raise PermissionError('Read-only database')
        if on_conflict not in ('reject','overwrite'):raise ValueError('Unknown conflict policy')
        with open(json_path,'r',encoding='utf-8') as f:payload=json.load(f)
        if not isinstance(payload,list):raise ValueError('Expected JSON array')
        seen=set()
        for t in payload:
            _valid_record(t)
            if t['title'] in seen:raise ValueError('Duplicate source title '+t['title'])
            seen.add(t['title'])
        changed=0
        with self.conn:
            for t in payload:
                existing=self._get_raw(t['title'])
                if existing == t:
                    if protect_imported:self._protect(t)
                    continue
                if existing is not None and self.is_protected(t['title']):
                    raise PermissionError(f'Protected historical record {t["title"]!r}; import rolled back')
                if existing is not None and on_conflict=='reject':
                    raise ValueError(f'Conflict for {t["title"]!r}: import rolled back')
                self._store(t)
                if protect_imported:self._protect(t)
                changed+=1
        return changed

    def _protect(self,t:dict):
        digest=hashlib.sha256(json.dumps(t,ensure_ascii=False,sort_keys=True,
                    separators=(',',':')).encode('utf-8')).hexdigest()
        row=self.conn.execute('SELECT record_sha256 FROM protected_titles WHERE title=?',
                              (t['title'],)).fetchone()
        if row is not None and row[0]!=digest:
            raise PermissionError('Preserved evidence hash mismatch: '+t['title'])
        self.conn.execute('INSERT OR IGNORE INTO protected_titles VALUES(?,?)',(t['title'],digest))

    def protect_all_current(self):
        if self.readonly:raise PermissionError('Read-only database')
        with self.conn:
            for (title,) in self.conn.execute('SELECT title FROM tiddlers'):
                self._protect(self._get_raw(title))

    def is_protected(self,title:str)->bool:
        return self.conn.execute('SELECT 1 FROM protected_titles WHERE title=?',(title,)).fetchone() is not None

    def protection_report(self):
        # A raw_json digest alone misses changes to the normalized columns
        # that the search and filter interfaces actually use. Check all three
        # representations: immutable source object, row projection, tag index.
        count=0;violations=[]
        for title,digest in self.conn.execute('SELECT title,record_sha256 FROM protected_titles'):
            row=self.conn.execute("""SELECT title,text,created,modified,tags_json,fields_json,raw_json
                                     FROM tiddlers WHERE title=?""",(title,)).fetchone()
            if row is None:
                violations.append(title+': absent'); continue
            try:
                t=self._get_raw(title)
                got=hashlib.sha256(json.dumps(t,ensure_ascii=False,sort_keys=True,
                            separators=(',',':')).encode('utf-8')).hexdigest()
                if got!=digest:violations.append(title+': source hash mismatch')
                tags=parse_tags(t.get('tags',[]))
                fields={k:v for k,v in t.items() if k not in {'title','text','created','modified','tags'}}
                normalized=(row['title']==t['title'] and
                     row['text']==t.get('text','') and
                     row['created']==t.get('created') and
                     row['modified']==t.get('modified') and
                     json.loads(row['tags_json'])==tags and
                     json.loads(row['fields_json'])==fields)
                if not normalized:violations.append(title+': normalized row inconsistent with original')
                found={r[0] for r in self.conn.execute('SELECT tag FROM tiddler_tags WHERE title=?',(title,))}
                if found!=set(tags):violations.append(title+': tag index inconsistent')
            except (ValueError,KeyError,TypeError,json.JSONDecodeError) as exc:
                violations.append(title+': unparsable record: '+str(exc)[:100])
            count+=1
        return {'protected_records':count,'violations':violations[:20],
                'violation_count':len(violations)}

    def _get_raw(self,title:str)->Optional[dict]:
        row=self.conn.execute('''SELECT title,text,created,modified,tags_json,fields_json,raw_json
                                  FROM tiddlers WHERE title=?''',(title,)).fetchone()
        if not row:return None
        if row['raw_json'] is not None:return json.loads(row['raw_json'])
        d={'title':row['title'],'text':row['text']}
        if row['created'] is not None:d['created']=row['created']
        if row['modified'] is not None:d['modified']=row['modified']
        tags=json.loads(row['tags_json'])
        if tags:d['tags']=encode_tags(tags)
        d.update(json.loads(row['fields_json']))
        return d

    def get_tiddler(self,title:str)->Optional[dict]:
        raw=self._get_raw(title)
        if raw is None:return None
        return dict(raw,title=title,text=raw.get('text',''),
                    tags=parse_tags(raw.get('tags',[])),
                    fields={k:v for k,v in raw.items() if k not in {'title','text','tags','created','modified'}})

    def save_tiddler(self,title:str,text:str,tags:list[str],fields:Optional[dict]=None,
                     created:Optional[str]=None)->None:
        if self.readonly:raise PermissionError('Read-only database')
        if self.is_protected(title):raise PermissionError('Historical source is protected; create a new title or versioned note')
        existing=self._get_raw(title)
        t=dict(existing) if existing else {'title':title}
        t.update(fields or {})
        t['title']=title;t['text']=text
        # Preserve original tag field representation on edit.
        t['tags']=encode_tags(tags) if isinstance(t.get('tags'),str) else list(tags)
        t['created']=created or t.get('created') or _utc_stamp()
        t['modified']=_utc_stamp()
        with self.conn:self._store(t)

    def update_tiddler(self,old_title:str,new_title:str,text:str,tags:list[str])->bool:
        """Edit, including a rename, in one all-or-nothing SQLite transaction."""
        if self.readonly:raise PermissionError('Read-only database')
        if not new_title:raise ValueError('Title required')
        with self.conn:
            original=self._get_raw(old_title)
            if original is None:return False
            if self.is_protected(old_title):raise PermissionError('Cannot edit protected historical record')
            if old_title!=new_title and self._get_raw(new_title) is not None:
                raise ValueError('Destination title already exists')
            original['title']=new_title
            original['text']=text
            original['tags']=encode_tags(tags) if isinstance(original.get('tags'),str) else list(tags)
            original['modified']=_utc_stamp()
            if old_title!=new_title:
                self.conn.execute('DELETE FROM tiddlers WHERE title=?',(old_title,))
            self._store(original)
        return True

    def delete_tiddler(self,title:str)->bool:
        if self.readonly:raise PermissionError('Read-only database')
        if self.is_protected(title):raise PermissionError('Cannot delete protected historical record')
        with self.conn:r=self.conn.execute('DELETE FROM tiddlers WHERE title=?',(title,))
        return r.rowcount>0

    def rename_tiddler(self,old_title:str,new_title:str)->bool:
        if self.readonly:raise PermissionError('Read-only database')
        if old_title==new_title:return self._get_raw(old_title) is not None
        if self.is_protected(old_title):raise PermissionError('Cannot rename protected historical record')
        with self.conn:
            old=self._get_raw(old_title)
            if old is None or self._get_raw(new_title) is not None:return False
            old['title']=new_title;old['modified']=_utc_stamp()
            self._store(old)
            self.conn.execute('DELETE FROM tiddlers WHERE title=?',(old_title,))
        return True

    def search_title(self,query:str,limit:int=200,offset:int=0)->list[str]:
        # INSTR avoids LIKE wildcard interpretation and uses predictable case folding.
        return [r[0] for r in self.conn.execute('''SELECT title FROM tiddlers
                    WHERE instr(lower(title),lower(?))>0 ORDER BY title LIMIT ? OFFSET ?''',
                    (query,limit,offset))]
    def search_text(self,query:str,limit:int=200,offset:int=0)->list[str]:
        """Full-text search. Raises SearchUnavailable if the search cannot run.

        It previously returned [] on any OperationalError, so a locked or
        corrupt index was indistinguishable from "no matches" -- a user could
        search for a post they had written, see nothing, and conclude the
        content was gone. Every term is quoted below, so a malformed MATCH
        expression cannot arise from user input; an error here is the index or
        the environment, and the caller is entitled to know the difference.
        """
        query=query.strip()
        if not query:return []
        terms=[t for t in query.split() if t]
        match=' AND '.join('"'+t.replace('"','""')+'"' for t in terms)
        try:
            return [r[0] for r in self.conn.execute('''SELECT title FROM tiddlers_fts
                         WHERE tiddlers_fts MATCH ? ORDER BY rank LIMIT ? OFFSET ?''',
                         (match,limit,offset))]
        except sqlite3.DatabaseError as exc:
            raise SearchUnavailable(
                f'Full-text search could not be completed: {exc}. The search '
                'index may be locked by another process or damaged; File -> '
                'Verify Post History and reopening the notebook will say '
                'which. This is NOT a result of zero matches.') from exc
    def search_tag(self,tag:str,limit:int=200,offset:int=0)->list[str]:
        return [r[0] for r in self.conn.execute('''SELECT title FROM tiddler_tags
                      WHERE tag=? ORDER BY title LIMIT ? OFFSET ?''',(tag,limit,offset))]
    def filtered_title_links(self, expression:str, limit:int=500)->list[str]:
        # Deliberately small supported subset of TiddlyWiki filter syntax.
        import re
        match=re.fullmatch(r'\[tag\[([^\]]+)\]field:([a-zA-Z0-9_-]+)\[([^\]]+)\]sort\[([a-zA-Z0-9_-]+)\]\]',expression)
        if not match:return []
        tag,field,value,sort=match.groups()
        path='$.'+json.dumps(field)
        sortpath='$.'+json.dumps(sort)
        rows=self.conn.execute('SELECT t.title FROM tiddlers t JOIN tiddler_tags g ON g.title=t.title '
           'WHERE g.tag=? AND json_extract(t.fields_json,?)=? '
           'ORDER BY json_extract(t.fields_json,?),t.title LIMIT ?',
           (tag,path,value,sortpath,limit))
        return [x[0] for x in rows]

    def all_tags(self)->list[str]:
        return [r[0] for r in self.conn.execute('SELECT DISTINCT tag FROM tiddler_tags ORDER BY tag')]
    def all_titles(self,limit:int=200,offset:int=0)->list[str]:
        return [r[0] for r in self.conn.execute('SELECT title FROM tiddlers ORDER BY title LIMIT ? OFFSET ?',
                                               (limit,offset))]
    def count(self):return self.conn.execute('SELECT COUNT(*) FROM tiddlers').fetchone()[0]
    def integrity_report(self)->dict:
        integrity=self.conn.execute('PRAGMA integrity_check').fetchone()[0]
        fk=self.conn.execute('PRAGMA foreign_key_check').fetchall()
        fts=self.conn.execute('SELECT COUNT(*) FROM tiddlers_fts').fetchone()[0]
        fts_integrity=self._check_fts_integrity()
        total=self.count()
        # `fts_matches` keeps its exact prior meaning -- "definitely consistent"
        # -- so every existing caller that refuses when it is false keeps
        # behaving as before. `fts_status` is the three-valued answer:
        #   'ok'           the row counts agree and the index verified
        #   'inconsistent' counts disagree, or the index failed its check
        #   'unknown'      the check could not be run (see _check_fts_integrity)
        if fts_integrity is None:
            fts_status='unknown'
        elif fts_integrity and fts==total:
            fts_status='ok'
        else:
            fts_status='inconsistent'
        return {'integrity':integrity,'foreign_key_violations':len(fk),
                'records':total,'fts_records':fts,'fts_matches':fts==total and fts_integrity is True,
                'fts_integrity':fts_integrity,'fts_status':fts_status}
    def rebuild_search(self):
        if self.readonly:raise PermissionError('Read-only database')
        with self.conn:self.conn.execute("INSERT INTO tiddlers_fts(tiddlers_fts) VALUES('rebuild')")

    def export_json(self,json_path:str,overwrite:bool=False)->int:
        # SQLite read transaction gives a consistent view even under concurrent writes.
        self.conn.execute('BEGIN')
        try:
            rows=self.conn.execute('''SELECT title,text,created,modified,tags_json,fields_json,raw_json
                            FROM tiddlers ORDER BY title''').fetchall()
            docs=[]
            for r in rows:
                if r['raw_json'] is not None:docs.append(json.loads(r['raw_json']))
                else:
                    d={'title':r['title'],'text':r['text']}
                    if r['created'] is not None:d['created']=r['created']
                    if r['modified'] is not None:d['modified']=r['modified']
                    tags=json.loads(r['tags_json'])
                    if tags:d['tags']=encode_tags(tags)
                    d.update(json.loads(r['fields_json']));docs.append(d)
        finally:self.conn.rollback()  # release read transaction (never changes data)
        data=json.dumps(docs,ensure_ascii=False,indent=2).encode('utf-8')
        _write_atomic(Path(json_path),data,overwrite=overwrite)
        return len(docs)

    def snapshot(self,path:str,overwrite:bool=False)->dict:
        """Consistent online SQLite backup, including WAL changes, with atomic rename."""
        if self.readonly:raise PermissionError('Read-only database')
        p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists() and not overwrite:raise FileExistsError(str(p))
        fd,tmp=tempfile.mkstemp(prefix='.'+p.name+'.',suffix='.tmp',dir=p.parent)
        os.close(fd)
        try:
            with sqlite3.connect(tmp) as dst:self.conn.backup(dst,pages=256,sleep=0.01)
            with sqlite3.connect(tmp) as db:
                if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                    raise ValueError('Backup failed integrity check')
            with open(tmp,'rb') as f:os.fsync(f.fileno())
            _publish_temp(tmp,p,overwrite)
            return {'path':str(p),'bytes':p.stat().st_size,
                    'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        finally:
            if os.path.exists(tmp):os.unlink(tmp)
