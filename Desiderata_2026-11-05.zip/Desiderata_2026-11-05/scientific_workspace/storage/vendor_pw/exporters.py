"""Deterministic plain-text export of one PERSONAL.WIKI notebook.

Qt-free, like renderer.py. Reached through WikiCore.export_bundle(); nothing
here touches SQLite connections directly.

WHY MARKDOWN AND NOT HTML/JSON-LD
---------------------------------
The export exists so a notebook can be handed to a language model, or to a
person, as one readable document. What a model consumes for *comprehension* is
prose; microformats and JSON-LD serve parsers, which this notebook does not yet
have. So this module writes exactly two files and no more.

DETERMINISM IS A CONTRACT, NOT A CONVENIENCE
--------------------------------------------
Two exports of an unchanged notebook are byte-identical. Nothing time-varying
is written *inside* either file -- the export timestamp lives in the directory
name only. Posts are emitted in a stable order and JSON is canonicalised.

That property is what makes an export directory diffable: committing it gives a
readable per-post history, and a one-word edit shows up as a one-word diff
rather than a rewritten document. A "generated at <now>" line in the bundle
would silently destroy it, which is why there isn't one.

CROSS-NAMESPACE TARGETS ARE CLASSIFIED LEXICALLY, NEVER RESOLVED
----------------------------------------------------------------
A `[[other:Post]]` target is recorded as `external` because of how it is
SPELLED, not because another notebook was consulted. This is what keeps the
determinism above true once namespaces exist.

Resolving it would make this bundle a function of other notebooks' contents, so
two exports of an unchanged notebook could differ because a neighbour changed --
destroying exactly the git-diffability the determinism exists for. A
workspace-level export, which legitimately is a function of the whole
workspace, is a separate format with its own digest.

Before this rule existed, every cross-namespace target would have been counted
as an unresolved reference, because anything not matching a local title was
called broken. That was correct behaviour for a single notebook and became
wrong the moment the syntax existed.

POST TEXT IS VERBATIM
---------------------
Post bodies are written exactly as stored, in TiddlyWiki markup (`!` headings,
``''bold''``, ``//italic//``, ``[[Link]]``). They are NOT translated to
Markdown. Translating would need a second renderer to maintain and would lose
information on every construct it did not cover; verbatim is lossless and the
convention is stated in the bundle header so a reader -- human or model -- is
never guessing. The file is named `.md` because its *structure* is Markdown:
heading levels, the table of contents, and the per-post metadata lines.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from .links import extract_links, split_target

#: Bundle/manifest format identifier. Change this when the layout changes, so a
#: consumer can refuse a shape it does not understand rather than guess.
BUNDLE_FORMAT = 'pw-markdown-bundle/2'

BUNDLE_NAME = 'BUNDLE.md'
MANIFEST_NAME = 'MANIFEST.json'

#: Link parsing lives in links.py, which imports nothing from this project.
#: `extract_links` is re-exported from here unchanged, so existing callers and
#: the names this module has always offered are unaffected by the move.
__all__ = ['export_markdown_bundle', 'extract_links', 'BUNDLE_FORMAT',
           'BUNDLE_NAME', 'MANIFEST_NAME']


def _canonical_json(payload: dict) -> str:
    """Sorted keys, compact separators, UTF-8 kept as-is, one trailing newline.

    Deliberately the same canonicalisation history_db.post_sha256 uses, so a
    digest computed here and one computed there cannot disagree on formatting.
    """
    return json.dumps(payload, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':')) + '\n'


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _anchor(title: str) -> str:
    """A stable in-document anchor for a title.

    Not a filename: this never touches the filesystem, so it needs no
    reserved-name, case-collision or Unicode-normalisation defences. Collisions
    are resolved by the caller appending an index.
    """
    slug = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
    return slug or 'post'


def _post_rows(core) -> list[dict]:
    """Every live post, with its identity, digest and classified links.

    `post_id` comes from the history database, which is the only place a stable
    identity exists: titles can be renamed. Deleted posts are excluded -- their
    final content stays in history and this is an export of the current
    notebook, not of its history.
    """
    from .db import parse_tags
    from .history_db import post_sha256

    live_titles = set()
    titles: list[str] = []
    page = 0
    while True:
        batch = core.all_titles(limit=500, offset=page * 500)
        if not batch:
            break
        titles.extend(batch)
        page += 1
    live_titles.update(titles)

    # For a live post last_title == current_title; deleted posts are skipped.
    identity = {row['last_title']: row['post_id']
                for row in core.history_posts() if not row['deleted']}

    rows = []
    for title in titles:
        record = core.get_tiddler(title)
        if record is None:          # removed between listing and read
            continue
        # Three classes, decided lexically. `local` holds TITLES rather than
        # raw targets, because `[[:Alpha]]` is the local post `Alpha` and the
        # bundle's anchor table is keyed on titles.
        local: list[str] = []
        broken: list[str] = []
        external: list[str] = []
        for target in extract_links(record.get('text', '')):
            parsed = split_target(target)
            if parsed is None:
                continue        # an external URL; extract_links drops these
            namespace, link_title = parsed
            if namespace is not None:
                external.append(target)         # as written, never resolved
            elif link_title in live_titles:
                local.append(link_title)
            else:
                broken.append(link_title)
        rows.append({
            'post_id': identity.get(title),
            'title': title,
            'sha256': post_sha256(record),
            # parse_tags is db.py's module-level helper and handles both the
            # list form and TiddlyWiki's `[[two words]] single` string form.
            'tags': sorted(parse_tags(record.get('tags', []))),
            'created': record.get('created'),
            'modified': record.get('modified'),
            'protected': core.is_protected(title),
            'links': local,
            'broken_links': broken,
            # Cross-namespace targets. Not resolved here on purpose: see the
            # module docstring. They are neither links nor broken links, and
            # counting them as either would be a false statement.
            'external_links': external,
            '_text': record.get('text', ''),
        })
    # Stable order: title, then post_id as the tie-break. Titles are UNIQUE in
    # the content schema, so the tie-break is belt-and-braces.
    rows.sort(key=lambda r: (r['title'], r['post_id'] or ''))
    return rows


def _history_status(core) -> str:
    """'ok', 'failed' or 'unknown', passed through from history_report().

    The three states matter in a provenance header: an export of a notebook
    whose history could not be checked must not be stamped with the same word
    as an export of one whose history disagreed with its content.
    """
    try:
        return core.history_report()['status']
    except AttributeError:
        # A notebook opened through an older core without history_report().
        try:
            core.verify_history()
            return 'ok'
        except Exception:
            return 'failed'


def _render_bundle(rows: list[dict], *, source_name: str, source_digest: str,
                   history_status: str) -> str:
    anchors: dict[str, str] = {}
    used: dict[str, int] = {}
    for row in rows:
        base = _anchor(row['title'])
        count = used.get(base, 0)
        used[base] = count + 1
        anchors[row['title']] = base if count == 0 else f'{base}-{count + 1}'

    out: list[str] = []
    out.append(f'# {source_name} — notebook bundle')
    out.append('')
    out.append(f'- Format: `{BUNDLE_FORMAT}`')
    out.append(f'- Source notebook: `{source_name}`')
    out.append(f'- Source SHA-256: `{source_digest}`')
    out.append(f'- Posts: {len(rows)}')
    out.append(f'- History verification: **{history_status}**')
    out.append('')
    out.append('Post bodies below are **verbatim TiddlyWiki markup**, not Markdown: '
               '`!` prefixes are headings, `\'\'text\'\'` is bold, `//text//` is '
               'italic, and `[[Title]]` links to another post in this bundle.')
    out.append('')
    out.append('This file contains no generation timestamp, so two exports of an '
               'unchanged notebook are byte-identical.')
    out.append('')
    out.append('## Contents')
    out.append('')
    for index, row in enumerate(rows, 1):
        tags = ''.join(f' `{tag}`' for tag in row['tags'])
        out.append(f'{index}. [{row["title"]}](#{anchors[row["title"]]}){tags}')
    out.append('')

    broken_total = sum(len(row['broken_links']) for row in rows)
    if broken_total:
        out.append(f'## Unresolved references ({broken_total})')
        out.append('')
        out.append('These link targets do not match any post in this notebook.')
        out.append('')
        for row in rows:
            for target in row['broken_links']:
                out.append(f'- `{row["title"]}` → `{target}`')
        out.append('')

    external_total = sum(len(row['external_links']) for row in rows)
    if external_total:
        out.append(f'## Cross-namespace references ({external_total})')
        out.append('')
        out.append('These targets name another namespace. They are listed as '
                   'written and deliberately **not resolved**: resolving them '
                   'would make this bundle depend on other notebooks, so two '
                   'exports of an unchanged notebook could differ. They are '
                   'not unresolved references.')
        out.append('')
        for row in rows:
            for target in row['external_links']:
                out.append(f'- `{row["title"]}` → `{target}`')
        out.append('')

    out.append('---')
    out.append('')
    for row in rows:
        out.append(f'## {row["title"]}')
        out.append('')
        meta = [f'`post_id:` {row["post_id"] or "—"}',
                f'`sha256:` {row["sha256"][:16]}…']
        if row['tags']:
            meta.append('`tags:` ' + ', '.join(row['tags']))
        if row['created']:
            meta.append(f'`created:` {row["created"]}')
        if row['modified']:
            meta.append(f'`modified:` {row["modified"]}')
        if row['protected']:
            meta.append('`protected:` yes')
        out.append(' · '.join(meta))
        if row['links']:
            out.append('')
            out.append('`links to:` ' + ', '.join(
                f'[{t}](#{anchors[t]})' for t in row['links']))
        if row['broken_links']:
            out.append('')
            out.append('`unresolved:` ' + ', '.join(f'`{t}`' for t in row['broken_links']))
        if row['external_links']:
            out.append('')
            out.append('`other namespaces:` ' + ', '.join(
                f'`{t}`' for t in row['external_links']))
        out.append('')
        text = (row['_text'] or '').rstrip('\n')
        out.append(text if text else '*(empty post)*')
        out.append('')
        out.append('---')
        out.append('')
    return '\n'.join(out).rstrip('\n') + '\n'


def export_markdown_bundle(core, destination: str | Path) -> dict:
    """Write BUNDLE.md and MANIFEST.json into a new directory.

    `destination` must not already exist: an export is a snapshot, and writing
    into a populated directory would leave files from two different snapshots
    side by side with no way to tell them apart.

    Returns a summary dict. The two files are byte-deterministic for an
    unchanged notebook; the caller is expected to put the timestamp in the
    directory name.
    """
    dest = Path(destination)
    if dest.exists() or dest.is_symlink():
        raise FileExistsError(f'Export destination already exists: {dest}')

    source = Path(core.db_path)
    source_digest = _sha256_file(source)
    history_status = _history_status(core)
    rows = _post_rows(core)

    bundle_text = _render_bundle(rows, source_name=source.name,
                                 source_digest=source_digest,
                                 history_status=history_status)
    bundle_bytes = bundle_text.encode('utf-8')

    manifest = {
        'export_format': BUNDLE_FORMAT,
        'source': {
            'file': source.name,          # name only: a full path is the
            'sha256': source_digest,      # exporting machine's business
            'posts': len(rows),
            'history_verification': history_status,
        },
        'bundle': {'file': BUNDLE_NAME, 'sha256': _sha256_bytes(bundle_bytes)},
        'posts': [{k: v for k, v in row.items() if not k.startswith('_')}
                  for row in rows],
        'totals': {
            'posts': len(rows),
            'links': sum(len(r['links']) for r in rows),
            'unresolved_links': sum(len(r['broken_links']) for r in rows),
            'cross_namespace_links': sum(len(r['external_links']) for r in rows),
            'protected': sum(1 for r in rows if r['protected']),
        },
    }

    dest.mkdir(parents=True)
    (dest / BUNDLE_NAME).write_bytes(bundle_bytes)
    (dest / MANIFEST_NAME).write_text(_canonical_json(manifest), encoding='utf-8')
    return {
        'directory': str(dest),
        'posts': len(rows),
        'unresolved_links': manifest['totals']['unresolved_links'],
        'history_verification': history_status,
        'bundle_sha256': manifest['bundle']['sha256'],
    }
