"""Qt-free public API for one independent PERSONAL.WIKI notebook.

The UI and command-line launchers should use this module, not SQLite tables,
connections or the history implementation. No PySide6 import is permitted here.

One notebook = one content SQLite v2 file and its companion history SQLite v1.
All persistence rules remain in db.py/history_db.py; render_tiddler is a pure
markup-to-HTML function in renderer.py. This facade is intentionally small.
"""
from __future__ import annotations

from contextlib import closing
import os
import tempfile
from html import escape
from pathlib import Path
import re
import sqlite3
import sys
from urllib.parse import quote

from .db import (create_new_database as _create_content_database, _publish_temp,
                SearchUnavailable)
from .exporters import export_markdown_bundle as _export_markdown_bundle
from .history_db import (
    HistoryError, HistoryMissingError, HistoryTiddlerDB,
    initialize_history as _initialize_history,
    history_path as _history_path,
)
from .renderer import render_tiddler as _render_tiddler

#: Exceptions a caller may need to catch. Re-exported here so a UI never
#: has to import from db.py or history_db.py, which the README reserves as
#: persistence implementation details.
__all__ = ['WikiCore', 'SearchUnavailable', 'HistoryError', 'HistoryMissingError']


class WikiCore:
    """One open notebook, independent of desktop UI frameworks.

    A caller owns and closes each instance. Open a separate instance in a
    background worker/thread; never share its SQLite connection across threads.
    """

    def __init__(self, path: str | Path, *, readonly: bool = False):
        self._db = HistoryTiddlerDB(str(path), readonly=readonly)
        self.db_path = str(path)
        self.readonly = readonly
        try:
            report = self._db.integrity_report()
            if report['integrity'] != 'ok' or report['foreign_key_violations']:
                raise ValueError('Database integrity check failed: ' + str(report))
            # Three states, three responses. 'unknown' means the index check
            # could not be run -- a full temp volume, a locked database -- and
            # says nothing about the index. Refusing a READ on that basis is
            # what turned a small /tmp into "your search index is corrupt" and
            # locked people out of healthy notebooks. A WRITE still refuses:
            # you should not modify a notebook you were unable to verify.
            self.fts_status = report['fts_status']
            if report['fts_status'] == 'inconsistent':
                raise ValueError('Search index is inconsistent with the stored '
                                 'posts: ' + str(report))
            if report['fts_status'] == 'unknown' and not readonly:
                raise ValueError(
                    'The search index could not be verified, so this notebook '
                    'will not be opened for writing. This is NOT a report that '
                    'anything is damaged -- the check itself could not run, '
                    'usually for want of temporary disk space beside the '
                    'database. Opening read-only is permitted. Report: '
                    + str(report))
            protection = self._db.protection_report()
            if protection['violation_count']:
                raise ValueError('Protected evidence audit failed: ' + str(protection['violations']))
        except BaseException:
            self._db.close()
            raise

    @staticmethod
    def check_storage_environment() -> None:
        """Check Python/SQLite prerequisites without loading the desktop UI."""
        if sys.version_info < (3, 11):
            raise RuntimeError('Python 3.11+ is required')
        with closing(sqlite3.connect(':memory:')) as connection:
            connection.execute('CREATE VIRTUAL TABLE fts_probe USING fts5(text)')
            if connection.execute('SELECT json_valid(?)', ('{"ok":true}',)).fetchone()[0] != 1:
                raise RuntimeError('SQLite JSON support is missing')

    @staticmethod
    def history_file(path: str | Path) -> Path:
        return _history_path(str(path))

    @staticmethod
    def has_history(path: str | Path) -> bool:
        sidecar = _history_path(str(path))
        return sidecar.is_file() and not sidecar.is_symlink()

    @staticmethod
    def initialize_history(path: str | Path) -> Path:
        """Explicitly baseline an existing pre-history notebook."""
        return _initialize_history(str(path))

    @staticmethod
    def create_database(path: str | Path) -> None:
        """Create the content/history pair without publishing a partial setup.

        Stage and verify both files on the destination filesystem. Publication
        is no-clobber; a caught error cleans up only files created by this
        invocation. As two filenames cannot be published atomically, a sudden
        power loss between links may still leave an *obviously incomplete* pair
        which is refused on next open rather than silently reconstructed.
        """
        dest = Path(path)
        companion = _history_path(str(dest))
        if dest.exists() or dest.is_symlink() or companion.exists() or companion.is_symlink():
            raise FileExistsError('Content or history database already exists; refusing to replace')
        if not dest.parent.is_dir():
            raise FileNotFoundError(f'Database destination folder does not exist: {dest.parent}')
        with tempfile.TemporaryDirectory(prefix='.pw_create_pair_', dir=dest.parent) as tmp:
            staged = Path(tmp) / 'new.db'
            _create_content_database(str(staged))
            _initialize_history(str(staged))
            with WikiCore(staged, readonly=True) as check:
                # history_report() rather than verify_history(): the latter
                # raises, so `not ...['verified']` was unreachable, and a
                # staging failure could not be distinguished from a damaged
                # pair. A brand-new pair must verify cleanly -- 'unknown' is
                # not good enough to publish.
                report = check.history_report()
                if check.count() or report['status'] != 'ok':
                    raise ValueError('New database pair failed verification: '
                                     + str(report))
            created = []
            try:
                for source, target in ((staged, dest), (_history_path(str(staged)), companion)):
                    source_stat = source.stat()
                    # Include even a partially published link: a later
                    # directory-fsync failure must still clean it up safely.
                    created.append((target, source_stat.st_dev, source_stat.st_ino))
                    _publish_temp(str(source), target, overwrite=False)
            except BaseException:
                # A different process must never have its files deleted.
                for target, device, inode in reversed(created):
                    try:
                        stat = target.stat(follow_symlinks=False)
                        if (stat.st_dev, stat.st_ino) == (device, inode):
                            target.unlink()
                    except FileNotFoundError:
                        pass
                raise

    def close(self) -> None:
        self._db.close()

    def __enter__(self) -> 'WikiCore':
        return self

    def __exit__(self, *_args) -> None:
        self.close()

    def count(self) -> int:
        return self._db.count()

    def get_tiddler(self, title: str) -> dict | None:
        return self._db.get_tiddler(title)

    def is_protected(self, title: str) -> bool:
        return self._db.is_protected(title)

    def all_titles(self, limit: int = 200, offset: int = 0) -> list[str]:
        return self._db.all_titles(limit, offset)

    def all_tags(self) -> list[str]:
        return self._db.all_tags()

    def search(self, query: str = '', *, mode: str = 'Title', limit: int = 200,
               offset: int = 0) -> list[str]:
        """Search one notebook only; never query another wiki folder."""
        if not query.strip():
            return self._db.all_titles(limit, offset)
        if mode == 'Title':
            return self._db.search_title(query, limit, offset)
        if mode == 'Text':
            return self._db.search_text(query, limit, offset)
        if mode == 'Tag':
            return self._db.search_tag(query, limit, offset)
        raise ValueError(f'Unsupported search mode: {mode!r}')

    def save_tiddler(self, title: str, text: str, tags: list[str], *,
                     fields: dict | None = None, created: str | None = None,
                     reason: str | None = None) -> None:
        self._db.save_tiddler(title, text, tags, fields=fields,
                              created=created, reason=reason)

    def update_tiddler(self, old_title: str, new_title: str, text: str,
                       tags: list[str], *, reason: str) -> bool:
        return self._db.update_tiddler(old_title, new_title, text, tags, reason=reason)

    def rename_tiddler(self, old_title: str, new_title: str, *, reason: str) -> bool:
        return self._db.rename_tiddler(old_title, new_title, reason=reason)

    def delete_tiddler(self, title: str, *, reason: str) -> bool:
        return self._db.delete_tiddler(title, reason=reason)

    def import_json(self, json_path: str | Path, *, on_conflict: str = 'reject',
                    protect_imported: bool = False, reason: str | None = None) -> int:
        return self._db.import_json(str(json_path), on_conflict=on_conflict,
                                    protect_imported=protect_imported, reason=reason)

    def export_json(self, json_path: str | Path, *, overwrite: bool = False) -> int:
        return self._db.export_json(str(json_path), overwrite=overwrite)

    def snapshot_pair(self, path: str | Path) -> dict:
        return self._db.snapshot_pair(str(path))

    def export_bundle(self, destination: str | Path) -> dict:
        """Write a deterministic plain-text bundle of this notebook.

        Two files -- `BUNDLE.md` and `MANIFEST.json` -- into a new directory.
        Nothing time-varying is written inside either, so two exports of an
        unchanged notebook are byte-identical and an export directory can be
        committed to version control for a readable per-post history. Put the
        export timestamp in the directory name.

        Read-only: this never writes to the notebook, so it is safe on a
        notebook opened with readonly=True. It does not export version
        history; use snapshot_pair for a complete backup.
        """
        return _export_markdown_bundle(self, destination)

    def verify_history(self) -> dict:
        """Raise HistoryError unless the history verifies cleanly.

        The exception carries the complete problem list on `.problems` and
        'failed' or 'unknown' on `.status`.
        """
        return self._db.verify_history()

    def history_report(self) -> dict:
        """The verification result as data: ok / failed / unknown, never raising.

        Prefer this where "could not check" must be distinguishable from
        "check found a problem" -- a report header, an export manifest, a
        status indicator.
        """
        return self._db.history_report()

    def history_posts(self) -> list[dict]:
        return self._db.history_posts()

    def post_history(self, post_id: str) -> list[dict]:
        return self._db.post_history(post_id)

    def integrity_report(self) -> dict:
        return self._db.integrity_report()

    def protection_report(self) -> dict:
        return self._db.protection_report()

    def render(self, title: str) -> str | None:
        """Render one post and the legacy supported discussion-list navigation.

        Returns None for missing posts. No Qt, network or filesystem I/O.
        The renderer's TiddlyWiki compatibility subset is unchanged.
        """
        post = self.get_tiddler(title)
        if post is None:
            return None
        document = _render_tiddler(post)
        filters = re.findall(r'<\$list\s+filter="([^"]+)"', post.get('text', ''))
        if filters:
            links = []
            for expression in filters:
                for destination in self._db.filtered_title_links(expression):
                    links.append('<li><a href="tw://tiddler/' + quote(destination, safe='') +
                                 '">' + escape(destination) + '</a></li>')
            if links:
                # Replace the FIRST occurrence only. The renderer emits one
                # </body> and escapes post text, so an unbounded replace is
                # safe today -- and one character makes it stay safe.
                document = document.replace(
                    '</body>',
                    '<section><h2>Discussion navigation (supported filter subset)</h2><ul>' +
                    ''.join(links) + '</ul></section></body>', 1)
        return document
