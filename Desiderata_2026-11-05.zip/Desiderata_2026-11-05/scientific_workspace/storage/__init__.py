"""Persistence adapters; no storage imports in the pure reasoning engine."""
