# Function–Data OOP — v0.2.1 Repaired Research Bundle

This bundle preserves the original reconstructed v0.2 code archive and the review that identified eleven defects, and supplies an explicitly updated v0.2.1 research reconstruction, a consolidated research paper with a three-page appendix of unresolved issues, runnable demos, and adversarial tests.

## Contents

- `fd_oop_argumentation_evolution/` — v0.2.1 Python source, 103 tests, the three demonstrations, repair log, technical issues and research questions, and two verification scripts.
- `documents/Function_Data_OOP_Consolidated_Research_v0_2_1_with_Appendix.docx` — 19-page consolidated paper, including new Appendix A (F1–F11, 12 open engineering issues, 12 open research questions).
- `documents/Function_Data_OOP_Consolidated_Research_and_Prior_Art_v0_2.docx` — unchanged original research document, before the appendix.
- `reviews/PACKAGE_REVIEW_2026-11-06.md` — supplied external defect report, preserved without editing.
- `baseline/function_data_oop_argumentation_evolution_v0_2.zip` — preserved pre-repair code archive for reproducing the original state.
- `SHA256SUMS.txt` — SHA-256 checksums of every included file other than this checksum manifest.

## Run from a clean extraction

Python 3.10+; standard library only for runtime and tests.

```bash
cd fd_oop_argumentation_evolution
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python -m fd_oop_reconstruction.demo original
PYTHONPATH=src python -m fd_oop_reconstruction.demo agentic
PYTHONPATH=src python -m fd_oop_reconstruction.demo evolution
python verification/mutation_check.py
PYTHONPATH=src python verification/benchmark_v021.py
```

## Version change warning

`EvolutionLedger.verify_history()` now returns a `HistoryVerdict` with `status` and `detail`. Its boolean conversion is retained solely to allow v0.2 callers to transition. Expired eligibility now produces `REVIEW_DUE`, not `REJECTED`. Knowledge reviews with absent independent tests or unresolved counterexamples record a durable `REJECTED` decision instead of raising without a record. Reflections with unverifiable objects report exclusions and block promotion of incomplete-coverage candidates. Relaxing overlay schemas requires a distinct additional reviewer with a configured host callback.

The 85 pre-existing tests have four documented expectation updates to account for those changed contracts; 18 new adversarial tests are included (103 total). Eleven selected deliberately injected mutants were detected by the new tests. All three demos emit valid JSON.

## Scope and claim ceiling

This is a research reconstruction, **not** the historically recovered Function–Data v1.9 or a production-ready System Zettel service. Tests demonstrate selected contract behavior, not formally proved gradual typing, truthful Toulmin argumentation, independent authorization, trustworthy external persistence, or successful agentic knowledge distillation. Refer to `docs/OPEN_QUESTIONS_AND_ISSUES.md` before reusing for consequential actions.
