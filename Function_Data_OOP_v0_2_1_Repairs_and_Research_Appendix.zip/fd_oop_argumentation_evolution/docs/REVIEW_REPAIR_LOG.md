# v0.2.1 adversarial review repair log

**Source review:** `reviews/PACKAGE_REVIEW_2026-11-06.md`, an external review of the original v0.2 package. **Baseline:** the original v0.2 code and consolidated paper in `Function_Data_OOP_Code_and_Consolidated_Research.zip`. **Status:** working repair iteration, not a production security certification.

The v0.2 package ran 85 tests. The reviewer reproduced eleven findings (F1–F11); the original review introduction refers to nine probes, but the final table lists eleven findings. This repair follows the eleven-item table, not the shorthand count.

## Finding-by-finding disposition

| Finding | Disposition in v0.2.1 | Evidence and limitation |
|---|---|---|
| F1 unknown object misdiagnosed as broken chain | **Fixed** | `HistoryVerdict(NO_SUCH_OBJECT, ...)` rather than `False`; test `test_f1_unknown_object_is_not_tampering`. |
| F2 integrity check raises on missing current row | **Fixed for tested states** | `HistoryVerdict(UNCHECKABLE, ...)` is total over expected missing/corrupt records; test F2. Unanticipated process-level I/O failures are not a formal totality proof. |
| F3 stale decision preserves approval language | **Fixed for new decisions** | Decision reason is prefixed `NOT APPLIED`; `validation.applied=no` and intent recorded separately; test F3. Historical frozen misleading rows require explicit correction events; they are not rewritten automatically. |
| F4 eligibility lapse indistinguishable from rejection | **Fixed** | `REVIEW_DUE` and `validation.eligibility=lapsed`; test F4. The proposal is consumed and must be re-proposed, which remains a design choice. |
| F5 `argument_structure=passed` without reviewer check | **Fixed** | `checked_at_proposal` is explicitly attributed to the proposal stage; test F5. This does not prove arguments are true. |
| F6 authority callback exception leaves no trace | **Fixed for handled exceptions** | Append-only review attempt events `STARTED`, `UNDETERMINED` and a pending proposal; test F6. Process termination still leaves an unfinished `STARTED`, not a completed verdict. |
| F7 applicability merges superseded, missing, corrupted | **Fixed for tested cases** | `Applicability` enum with per-object diagnostics: `APPLICABLE`, `SUPERSEDED`, `EVIDENCE_GONE`, `EVIDENCE_UNVERIFIABLE`; test F7. Convenience boolean is derived, not authoritative. |
| F8 knowledge review is not atomic / no duplicate check | **Fixed within local SQLite model** | Explicit `BEGIN IMMEDIATE`, ATTACH source database for cross-database locking, duplicate review check, deterministic refusal/STALE precedence; tests F8 including two concurrent reviews. External authority cannot be atomically coordinated with SQLite. |
| F9 one bad object aborts global reflection | **Fixed** | Partial report includes `exclusions` and `coverage_complete=false`; unverifiable objects do not count as evidence. Candidates from incomplete coverage are tagged `BLOCKED_INCOMPLETE_COVERAGE` and knowledge proposal rejects them. Test F9. |
| F10 repeated full scans / N+1 | **Partially fixed** | Added `object_id` indexes and one joined query for all decision/proposal rows, verified query plan; test F10. Verification still requires O(n) history work per call; cumulative repeated review work remains potentially quadratic. |
| F11 claimed protected-metadata invariant absent | **Partially fixed and claim narrowed** | Ordinary review cannot relax or make an unproved refinement of the JSON overlay schema; a distinct elevated reviewer and configured host callback are required. Operation contract remains immutable. Tests F11. This is not an authenticated production boundary; callers controlling the in-process host can forge policy attestations. |

## Additional hardening

- `EvolutionLedger.append_correction(...)` writes immutable compensating interpretation records without changing frozen decisions. Correction records are **not independently anchored** and are not proof of truth.
- `EvolutionLedger.verify_history()` now batch-joins proposals and decisions and returns typed diagnostics; the old `bool(verdict)` behavior remains strictly as a compatibility convenience.
- Review attempts record a distinguishable conflict outcome when a concurrent review already decided the proposal.
- `knowledge.review()` rejects knowledge promotion with missing independent test references or unresolved counterexamples by writing a durable `REJECTED` decision rather than raising without a decision. This is an intentional API behavior change.
- Bad histories do not invalidate healthy objects in reflection, but incomplete-coverage candidates cannot be promoted as if the full registry were verified.

## API changes requiring downstream attention

```python
v = ledger.verify_history('obj')
assert v.status.value in ('VERIFIED','BROKEN','NO_SUCH_OBJECT','UNCHECKABLE')
# bool(v) supported for compatibility, but loses diagnostic information

# KnowledgeLedger.accepted() now includes:
# applicability, applicability_details, currently_applicable (derived)

# Both evolution and knowledge ledgers offer review_attempts(proposal_id).
# EvolutionLedger also offers append_correction(...) and corrections(...).

controller = TypeEvolutionController(
    catalog, ledger, authorize_review=normal_authority,
    authorize_sensitive_review=higher_authority,
)
# For relaxation only: controller.review(..., elevated_reviewer='independent-supervisor')
```

In v0.2.1 a lapsed assignment returns decision status `REVIEW_DUE`, not `REJECTED`. Knowledge reviews lacking tests or presenting unresolved counterexamples now return a durable `REJECTED` decision rather than raising `EvolutionError`. Original regression tests were adjusted **only for these intentionally changed semantics**; all other v0.2 tests were retained.

## Verification performed

- 85 existing tests (with four updated expectations reflecting documented API changes), plus 18 new regression tests: **103 tests passing** on the current interpreter.
- **11 targeted mutation checks killed**: reintroduced wrong unknown-object verdict, non-total missing-row check, missing stale warning, misclassified eligibility lapse, lost authority-failure attempt, missing index, fake argument-validation pass, collapsed knowledge applicability, missing atomic duplicate check, fail-fast reflection, and ignored schema-protection gate. See `verification/mutation_check.py`. This is a selected mutant set, not exhaustive mutation coverage.
- All three demos (`original`, `agentic`, `evolution`) produce valid JSON output.
- Recorded exploratory timings at 20 / 60 / 120 accepted decisions: `verify_history` 4.6 / 7.3 / 14.0 ms and last propose+review 24.0 / 26.8 / 45.6 ms in one local run. Numbers are exploratory and are **not** a controlled performance comparison to the review's original measurements. The asymptotic limitation remains.

**Important:** no third-party dependency, formal gradual-typing proof, authenticated principal verification, external integrity anchor, true semantic truth assessment, or production-grade policy sandbox has been added.
