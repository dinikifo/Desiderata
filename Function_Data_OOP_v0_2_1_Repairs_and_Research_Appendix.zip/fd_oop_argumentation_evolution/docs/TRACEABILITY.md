# Reconstruction traceability and provenance

**Source:** The user-provided `Αρχειοθέτηση(4).zip`, principally `zetel.39.txt` and `zetel.40.txt`. These are conversational descriptions of previously developed code. They are not the original frozen Python source files themselves. No attempt is made to pass this implementation off as frozen Function–Data v1.9 or System Zettel Round 26.

| Design element in this reconstruction | Supporting archive discussion | Reconstruction decision / uncertainty |
|---|---|---|
| Dedicated `JsonData` subclass per callable; `FunctionPair`, `Metadata`, `ContractCatalog`, `ExecutionRegistry`, `Step` | `zetel.39.txt`, “Reconsidering the Function–Data paradigm”; “Function–Data v1.9 — Codebase simplification review” | Historical names and intent retained; constructor signatures inferred. |
| Versioned operation contracts and logical checkpoint transitions | `zetel.39.txt`, P0–P5 discussions and “Migration Blueprint”; `zetel.40.txt`, “Function–Data — Project Reconstruction” | `name@version` chosen as illustrative string identity; state transitions checked at runtime. |
| Rule-based domain inference and entity operation dictionaries | `zetel.39.txt`, opening “Initial review”; “A deeper hypothesis” | We use host-supplied predicates and reject ambiguous suggestions; no LLM or inference engine. |
| JSON copy/immutable snapshots | `zetel.39.txt`, P1 probe around `JsonData(payload=original_dict)` retaining alias references; “Codebase simplification review” | Our copy is defensive by default, deliberately more restrictive than the documented raw construction. |
| Durable checkpoints and persisted revisions | `zetel.39.txt`, durable workflow extension P4; `zetel.40.txt`, G4 “Durable Function–Data work” | SQLite schema and optimistic compare-and-swap recreated, not source-equivalent. |
| `AcceptanceGateway` distinct from computational completion | `zetel.39.txt`, “Reconsidering”; “Codebase simplification review”; `zetel.40.txt`, base-project summary | Verifier callback is host supplied, cannot constitute production independent evidence authentication. |
| Domain supervisor/self-healing limited by external effects | `zetel.39.txt`, “A deeper hypothesis” (`infer_job`, `plan_recovery_job`) | Rule-based `DomainSupervisor` and explicit `RecoveryManager` stand in for the more extensive v1.9 machinery. |
| Effect admission separate from FD operations | `zetel.39.txt`, “Migration Blueprint”; `zetel.40.txt`, G1a/G1b, G3 native delegation | Educational guarded-effect port plus more detailed native-style attempt ledger. |
| FD agent shell / source-bound work | `zetel.40.txt`, G2 and G3 | `FDAgent` is deterministic, not LLM-controlled; proposal requires a sealed FD job. |
| `NEW → PREPARED → SEALED` recovery | `zetel.40.txt`, G4 | Exact conceptual checkpoints used; payload schema invented. |
| Native authority retains one-use admission, approval, effects | `zetel.40.txt`, G1–G3 and G6; `zetel.39.txt`, migration feasibility | Native boundary represented by independent Python object and separate SQLite ledger, not actual Round 26 code. |
| Unknown effects and owner receipt reconciliation | `zetel.39.txt`, P4 and external-effect studies; `zetel.40.txt`, G3 | Simulated post-commit crash and owner receipts show fail-closed reconciliation. |
| Cross-goal identity, reassignment and historical outcomes | `zetel.40.txt`, G5a–G7 | `GoalAssignments` and `MethodMemory` demonstrate persistence but not scientific evidence of improved adaptation. |

## Historically grounded vs. invented

**Grounded at the component/concept level**: class concepts `JsonData`, `FunctionPair`, `Metadata`, `Step`, `ContractCatalog`, registry; entity operations; domain supervision; explicit intent/checkpoint model; independent acceptance; native authority; goal assignment; source pins; owner receipts; guarded effects; G4 state sequence; handling of uncertain effects.

**Invented or greatly simplified for this runnable package**: exact Python signatures, enums, schema validation, SQLite table designs, source note model, deterministic “agent planner,” content template, approval token mechanism, method history schema, goal predicate, mock operator, and reviewer callback. No claim of test parity with the historical 249-test frozen framework or the historical agent suites.

## Suggested next reconstruction step

With the *actual* frozen `core.py`, `registered_ops.py`, `public_api.py`, `acceptance.py`, associated tests and G2–G6 agent packages, run contract-diff and fixture replay tests to distinguish faithful behavior from reconstruction choices. Treat failures as data, not as licenses to weaken authority boundaries.


## v0.2 evolution extension: new research hypothesis, not historic recovered code

The structured Toulmin discussion, before/after JSON snapshots, annotation lists,
agentic runtime type refinement and whole-catalog knowledge distillation were
introduced by the user **after** the v0.1 reconstruction. None of these v0.2
modules should be attributed to frozen historical Function–Data v1.9 or System
Zettel G7 as completed historical implementation. `evolution.py`,
`evolution_agent.py`, `distillation.py`, `knowledge.py`, and
`evolution_demo.py` are **new research implementations**, and the optional
`ExecutionRegistry.state_guard` and `FDAgent` evolution facade are new
compatibility extensions to the earlier reconstruction. See
[ARGUMENTATION_EVOLUTION.md](ARGUMENTATION_EVOLUTION.md).
