# Appendix A — Open questions, unresolved issues, and research obligations

**Function–Data OOP / System Zettel / Toulmin evolution — v0.2.1, 6 November 2026**

This appendix is deliberately an *issue register*, not an assertion that all identified defects are resolved. Its categories separate **engineering limitations** from **unanswered research hypotheses**. It is grounded in `PACKAGE_REVIEW_2026-11-06.md`, the v0.2 baseline, the v0.2.1 repair work, and the consolidated research paper. It does not independently establish claims of novelty or empirical advantage.

## A. Repaired defects and remaining qualifications

The reviewer identified F1–F11. F1, F3 (for newly generated records), F4, F5, F7, and F9 have directly tested behavioral fixes. F2 is handled for known reachable records but is not a proof of totality under every storage failure. F6 now preserves review attempts through normal exceptions but not through an instantaneous loss of process or machine. F8 coordinates decisions with local SQLite transactions but not with an external authorization provider. F10 has indexes and joined verification but retains linear full-history verification. F11 introduces a conservative higher-authority gate for relaxation of overlay JSON schemas; it does not provide authenticated privilege separation or a formal metadata-policy calculus.

## B. Engineering issues that remain open

| ID | Priority | Question / issue | What would close it |
|---|---|---|---|
| E01 | Critical for production | **External tamper-evidence:** The SQLite genesis and decision hash chain has no independently anchored root; a DB owner could rewrite the chain. Review-attempt and correction events are trigger-frozen but not cryptographically anchored. | Signed or externally witnessed chain heads; independent audit of completeness and key management. |
| E02 | High | **Host authority:** Reviewer identities and elevated-review attestations are labels/callback results, not authenticated credentials. A caller with Python process control can forge them. | Out-of-process authorization service, authenticated principals, policy enforcement and adversarial bypass tests. |
| E03 | High | **Transaction boundaries:** Attached SQLite databases permit local lock coordination in this deployment, but external approval, resource-owner effects, and machine-failure atomicity are outside that transaction. | Document the journal/WAL conditions; test concurrent writers, process crashes and recovery; use an outbox or equivalent where appropriate. |
| E04 | High | **Unfinished attempts:** `STARTED` is durable before calling authority, but crashes leave attempts unfinished. How should stale in-flight reviews be diagnosed without incorrectly classifying them as refusals? | Recovery scan with explicit `INTERRUPTED` or `RECONCILIATION_DUE`, independent authority reconciliation, and restart tests. |
| E05 | High | **Protected-policy completeness:** Only operation identity and conservative JSON-schema relaxations are protected. Future metadata fields may silently change authorization, evidence or reliance semantics. | A separately versioned, protected policy namespace; controlled policy evolution with independent review and non-relaxable roots. |
| E06 | High | **Schema compatibility and migration:** Validation of one candidate instance does not prove historical, forward, or cross-service compatibility; our subset test is conservative and incomplete. | Formalize the supported subset, migration semantics, compatibility directions, pinned-job behavior and counterexample tests. |
| E07 | Medium | **Repeated verification complexity:** The optimized verifier remains O(n) for an n-decision history; repeated reviews can be O(n²) cumulatively. | Test anchored/incremental verification, batch diagnostics and large-history stress tests with explicit integrity guarantees. |
| E08 | High | **Knowledge-record integrity:** Knowledge proposals and decisions use frozen SQLite rows and digests, but do not yet have a fully verified, independently anchored hash chain analogous to evolution decisions. | Validate stored digests on every retrieval, chain knowledge decisions/corrections, external anchoring and corruption tests. |
| E09 | High | **Partial reflection interpretation:** Candidates from incomplete registry verification are currently blocked, but the system cannot determine how severely missing objects affect a candidate's domain of applicability. | Formal coverage model with completeness claims, scoping, risk policy and controlled evidence requalification. |
| E10 | Medium | **Versioned semantic interpretation:** Old JSON fields may change meaning even when old snapshots still parse. | Versioned semantic contracts, interpretation/migration rules and replay tests against historical schemas. |
| E11 | High | **Retained sensitive evidence:** Argument grounds and snapshots can contain private or confidential facts; immutable storage conflicts with minimization and deletion. | Data classification, selective disclosure, key destruction/redaction procedures, and privacy threat model. |
| E12 | Medium | **API transitional behavior:** A `HistoryVerdict` still offers implicit boolean conversion; `REVIEW_DUE` consumes a proposal; legacy accepted rows are not automatically corrected. | Migration plan to explicit verdict handling, reopening/re-proposal semantics, and targeted correction-event tooling. |

## C. Conceptual and empirical questions that remain unanswered

| ID | Question | Why current code is insufficient | Decisive test or analysis |
|---|---|---|---|
| R01 | Is the model genuinely a form of gradual typing? | It evolves runtime JSON constraints, without formal static/dynamic typing semantics. | A small formal calculus with gradual guarantee criteria, or use the narrower term *argumentation-governed contract refinement*. |
| R02 | Are Toulmin arguments faithful reasons or persuasive rationalizations? | Structural validation does not validate factual premises, warrants, or causal fidelity. | Blind review with adversarial explanations and independent evidence sources. |
| R03 | Can defeaters propagate correctly through alternative justifications? | Arguments are JSON lists with limited `responds_to`, not a typed defeasible dependency graph. | Multi-object controlled experiment with one defeated warrant and independent alternative supports. |
| R04 | Can reflection learn meaningful rules rather than repeat correlated text? | Deterministic repetition and identical schema shape do not establish semantic equivalence. | Held-out operations with similar field names but different semantics and correctness oracles. |
| R05 | Can rejected and inconclusive proposals contribute more knowledge than accepted changes? | Current distillation emphasizes accepted supporting arguments and stable field patterns. | Compare learning with and without rejected proposals, counterexamples, and missing-evidence records. |
| R06 | Does Toulmin history outperform strong conventional alternatives? | Tests establish mechanism, not improvement over ADRs, schema registries, provenance graphs, audit trails and carefully structured free text. | Capability-matched blinded trials varying only the structured argumentative layer. |
| R07 | Can the system abstain appropriately under uncertainty? | It has `REVIEW_DUE` and `UNDETERMINED`, but no epistemic calibration or stopping policy. | Unknown-source and ambiguous-evidence tasks scored for justified abstention and unnecessary suspension. |
| R08 | What is a justified reliance condition? | Structural validity, permission, semantic correctness, and fitness for purpose remain separate but incompletely formalized. | Specify conditions, purposes, scopes and independent acceptance oracles for each contract. |
| R09 | Can the system prevent higher-order governance drift over multiple revisions? | A distinct elevated reviewer blocks ordinary relaxations; it does not prove safe evolution of the elevated rules themselves. | Authority-policy invariant model and longitudinal adversarial revision chains. |
| R10 | Can argumentation histories be safely summarized without losing defeaters? | History grows unbounded; no proof-preserving compression or retrieval criteria exist. | Compare full histories with summaries on challenged-premise localization and false generalizations. |
| R11 | Does the architecture reduce total lifecycle cost? | Additional schema validation, persistent records and review steps have measurable overhead; benefits remain hypothetical. | Engineer-time, storage, review quality, security incident and maintenance-cost comparisons. |
| R12 | What exactly does an evolving object's identity encompass? | Function–Data contract, instance state, version lineage, authorization and justification are currently separable but loosely coupled. | Define object/contract lineage semantics, branching, merges and semantic discontinuity tests. |

## D. Priority gates for the next research iteration

**Gate 1 — Production-trust boundary (engineering):** Do not claim secure governance until E01–E05 and E08 are satisfied under a specified adversarial model. Append-only SQL triggers are not external tamper-evidence, and callback labels are not credentials.

**Gate 2 — Defeasible dependency experiment (scientific):** Build three or more Function–Data objects with shared and independent warrants; introduce a defeating counterexample; measure identification accuracy, unnecessary invalidations, justified abstentions and correct repair proposals. Compare against a capability-matched structured-evidence baseline that does not use Toulmin formatting.

**Gate 3 — Schema-compatibility semantics (formal):** Specify the restricted JSON-schema subset, precise narrowing conditions, migration obligations and backward/forward compatibility tests. Until then, do not call this formal gradual typing.

**Gate 4 — Global reflection reliability (empirical):** Use held-out operations, misleading correlations, incomplete registry coverage and independently assessed rules. Record errors, negative results and reviewer calibration rather than counting accepted claims as successful learning.

**Gate 5 — Durability/performance (engineering):** Benchmark at fixed history lengths (e.g., 100, 1,000, 10,000 decisions), test cold and warm execution, and demonstrate what an anchored incremental integrity check actually guarantees.

## E. Status of the central research hypothesis

The repaired code supports *inspection* of versioned changes and their stated rationales, durable recording of some uncertain review outcomes, safer separation of missing versus invalid provenance, and nonautomatic knowledge promotion. It has **not** demonstrated that a reasoning agent distills transferable knowledge, that reasons are causally faithful, that metadata evolution is type-theoretically gradual, or that the design is superior to a simpler conventional implementation.

**Conservative position:** the most credible target remains a **justification-aware contract**: a versioned, executable Function–Data contract whose conditions of justified reliance can be stated, traced, challenged, and reconsidered without confusing an epistemic change with an authorized software mutation or irreversible external effect.
