# Argumentation-Governed Agentic Type Evolution

This is a **research extension** to the existing executable Function–Data OOP and governed FD-agent reconstruction. It does **not** reproduce a historical released codebase or demonstrate that LLM agent reflection improves performance. It provides deterministic machinery on which to test that thesis.

## Thesis represented in code

For a registered Function–Data object `O(t) = (contract, data(t), metadata(t), revision(t))`, each proposed transformation captures:

- An ordered **list of JSON Toulmin arguments** (`claim`, `grounds`, `warrant`, `backing`, `qualifier`, `rebuttals`, `evidence_refs`), optional `argument_id`, `stance` (`support` or `oppose`), and `responds_to` references for dialogue threads.
- The complete **before** JSON data and metadata (detached snapshot).
- The complete **candidate** JSON data and metadata (detached snapshot).
- A **list of string notes** plus optional structured goal context.
- An independent **review decision**, schema validation result, authorization decision, revision fence, and digest-linked decision record.
- The complete committed **after** JSON data and metadata **only when accepted**.

Historical proposals and decisions are append-only at the SQLite API and protected against casual row mutation by database triggers. Rejected and stale proposals retain the candidate and reasoning but do **not** become the authoritative object. An immutable genesis snapshot anchors the object's initial state. The chain is not cryptographically secure against a privileged attacker who controls the database, schema, and application.

The list can include both arguments for and arguments against a proposed change; opposition is preserved and is not treated as an endorsed claim by the distiller. Structural checking is **not** a correctness proof of the argument, its backing, or the evidence reference.

## Three distinct meanings of typing

1. **Static Python typing:** the original dedicated `JsonData` class must still match the registered Python function's input annotation. This is preserved; the executable method is not rewritten at runtime.
2. **Runtime JSON schema typing:** the new `metadata['schema']` starts with `type: 'any'`, which can be refined to a runtime-checked constraint (e.g. `integer`, `minimum: 1`); it can also be revised, relaxed, or replaced following review.
3. **Argumentation and epistemic evidence:** the reasons for the type change are stored. They do not make the constraint true or grant authority to install it.

This is **agentic, argumentation-governed contract refinement**, a proposed application of gradual typing ideas. It is **not** a complete implementation of formal gradual typing, static inference, blame calculus, sound casts, or automated Python source-code transformation.

The JSON schema validator is intentionally a **small documented subset**, not a standards-compliant implementation of all JSON Schema features. Supported keywords: `type` (`any`, `object`, `array`, `string`, `integer`, `number`, `boolean`, `null`, including unions as a list), `properties`, `required`, `additionalProperties` (boolean), `items`, `minimum`, `maximum`, `minLength`, `maxLength`, `enum`. Unknown keywords are rejected. No `allOf`, `$ref`, `pattern`, regex, conditional schemas, or custom functions. Numeric `bool` values are not integers. JSON-only, finite values are enforced.

## Runtime and authority boundaries

```text
AGENT (may propose)
    |     goals checked by GoalAssignments
    v
TypeEvolutionController.propose(... arguments=[...], notes=[...])
    |
    v
EvolutionLedger: append-only proposal with before/candidate snapshots
    |
    v
INDEPENDENT REVIEWER / HOST (may approve or refuse)
    |     external authorizer callback + active-goal eligibility
    |     schema validation + immutable FunctionPair identity
    |     compare-and-swap revision fence
    v
EvolutionLedger: accepted/rejected/stale decision + complete after (on accept)
    |
    +--> Evolved runtime schema (object.metadata['schema'])
    |       new FD jobs pin the latest revision
    |       already-started jobs keep their pinned schema
    v
VersionedExecutionRegistry -> ORIGINAL FD registry + pre-commit state guard
    |
    v
Existing FDAgent start/resume -> SEALED draft
    |
    v
Existing NativeAuthority -> VaultOwner -> independent outcome oracle
    (No new effect permissions given to the evolution or reflection agent.)

ReflectionDistiller examines:
    EVERY catalog FunctionPair + versioned objects + full decision histories
    |
    v
CandidateKnowledge (heuristic, not an authoritative new rule)
    |
    v
KnowledgeLedger (immutable proposal + independent test refs + independent reviewer)
    |
    v
Accepted knowledge entry (still NOT automatically installed as a schema)
```

**Execution critical detail:** The existing `ExecutionRegistry` gained a single optional `state_guard` hook that runs *before* committing every computational checkpoint. `VersionedExecutionRegistry` installs a guard checking each job against its pinned schema, preventing an invalid patch from being committed. An invalid worker transition is recorded as a failed job. `FDAgent` optionally uses this guarded facade when it is constructed with an evolution ledger and matching object ID. The existing native effect and approval code is unchanged.

**Limit:** the job record and schema binding are persisted in two SQLite transactions; an interruption between them may create an orphan FD job, which the facade refuses to continue. This is fail-closed but not atomic. A production-grade system should move binding into the FD job creation transaction or implement a proven reservation protocol.

## Minimal developer example

```python
from fd_oop_reconstruction import (
    EvolutionLedger, TypeEvolutionController, object_metadata,
    AgenticEvolutionService, ReflectionDistiller, agentic_evolution_controller
)
from fd_oop_reconstruction.agentic import build_agent_catalog, GoalAssignments

catalog = build_agent_catalog()
ledger = EvolutionLedger("evolution.db")
assignments = GoalAssignments("assignments.db")
assignments.assign("agent", "goal-1", "operator")

controller = agentic_evolution_controller(
    catalog, ledger, assignments,
    authorize_review=lambda reviewer, proposal: reviewer == "operator",
)
controller.register_object(
    "prepare-object", "fd_agent.prepare_work@0.1.0",
    data={"source_revision": 1},
    schema={"type": "object", "required": ["source_revision"],
            "properties": {"source_revision": {"type": "any"}}},
)
agent_evolution = AgenticEvolutionService(
    "agent", assignments, controller, ReflectionDistiller(catalog, ledger)
)

old = ledger.get("prepare-object")
new_meta = old.metadata
new_meta["schema"]["properties"]["source_revision"] = {
    "type": "integer", "minimum": 1
}
change = agent_evolution.propose_for_goal(
    "goal-1", "prepare-object", expected_revision=old.revision,
    data={"source_revision": 1}, metadata=new_meta,
    arguments=[{
        "argument_id": "a1", "stance": "support",
        "claim": "source_revision should be a positive integer",
        "grounds": ["This source owner uses positive integer revisions"],
        "warrant": "A typed revision permits consistent pin checks",
        "qualifier": "within this owner implementation",
        "rebuttals": ["Other owners may issue opaque strings"],
    }],
    notes=["Reviewed source-owner contract", "Keep old schema for old jobs"],
)
# This action is performed by the host/operator, NEVER the agent itself.
decision = controller.review(
    change.proposal_id, reviewer="operator", approve=True,
    reason="Validated schema and independently reviewed arguments",
)
assert decision.status == "ACCEPTED"
assert ledger.verify_history("prepare-object")
```

For end-to-end operation including a completed and accepted native-controlled effect:

```bash
PYTHONPATH=src python -m fd_oop_reconstruction.demo evolution
```

The demo creates two separate dedicated Function–Data methods, an agent-goal assignment, two accepted schema evolutions with supporting/opposing arguments and notes, executes the source-bound `FDAgent` under its latest schema, runs the pre-existing native authority / owner / oracle pipeline, extracts two cross-method candidate rules, then promotes one rule to a separately approved, test-referenced knowledge entry. All data are local and ephemeral within the demo.

## Reflection and distillation boundaries

`ReflectionDistiller.reflect()` analyzes the complete `ContractCatalog` and each current object and decision history. It searches for:

- A **repeated field schema** across at least two *different function contracts*.
- A **repeated supporting Toulmin claim** in accepted evolution decisions across at least two different function contracts.

It surfaces contrary field schemas and recorded rebuttals. It is a rule-based extractor, not a language-model reasoner, a statistical confidence estimator, or a theorem prover. The candidate is not adopted automatically.

`KnowledgeLedger` persists the candidate and source revision/digest fingerprints, requires reviewer independence and externally supplied authorization, refuses unresolved counterexamples, and requires test-reference strings to accept a claim. It stores test identifiers but does not itself execute or authenticate independent tests. Accepted entries remain *advisory knowledge* and never modify method code or metadata automatically.

## Limitations and research experiments

- **Authority identity** is a label checked by a user-supplied callback, not a security credential. All actors share a Python process and databases. A hostile Python worker or DB administrator can bypass controls; do not use this as production policy enforcement.
- **External evidence** is only referenced by strings. A source digest is not a statement of truth, authenticity, or relevance. Toulmin argument validity is checked structurally, not semantically.
- **Concurrency** is CAS on SQLite object revisions; source-goal assignment and object evolution are in distinct databases, so assignment eligibility is not an atomic cross-system transaction.
- **Schema semantics** are a subset and only affect jobs launched through the guarded adapter. Changing the FunctionPair's transition graph, worker implementation, or original dedicated Python class requires a new separately registered version; metadata evolution intentionally refuses executable contract mutation.
- **Already-running jobs** use the schema pinned at creation; this avoids silent re-interpretation but means stricter types are not retroactive. Old jobs can be explicitly drained or migrated under a separately governed migration plan.
- **Distillation is a hypothesis**, not proven improvement or weight-level model training. To test it, compare a baseline agent that sees current schemas only against the same-capability agent with full argumentation/change histories, measuring change correctness, incompatible revisions, cross-method transfer, review effort, and held-out task performance.
- **Untrusted notes / argument content** are data, not instruction channels. If later fed to an LLM, treat them as untrusted input and independently enforce all permissions.
