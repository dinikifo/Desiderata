"""Read-only, whole-registry reflection and candidate rule distillation.

Explicit, inspectable heuristic extraction rather than claims of model learning.
Distilled candidates NEVER change method contracts, schemas or authority.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .original import ContractCatalog, canonical_hash, strict_json_copy
from .evolution import EvolutionLedger, HistoryStatus


@dataclass(frozen=True)
class CandidateKnowledge:
    candidate_id: str
    kind: str
    statement: str
    supporting_objects: tuple[str, ...]
    supporting_events: tuple[str, ...]
    counterexamples: tuple[str, ...]
    limitations: tuple[str, ...]
    status: str = "NEEDS_INDEPENDENT_REVIEW"

    def as_json(self) -> dict[str, Any]:
        return strict_json_copy({
            "candidate_id": self.candidate_id, "kind": self.kind,
            "statement": self.statement, "supporting_objects": list(self.supporting_objects),
            "supporting_events": list(self.supporting_events),
            "counterexamples": list(self.counterexamples),
            "limitations": list(self.limitations), "status": self.status,
        })


@dataclass(frozen=True)
class ReflectionReport:
    methods: tuple[dict[str, Any], ...]
    objects: tuple[dict[str, Any], ...]
    candidates: tuple[CandidateKnowledge, ...]
    exclusions: tuple[dict[str, str], ...] = ()

    def as_json(self) -> dict[str, Any]:
        return strict_json_copy({
            "methods": list(self.methods), "objects": list(self.objects),
            "candidate_knowledge": [r.as_json() for r in self.candidates],
            "exclusions": list(self.exclusions),
            "coverage_complete": not self.exclusions,
        })


class ReflectionDistiller:
    """Detect structurally repeated field constraints and claims.

    Minimum support is number of DISTINCT registered method contracts, not
    multiple snapshots of the same method. Conflicts are surfaced, not erased.
    No probabilistic confidence, semantic proof or neural-weight updates.
    """
    def __init__(self, catalog: ContractCatalog, ledger: EvolutionLedger):
        self.catalog, self.ledger = catalog, ledger

    def reflect(self, *, min_support: int = 2) -> ReflectionReport:
        if type(min_support) is not int or min_support < 2:
            raise ValueError("min_support must be at least two")
        methods: list[dict[str, Any]] = []
        for identity in self.catalog.identities():
            pair = self.catalog.resolve(identity)
            methods.append({"contract": identity,
                            "function": pair.function.__name__,
                            "data_type": pair.data_type.__name__,
                            "checkpoints": sorted({pair.metadata.start, *pair.metadata.transitions,
                                                   *(cp for destinations in pair.metadata.transitions.values() for cp in destinations)}),
                            "terminal": sorted(pair.metadata.terminal)})
        objects: list[dict[str, Any]] = []
        fields: dict[str, dict[str, list[tuple[str, str]]]] = {}
        claims: dict[str, dict[str, Any]] = {}
        exclusions: list[dict[str, str]] = []
        for object_id in self.ledger.object_ids():
            verdict = self.ledger.verify_history(object_id)
            if verdict.status is not HistoryStatus.VERIFIED:
                exclusions.append({"object_id": object_id, "status": verdict.status.value,
                                   "diagnostic": verdict.detail})
                continue
            obj = self.ledger.get(object_id)
            history = self.ledger.history(obj.object_id)
            objects.append({"object_id": obj.object_id, "contract": obj.contract,
                            "revision": obj.revision, "data": obj.data,
                            "metadata": obj.metadata, "history": history})
            schema = obj.metadata["schema"]
            for field, child in schema.get("properties", {}).items():
                token = canonical_hash(child)
                fields.setdefault(field, {}).setdefault(token, []).append((obj.object_id, obj.contract))
            for event in history:
                if event["status"] != "ACCEPTED":
                    continue
                for argument in event["arguments"]:
                    if argument.get("stance", "support") != "support":
                        continue  # An accepted change does not endorse opposing claims.
                    claim = argument["claim"].strip().casefold()
                    rec = claims.setdefault(claim, {"wording": argument["claim"], "objects": set(),
                                                    "contracts": set(), "events": set(), "rebuttals": set()})
                    rec["objects"].add(obj.object_id)
                    rec["contracts"].add(obj.contract)
                    rec["events"].add(event["proposal_id"])
                    rec["rebuttals"].update(argument["rebuttals"])
        result: list[CandidateKnowledge] = []
        for field, variants in sorted(fields.items()):
            for digest, occurrences in sorted(variants.items()):
                contracts = {contract for _, contract in occurrences}
                if len(contracts) < min_support:
                    continue
                supporters = tuple(sorted({oid for oid, _ in occurrences}))
                contradictions = tuple(sorted({oid for other_digest, entries in variants.items()
                                               if other_digest != digest for oid, _ in entries}))
                status = "NEEDS_INDEPENDENT_REVIEW"
                limitation = ("Different schemas for the same field exist elsewhere in the registry."
                              if contradictions else "Shared schema shape is not evidence that semantics agree.")
                # Exact schema JSON is kept in the reported objects for inspection.
                candidate_id = "shape-" + canonical_hash({"field": field, "digest": digest})[:12]
                result.append(CandidateKnowledge(candidate_id, "REPEATED_FIELD_SCHEMA",
                     f"Consider a shared validation policy for field '{field}' with schema digest {digest[:12]}.",
                     supporters, (), contradictions, (limitation,), status))
        for key, info in sorted(claims.items()):
            if len(info["contracts"]) < min_support:
                continue
            result.append(CandidateKnowledge(
                "claim-" + canonical_hash({"claim": key})[:12], "REPEATED_ACCEPTED_ARGUMENT",
                f"Consider testing the cross-method claim: {info['wording']}",
                tuple(sorted(info["objects"])), tuple(sorted(info["events"])), (),
                ("Acceptance records show approval, not that the claim is true.",
                 *sorted("Recorded rebuttal: " + r for r in info["rebuttals"])),
            ))
        if exclusions:
            # Partial reports are useful diagnostics but not promotion-ready evidence.
            result = [CandidateKnowledge(c.candidate_id, c.kind, c.statement,
                       c.supporting_objects, c.supporting_events, c.counterexamples,
                       c.limitations + ("Registry reflection incomplete; excluded unverified objects.",),
                       "BLOCKED_INCOMPLETE_COVERAGE") for c in result]
        return ReflectionReport(tuple(methods), tuple(objects), tuple(result), tuple(exclusions))
