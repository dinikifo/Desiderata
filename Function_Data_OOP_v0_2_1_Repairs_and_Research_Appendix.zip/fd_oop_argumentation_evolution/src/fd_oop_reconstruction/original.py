"""Research reconstruction of the original Function–Data operational kernel.

Not the historical frozen v1.9 source/API. Its principles are preserved, but
interfaces and persistence details are reconstructed from discussion transcripts.
Workers MUST be deterministic/replay-safe and must not perform external effects:
optimistic concurrency may run an operation more than once before committing it.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
import inspect
from contextlib import contextmanager
from enum import Enum
import hashlib
import json
import math
import sqlite3
from pathlib import Path
from typing import Any, Callable, Mapping, get_type_hints
import uuid


@contextmanager
def sql_conn(path: str | Path):
    """Always commit/roll back AND close SQLite connections."""
    connection = sqlite3.connect(str(path), timeout=5)
    try:
        with connection:
            yield connection
    finally:
        connection.close()


class ContractError(ValueError):
    """An operation, data, state or transition violated a contract."""


class ConcurrencyError(RuntimeError):
    """Another worker committed a revision first."""


class AcceptanceError(RuntimeError):
    """Independently supported acceptance could not be established."""


def strict_json_copy(value: Any) -> Any:
    """Reject non-JSON types/keys/nonfinite floats and detach mutable aliases."""
    def check(item: Any, ancestors: set[int]) -> None:
        if item is None or type(item) in (str, bool, int):
            return
        if type(item) is float:
            if not math.isfinite(item):
                raise ContractError("nonfinite number")
            return
        if type(item) not in (dict, list):
            raise ContractError(f"non-JSON type {type(item).__name__}")
        if id(item) in ancestors:
            raise ContractError("cyclic data")
        ancestors.add(id(item))
        if type(item) is dict:
            for k, v in item.items():
                if type(k) is not str:
                    raise ContractError("JSON object keys must be strings")
                check(v, ancestors)
        else:
            for v in item:
                check(v, ancestors)
        ancestors.remove(id(item))
    check(value, set())
    return json.loads(json.dumps(value, allow_nan=False, sort_keys=True))


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(strict_json_copy(value), sort_keys=True,
                                     separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


class Intent(str, Enum):
    YIELD = "YIELD"            # Commit one checkpoint; may resume
    COMPLETE = "COMPLETE"      # Commit a terminal checkpoint
    STOP = "STOP"              # Deliberate termination, no success claim
    ERROR = "ERROR"            # Structured terminal failure
    PARAMETER = "PARAMETER"    # Commit a stage and await explicit input


class Status(str, Enum):
    NEW = "NEW"
    YIELDED = "YIELDED"
    PARAMETERS_REQUIRED = "PARAMETERS_REQUIRED"
    COMPLETED = "COMPLETED"
    STOPPED = "STOPPED"
    FAILED = "FAILED"


@dataclass(frozen=True)
class Metadata:
    name: str
    version: str
    start: str
    transitions: Mapping[str, tuple[str, ...]]
    terminal: frozenset[str]
    pure: bool = True

    def __post_init__(self) -> None:
        if not self.name or not self.version or not self.start:
            raise ContractError("operation identity and start checkpoint required")
        if not self.pure:
            raise ContractError("FD registry accepts pure operations only; use an effect owner")
        if not self.terminal:
            raise ContractError("at least one terminal checkpoint required")
        if self.start in self.terminal:
            raise ContractError("start cannot be terminal")
        allowed = {self.start, *self.transitions.keys(),
                   *(dest for seq in self.transitions.values() for dest in seq)}
        if not self.terminal <= allowed:
            raise ContractError("terminal checkpoint not in transition graph")
        # Protect registered contracts against caller mutation after registration.
        frozen_graph = {str(k): tuple(v) for k, v in self.transitions.items()}
        object.__setattr__(self, "transitions", MappingProxyType(frozen_graph))

    @property
    def identity(self) -> str:
        return f"{self.name}@{self.version}"

    def allows(self, source: str, dest: str) -> bool:
        return dest in self.transitions.get(source, ())


@dataclass
class JsonData:
    payload: dict[str, Any]
    checkpoint: str = "START"

    def __post_init__(self) -> None:
        if not isinstance(self.payload, dict):
            raise ContractError("JsonData.payload must be an object")
        self.payload = strict_json_copy(self.payload)
        if not isinstance(self.checkpoint, str) or not self.checkpoint:
            raise ContractError("checkpoint must be a nonempty string")

    def snapshot(self) -> dict[str, Any]:
        return strict_json_copy(self.payload)


@dataclass(frozen=True)
class Step:
    next_checkpoint: str | None = None
    patch: Mapping[str, Any] = field(default_factory=dict)
    intent: Intent = Intent.YIELD
    diagnostic: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "patch", strict_json_copy(dict(self.patch)))
        if not isinstance(self.intent, Intent):
            raise ContractError("invalid intent")


@dataclass(frozen=True)
class FunctionPair:
    metadata: Metadata
    data_type: type[JsonData]
    function: Callable[[JsonData], Step]

    def __post_init__(self) -> None:
        if self.data_type is JsonData or not issubclass(self.data_type, JsonData):
            raise ContractError("each function needs a DEDICATED JsonData subclass")
        if not callable(self.function):
            raise ContractError("operation must be callable")
        # Runtime counterpart to the original framework's function/data typing rule.
        signature = inspect.signature(self.function)
        parameters = list(signature.parameters.values())
        if len(parameters) != 1 or parameters[0].kind not in (inspect.Parameter.POSITIONAL_ONLY,
                                                                  inspect.Parameter.POSITIONAL_OR_KEYWORD):
            raise ContractError("function must accept exactly one data parameter")
        try:
            annotation = get_type_hints(self.function).get(parameters[0].name)
        except (NameError, TypeError):
            annotation = None
        if annotation is not self.data_type:
            raise ContractError("function input annotation must match dedicated data class")


class ContractCatalog:
    """One-to-one ownership of registered callables and data classes."""
    def __init__(self) -> None:
        self._pairs: dict[str, FunctionPair] = {}
        self._classes: set[type[JsonData]] = set()
        self._functions: set[Callable[..., Any]] = set()

    def register(self, pair: FunctionPair) -> None:
        key = pair.metadata.identity
        if key in self._pairs or pair.data_type in self._classes or pair.function in self._functions:
            raise ContractError("duplicate contract, data class, or function registration")
        self._pairs[key] = pair
        self._classes.add(pair.data_type)
        self._functions.add(pair.function)

    def resolve(self, identity: str) -> FunctionPair:
        try:
            return self._pairs[identity]
        except KeyError as exc:
            raise ContractError(f"unknown contract: {identity}") from exc

    def identities(self) -> tuple[str, ...]:
        return tuple(sorted(self._pairs))


@dataclass(frozen=True)
class Job:
    job_id: str
    contract: str
    checkpoint: str
    payload: dict[str, Any]
    revision: int
    status: Status
    diagnostic: str


class SQLiteJobStore:
    """Durable FD state: optimistic CAS for revisions, append-only event trail.

    Uses one SQLite DB for FD computational state only; it MUST NOT be treated as
    an authority ledger for external resource writes.
    """
    def __init__(self, path: str | Path):
        self.path = str(path)
        with self._connect() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY, contract TEXT NOT NULL,
                checkpoint TEXT NOT NULL, payload TEXT NOT NULL,
                revision INTEGER NOT NULL, status TEXT NOT NULL,
                diagnostic TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS events (
                job_id TEXT NOT NULL, revision INTEGER NOT NULL,
                checkpoint TEXT NOT NULL, status TEXT NOT NULL,
                payload_hash TEXT NOT NULL, diagnostic TEXT NOT NULL,
                PRIMARY KEY(job_id, revision)
            );
            CREATE TABLE IF NOT EXISTS acceptances (
                job_id TEXT NOT NULL, revision INTEGER NOT NULL,
                observer TEXT NOT NULL, evidence_hash TEXT NOT NULL,
                PRIMARY KEY(job_id, revision)
            );
            """)

    def _connect(self):
        return sql_conn(self.path)

    def create(self, pair: FunctionPair, payload: Mapping[str, Any], *, job_id: str | None = None) -> Job:
        obj = pair.data_type(payload=dict(payload), checkpoint=pair.metadata.start)
        identity = pair.metadata.identity
        job_id = job_id or str(uuid.uuid4())
        encoded = json.dumps(obj.snapshot(), sort_keys=True)
        with self._connect() as db:
            db.execute("INSERT INTO jobs VALUES(?,?,?,?,?,?,?)",
                       (job_id, identity, pair.metadata.start, encoded, 0, Status.NEW.value, ""))
            db.execute("INSERT INTO events VALUES(?,?,?,?,?,?)",
                       (job_id, 0, pair.metadata.start, Status.NEW.value,
                        canonical_hash(obj.payload), ""))
        return self.get(job_id)

    def get(self, job_id: str) -> Job:
        with self._connect() as db:
            row = db.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        if row is None:
            raise KeyError(job_id)
        return Job(row[0], row[1], row[2], json.loads(row[3]), row[4], Status(row[5]), row[6])

    def commit(self, before: Job, checkpoint: str, payload: dict[str, Any],
               status: Status, diagnostic: str = "") -> Job:
        data = strict_json_copy(payload)
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            cursor = db.execute("""UPDATE jobs SET checkpoint=?, payload=?, revision=?,
                            status=?, diagnostic=? WHERE job_id=? AND revision=? AND status=?""",
                  (checkpoint, json.dumps(data, sort_keys=True), before.revision + 1,
                   status.value, diagnostic, before.job_id, before.revision, before.status.value))
            if cursor.rowcount != 1:
                raise ConcurrencyError("stale job revision; another worker has committed")
            db.execute("INSERT INTO events VALUES(?,?,?,?,?,?)",
                       (before.job_id, before.revision + 1, checkpoint, status.value,
                        canonical_hash(data), diagnostic))
        return self.get(before.job_id)

    def history(self, job_id: str) -> list[tuple[int, str, str]]:
        with self._connect() as db:
            rows = db.execute("SELECT revision,checkpoint,status FROM events WHERE job_id=? ORDER BY revision", (job_id,)).fetchall()
        return [(int(a), b, c) for a, b, c in rows]


class ExecutionRegistry:
    """Execute pure FunctionPairs and atomically commit *proposed* state changes."""
    def __init__(self, catalog: ContractCatalog, store: SQLiteJobStore,
                 state_guard: Callable[[Job, Mapping[str, Any]], None] | None = None):
        self.catalog = catalog
        self.store = store
        # Optional veto before each durable transition; a guard may inspect
        # pinned, versioned type constraints. No independent authority is implied.
        self.state_guard = state_guard

    def create(self, contract: str, payload: Mapping[str, Any]) -> Job:
        return self.store.create(self.catalog.resolve(contract), payload)

    def advance(self, job_id: str, *, expected_revision: int | None = None,
                parameters: Mapping[str, Any] | None = None) -> Job:
        before = self.store.get(job_id)
        if expected_revision is not None and expected_revision != before.revision:
            raise ConcurrencyError("expected revision mismatch")
        if before.status not in (Status.NEW, Status.YIELDED, Status.PARAMETERS_REQUIRED):
            raise ContractError(f"cannot advance terminal job: {before.status.value}")
        pair = self.catalog.resolve(before.contract)
        payload = strict_json_copy(before.payload)
        if before.status is Status.PARAMETERS_REQUIRED:
            if parameters is None:
                raise ContractError("explicit parameters are required")
            payload.update(strict_json_copy(dict(parameters)))
        elif parameters is not None:
            raise ContractError("parameters may only be supplied on a PARAMETER checkpoint")
        data = pair.data_type(payload=payload, checkpoint=before.checkpoint)
        try:
            step = pair.function(data)
            if type(step) is not Step:
                raise ContractError("function must return Step")
            if step.intent in (Intent.ERROR, Intent.STOP):
                if step.patch or (step.next_checkpoint not in (None, before.checkpoint)):
                    raise ContractError("terminal stop/error cannot modify state")
                status = Status.FAILED if step.intent is Intent.ERROR else Status.STOPPED
                return self.store.commit(before, before.checkpoint, before.payload, status, step.diagnostic)
            next_cp = step.next_checkpoint
            if not isinstance(next_cp, str) or not pair.metadata.allows(before.checkpoint, next_cp):
                raise ContractError(f"illegal transition: {before.checkpoint} -> {next_cp}")
            is_terminal = next_cp in pair.metadata.terminal
            if step.intent is Intent.COMPLETE and not is_terminal:
                raise ContractError("COMPLETE requires terminal checkpoint")
            if step.intent is not Intent.COMPLETE and is_terminal:
                raise ContractError("terminal checkpoint requires COMPLETE")
            updated = strict_json_copy({**payload, **dict(step.patch)})
            if self.state_guard is not None:
                self.state_guard(before, updated)
            status = {Intent.YIELD: Status.YIELDED, Intent.PARAMETER: Status.PARAMETERS_REQUIRED,
                      Intent.COMPLETE: Status.COMPLETED}[step.intent]
            return self.store.commit(before, next_cp, updated, status, step.diagnostic)
        except ConcurrencyError:
            raise
        except Exception as exc:
            # Invalid steps and unexpected failures are recorded, never accepted.
            try:
                self.store.commit(before, before.checkpoint, before.payload,
                                  Status.FAILED, f"{type(exc).__name__}: {exc}")
            except ConcurrencyError:
                raise
            raise


@dataclass(frozen=True)
class Evidence:
    job_id: str
    revision: int
    observer: str
    claim_by: str
    observations: Mapping[str, Any]


class AcceptanceGateway:
    """Computational completion != accepted outcome.

    The verifier must be chosen/operated outside the worker. This is an API
    separation, not a sandbox protecting against malicious in-process Python.
    """
    def __init__(self, store: SQLiteJobStore):
        self.store = store

    def evaluate(self, evidence: Evidence,
                 verifier: Callable[[Job, Mapping[str, Any]], bool]) -> bool:
        job = self.store.get(evidence.job_id)
        if job.status is not Status.COMPLETED:
            raise AcceptanceError("operation not complete")
        if evidence.revision != job.revision:
            raise AcceptanceError("stale evidence revision")
        if not evidence.observer or evidence.observer == evidence.claim_by:
            raise AcceptanceError("observer must be independent of claimant")
        observation = strict_json_copy(dict(evidence.observations))
        if not bool(verifier(job, observation)):
            return False
        with self.store._connect() as db:
            # A completed job is terminal; no successful concurrent state change is allowed.
            db.execute("INSERT OR IGNORE INTO acceptances VALUES(?,?,?,?)",
                       (job.job_id, job.revision, evidence.observer, canonical_hash(observation)))
        return True

    def accepted(self, job_id: str) -> bool:
        job = self.store.get(job_id)
        with self.store._connect() as db:
            row = db.execute("SELECT 1 FROM acceptances WHERE job_id=? AND revision=?",
                             (job_id, job.revision)).fetchone()
        return bool(row)


@dataclass(frozen=True)
class RecoveryAdvice:
    proposed_action: str
    reason: str
    requires_approval: bool = True


class DomainSupervisor:
    """Rule-based reflection; diagnosis does not grant execution authority."""
    def inspect(self, job: Job, *, external_effect_uncertain: bool = False) -> RecoveryAdvice:
        if external_effect_uncertain:
            return RecoveryAdvice("HALT_AND_RECONCILE", "external effect outcome unknown")
        if job.status is Status.FAILED:
            return RecoveryAdvice("REQUEST_OPERATOR_RECOVERY", job.diagnostic or "failed job")
        if job.status is Status.PARAMETERS_REQUIRED:
            return RecoveryAdvice("REQUEST_PARAMETERS", "operation requires new inputs")
        if job.status is Status.COMPLETED:
            return RecoveryAdvice("VERIFY_ACCEPTANCE", "computation alone is not acceptance")
        if job.status is Status.STOPPED:
            return RecoveryAdvice("HALT", "operation deliberately stopped")
        return RecoveryAdvice("CONTINUE_CHECKED", "checkpoint transition available")


@dataclass(frozen=True)
class RecoveryPermit:
    job_id: str
    expected_revision: int
    operator_id: str
    reason: str


class RecoveryManager:
    """Host-governed retry of a failed PURE computation.

    A trusted external check must validate the permit; the caller's string
    operator_id is not an authentication mechanism. Never use this for an
    uncertain external effect or for a computation that can create effects.
    """
    def __init__(self, store: SQLiteJobStore,
                 authorize: Callable[[RecoveryPermit], bool]):
        self.store = store
        self.authorize = authorize

    def recover(self, permit: RecoveryPermit, *, corrected_input: Mapping[str, Any] | None = None,
                external_effect_uncertain: bool = False) -> Job:
        if external_effect_uncertain:
            raise ContractError("unresolved external effect forbids recovery")
        current = self.store.get(permit.job_id)
        if current.revision != permit.expected_revision:
            raise ConcurrencyError("stale recovery permit")
        if current.status is not Status.FAILED:
            raise ContractError("only failed computations can be recovered")
        if not permit.operator_id or not permit.reason or not self.authorize(permit):
            raise ContractError("recovery requires independent authorization")
        fixed = {**current.payload, **strict_json_copy(dict(corrected_input or {}))}
        # No progression or effect occurs here; a subsequent execution is explicit.
        return self.store.commit(current, current.checkpoint, fixed, Status.YIELDED,
                                 f"authorized recovery: {permit.reason}")
