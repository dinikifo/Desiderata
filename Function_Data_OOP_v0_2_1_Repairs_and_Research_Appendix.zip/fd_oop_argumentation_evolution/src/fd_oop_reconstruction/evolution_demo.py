"""End-to-end demo of argumentation-governed gradual type refinement.

Shows a real FD-agent prepare/seal task governed by a refined schema and
NATIVE-controlled effect, plus read-only cross-method reflection.
"""
from __future__ import annotations

import json
from pathlib import Path
from tempfile import TemporaryDirectory

from .agentic import (FDAgent, Goal, GoalAssignments, IndependentOutcomeOracle,
                      NativeAuthority, VaultOwner, build_agent_catalog)
from .distillation import ReflectionDistiller
from .knowledge import KnowledgeLedger
from .evolution import EvolutionLedger, TypeEvolutionController
from .evolution_agent import AgenticEvolutionService, agentic_evolution_controller
from .original import JsonData, Step, Intent, FunctionPair, Metadata


class SourceAuditData(JsonData):
    """Second dedicated Function–Data class used for cross-method comparison."""


def audit_source(data: SourceAuditData) -> Step:
    return Step("DONE", {"checked_revision": data.payload["source_revision"]}, Intent.COMPLETE)


ARGUMENT = {
    "argument_id": "arg-support-1",
    "claim": "Source-bound operations should require an integer source revision.",
    "grounds": ["Resource owners publish nonnegative integer revisions in this prototype."],
    "warrant": "A typed revision permits reproducible source-pin comparisons.",
    "backing": ["Agentic source-pin and owner-receipt regression tests."],
    "qualifier": "Applies to these source-bound contracts, subject to owner semantics.",
    "rebuttals": ["Other resource owners may use opaque string revisions."],
    "evidence_refs": ["tests/test_agentic.py", "tests/test_evolution.py"],
}
COUNTERARGUMENT = {
    "argument_id": "arg-oppose-1", "stance": "oppose", "responds_to": "arg-support-1",
    "claim": "An integer-only type may exclude other resource-owner revision formats.",
    "grounds": ["Some external systems use opaque identifiers rather than integers."],
    "warrant": "Constraints that exclude valid producers are not universally interoperable.",
    "backing": ["The revision format belongs to its resource owner."],
    "qualifier": "Applies to heterogeneous source ecosystems.",
    "rebuttals": ["This prototype's owner presently issues integer revisions."],
    "evidence_refs": ["design:source-owner-contract"],
}


def run(root: Path) -> dict:
    catalog = build_agent_catalog()
    catalog.register(FunctionPair(Metadata("example.source_audit", "1", "START",
                        {"START": ("DONE",)}, frozenset({"DONE"})),
                        SourceAuditData, audit_source))
    ledger = EvolutionLedger(str(root / "evolution.db"))
    assignments = GoalAssignments(root / "assignments.db")
    assignments.assign("research-agent", "goal-archive", "operator")
    controller = agentic_evolution_controller(catalog, ledger, assignments,
                authorize_review=lambda reviewer, proposal: reviewer == "operator")
    shared_start = {"type": "object", "properties": {"source_revision": {"type": "any"}},
                    "required": ["source_revision"]}
    ctrl = controller
    ctrl.register_object("agent-prepare", "fd_agent.prepare_work@0.1.0",
                         {"source_revision": 1}, shared_start,
                         description="Agent's prepare-work object")
    ctrl.register_object("source-audit", "example.source_audit@1",
                         {"source_revision": 1}, shared_start,
                         description="Independent source audit operation")
    reflect = ReflectionDistiller(catalog, ledger)
    agent_evolution = AgenticEvolutionService("research-agent", assignments, ctrl, reflect)
    proposals = []
    decisions = []
    for oid in ("agent-prepare", "source-audit"):
        obj = ledger.get(oid)
        new_meta = obj.metadata
        new_meta["schema"]["properties"]["source_revision"] = {"type": "integer", "minimum": 1}
        p = agent_evolution.propose_for_goal("goal-archive", oid, expected_revision=0,
              arguments=[ARGUMENT, COUNTERARGUMENT], data={"source_revision": 1}, metadata=new_meta,
              notes=["Retain the untyped prior schema as a historical snapshot.",
                     "Never allow the agent to approve its own proposal."])
        proposals.append(p.proposal_id)
        decisions.append(ctrl.review(p.proposal_id, reviewer="operator", approve=True,
                                     reason="independent schema validation and authorized review"))
    # The same existing FD agent executes through a schema-pinned facade.
    vault = VaultOwner(root / "vault.db")
    pin = vault.put_note("source", "ARCHIVAL FACT: provisional testimony")
    goal = Goal("goal-archive", "Preserve source-bound archival record", "source",
                "result-note", "ARCHIVAL FACT")
    agent = FDAgent("research-agent", root / "fd.db", assignments,
                    evolution_ledger=ledger, evolving_object_id="agent-prepare")
    initial = agent.start(goal, pin)
    agent.resume(initial.job_id)
    sealed = agent.resume(initial.job_id)
    proposal = agent.proposal(sealed.job_id)
    native = NativeAuthority(root / "native.db", vault, assignments, agent.store)
    # Host/operator does this: FD agent has NO approve/execute effect method.
    approval = native.operator_approve(proposal, operator_id="operator")
    effect = native.execute(proposal, approval)
    verdict = IndependentOutcomeOracle(vault).review(goal, proposal, effect)
    report = reflect.reflect()
    # Distilled ideas do NOT automatically become schema rules. Persist one
    # candidate for explicitly independent evaluation and optional acceptance.
    knowledge = KnowledgeLedger(str(root / "knowledge.db"), ledger,
                    authorize_review=lambda reviewer, proposal: reviewer == "operator")
    knowledge_proposal = knowledge.propose(report.candidates[1], proposer="research-agent")
    knowledge_decision = knowledge.review(knowledge_proposal.submission_id,
                         reviewer="operator", approve=True,
                         rationale="Prototype evidence and test references reviewed",
                         test_refs=("tests/test_evolution.py::test_cross_method_repeated_claim_candidate",))
    return {
        "object_revisions": {o.object_id: o.revision for o in ledger.objects()},
        "accepted_evolution_decisions": [d.status for d in decisions],
        "first_evolution_before_and_after": {
            "before": ledger.history("agent-prepare")[0]["before"],
            "after": ledger.history("agent-prepare")[0]["after"],
            "arguments": ledger.history("agent-prepare")[0]["arguments"],
            "notes": ledger.history("agent-prepare")[0]["notes"],
        },
        "history_chain_valid": {o.object_id: bool(ledger.verify_history(o.object_id)) for o in ledger.objects()},
        "history_verdicts": {o.object_id: {"status": ledger.verify_history(o.object_id).status.value,
                                           "detail": ledger.verify_history(o.object_id).detail}
                             for o in ledger.objects()},
        "pinned_job_object_revision": ledger.job_binding(initial.job_id)[1],
        "fd_checkpoints": agent.store.history(initial.job_id),
        "native_effect": effect.status.value,
        "independent_goal_assessment": verdict.assessment.value,
        "distilled_candidate_knowledge": [k.as_json() for k in report.candidates],
        "reviewed_knowledge_decision": knowledge_decision.status,
        "accepted_knowledge_count": len(knowledge.accepted()),
    }


def main():
    with TemporaryDirectory() as temp:
        print(json.dumps(run(Path(temp)), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
