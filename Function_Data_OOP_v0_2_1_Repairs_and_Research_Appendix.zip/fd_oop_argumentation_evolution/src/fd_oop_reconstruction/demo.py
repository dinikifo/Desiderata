"""Run: python -m fd_oop_reconstruction.demo original | agentic"""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import sys

from .original import (JsonData, Step, Intent, Metadata, FunctionPair, ContractCatalog,
                       SQLiteJobStore, ExecutionRegistry, AcceptanceGateway, Evidence)
from .agentic import (VaultOwner, GoalAssignments, FDAgent, NativeAuthority,
                      Goal, IndependentOutcomeOracle, MethodMemory)


class SquareData(JsonData):
    pass


def compute_square(data: SquareData) -> Step:
    return Step('DONE', {'result': data.payload['number']**2}, Intent.COMPLETE)


def run_original(root: Path) -> dict:
    catalog=ContractCatalog()
    catalog.register(FunctionPair(Metadata('math.square','1.0','START',
                      {'START': ('DONE',)},frozenset({'DONE'})),SquareData,compute_square))
    store=SQLiteJobStore(root/'original.db')
    engine=ExecutionRegistry(catalog,store)
    job=engine.create('math.square@1.0',{'number':7})
    done=engine.advance(job.job_id)
    independently_accepted=AcceptanceGateway(store).evaluate(
        Evidence(job.job_id,done.revision,'independent-checker','square-worker',{'expected':49}),
        lambda j,e: j.payload['result']==e['expected'])
    return {'contract':done.contract,'checkpoint_history':store.history(job.job_id),
            'payload':done.payload,'computed':done.status.value,
            'independently_accepted':independently_accepted}


def run_agentic(root: Path) -> dict:
    vault=VaultOwner(root/'vault.db')
    assignments=GoalAssignments(root/'assignments.db')
    agent=FDAgent('research-agent',root/'fd-agent.db',assignments)
    native=NativeAuthority(root/'native.db',vault,assignments,agent.store)
    memory=MethodMemory(root/'methods.db')
    goal=Goal('verify-archival-note','Prepare and publish a source-bound note',
              'source','result-note', 'ARCHIVAL FACT')
    pin=vault.put_note('source','ARCHIVAL FACT: evidence remains provisional')
    assignments.assign('research-agent',goal.goal_id,'research-operator')
    initial=agent.start(goal,pin)
    prepared=agent.resume(initial.job_id)
    sealed=agent.resume(initial.job_id)
    proposal=agent.proposal(sealed.job_id)
    # NOTE: a host/operator performs this step. The FD agent cannot approve itself.
    approval=native.operator_approve(proposal,operator_id='research-operator')
    attempt=native.execute(proposal,approval,simulate_crash_after_commit=True)
    reconciled=native.reconcile(attempt.attempt_id)
    outcome=IndependentOutcomeOracle(vault).review(goal,proposal,reconciled)
    memory.record(agent.agent_id,goal.goal_id,sealed.job_id,outcome)
    return {'agent':agent.agent_id,'fd_checkpoints':agent.store.history(initial.job_id),
            'first_native_effect_status':attempt.status.value,
            'reconciled_effect_status':reconciled.status.value,
            'independent_goal_assessment':outcome.assessment.value,
            'reason':outcome.grounds,
            'recorded_goal_history':memory.history(agent.agent_id),
            'published_artifact':vault.read_note('result-note').content}


def main():
    if len(sys.argv)!=2 or sys.argv[1] not in {'original','agentic','evolution'}:
        raise SystemExit('usage: python -m fd_oop_reconstruction.demo original|agentic|evolution')
    with TemporaryDirectory() as temp:
        if sys.argv[1] == 'evolution':
            from .evolution_demo import run as run_evolution
            result = run_evolution(Path(temp))
        else:
            result=(run_original if sys.argv[1]=='original' else run_agentic)(Path(temp))
        print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
