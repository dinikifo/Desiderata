"""Research reconstruction of a governed Function–Data agentic architecture.

The agent prepares work with pure Function–Data operations. A separately
instantiated native authority decides if an external effect may occur. The
resource owner attests writes and an independent oracle assesses outcomes.
This is a single-process educational design, NOT a production security sandbox.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
import json
from pathlib import Path
import secrets
import sqlite3
from typing import Any
import uuid

from .original import (
    AcceptanceGateway, ContractCatalog, ContractError, ExecutionRegistry,
    FunctionPair, Intent, Job, JsonData, Metadata, SQLiteJobStore, Status,
    Step, canonical_hash, sql_conn,
)


class AuthorityError(RuntimeError):
    pass


class SourceChanged(AuthorityError):
    pass


class EffectUncertain(AuthorityError):
    pass


@dataclass(frozen=True)
class SourcePin:
    note_id: str
    revision: int
    digest: str
    content: str


@dataclass(frozen=True)
class Receipt:
    effect_id: str
    target_id: str
    target_revision: int
    target_digest: str
    source_id: str
    source_revision: int
    source_digest: str


class VaultOwner:
    """Authoritative note source and owner-transactional, idempotent effect receipt.

    Host-operated put_note() is a fixture for creating source data. The agent
    cannot obtain a write capability from its own FD execution registry.
    """
    def __init__(self, path: str | Path):
        self.path = str(path)
        with self._db() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS notes (
                note_id TEXT PRIMARY KEY, revision INTEGER NOT NULL,
                content TEXT NOT NULL, digest TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS receipts (
                effect_id TEXT PRIMARY KEY, target_id TEXT NOT NULL,
                target_revision INTEGER NOT NULL, target_digest TEXT NOT NULL,
                source_id TEXT NOT NULL, source_revision INTEGER NOT NULL,
                source_digest TEXT NOT NULL
            );
            """)

    def _db(self):
        return sql_conn(self.path)

    @staticmethod
    def _digest(content: str) -> str:
        return hashlib.sha256(content.encode('utf-8')).hexdigest()

    def put_note(self, note_id: str, content: str) -> SourcePin:
        """Fixture/operator-owned source modification, not an agent tool."""
        if not note_id or not isinstance(content, str):
            raise ValueError("invalid note")
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            old = db.execute("SELECT revision FROM notes WHERE note_id=?", (note_id,)).fetchone()
            revision = old[0] + 1 if old else 1
            db.execute("INSERT OR REPLACE INTO notes VALUES (?,?,?,?)",
                       (note_id, revision, content, self._digest(content)))
        return self.read_note(note_id)

    def read_note(self, note_id: str) -> SourcePin:
        with self._db() as db:
            row = db.execute("SELECT revision,digest,content FROM notes WHERE note_id=?", (note_id,)).fetchone()
        if row is None:
            raise KeyError(note_id)
        return SourcePin(note_id, int(row[0]), row[1], row[2])

    def assert_current(self, pin: SourcePin) -> None:
        try:
            current = self.read_note(pin.note_id)
        except KeyError as exc:
            raise SourceChanged("pinned source missing") from exc
        if (current.revision, current.digest) != (pin.revision, pin.digest):
            raise SourceChanged("source revision/content changed")

    def get_receipt(self, effect_id: str) -> Receipt | None:
        with self._db() as db:
            row = db.execute("SELECT * FROM receipts WHERE effect_id=?", (effect_id,)).fetchone()
        return Receipt(*row) if row else None

    def publish(self, effect_id: str, target_id: str, text: str, source: SourcePin,
                *, simulate_crash_after_commit: bool = False) -> Receipt:
        """Owner-only resource effect, source revalidation and receipt in ONE transaction."""
        if not effect_id or not target_id or source.note_id == target_id:
            raise AuthorityError("invalid effect or target")
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            old_receipt = db.execute("SELECT * FROM receipts WHERE effect_id=?", (effect_id,)).fetchone()
            if old_receipt:
                if old_receipt[1] != target_id or old_receipt[3] != self._digest(text):
                    raise AuthorityError("idempotency key reused for a different effect")
                receipt = Receipt(*old_receipt)
            else:
                row = db.execute("SELECT revision,digest FROM notes WHERE note_id=?", (source.note_id,)).fetchone()
                if row is None or (int(row[0]), row[1]) != (source.revision, source.digest):
                    raise SourceChanged("source changed while owner was admitting the write")
                if db.execute("SELECT 1 FROM notes WHERE note_id=?", (target_id,)).fetchone():
                    raise AuthorityError("target already exists; no silent overwrite")
                digest = self._digest(text)
                db.execute("INSERT INTO notes VALUES(?,?,?,?)", (target_id, 1, text, digest))
                db.execute("INSERT INTO receipts VALUES(?,?,?,?,?,?,?)",
                           (effect_id, target_id, 1, digest,
                            source.note_id, source.revision, source.digest))
                receipt = Receipt(effect_id, target_id, 1, digest,
                                  source.note_id, source.revision, source.digest)
        if simulate_crash_after_commit:
            raise EffectUncertain("simulated exception after owner committed")
        return receipt


@dataclass(frozen=True)
class Goal:
    goal_id: str
    description: str
    source_id: str
    target_id: str
    required_text: str = ""


class GoalAssignments:
    """Host-governed, durable identities and goal assignments, not self-approval."""
    def __init__(self, path: str | Path):
        self.path = str(path)
        with sql_conn(self.path) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS assignments (
                agent_id TEXT NOT NULL, goal_id TEXT NOT NULL,
                revision INTEGER NOT NULL, operator_id TEXT NOT NULL,
                active INTEGER NOT NULL, PRIMARY KEY(agent_id, goal_id)
            )""")

    def assign(self, agent_id: str, goal_id: str, operator_id: str) -> None:
        if not all((agent_id, goal_id, operator_id)):
            raise AuthorityError("host assignment requires agent, goal and operator")
        with sql_conn(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT revision FROM assignments WHERE agent_id=? AND goal_id=?",
                             (agent_id, goal_id)).fetchone()
            rev = int(row[0]) + 1 if row else 1
            db.execute("INSERT OR REPLACE INTO assignments VALUES(?,?,?,?,1)",
                       (agent_id, goal_id, rev, operator_id))

    def revoke(self, agent_id: str, goal_id: str) -> None:
        with sql_conn(self.path) as db:
            db.execute("UPDATE assignments SET active=0,revision=revision+1 WHERE agent_id=? AND goal_id=?",
                       (agent_id, goal_id))

    def require_active(self, agent_id: str, goal_id: str) -> int:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT revision,active FROM assignments WHERE agent_id=? AND goal_id=?",
                             (agent_id, goal_id)).fetchone()
        if not row or not row[1]:
            raise AuthorityError("agent has no active host-issued assignment")
        return int(row[0])


class PrepareWorkData(JsonData):
    """Dedicated data class for fd_agent.prepare_work@0.1.0."""


def prepare_work(data: PrepareWorkData) -> Step:
    """Pure, two-checkpoint agent planning operation; cannot perform effects."""
    p = data.snapshot()
    if data.checkpoint == "NEW":
        for key in ("goal_id", "agent_id", "source_id", "source_revision", "source_digest",
                    "source_content", "target_id", "assignment_revision"):
            if key not in p:
                return Step(intent=Intent.ERROR, diagnostic=f"missing {key}")
        draft = (f"Goal: {p['goal_id']}\n"
                 f"Source: {p['source_id']}@{p['source_revision']} ({p['source_digest']})\n"
                 f"Recorded excerpt:\n{p['source_content']}\n")
        return Step("PREPARED", {"draft": draft,
                                 "draft_digest": hashlib.sha256(draft.encode()).hexdigest()},
                    Intent.YIELD, "prepared source-bound draft")
    if data.checkpoint == "PREPARED":
        if hashlib.sha256(p["draft"].encode()).hexdigest() != p["draft_digest"]:
            return Step(intent=Intent.ERROR, diagnostic="prepared draft hash mismatch")
        return Step("SEALED", {"sealed": True}, Intent.COMPLETE, "computational work sealed")
    return Step(intent=Intent.ERROR, diagnostic="unexpected checkpoint")


def build_agent_catalog() -> ContractCatalog:
    catalog = ContractCatalog()
    catalog.register(FunctionPair(
        Metadata("fd_agent.prepare_work", "0.1.0", "NEW",
                 {"NEW": ("PREPARED",), "PREPARED": ("SEALED",)},
                 frozenset({"SEALED"})),
        PrepareWorkData, prepare_work))
    return catalog


@dataclass(frozen=True)
class Proposal:
    agent_id: str
    goal_id: str
    assignment_revision: int
    fd_job_id: str
    fd_revision: int
    source_id: str
    source_revision: int
    source_digest: str
    target_id: str
    draft: str
    draft_digest: str

    @property
    def identity(self) -> str:
        return canonical_hash(vars(self))

    def source_pin(self, vault: VaultOwner) -> SourcePin:
        """Bind previously checked revision and digest to the CURRENT source."""
        current = vault.read_note(self.source_id)
        if (current.revision, current.digest) != (self.source_revision, self.source_digest):
            raise SourceChanged("proposal pins stale source")
        return current


class FDAgent:
    """Can compute and PROPOSE; has no authority/owner mutation methods."""
    def __init__(self, agent_id: str, fd_db: str | Path, assignments: GoalAssignments,
                 *, evolution_ledger=None, evolving_object_id: str | None = None):
        self.agent_id = agent_id
        self.assignments = assignments
        self.store = SQLiteJobStore(fd_db)
        self.registry = ExecutionRegistry(build_agent_catalog(), self.store)
        if (evolution_ledger is None) != (evolving_object_id is None):
            raise ContractError("evolution ledger and evolving object ID must be supplied together")
        self.evolving = None
        self.evolving_object_id = evolving_object_id
        if evolution_ledger is not None:
            from .evolution import VersionedExecutionRegistry
            bound = evolution_ledger.get(evolving_object_id)
            if bound.contract != "fd_agent.prepare_work@0.1.0":
                raise ContractError("agent evolution object must match prepare_work contract")
            self.evolving = VersionedExecutionRegistry(self.registry.catalog, self.store,
                                                       evolution_ledger)

    def start(self, goal: Goal, source: SourcePin) -> Job:
        assignment_revision = self.assignments.require_active(self.agent_id, goal.goal_id)
        if goal.source_id != source.note_id:
            raise ContractError("goal and source disagree")
        inputs = {
            "agent_id": self.agent_id,
            "goal_id": goal.goal_id,
            "assignment_revision": assignment_revision,
            "source_id": source.note_id,
            "source_revision": source.revision,
            "source_digest": source.digest,
            "source_content": source.content,
            "target_id": goal.target_id,
        }
        if self.evolving is not None:
            return self.evolving.create_for_object(self.evolving_object_id, payload=inputs)
        return self.registry.create("fd_agent.prepare_work@0.1.0", inputs)

    def resume(self, job_id: str) -> Job:
        job = self.store.get(job_id)
        self.assignments.require_active(self.agent_id, job.payload['goal_id'])
        if job.payload['agent_id'] != self.agent_id:
            raise AuthorityError("agent identity mismatch")
        if self.assignments.require_active(self.agent_id, job.payload['goal_id']) != job.payload['assignment_revision']:
            raise AuthorityError("goal assignment has changed; reject stale work")
        if self.evolving is not None:
            return self.evolving.advance(job_id, expected_revision=job.revision)
        return self.registry.advance(job_id, expected_revision=job.revision)

    def proposal(self, job_id: str) -> Proposal:
        job = self.store.get(job_id)
        if job.status is not Status.COMPLETED or job.checkpoint != "SEALED":
            raise ContractError("only sealed FD computation can produce a proposal")
        p = job.payload
        if p['agent_id'] != self.agent_id:
            raise AuthorityError("wrong agent")
        if self.assignments.require_active(self.agent_id, p['goal_id']) != p['assignment_revision']:
            raise AuthorityError("assignment revision no longer current")
        if not p.get('sealed') or hashlib.sha256(p['draft'].encode()).hexdigest() != p['draft_digest']:
            raise ContractError("draft integrity failure")
        return Proposal(p['agent_id'], p['goal_id'], p['assignment_revision'],
                        job.job_id, job.revision, p['source_id'], p['source_revision'],
                        p['source_digest'], p['target_id'], p['draft'], p['draft_digest'])


class AttemptStatus(str, Enum):
    RESERVED = "RESERVED"
    SUCCESS = "SUCCESS"
    UNKNOWN = "UNKNOWN"
    REJECTED = "REJECTED"


@dataclass(frozen=True)
class Attempt:
    attempt_id: str
    status: AttemptStatus
    proposal_hash: str
    receipt: Receipt | None = None
    diagnostic: str = ""


class NativeAuthority:
    """Native-style admission and ledger; never delegates approval to FDAgent.

    Operator approval is simulated by an explicit host API. This is NOT a
    privilege boundary if hostile code shares this Python process.
    """
    def __init__(self, path: str | Path, vault: VaultOwner,
                 assignments: GoalAssignments, fd_store: SQLiteJobStore):
        self.path = str(path)
        self.vault = vault
        self.assignments = assignments
        self.fd_store = fd_store
        with sql_conn(self.path) as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS approvals (
              token_hash TEXT PRIMARY KEY, proposal_hash TEXT NOT NULL,
              operator_id TEXT NOT NULL, used INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS attempts (
              attempt_id TEXT PRIMARY KEY, proposal_hash TEXT NOT NULL,
              token_hash TEXT NOT NULL UNIQUE, status TEXT NOT NULL,
              diagnostic TEXT NOT NULL, receipt_json TEXT
            );
            """)

    def _verify_proposal(self, proposal: Proposal) -> SourcePin:
        # Host validates exact committed FD computation; proposal alone is not proof.
        try:
            job = self.fd_store.get(proposal.fd_job_id)
        except KeyError as exc:
            raise AuthorityError("FD job does not exist") from exc
        if (job.status is not Status.COMPLETED or job.checkpoint != "SEALED" or
            job.contract != "fd_agent.prepare_work@0.1.0" or
            job.revision != proposal.fd_revision):
            raise AuthorityError("proposal not backed by a sealed FD checkpoint")
        expected = ("agent_id", "goal_id", "assignment_revision", "source_id",
                    "source_revision", "source_digest", "target_id", "draft", "draft_digest")
        if not job.payload.get("sealed") or any(job.payload.get(k) != getattr(proposal, k) for k in expected):
            raise AuthorityError("proposal disagrees with durable FD state")
        rev = self.assignments.require_active(proposal.agent_id, proposal.goal_id)
        if rev != proposal.assignment_revision:
            raise AuthorityError("approval/assignment revision mismatch")
        if hashlib.sha256(proposal.draft.encode()).hexdigest() != proposal.draft_digest:
            raise AuthorityError("draft mismatch")
        if not proposal.target_id or proposal.target_id == proposal.source_id:
            raise AuthorityError("target must differ from source")
        pin = proposal.source_pin(self.vault)
        if job.payload.get("source_content") != pin.content:
            raise AuthorityError("source excerpt is not the owner-attested text")
        return pin

    def operator_approve(self, proposal: Proposal, *, operator_id: str) -> str:
        """HOST ONLY: represent a concrete, independently confirmed authorization."""
        if not operator_id:
            raise AuthorityError("operator identity required")
        self._verify_proposal(proposal)
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with sql_conn(self.path) as db:
            db.execute("INSERT INTO approvals VALUES(?,?,?,0)",
                       (token_hash, proposal.identity, operator_id))
        return token

    def execute(self, proposal: Proposal, approval_token: str,
                *, simulate_crash_after_commit: bool = False) -> Attempt:
        # Source and goal rechecked *before* attempt reservation, and again
        # source pin checked inside the owner's atomic write transaction.
        pin = self._verify_proposal(proposal)
        token_hash = hashlib.sha256(approval_token.encode()).hexdigest()
        with sql_conn(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT proposal_hash, used FROM approvals WHERE token_hash=?",
                             (token_hash,)).fetchone()
            if not row or row[1] or row[0] != proposal.identity:
                raise AuthorityError("invalid, replayed, or mismatched approval")
            db.execute("UPDATE approvals SET used=1 WHERE token_hash=? AND used=0", (token_hash,))
            effect_id = str(uuid.uuid4())  # Native authority owns effect id, not FD
            db.execute("INSERT INTO attempts VALUES(?,?,?,?,?,?)",
                       (effect_id, proposal.identity, token_hash, "RESERVED", "", None))
        try:
            receipt = self.vault.publish(effect_id, proposal.target_id,
                                         proposal.draft, pin,
                                         simulate_crash_after_commit=simulate_crash_after_commit)
        except SourceChanged as exc:
            # Owner confirmed no effect was committed in its transaction.
            return self._set_attempt(effect_id, proposal.identity, AttemptStatus.REJECTED,
                                     None, str(exc))
        except Exception as exc:
            # Never replay an ambiguous external operation automatically.
            return self._set_attempt(effect_id, proposal.identity, AttemptStatus.UNKNOWN,
                                     None, f"{type(exc).__name__}: {exc}")
        return self._set_attempt(effect_id, proposal.identity, AttemptStatus.SUCCESS, receipt)

    def _set_attempt(self, effect_id: str, proposal_hash: str, status: AttemptStatus,
                     receipt: Receipt | None, diagnostic: str = "") -> Attempt:
        with sql_conn(self.path) as db:
            db.execute("UPDATE attempts SET status=?, diagnostic=?, receipt_json=? WHERE attempt_id=?",
                       (status.value, diagnostic, json.dumps(vars(receipt)) if receipt else None, effect_id))
        return Attempt(effect_id, status, proposal_hash, receipt, diagnostic)

    def get_attempt(self, attempt_id: str) -> Attempt:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT proposal_hash,status,diagnostic,receipt_json FROM attempts WHERE attempt_id=?",
                             (attempt_id,)).fetchone()
        if not row:
            raise KeyError(attempt_id)
        return Attempt(attempt_id, AttemptStatus(row[1]), row[0],
                       Receipt(**json.loads(row[3])) if row[3] else None, row[2])

    def reconcile(self, attempt_id: str) -> Attempt:
        """Read-only owner receipt check. No blind replay, no missing-receipt success."""
        attempt = self.get_attempt(attempt_id)
        if attempt.status not in (AttemptStatus.UNKNOWN, AttemptStatus.RESERVED):
            return attempt
        receipt = self.vault.get_receipt(attempt_id)
        if receipt:
            return self._set_attempt(attempt_id, attempt.proposal_hash,
                                     AttemptStatus.SUCCESS, receipt, "reconciled owner receipt")
        if attempt.status is AttemptStatus.RESERVED:
            return self._set_attempt(attempt_id, attempt.proposal_hash,
                                     AttemptStatus.UNKNOWN, None, "reserved attempt without an owner receipt")
        return attempt  # Absence is NOT proof that an external effect never occurred.


class Assessment(str, Enum):
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    INCONCLUSIVE = "INCONCLUSIVE"


@dataclass(frozen=True)
class Outcome:
    assessment: Assessment
    grounds: str


class IndependentOutcomeOracle:
    """Checks owner receipt + artifact + explicit goal predicate; separate authority."""
    def __init__(self, vault: VaultOwner):
        self.vault = vault

    def review(self, goal: Goal, proposal: Proposal, attempt: Attempt) -> Outcome:
        if attempt.status is not AttemptStatus.SUCCESS or attempt.receipt is None:
            return Outcome(Assessment.INCONCLUSIVE, "no confirmed owner effect")
        if (proposal.goal_id != goal.goal_id or proposal.target_id != goal.target_id or
            proposal.source_id != goal.source_id):
            return Outcome(Assessment.REJECTED, "goal/receipt mismatch")
        receipt = self.vault.get_receipt(attempt.attempt_id)
        if receipt != attempt.receipt:
            return Outcome(Assessment.REJECTED, "owner evidence does not match native ledger")
        try:
            target = self.vault.read_note(goal.target_id)
        except KeyError:
            return Outcome(Assessment.REJECTED, "artifact missing")
        if target.digest != receipt.target_digest or target.content != proposal.draft:
            return Outcome(Assessment.REJECTED, "artifact content/revision mismatch")
        if not goal.required_text:
            return Outcome(Assessment.INCONCLUSIVE, "no independently checkable acceptance criterion")
        if goal.required_text not in target.content:
            return Outcome(Assessment.REJECTED, "required goal text absent")
        return Outcome(Assessment.ACCEPTED, "owner receipt and explicit goal predicate verified")


class MethodMemory:
    """Stores method evaluations as EVIDENCE, not self-modifying policy."""
    def __init__(self, path: str | Path):
        self.path = str(path)
        with sql_conn(self.path) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS method_history (
                entry_id TEXT PRIMARY KEY, agent_id TEXT NOT NULL,
                goal_id TEXT NOT NULL, job_id TEXT NOT NULL,
                assessment TEXT NOT NULL, evidence_hash TEXT NOT NULL,
                method TEXT NOT NULL
            )""")

    def record(self, agent_id: str, goal_id: str, job_id: str,
               outcome: Outcome, *, method: str = "source_bound_fd_prepare") -> None:
        with sql_conn(self.path) as db:
            db.execute("INSERT INTO method_history VALUES(?,?,?,?,?,?,?)",
                       (str(uuid.uuid4()), agent_id, goal_id, job_id,
                        outcome.assessment.value, canonical_hash({"assessment": outcome.assessment.value, "grounds": outcome.grounds}), method))

    def history(self, agent_id: str) -> list[tuple[str, str, str]]:
        with sql_conn(self.path) as db:
            rows = db.execute("SELECT goal_id, assessment, method FROM method_history WHERE agent_id=? ORDER BY rowid",
                              (agent_id,)).fetchall()
        return rows
