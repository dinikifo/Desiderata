"""Argumentation-governed, versioned Function–Data object evolution.

A research implementation, NOT a production authorization or dynamic-code sandbox.
The authoritative FunctionPair signature and execution graph remain immutable;
metadata evolution changes a validated JSON *overlay* (schema and descriptions).
Changing executable method semantics requires a NEW registered contract/version.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import json
import re
import sqlite3
from typing import Any, Callable, Mapping
import uuid

from .original import (
    ContractCatalog, ContractError, ConcurrencyError, ExecutionRegistry,
    Job, SQLiteJobStore, canonical_hash, sql_conn, strict_json_copy,
)


class EvolutionError(ContractError):
    """Malformed or refused evolution request."""


class SchemaError(EvolutionError):
    """A type constraint or a JSON value violates a schema."""


class HistoryStatus(str, Enum):
    VERIFIED = "VERIFIED"
    BROKEN = "BROKEN"
    NO_SUCH_OBJECT = "NO_SUCH_OBJECT"
    UNCHECKABLE = "UNCHECKABLE"


@dataclass(frozen=True)
class HistoryVerdict:
    status: HistoryStatus
    detail: str = ""

    def __bool__(self) -> bool:
        # Backward-compatibility bridge only; consumers requiring diagnoses use .status.
        return self.status is HistoryStatus.VERIFIED


class EvolutionDecisionStatus(str, Enum):
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    STALE = "STALE"
    REVIEW_DUE = "REVIEW_DUE"


class ReviewAttemptStatus(str, Enum):
    STARTED = "STARTED"
    AUTHORIZED = "AUTHORIZED"
    REFUSED = "REFUSED"
    UNDETERMINED = "UNDETERMINED"
    CONFLICT = "CONFLICT"
    COMPLETED = "COMPLETED"


def _schema_types(schema: dict[str, Any]) -> set[str]:
    value = schema.get("type", "any")
    raw = {value} if type(value) is str else set(value)
    if "any" in raw:
        return {"object", "array", "string", "integer", "number", "boolean", "null"}
    return raw


def schema_narrows_or_equals(new: dict[str, Any], old: dict[str, Any]) -> bool:
    """Conservative, sound-for-common-subset *sufficient* check, not formal JSON Schema implication.

    False means relaxation OR unproved equivalence. This is intentionally fail-closed
    and invokes a distinct higher-authority review, not automatic refusal forever.
    """
    check_schema(new)
    check_schema(old)
    if new == old:
        return True
    if "enum" in new:
        try:
            return all((validate_json(v, old) is None) for v in new["enum"])
        except SchemaError:
            return False
    if "enum" in old:
        return False
    nt, ot = _schema_types(new), _schema_types(old)
    if not all(t in ot or (t == "integer" and "number" in ot) for t in nt):
        return False
    for lower, upper in (("minimum", "maximum"), ("minLength", "maxLength")):
        if lower in old and (lower not in new or new[lower] < old[lower]):
            return False
        if upper in old and (upper not in new or new[upper] > old[upper]):
            return False
    if "object" in nt:
        old_required, new_required = set(old.get("required", [])), set(new.get("required", []))
        if not old_required.issubset(new_required):
            return False
        op, np = old.get("properties", {}), new.get("properties", {})
        if old.get("additionalProperties", True) is False:
            if new.get("additionalProperties", True) is not False:
                return False
            if set(np) - set(op):
                return False
        for key, old_child in op.items():
            if key not in np:
                # If new excludes the key via additionalProperties=False, that's narrower.
                if new.get("additionalProperties", True) is not False:
                    return False
            elif not schema_narrows_or_equals(np[key], old_child):
                return False
    if "array" in nt and "items" in old:
        if "items" not in new or not schema_narrows_or_equals(new["items"], old["items"]):
            return False
    return True


def _strings(value: Any, label: str, *, nonempty: bool = False) -> tuple[str, ...]:
    if type(value) not in (list, tuple) or (nonempty and not value):
        raise EvolutionError(f"{label} must be a {'nonempty ' if nonempty else ''}list of strings")
    if any(type(s) is not str or not s.strip() for s in value):
        raise EvolutionError(f"{label} entries must be nonblank strings")
    return tuple(value)


@dataclass(frozen=True)
class ToulminArgument:
    """Strictly structured reasoning; syntactic validity does not prove truth."""
    claim: str
    grounds: tuple[str, ...]
    warrant: str
    backing: tuple[str, ...] = ()
    qualifier: str = "provisional"
    rebuttals: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    argument_id: str = ""
    stance: str = "support"
    responds_to: str | None = None

    def __post_init__(self) -> None:
        if type(self.claim) is not str or not self.claim.strip():
            raise EvolutionError("Toulmin claim is required")
        if type(self.warrant) is not str or not self.warrant.strip():
            raise EvolutionError("Toulmin warrant is required")
        if type(self.qualifier) is not str or not self.qualifier.strip():
            raise EvolutionError("Toulmin qualifier is required")
        if type(self.argument_id) is not str or (self.argument_id and not self.argument_id.strip()):
            raise EvolutionError("argument_id must be a nonblank identifier if supplied")
        if self.stance not in ("support", "oppose"):
            raise EvolutionError("argument stance must be 'support' or 'oppose'")
        if self.responds_to is not None and (type(self.responds_to) is not str or not self.responds_to.strip()):
            raise EvolutionError("responds_to must reference an argument identifier")
        if self.responds_to is not None and not self.argument_id:
            raise EvolutionError("responding argument must have an argument_id")
        for key in ("grounds", "backing", "rebuttals", "evidence_refs"):
            object.__setattr__(self, key, _strings(getattr(self, key), key, nonempty=key == "grounds"))

    def as_json(self) -> dict[str, Any]:
        output = {
            "claim": self.claim, "grounds": list(self.grounds),
            "warrant": self.warrant, "backing": list(self.backing),
            "qualifier": self.qualifier, "rebuttals": list(self.rebuttals),
            "evidence_refs": list(self.evidence_refs),
        }
        if self.argument_id:
            output["argument_id"] = self.argument_id
        if self.stance != "support":
            output["stance"] = self.stance
        if self.responds_to is not None:
            output["responds_to"] = self.responds_to
        return strict_json_copy(output)

    @classmethod
    def from_json(cls, value: Mapping[str, Any]) -> ToulminArgument:
        if type(value) is not dict:
            raise EvolutionError("argument must be a JSON object")
        legal = {"claim", "grounds", "warrant", "backing", "qualifier", "rebuttals",
                 "evidence_refs", "argument_id", "stance", "responds_to"}
        if set(value) - legal:
            raise EvolutionError("unknown Toulmin fields: " + ", ".join(sorted(set(value) - legal)))
        return cls(
            claim=value.get("claim", ""),
            grounds=value.get("grounds", []),
            warrant=value.get("warrant", ""),
            backing=value.get("backing", []),
            qualifier=value.get("qualifier", "provisional"),
            rebuttals=value.get("rebuttals", []),
            evidence_refs=value.get("evidence_refs", []),
            argument_id=value.get("argument_id", ""),
            stance=value.get("stance", "support"),
            responds_to=value.get("responds_to"),
        )


_ALLOWED_TYPES = frozenset({"any", "object", "array", "string", "integer", "number", "boolean", "null"})
_SCHEMA_KEYS = frozenset({"type", "properties", "required", "additionalProperties", "items",
                          "minLength", "maxLength", "minimum", "maximum", "enum"})


def check_schema(schema: Mapping[str, Any], *, _depth: int = 0) -> None:
    """Validate the explicitly supported JSON schema SUBSET, not general JSON Schema."""
    if _depth > 24:
        raise SchemaError("schema recursion limit")
    if type(schema) is not dict:
        raise SchemaError("schema must be a JSON object")
    if set(schema) - _SCHEMA_KEYS:
        raise SchemaError(f"unsupported schema keywords: {sorted(set(schema)-_SCHEMA_KEYS)}")
    types = schema.get("type", "any")
    types = [types] if type(types) is str else types
    if type(types) is not list or not types or any(type(t) is not str or t not in _ALLOWED_TYPES for t in types):
        raise SchemaError("invalid schema type")
    if len(set(types)) != len(types):
        raise SchemaError("duplicate schema type")
    properties = schema.get("properties", {})
    if type(properties) is not dict:
        raise SchemaError("properties must be an object")
    for name, child in properties.items():
        if type(name) is not str or not name:
            raise SchemaError("property names must be nonempty strings")
        check_schema(child, _depth=_depth + 1)
    required = schema.get("required", [])
    if type(required) is not list or any(type(x) is not str or not x for x in required) or len(set(required)) != len(required):
        raise SchemaError("required must be a list of distinct nonempty names")
    if "additionalProperties" in schema and type(schema["additionalProperties"]) is not bool:
        raise SchemaError("additionalProperties must be boolean")
    if "items" in schema:
        check_schema(schema["items"], _depth=_depth + 1)
    for key in ("minLength", "maxLength"):
        if key in schema and (type(schema[key]) is not int or schema[key] < 0):
            raise SchemaError(f"{key} must be nonnegative integer")
    if ("minLength" in schema and "maxLength" in schema
            and schema["minLength"] > schema["maxLength"]):
        raise SchemaError("minLength exceeds maxLength")
    for key in ("minimum", "maximum"):
        if key in schema and (type(schema[key]) not in (int, float)):
            raise SchemaError(f"{key} must be numeric")
    if "minimum" in schema and "maximum" in schema and schema["minimum"] > schema["maximum"]:
        raise SchemaError("minimum exceeds maximum")
    if "enum" in schema:
        values = strict_json_copy(schema["enum"])
        if type(values) is not list or not values:
            raise SchemaError("enum must be nonempty array")
        if len({canonical_hash(v) for v in values}) != len(values):
            raise SchemaError("duplicate enum values")
    strict_json_copy(dict(schema))


def _matches(value: Any, name: str) -> bool:
    return {
        "any": lambda: True,
        "object": lambda: type(value) is dict,
        "array": lambda: type(value) is list,
        "string": lambda: type(value) is str,
        "integer": lambda: type(value) is int,
        "number": lambda: type(value) in (int, float),
        "boolean": lambda: type(value) is bool,
        "null": lambda: value is None,
    }[name]()


def validate_json(value: Any, schema: Mapping[str, Any], *, path: str = "$", _depth: int = 0) -> None:
    """Validate JSON value against the supported type/shape/refinement subset."""
    if _depth == 0:
        check_schema(schema)
        strict_json_copy(value)
    if _depth > 24:
        raise SchemaError("value recursion limit")
    types = schema.get("type", "any")
    types = [types] if type(types) is str else types
    if not any(_matches(value, t) for t in types):
        raise SchemaError(f"{path}: expected {types}, got {type(value).__name__}")
    if "enum" in schema and canonical_hash(value) not in {canonical_hash(x) for x in schema["enum"]}:
        raise SchemaError(f"{path}: value not in enum")
    if type(value) is dict:
        required = schema.get("required", [])
        missing = set(required) - set(value)
        if missing:
            raise SchemaError(f"{path}: missing fields {sorted(missing)}")
        props = schema.get("properties", {})
        for name, child in value.items():
            if name in props:
                validate_json(child, props[name], path=f"{path}.{name}", _depth=_depth + 1)
            elif schema.get("additionalProperties", True) is False:
                raise SchemaError(f"{path}: unexpected field {name}")
    if type(value) is list and "items" in schema:
        for i, child in enumerate(value):
            validate_json(child, schema["items"], path=f"{path}[{i}]", _depth=_depth + 1)
    if type(value) is str:
        if len(value) < schema.get("minLength", 0):
            raise SchemaError(f"{path}: string too short")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            raise SchemaError(f"{path}: string too long")
    if type(value) in (int, float):
        if "minimum" in schema and value < schema["minimum"]:
            raise SchemaError(f"{path}: value below minimum")
        if "maximum" in schema and value > schema["maximum"]:
            raise SchemaError(f"{path}: value above maximum")


def contract_description(catalog: ContractCatalog, identity: str) -> dict[str, Any]:
    m = catalog.resolve(identity).metadata
    return strict_json_copy({
        "name": m.name, "version": m.version, "start": m.start,
        "transitions": {k: list(v) for k, v in m.transitions.items()},
        "terminal": sorted(m.terminal), "pure": m.pure,
    })


def object_metadata(catalog: ContractCatalog, identity: str, schema: dict[str, Any],
                    *, description: str = "", tags: tuple[str, ...] = ()) -> dict[str, Any]:
    check_schema(schema)
    return {"operation": contract_description(catalog, identity),
            "schema": strict_json_copy(schema), "description": description,
            "tags": list(_strings(tags, "tags"))}


def _check_metadata(value: Any, catalog: ContractCatalog, identity: str) -> dict[str, Any]:
    meta = strict_json_copy(value)
    if type(meta) is not dict or set(meta) != {"operation", "schema", "description", "tags"}:
        raise EvolutionError("metadata must contain operation, schema, description and tags")
    if meta["operation"] != contract_description(catalog, identity):
        raise EvolutionError("cannot modify executable contract; register a NEW FunctionPair version")
    check_schema(meta["schema"])
    if type(meta["description"]) is not str:
        raise EvolutionError("metadata description must be a string")
    _strings(meta["tags"], "tags")
    return meta


@dataclass(frozen=True)
class VersionedObject:
    object_id: str
    contract: str
    revision: int
    data: dict[str, Any]
    metadata: dict[str, Any]


@dataclass(frozen=True)
class ChangeProposal:
    proposal_id: str
    object_id: str
    base_revision: int
    proposer: str
    before_data: dict[str, Any]
    before_metadata: dict[str, Any]
    candidate_data: dict[str, Any]
    candidate_metadata: dict[str, Any]
    arguments: tuple[ToulminArgument, ...]
    notes: tuple[str, ...]
    context: dict[str, Any]
    digest: str


@dataclass(frozen=True)
class ChangeDecision:
    proposal_id: str
    object_id: str
    status: str
    from_revision: int
    to_revision: int | None
    reviewer: str
    reason: str
    validation: dict[str, Any]
    digest: str


def _json(value: Any) -> str:
    return json.dumps(strict_json_copy(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"))


class EvolutionLedger:
    """Separate append-only proposals and decisions, CAS current object state.

    SQL triggers disallow accidental mutation of historical rows. A DB owner can
    bypass them: the hash chain is tamper-evident only under an external anchor.
    """
    def __init__(self, path: str):
        self.path = str(path)
        with sql_conn(self.path) as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS evolution_objects (
                object_id TEXT PRIMARY KEY, contract TEXT NOT NULL,
                revision INTEGER NOT NULL, data_json TEXT NOT NULL, metadata_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS evolution_genesis (
                object_id TEXT PRIMARY KEY, contract TEXT NOT NULL,
                initial_data TEXT NOT NULL, initial_metadata TEXT NOT NULL, digest TEXT NOT NULL
            );
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_genesis_update
                BEFORE UPDATE ON evolution_genesis BEGIN SELECT RAISE(ABORT, 'immutable genesis'); END;
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_genesis_delete
                BEFORE DELETE ON evolution_genesis BEGIN SELECT RAISE(ABORT, 'immutable genesis'); END;
            CREATE TABLE IF NOT EXISTS evolution_proposals (
                proposal_id TEXT PRIMARY KEY, object_id TEXT NOT NULL,
                base_revision INTEGER NOT NULL, proposer TEXT NOT NULL,
                before_data TEXT NOT NULL, before_metadata TEXT NOT NULL,
                candidate_data TEXT NOT NULL, candidate_metadata TEXT NOT NULL,
                arguments_json TEXT NOT NULL, notes_json TEXT NOT NULL,
                context_json TEXT NOT NULL, digest TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS evolution_decisions (
                proposal_id TEXT PRIMARY KEY, object_id TEXT NOT NULL,
                status TEXT NOT NULL, from_revision INTEGER NOT NULL,
                to_revision INTEGER, reviewer TEXT NOT NULL, reason TEXT NOT NULL,
                validation_json TEXT NOT NULL, after_data TEXT,
                after_metadata TEXT, previous_digest TEXT NOT NULL, digest TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS evolution_review_attempts (
                event_id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL,
                proposal_id TEXT NOT NULL, reviewer TEXT NOT NULL,
                status TEXT NOT NULL, diagnostic TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS evolution_corrections (
                correction_id TEXT PRIMARY KEY, proposal_id TEXT NOT NULL,
                reviewer TEXT NOT NULL, rationale TEXT NOT NULL,
                corrected_interpretation TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS evolution_decisions_object_idx
                ON evolution_decisions(object_id);
            CREATE INDEX IF NOT EXISTS evolution_proposals_object_idx
                ON evolution_proposals(object_id);
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_review_attempts_update
                BEFORE UPDATE ON evolution_review_attempts BEGIN SELECT RAISE(ABORT, 'immutable review attempt'); END;
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_review_attempts_delete
                BEFORE DELETE ON evolution_review_attempts BEGIN SELECT RAISE(ABORT, 'immutable review attempt'); END;
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_corrections_update
                BEFORE UPDATE ON evolution_corrections BEGIN SELECT RAISE(ABORT, 'immutable correction'); END;
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_corrections_delete
                BEFORE DELETE ON evolution_corrections BEGIN SELECT RAISE(ABORT, 'immutable correction'); END;
            CREATE TABLE IF NOT EXISTS evolution_job_bindings (
                job_id TEXT PRIMARY KEY, object_id TEXT NOT NULL,
                object_revision INTEGER NOT NULL, schema_json TEXT NOT NULL
            );
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_proposal_update
                BEFORE UPDATE ON evolution_proposals BEGIN SELECT RAISE(ABORT, 'immutable proposal'); END;
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_proposal_delete
                BEFORE DELETE ON evolution_proposals BEGIN SELECT RAISE(ABORT, 'immutable proposal'); END;
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_decision_update
                BEFORE UPDATE ON evolution_decisions BEGIN SELECT RAISE(ABORT, 'immutable decision'); END;
            CREATE TRIGGER IF NOT EXISTS freeze_evolution_decision_delete
                BEFORE DELETE ON evolution_decisions BEGIN SELECT RAISE(ABORT, 'immutable decision'); END;
            """)

    def record_review_attempt(self, attempt_id: str, proposal_id: str,
                              reviewer: str, status: ReviewAttemptStatus,
                              diagnostic: str = "") -> None:
        with sql_conn(self.path) as db:
            db.execute("INSERT INTO evolution_review_attempts VALUES(?,?,?,?,?,?)",
                       (str(uuid.uuid4()), attempt_id, proposal_id, reviewer, status.value, diagnostic))

    def review_attempts(self, proposal_id: str) -> list[dict[str, str]]:
        with sql_conn(self.path) as db:
            rows = db.execute("""SELECT attempt_id,reviewer,status,diagnostic
                        FROM evolution_review_attempts WHERE proposal_id=? ORDER BY rowid""",
                        (proposal_id,)).fetchall()
        return [dict(zip(("attempt_id", "reviewer", "status", "diagnostic"), row)) for row in rows]

    def append_correction(self, proposal_id: str, *, reviewer: str, rationale: str,
                          corrected_interpretation: str) -> str:
        if self.decision(proposal_id) is None:
            raise EvolutionError("a correction requires an existing decision")
        if not all(type(x) is str and x.strip() for x in (reviewer, rationale, corrected_interpretation)):
            raise EvolutionError("correction requires reviewer, rationale and interpretation")
        correction_id = str(uuid.uuid4())
        with sql_conn(self.path) as db:
            db.execute("INSERT INTO evolution_corrections VALUES(?,?,?,?,?)",
                       (correction_id, proposal_id, reviewer, rationale, corrected_interpretation))
        return correction_id

    def corrections(self, proposal_id: str) -> list[dict[str, str]]:
        with sql_conn(self.path) as db:
            rows = db.execute("""SELECT correction_id,reviewer,rationale,corrected_interpretation
                            FROM evolution_corrections WHERE proposal_id=? ORDER BY rowid""",
                            (proposal_id,)).fetchall()
        return [dict(zip(("correction_id", "reviewer", "rationale", "corrected_interpretation"), row)) for row in rows]

    def object_ids(self) -> tuple[str, ...]:
        """Include missing current rows represented by historical genesis records."""
        with sql_conn(self.path) as db:
            rows = db.execute("""SELECT object_id FROM evolution_objects
                      UNION SELECT object_id FROM evolution_genesis ORDER BY object_id""").fetchall()
        return tuple(row[0] for row in rows)

    def chain_head(self, object_id: str) -> str:
        with sql_conn(self.path) as db:
            row = db.execute("""SELECT digest FROM evolution_decisions
                       WHERE object_id=? ORDER BY rowid DESC LIMIT 1""", (object_id,)).fetchone()
        return row[0] if row else self.genesis(object_id)[3]

    def register(self, object_id: str, contract: str, data: dict[str, Any], metadata: dict[str, Any]) -> VersionedObject:
        if not object_id:
            raise EvolutionError("object id required")
        initial_digest = canonical_hash({"object_id": object_id, "contract": contract,
                                         "initial_data": data, "initial_metadata": metadata})
        with sql_conn(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO evolution_objects VALUES(?,?,?,?,?)",
                       (object_id, contract, 0, _json(data), _json(metadata)))
            db.execute("INSERT INTO evolution_genesis VALUES(?,?,?,?,?)",
                       (object_id, contract, _json(data), _json(metadata), initial_digest))
        return self.get(object_id)

    def genesis(self, object_id: str) -> tuple[str, dict[str, Any], dict[str, Any], str]:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT * FROM evolution_genesis WHERE object_id=?", (object_id,)).fetchone()
        if not row:
            raise KeyError(object_id)
        return row[1], json.loads(row[2]), json.loads(row[3]), row[4]

    def get(self, object_id: str) -> VersionedObject:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT * FROM evolution_objects WHERE object_id=?", (object_id,)).fetchone()
        if not row:
            raise KeyError(object_id)
        return VersionedObject(row[0], row[1], row[2], json.loads(row[3]), json.loads(row[4]))

    @staticmethod
    def _proposal_dict(p: ChangeProposal) -> dict[str, Any]:
        return {"proposal_id": p.proposal_id, "object_id": p.object_id,
                "base_revision": p.base_revision, "proposer": p.proposer,
                "before_data": p.before_data, "before_metadata": p.before_metadata,
                "candidate_data": p.candidate_data, "candidate_metadata": p.candidate_metadata,
                "arguments": [a.as_json() for a in p.arguments], "notes": list(p.notes),
                "context": p.context}

    def propose(self, *, object_id: str, expected_revision: int, proposer: str,
                candidate_data: dict[str, Any], candidate_metadata: dict[str, Any],
                arguments: tuple[ToulminArgument, ...], notes: tuple[str, ...],
                context: dict[str, Any] | None = None) -> ChangeProposal:
        if not proposer or not arguments:
            raise EvolutionError("identified proposer and Toulmin argument list required")
        if not any(a.stance == "support" for a in arguments):
            raise EvolutionError("a change requires at least one supporting argument")
        seen: set[str] = set()
        for a in arguments:
            if a.responds_to is not None and a.responds_to not in seen:
                raise EvolutionError("responds_to must refer to a preceding argument")
            if a.argument_id:
                if a.argument_id in seen:
                    raise EvolutionError("duplicate argument_id")
                seen.add(a.argument_id)
        notes = _strings(notes, "notes")
        candidate_data = strict_json_copy(candidate_data)
        candidate_metadata = strict_json_copy(candidate_metadata)
        context = strict_json_copy(context or {})
        with sql_conn(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT contract,revision,data_json,metadata_json FROM evolution_objects WHERE object_id=?",
                             (object_id,)).fetchone()
            if not row:
                raise KeyError(object_id)
            if row[1] != expected_revision:
                raise ConcurrencyError("stale object revision at proposal")
            before_data, before_metadata = json.loads(row[2]), json.loads(row[3])
            if candidate_data == before_data and candidate_metadata == before_metadata:
                raise EvolutionError("proposed change has no effect")
            p = ChangeProposal(str(uuid.uuid4()), object_id, expected_revision, proposer,
                               before_data, before_metadata, candidate_data, candidate_metadata,
                               arguments, notes, context, "")
            digest = canonical_hash(self._proposal_dict(p))
            p = ChangeProposal(**{**vars(p), "digest": digest})
            db.execute("INSERT INTO evolution_proposals VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                       (p.proposal_id, p.object_id, p.base_revision, p.proposer,
                        _json(p.before_data), _json(p.before_metadata),
                        _json(p.candidate_data), _json(p.candidate_metadata),
                        _json([a.as_json() for a in p.arguments]), _json(list(p.notes)),
                        _json(p.context), p.digest))
        return p

    def proposal(self, proposal_id: str) -> ChangeProposal:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT * FROM evolution_proposals WHERE proposal_id=?", (proposal_id,)).fetchone()
        if not row:
            raise KeyError(proposal_id)
        args = tuple(ToulminArgument.from_json(v) for v in json.loads(row[8]))
        return ChangeProposal(row[0], row[1], row[2], row[3], json.loads(row[4]),
                              json.loads(row[5]), json.loads(row[6]), json.loads(row[7]),
                              args, tuple(json.loads(row[9])), json.loads(row[10]), row[11])

    def decision(self, proposal_id: str) -> ChangeDecision | None:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT * FROM evolution_decisions WHERE proposal_id=?", (proposal_id,)).fetchone()
        if row is None:
            return None
        return ChangeDecision(row[0], row[1], row[2], row[3], row[4], row[5], row[6], json.loads(row[7]), row[11])

    def decide(self, p: ChangeProposal, *, reviewer: str, approve: bool, reason: str,
               validation: dict[str, Any],
               status_override: EvolutionDecisionStatus | None = None) -> ChangeDecision:
        """Commit decision + accepted state in one local SQLite transaction."""
        if not reviewer or not reason:
            raise EvolutionError("reviewer and decision reason required")
        if reviewer == p.proposer:
            raise EvolutionError("proposer cannot self-review")
        with sql_conn(self.path) as db:
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM evolution_decisions WHERE proposal_id=?", (p.proposal_id,)).fetchone():
                raise EvolutionError("proposal was already decided")
            row = db.execute("SELECT revision,data_json,metadata_json FROM evolution_objects WHERE object_id=?",
                             (p.object_id,)).fetchone()
            if row is None:
                raise KeyError(p.object_id)
            revision = int(row[0])
            same_base = (revision == p.base_revision and json.loads(row[1]) == p.before_data
                         and json.loads(row[2]) == p.before_metadata)
            status = (EvolutionDecisionStatus.STALE.value if not same_base
                      else status_override.value if status_override is not None
                      else EvolutionDecisionStatus.ACCEPTED.value if approve
                      else EvolutionDecisionStatus.REJECTED.value)
            if status_override is not None and status_override not in (EvolutionDecisionStatus.REVIEW_DUE,):
                raise EvolutionError("unsupported decision status override")
            validation = strict_json_copy(validation)
            validation["reviewer_approval_intent"] = bool(approve)
            validation["applied"] = "yes" if status == "ACCEPTED" else "no"
            if status == "STALE":
                reason = (f"NOT APPLIED: base revision {p.base_revision} changed before decision "
                          f"(current revision {revision}); reviewer's "
                          f"{'approval' if approve else 'rejection'} rationale: {reason}")
                validation["stale_against"] = p.base_revision
            if status == "REVIEW_DUE":
                reason = "NOT APPLIED: further review required: " + reason
            to_revision = revision + 1 if status == "ACCEPTED" else None
            if status == "ACCEPTED":
                # Enforce the protected overlay boundary at the persistence layer,
                # not only in the higher-level controller. This is not an in-process
                # security boundary against callers able to forge review attestations.
                if p.candidate_metadata.get("operation") != p.before_metadata.get("operation"):
                    raise EvolutionError("cannot modify registered operation metadata")
                check_schema(p.candidate_metadata["schema"])
                validate_json(p.candidate_data, p.candidate_metadata["schema"])
                if (not schema_narrows_or_equals(p.candidate_metadata["schema"],
                                                 p.before_metadata["schema"])
                        and validation.get("protected_schema") != "approved_by_distinct_higher_authority"):
                    raise EvolutionError("protected schema relaxation requires higher-authority attestation")
                updated = db.execute("""UPDATE evolution_objects SET revision=?,data_json=?,metadata_json=?
                    WHERE object_id=? AND revision=?""", (to_revision, _json(p.candidate_data),
                    _json(p.candidate_metadata), p.object_id, revision))
                if updated.rowcount != 1:
                    raise ConcurrencyError("object changed before evolution commit")
            last = db.execute("""SELECT digest FROM evolution_decisions
                   WHERE object_id=? ORDER BY rowid DESC LIMIT 1""", (p.object_id,)).fetchone()
            prev_digest = last[0] if last else self.genesis(p.object_id)[3]
            core = {"proposal_digest": p.digest, "status": status, "from_revision": revision,
                    "to_revision": to_revision, "reviewer": reviewer, "reason": reason,
                    "validation": validation,
                    "after_data": p.candidate_data if status == "ACCEPTED" else None,
                    "after_metadata": p.candidate_metadata if status == "ACCEPTED" else None,
                    "previous_digest": prev_digest}
            digest = canonical_hash(core)
            db.execute("INSERT INTO evolution_decisions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                       (p.proposal_id, p.object_id, status, revision, to_revision, reviewer, reason,
                        _json(validation), _json(p.candidate_data) if status == "ACCEPTED" else None,
                        _json(p.candidate_metadata) if status == "ACCEPTED" else None,
                        prev_digest, digest))
        result = self.decision(p.proposal_id)
        assert result is not None
        return result

    def history(self, object_id: str) -> list[dict[str, Any]]:
        with sql_conn(self.path) as db:
            ids = db.execute("""SELECT d.proposal_id FROM evolution_decisions d
                        WHERE d.object_id=? ORDER BY d.rowid""", (object_id,)).fetchall()
        events = []
        for (pid,) in ids:
            p = self.proposal(pid)
            d = self.decision(pid)
            assert d is not None
            events.append({"proposal_id": pid, "status": d.status, "reviewer": d.reviewer,
                           "reason": d.reason, "before": {"data": p.before_data, "metadata": p.before_metadata},
                           "candidate": {"data": p.candidate_data, "metadata": p.candidate_metadata},
                           "after": {"data": p.candidate_data, "metadata": p.candidate_metadata}
                                      if d.status == "ACCEPTED" else None,
                           "from_revision": d.from_revision, "to_revision": d.to_revision,
                           "arguments": [a.as_json() for a in p.arguments], "notes": list(p.notes),
                           "validation": d.validation, "proposal_digest": p.digest,
                           "decision_digest": d.digest,
                           "corrections": self.corrections(pid)})
        return events

    def verify_history(self, object_id: str) -> HistoryVerdict:
        """Return an exhaustive integrity verdict; batch-join proposal and decision rows.

        Full verification remains O(history length); no unanchored trust cache is used.
        The boolean operator exists only for compatibility with v0.2 callers.
        """
        try:
            with sql_conn(self.path) as db:
                genesis = db.execute("SELECT * FROM evolution_genesis WHERE object_id=?", (object_id,)).fetchone()
                current = db.execute("SELECT * FROM evolution_objects WHERE object_id=?", (object_id,)).fetchone()
                if genesis is None:
                    orphan_history = db.execute("SELECT 1 FROM evolution_decisions WHERE object_id=? LIMIT 1", (object_id,)).fetchone()
                    orphan_proposal = db.execute("SELECT 1 FROM evolution_proposals WHERE object_id=? LIMIT 1", (object_id,)).fetchone()
                    if current is not None or orphan_history or orphan_proposal:
                        return HistoryVerdict(HistoryStatus.UNCHECKABLE, "genesis missing for recorded object/history")
                    return HistoryVerdict(HistoryStatus.NO_SUCH_OBJECT, "unknown object id")
                if current is None:
                    return HistoryVerdict(HistoryStatus.UNCHECKABLE, "genesis exists but current object row is missing")
                rows = db.execute("""SELECT d.*, p.proposal_id, p.object_id, p.base_revision,
                              p.proposer, p.before_data, p.before_metadata, p.candidate_data,
                              p.candidate_metadata, p.arguments_json, p.notes_json,
                              p.context_json, p.digest FROM evolution_decisions d
                              LEFT JOIN evolution_proposals p ON p.proposal_id=d.proposal_id
                              WHERE d.object_id=? ORDER BY d.rowid""", (object_id,)).fetchall()
            init_contract, init_data, init_meta, prior = genesis[1], json.loads(genesis[2]), json.loads(genesis[3]), genesis[4]
            if canonical_hash({"object_id": object_id, "contract": init_contract,
                               "initial_data": init_data, "initial_metadata": init_meta}) != prior:
                return HistoryVerdict(HistoryStatus.BROKEN, "genesis digest mismatch")
            last_accepted: tuple[int, dict[str, Any], dict[str, Any]] | None = None
            for idx, row in enumerate(rows):
                if row[12] is None:
                    return HistoryVerdict(HistoryStatus.BROKEN, f"decision {idx}: proposal missing")
                p = ChangeProposal(row[12], row[13], row[14], row[15], json.loads(row[16]),
                                   json.loads(row[17]), json.loads(row[18]), json.loads(row[19]),
                                   tuple(ToulminArgument.from_json(a) for a in json.loads(row[20])),
                                   tuple(json.loads(row[21])), json.loads(row[22]), row[23])
                if p.object_id != object_id or canonical_hash(self._proposal_dict(p)) != p.digest:
                    return HistoryVerdict(HistoryStatus.BROKEN, f"decision {idx}: proposal digest mismatch")
                after_data = json.loads(row[8]) if row[8] is not None else None
                after_meta = json.loads(row[9]) if row[9] is not None else None
                core = {"proposal_digest": p.digest, "status": row[2], "from_revision": row[3],
                        "to_revision": row[4], "reviewer": row[5], "reason": row[6],
                        "validation": json.loads(row[7]), "after_data": after_data,
                        "after_metadata": after_meta, "previous_digest": prior}
                if row[10] != prior or canonical_hash(core) != row[11]:
                    return HistoryVerdict(HistoryStatus.BROKEN, f"decision {idx}: chain digest mismatch")
                expected_revision = last_accepted[0] if last_accepted is not None else 0
                if row[3] != expected_revision:
                    return HistoryVerdict(HistoryStatus.BROKEN, f"decision {idx}: revision gap")
                if row[2] == EvolutionDecisionStatus.ACCEPTED.value:
                    if (row[4] != row[3] + 1 or after_data != p.candidate_data
                            or after_meta != p.candidate_metadata):
                        return HistoryVerdict(HistoryStatus.BROKEN, f"decision {idx}: invalid acceptance")
                    prev_data = last_accepted[1] if last_accepted else init_data
                    prev_meta = last_accepted[2] if last_accepted else init_meta
                    if p.before_data != prev_data or p.before_metadata != prev_meta:
                        return HistoryVerdict(HistoryStatus.BROKEN, f"decision {idx}: before snapshot mismatch")
                    last_accepted = (row[4], after_data, after_meta)
                elif row[2] in {EvolutionDecisionStatus.STALE.value,
                                 EvolutionDecisionStatus.REJECTED.value,
                                 EvolutionDecisionStatus.REVIEW_DUE.value}:
                    if row[4] is not None or after_data is not None or after_meta is not None:
                        return HistoryVerdict(HistoryStatus.BROKEN, f"decision {idx}: nonaccepted after snapshot")
                else:
                    return HistoryVerdict(HistoryStatus.BROKEN, f"decision {idx}: unknown decision status")
                prior = row[11]
            observed = (current[2], json.loads(current[3]), json.loads(current[4]))
            wanted = last_accepted if last_accepted is not None else (0, init_data, init_meta)
            if current[1] != init_contract or observed != wanted:
                return HistoryVerdict(HistoryStatus.BROKEN, "current object differs from verified chain")
            return HistoryVerdict(HistoryStatus.VERIFIED, f"verified {len(rows)} decisions")
        except (ValueError, TypeError, KeyError, IndexError, sqlite3.DatabaseError, EvolutionError) as exc:
            return HistoryVerdict(HistoryStatus.UNCHECKABLE, f"unable to inspect record: {type(exc).__name__}")

    def bind_job(self, job_id: str, obj: VersionedObject) -> None:
        with sql_conn(self.path) as db:
            db.execute("INSERT INTO evolution_job_bindings VALUES(?,?,?,?)",
                       (job_id, obj.object_id, obj.revision, _json(obj.metadata["schema"])))

    def job_binding(self, job_id: str) -> tuple[str, int, dict[str, Any]]:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT object_id,object_revision,schema_json FROM evolution_job_bindings WHERE job_id=?",
                             (job_id,)).fetchone()
        if row is None:
            raise EvolutionError("unbound job; typed evolution requires a pinned object revision")
        return row[0], row[1], json.loads(row[2])

    def objects(self) -> list[VersionedObject]:
        with sql_conn(self.path) as db:
            names = [r[0] for r in db.execute("SELECT object_id FROM evolution_objects ORDER BY object_id")]
        return [self.get(s) for s in names]


class TypeEvolutionController:
    """Propose and independently review changes; no self-authorization.

    authorization is a host-supplied callable, NOT an authenticated principal.
    """
    def __init__(self, catalog: ContractCatalog, ledger: EvolutionLedger,
                 authorize_review: Callable[[str, ChangeProposal], bool],
                 eligibility_check: Callable[[ChangeProposal], bool] | None = None,
                 authorize_sensitive_review: Callable[[str, ChangeProposal], bool] | None = None):
        self.catalog, self.ledger = catalog, ledger
        self.authorize_review = authorize_review
        self.eligibility_check = eligibility_check
        self.authorize_sensitive_review = authorize_sensitive_review

    def register_object(self, object_id: str, contract: str, data: dict[str, Any],
                        schema: dict[str, Any], *, description: str = "",
                        tags: tuple[str, ...] = ()) -> VersionedObject:
        meta = object_metadata(self.catalog, contract, schema, description=description, tags=tags)
        if type(data) is not dict:
            raise EvolutionError("Function–Data instance must hold a JSON object")
        _check_metadata(meta, self.catalog, contract)
        validate_json(data, schema)
        return self.ledger.register(object_id, contract, data, meta)

    def propose(self, object_id: str, *, proposer: str, expected_revision: int,
                arguments: list[dict[str, Any]] | tuple[ToulminArgument, ...],
                data: dict[str, Any] | None = None, metadata: dict[str, Any] | None = None,
                notes: list[str] | tuple[str, ...] = (),
                context: dict[str, Any] | None = None) -> ChangeProposal:
        verdict = self.ledger.verify_history(object_id)
        if not verdict:
            raise EvolutionError(f"cannot evolve: {verdict.status.value}: {verdict.detail}")
        current = self.ledger.get(object_id)
        if current.revision != expected_revision:
            raise ConcurrencyError("stale object revision")
        parsed = tuple(ToulminArgument.from_json(arg) if type(arg) is dict else arg for arg in arguments)
        if any(type(a) is not ToulminArgument for a in parsed):
            raise EvolutionError("all argument entries must be ToulminArgument or JSON object")
        return self.ledger.propose(object_id=object_id, expected_revision=expected_revision,
                                   proposer=proposer, candidate_data=current.data if data is None else data,
                                   candidate_metadata=current.metadata if metadata is None else metadata,
                                   arguments=parsed, notes=tuple(notes), context=context)

    def review(self, proposal_id: str, *, reviewer: str, approve: bool,
               reason: str, elevated_reviewer: str | None = None) -> ChangeDecision:
        p = self.ledger.proposal(proposal_id)
        if self.ledger.decision(proposal_id) is not None:
            raise EvolutionError("already decided")
        if reviewer == p.proposer:
            raise EvolutionError("proposer cannot review own change")
        attempt_id = str(uuid.uuid4())
        self.ledger.record_review_attempt(attempt_id, proposal_id, reviewer,
                                          ReviewAttemptStatus.STARTED)
        try:
            authorized = self.authorize_review(reviewer, p)
        except Exception as exc:
            # No decision is made. The attempt remains independently observable.
            self.ledger.record_review_attempt(attempt_id, proposal_id, reviewer,
                          ReviewAttemptStatus.UNDETERMINED, type(exc).__name__)
            raise EvolutionError("review authority undetermined; proposal remains pending") from exc
        if not authorized:
            self.ledger.record_review_attempt(attempt_id, proposal_id, reviewer,
                                              ReviewAttemptStatus.REFUSED, "reviewer not authorized")
            raise EvolutionError("reviewer has no externally established authority")
        self.ledger.record_review_attempt(attempt_id, proposal_id, reviewer,
                                          ReviewAttemptStatus.AUTHORIZED)
        validation: dict[str, Any] = {
            "argument_structure": "checked_at_proposal", "schema": "not_run",
            "supporting_arguments": sum(a.stance == "support" for a in p.arguments),
            "opposing_arguments": sum(a.stance == "oppose" for a in p.arguments),
        }
        override = None
        try:
            eligible = self.eligibility_check is None or self.eligibility_check(p)
        except Exception as exc:
            eligible = False
            validation["eligibility"] = "undetermined"
            validation["eligibility_diagnostic"] = type(exc).__name__
        if not eligible:
            override = EvolutionDecisionStatus.REVIEW_DUE
            validation.setdefault("eligibility", "lapsed")
            reason = "eligibility unavailable or lapsed; " + reason
        if approve and override is None:
            try:
                verdict = self.ledger.verify_history(p.object_id)
                if not verdict:
                    raise EvolutionError(f"integrity {verdict.status.value}: {verdict.detail}")
                identity = self.ledger.get(p.object_id).contract
                _check_metadata(p.candidate_metadata, self.catalog, identity)
                if type(p.candidate_data) is not dict:
                    raise EvolutionError("Function–Data instance must hold a JSON object")
                validate_json(p.candidate_data, p.candidate_metadata["schema"])
                validation["schema"] = "passed"
                validation["operation_contract"] = "unchanged"
                # The overlay schema is a protected *validation boundary*.
                # Relaxation or unproved narrowing needs independent higher authority.
                if not schema_narrows_or_equals(p.candidate_metadata["schema"],
                                                p.before_metadata["schema"]):
                    validation["protected_schema"] = "additional_review_required"
                    if (not elevated_reviewer or elevated_reviewer in {reviewer, p.proposer}
                            or self.authorize_sensitive_review is None):
                        override = EvolutionDecisionStatus.REVIEW_DUE
                        reason = "schema relaxation or unproved refinement requires distinct higher review; " + reason
                    else:
                        try:
                            extra_ok = self.authorize_sensitive_review(elevated_reviewer, p)
                        except Exception as exc:
                            extra_ok = False
                            validation["elevated_authority_diagnostic"] = type(exc).__name__
                        if not extra_ok:
                            override = EvolutionDecisionStatus.REVIEW_DUE
                            reason = "higher authorization unavailable or refused; " + reason
                        else:
                            validation["protected_schema"] = "approved_by_distinct_higher_authority"
                            validation["elevated_reviewer"] = elevated_reviewer
            except (ContractError, ValueError) as exc:
                validation["schema"] = "failed"
                validation["reason"] = str(exc)
                approve = False
                reason = f"validation refused proposed change: {exc}"
        try:
            decision = self.ledger.decide(p, reviewer=reviewer, approve=approve,
                                          reason=reason, validation=validation,
                                          status_override=override)
        except Exception as exc:
            status = (ReviewAttemptStatus.CONFLICT
                      if isinstance(exc, EvolutionError) and "already decided" in str(exc)
                      else ReviewAttemptStatus.UNDETERMINED)
            self.ledger.record_review_attempt(attempt_id, proposal_id, reviewer,
                    status, f"commit: {type(exc).__name__}")
            raise
        self.ledger.record_review_attempt(attempt_id, proposal_id, reviewer,
                ReviewAttemptStatus.COMPLETED, decision.status)
        return decision


class VersionedExecutionRegistry:
    """Constrained facade over EXISTING Function–Data runtime.

    At creation, uses the object data as a prototype, validates the candidate
    payload under the current overlay schema, and pins this schema for the job.
    At every advance, the core ExecutionRegistry guard checks the PINNED schema.
    Direct use of the unguarded registry or direct database access bypasses this
    facade; security isolation is not claimed. Job/binding writes are separate
    transactions: interruption may leave an orphan job, which this facade refuses.
    """
    def __init__(self, catalog: ContractCatalog, store: SQLiteJobStore, ledger: EvolutionLedger):
        self.catalog, self.store, self.ledger = catalog, store, ledger
        self.engine = ExecutionRegistry(catalog, store, state_guard=self._guard)

    def _guard(self, before: Job, payload: Mapping[str, Any]) -> None:
        _, _, pinned_schema = self.ledger.job_binding(before.job_id)
        validate_json(dict(payload), pinned_schema)

    def create_for_object(self, object_id: str, *, payload: dict[str, Any] | None = None) -> Job:
        obj = self.ledger.get(object_id)
        merged = {**obj.data, **strict_json_copy(payload or {})}
        validate_json(merged, obj.metadata["schema"])
        job = self.engine.create(obj.contract, merged)
        self.ledger.bind_job(job.job_id, obj)
        return job

    def advance(self, job_id: str, *, expected_revision: int | None = None,
                parameters: Mapping[str, Any] | None = None) -> Job:
        # Fence unbound jobs even if they are already terminal.
        self.ledger.job_binding(job_id)
        return self.engine.advance(job_id, expected_revision=expected_revision, parameters=parameters)
