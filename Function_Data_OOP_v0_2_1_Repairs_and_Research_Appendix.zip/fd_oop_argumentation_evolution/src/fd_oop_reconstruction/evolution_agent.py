"""Optional adapter attaching evolution proposals to host-issued agent goals.

Proposing a change is agentic; deciding/committing is an independent host action.
Assignment revision re-checks are an illustrative guard and are not atomically
coordinated with the separate GoalAssignments database.
"""
from __future__ import annotations

from typing import Any, Callable

from .agentic import GoalAssignments, AuthorityError
from .evolution import ChangeProposal, TypeEvolutionController, EvolutionLedger
from .distillation import ReflectionDistiller, ReflectionReport
from .original import ContractCatalog


def agentic_evolution_controller(catalog: ContractCatalog, ledger: EvolutionLedger,
                                  assignments: GoalAssignments,
                                  authorize_review: Callable[[str, ChangeProposal], bool]
                                  ) -> TypeEvolutionController:
    def eligible(p: ChangeProposal) -> bool:
        ctx = p.context
        if not ctx.get("goal_id") or not ctx.get("agent_id"):
            return False
        try:
            return assignments.require_active(ctx["agent_id"], ctx["goal_id"]) == ctx.get("assignment_revision")
        except AuthorityError:
            return False
    return TypeEvolutionController(catalog, ledger, authorize_review, eligibility_check=eligible)


class AgenticEvolutionService:
    """Agent-facing proposal interface, without a commit or approval method."""
    def __init__(self, agent_id: str, assignments: GoalAssignments,
                 controller: TypeEvolutionController, distiller: ReflectionDistiller):
        self.agent_id = agent_id
        self.assignments = assignments
        self.controller = controller
        self.distiller = distiller

    def propose_for_goal(self, goal_id: str, object_id: str, *, expected_revision: int,
                         arguments: list[dict[str, Any]], data: dict[str, Any] | None = None,
                         metadata: dict[str, Any] | None = None,
                         notes: list[str] | None = None) -> ChangeProposal:
        revision = self.assignments.require_active(self.agent_id, goal_id)
        return self.controller.propose(object_id, proposer=self.agent_id,
                                       expected_revision=expected_revision, arguments=arguments,
                                       data=data, metadata=metadata, notes=notes or [],
                                       context={"agent_id": self.agent_id, "goal_id": goal_id,
                                                "assignment_revision": revision})

    def reflect(self, *, min_support: int = 2) -> ReflectionReport:
        return self.distiller.reflect(min_support=min_support)
