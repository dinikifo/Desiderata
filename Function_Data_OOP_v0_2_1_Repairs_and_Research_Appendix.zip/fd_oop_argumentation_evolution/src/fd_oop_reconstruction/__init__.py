"""Function–Data OOP + governed agentic OOP: illustrative reconstruction, not historical source."""
from .original import (
    JsonData, FunctionPair, Metadata, Step, Intent, Status, ContractCatalog,
    SQLiteJobStore, ExecutionRegistry, AcceptanceGateway, Evidence, DomainSupervisor,
    ContractError, ConcurrencyError, AcceptanceError, strict_json_copy,
)
from .agentic import (
    FDAgent, VaultOwner, NativeAuthority, GoalAssignments, Goal,
    IndependentOutcomeOracle, MethodMemory, Assessment, AttemptStatus,
    AuthorityError, SourceChanged, build_agent_catalog,
)

from .domain import DomainRule, DomainInference, EntityOperations
from .original import RecoveryManager, RecoveryPermit
from .effects import GuardedEffectGateway, EffectRequest

# Argumentation-governed schema evolution (research extension, v0.2).
from .evolution import (
    ToulminArgument, ChangeProposal, ChangeDecision, VersionedObject,
    EvolutionLedger, TypeEvolutionController, VersionedExecutionRegistry,
    EvolutionError, SchemaError, object_metadata, validate_json, check_schema,
    HistoryStatus, HistoryVerdict, EvolutionDecisionStatus, ReviewAttemptStatus,
    schema_narrows_or_equals,
)
from .distillation import ReflectionDistiller, ReflectionReport, CandidateKnowledge
from .evolution_agent import AgenticEvolutionService, agentic_evolution_controller
from .knowledge import (KnowledgeLedger, KnowledgeProposal, KnowledgeDecision,
                        Applicability, KnowledgeDecisionStatus, KnowledgeReviewAttemptStatus)
