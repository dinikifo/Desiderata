"""Governed promotion of candidate knowledge with typed provenance diagnostics.

A separate knowledge review never changes the executable Function–Data contract.
External authorization is host supplied, not cryptographic authentication.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import json
import sqlite3
from typing import Any, Callable
import uuid

from .distillation import CandidateKnowledge
from .evolution import EvolutionError, EvolutionLedger, HistoryStatus, _strings, _json
from .original import canonical_hash, sql_conn, strict_json_copy


class Applicability(str, Enum):
    APPLICABLE = "APPLICABLE"
    SUPERSEDED = "SUPERSEDED"
    EVIDENCE_GONE = "EVIDENCE_GONE"
    EVIDENCE_UNVERIFIABLE = "EVIDENCE_UNVERIFIABLE"


class KnowledgeDecisionStatus(str, Enum):
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    STALE = "STALE"
    REVIEW_DUE = "REVIEW_DUE"


class KnowledgeReviewAttemptStatus(str, Enum):
    STARTED = "STARTED"
    AUTHORIZED = "AUTHORIZED"
    REFUSED = "REFUSED"
    UNDETERMINED = "UNDETERMINED"
    CONFLICT = "CONFLICT"
    COMPLETED = "COMPLETED"


@dataclass(frozen=True)
class KnowledgeProposal:
    submission_id: str
    proposer: str
    candidate: CandidateKnowledge
    source_snapshots: dict[str, dict[str, Any]]
    digest: str


@dataclass(frozen=True)
class KnowledgeDecision:
    submission_id: str
    status: str
    reviewer: str
    rationale: str
    test_refs: tuple[str, ...]
    digest: str


class KnowledgeLedger:
    """Append-only candidate/review records, with atomic decisions and typed applicability."""

    def __init__(self, path: str, evolution: EvolutionLedger,
                 authorize_review: Callable[[str, KnowledgeProposal], bool]):
        self.path, self.evolution, self.authorize_review = str(path), evolution, authorize_review
        with sql_conn(self.path) as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS knowledge_proposals (
                submission_id TEXT PRIMARY KEY, proposer TEXT NOT NULL,
                candidate_json TEXT NOT NULL, source_snapshots_json TEXT NOT NULL,
                digest TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS knowledge_decisions (
                submission_id TEXT PRIMARY KEY, status TEXT NOT NULL,
                reviewer TEXT NOT NULL, rationale TEXT NOT NULL,
                test_refs_json TEXT NOT NULL, digest TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS knowledge_review_attempts (
                event_id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL,
                submission_id TEXT NOT NULL, reviewer TEXT NOT NULL,
                status TEXT NOT NULL, diagnostic TEXT NOT NULL
            );
            CREATE TRIGGER IF NOT EXISTS knowledge_proposals_no_update
                BEFORE UPDATE ON knowledge_proposals BEGIN SELECT RAISE(ABORT, 'immutable knowledge proposal'); END;
            CREATE TRIGGER IF NOT EXISTS knowledge_proposals_no_delete
                BEFORE DELETE ON knowledge_proposals BEGIN SELECT RAISE(ABORT, 'immutable knowledge proposal'); END;
            CREATE TRIGGER IF NOT EXISTS knowledge_decisions_no_update
                BEFORE UPDATE ON knowledge_decisions BEGIN SELECT RAISE(ABORT, 'immutable knowledge decision'); END;
            CREATE TRIGGER IF NOT EXISTS knowledge_decisions_no_delete
                BEFORE DELETE ON knowledge_decisions BEGIN SELECT RAISE(ABORT, 'immutable knowledge decision'); END;
            CREATE TRIGGER IF NOT EXISTS knowledge_review_attempts_no_update
                BEFORE UPDATE ON knowledge_review_attempts BEGIN SELECT RAISE(ABORT, 'immutable review attempt'); END;
            CREATE TRIGGER IF NOT EXISTS knowledge_review_attempts_no_delete
                BEFORE DELETE ON knowledge_review_attempts BEGIN SELECT RAISE(ABORT, 'immutable review attempt'); END;
            """)

    def _record_attempt(self, attempt_id: str, submission_id: str, reviewer: str,
                        status: KnowledgeReviewAttemptStatus, diagnostic: str = "") -> None:
        with sql_conn(self.path) as db:
            db.execute("INSERT INTO knowledge_review_attempts VALUES(?,?,?,?,?,?)",
                       (str(uuid.uuid4()), attempt_id, submission_id, reviewer, status.value, diagnostic))

    def review_attempts(self, submission_id: str) -> list[dict[str, str]]:
        with sql_conn(self.path) as db:
            rows = db.execute("""SELECT attempt_id,reviewer,status,diagnostic
                       FROM knowledge_review_attempts WHERE submission_id=? ORDER BY rowid""",
                       (submission_id,)).fetchall()
        return [dict(zip(("attempt_id", "reviewer", "status", "diagnostic"), row)) for row in rows]

    def _fingerprint(self, object_id: str) -> dict[str, Any]:
        verdict = self.evolution.verify_history(object_id)
        if verdict.status is not HistoryStatus.VERIFIED:
            raise EvolutionError(f"evidence not verifiable: {object_id}: {verdict.status.value}: {verdict.detail}")
        obj = self.evolution.get(object_id)
        return {"revision": obj.revision, "contract": obj.contract,
                "data_hash": canonical_hash(obj.data), "metadata_hash": canonical_hash(obj.metadata),
                "last_event": self.evolution.chain_head(object_id)}

    def _source_applicability(self, sources: dict[str, dict[str, Any]]) -> tuple[Applicability, dict[str, dict[str, str]]]:
        details: dict[str, dict[str, str]] = {}
        for oid, old_fingerprint in sources.items():
            verdict = self.evolution.verify_history(oid)
            if verdict.status is HistoryStatus.NO_SUCH_OBJECT:
                details[oid] = {"status": Applicability.EVIDENCE_GONE.value,
                                "diagnostic": verdict.detail}
            elif verdict.status is not HistoryStatus.VERIFIED:
                # Genesis remains but current row gone: evidence is not safely verifiable.
                # Treat as EVIDENCE_GONE only when that disappearance is explicit.
                status = (Applicability.EVIDENCE_GONE if
                          verdict.status is HistoryStatus.UNCHECKABLE and "current object row is missing" in verdict.detail
                          else Applicability.EVIDENCE_UNVERIFIABLE)
                details[oid] = {"status": status.value, "diagnostic": verdict.detail}
            else:
                try:
                    latest = self._fingerprint(oid)
                except (EvolutionError, KeyError, sqlite3.DatabaseError) as exc:
                    details[oid] = {"status": Applicability.EVIDENCE_UNVERIFIABLE.value,
                                    "diagnostic": type(exc).__name__}
                else:
                    status = (Applicability.APPLICABLE if latest == old_fingerprint
                              else Applicability.SUPERSEDED)
                    details[oid] = {"status": status.value,
                                    "diagnostic": "fingerprint matches" if status is Applicability.APPLICABLE
                                                  else "source contract or data changed"}
        statuses = {v["status"] for v in details.values()}
        for priority in (Applicability.EVIDENCE_UNVERIFIABLE, Applicability.EVIDENCE_GONE,
                         Applicability.SUPERSEDED, Applicability.APPLICABLE):
            if priority.value in statuses:
                return priority, details
        return Applicability.EVIDENCE_UNVERIFIABLE, {"*": {"status": "EVIDENCE_UNVERIFIABLE", "diagnostic": "no evidence"}}

    def propose(self, candidate: CandidateKnowledge, *, proposer: str) -> KnowledgeProposal:
        if type(candidate) is not CandidateKnowledge or not proposer:
            raise EvolutionError("knowledge proposal requires typed candidate and proposer")
        if not candidate.supporting_objects:
            raise EvolutionError("knowledge requires supporting objects")
        if candidate.status == "BLOCKED_INCOMPLETE_COVERAGE":
            raise EvolutionError("incomplete registry coverage cannot be promoted as knowledge")
        fingerprints = {oid: self._fingerprint(oid) for oid in candidate.supporting_objects}
        submission_id = str(uuid.uuid4())
        base = {"submission_id": submission_id, "proposer": proposer,
                "candidate": candidate.as_json(), "source_snapshots": fingerprints}
        digest = canonical_hash(base)
        with sql_conn(self.path) as db:
            db.execute("INSERT INTO knowledge_proposals VALUES(?,?,?,?,?)",
                       (submission_id, proposer, _json(candidate.as_json()), _json(fingerprints), digest))
        return KnowledgeProposal(submission_id, proposer, candidate, fingerprints, digest)

    def proposal(self, submission_id: str) -> KnowledgeProposal:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT * FROM knowledge_proposals WHERE submission_id=?",
                             (submission_id,)).fetchone()
        if row is None:
            raise KeyError(submission_id)
        c = json.loads(row[2])
        candidate = CandidateKnowledge(c["candidate_id"], c["kind"], c["statement"],
                        tuple(c["supporting_objects"]), tuple(c["supporting_events"]),
                        tuple(c["counterexamples"]), tuple(c["limitations"]), c["status"])
        return KnowledgeProposal(row[0], row[1], candidate, json.loads(row[3]), row[4])

    def decision(self, submission_id: str) -> KnowledgeDecision | None:
        with sql_conn(self.path) as db:
            row = db.execute("SELECT * FROM knowledge_decisions WHERE submission_id=?",
                             (submission_id,)).fetchone()
        if row is None:
            return None
        return KnowledgeDecision(row[0], row[1], row[2], row[3], tuple(json.loads(row[4])), row[5])

    def review(self, submission_id: str, *, reviewer: str, approve: bool,
               rationale: str, test_refs: tuple[str, ...] = ()) -> KnowledgeDecision:
        p = self.proposal(submission_id)
        if not reviewer or not rationale:
            raise EvolutionError("reviewer and rationale required")
        if reviewer == p.proposer:
            raise EvolutionError("knowledge proposer cannot approve its own finding")
        if self.decision(submission_id) is not None:
            raise EvolutionError("knowledge proposal was already decided")
        tests = _strings(test_refs, "test_refs")
        attempt_id = str(uuid.uuid4())
        self._record_attempt(attempt_id, submission_id, reviewer, KnowledgeReviewAttemptStatus.STARTED)
        try:
            allowed = self.authorize_review(reviewer, p)
        except Exception as exc:
            self._record_attempt(attempt_id, submission_id, reviewer,
                                 KnowledgeReviewAttemptStatus.UNDETERMINED, type(exc).__name__)
            raise EvolutionError("knowledge review authority undetermined; proposal remains pending") from exc
        if not allowed:
            self._record_attempt(attempt_id, submission_id, reviewer,
                                 KnowledgeReviewAttemptStatus.REFUSED, "reviewer not authorized")
            raise EvolutionError("knowledge reviewer has no external authority")
        self._record_attempt(attempt_id, submission_id, reviewer, KnowledgeReviewAttemptStatus.AUTHORIZED)
        # ATTACH before BEGIN IMMEDIATE. In this SQLite deployment the transaction
        # establishes reserved locks across both knowledge and evolution databases.
        # Snapshot check and decision insertion are then a single atomic region.
        try:
            with sql_conn(self.path) as db:
                if self.evolution.path != self.path:
                    db.execute("ATTACH DATABASE ? AS evolution_source", (self.evolution.path,))
                db.execute("BEGIN IMMEDIATE")
                if db.execute("SELECT 1 FROM knowledge_decisions WHERE submission_id=?",
                              (submission_id,)).fetchone():
                    raise EvolutionError("knowledge proposal was already decided")
                # Staleness/invalid evidence takes precedence over counterexamples.
                applicability, details = self._source_applicability(p.source_snapshots)
                if applicability is not Applicability.APPLICABLE:
                    status = KnowledgeDecisionStatus.STALE if applicability is Applicability.SUPERSEDED else KnowledgeDecisionStatus.REVIEW_DUE
                    rationale = f"NOT APPLIED: source {applicability.value}: {details}; reviewer's rationale: {rationale}"
                elif approve and p.candidate.counterexamples:
                    status = KnowledgeDecisionStatus.REJECTED
                    rationale = "NOT APPLIED: unresolved counterexamples: " + rationale
                elif approve and not tests:
                    status = KnowledgeDecisionStatus.REJECTED
                    rationale = "NOT APPLIED: independent test references missing: " + rationale
                else:
                    status = KnowledgeDecisionStatus.ACCEPTED if approve else KnowledgeDecisionStatus.REJECTED
                digest = canonical_hash({"submission_digest": p.digest, "status": status.value,
                                         "reviewer": reviewer, "rationale": rationale, "test_refs": list(tests)})
                db.execute("INSERT INTO knowledge_decisions VALUES(?,?,?,?,?,?)",
                           (p.submission_id, status.value, reviewer, rationale, _json(list(tests)), digest))
        except (sqlite3.DatabaseError,) as exc:
            self._record_attempt(attempt_id, submission_id, reviewer,
                                 KnowledgeReviewAttemptStatus.UNDETERMINED, type(exc).__name__)
            raise EvolutionError("knowledge review transaction failed") from exc
        except Exception as exc:
            state = (KnowledgeReviewAttemptStatus.CONFLICT
                     if isinstance(exc, EvolutionError) and "already decided" in str(exc)
                     else KnowledgeReviewAttemptStatus.UNDETERMINED)
            self._record_attempt(attempt_id, submission_id, reviewer, state, type(exc).__name__)
            raise
        d = self.decision(submission_id)
        assert d is not None
        self._record_attempt(attempt_id, submission_id, reviewer,
                             KnowledgeReviewAttemptStatus.COMPLETED, d.status)
        return d

    def accepted(self) -> list[dict[str, Any]]:
        with sql_conn(self.path) as db:
            ids = [r[0] for r in db.execute(
                "SELECT submission_id FROM knowledge_decisions WHERE status='ACCEPTED' ORDER BY rowid")]
        output = []
        for sid in ids:
            p, d = self.proposal(sid), self.decision(sid)
            assert d is not None
            status, details = self._source_applicability(p.source_snapshots)
            output.append({"submission_id": sid, "candidate": p.candidate.as_json(),
                           "source_snapshots": p.source_snapshots,
                           "applicability": status.value,
                           "applicability_details": details,
                           "currently_applicable": status is Applicability.APPLICABLE,
                           "reviewer": d.reviewer, "test_refs": list(d.test_refs),
                           "rationale": d.rationale})
        return strict_json_copy(output)
