"""Minimal original FD public-effect boundary; full durable owner is in agentic.py."""
from dataclasses import dataclass
from typing import Any, Callable, Mapping
from .original import ContractError, Job, Status, strict_json_copy


@dataclass(frozen=True)
class EffectRequest:
    kind: str
    resource: str
    payload: Mapping[str, Any]


class GuardedEffectGateway:
    """Not an effect store. Refuses without an EXTERNAL authority decision.

    Unlike the native agentic authority, this small original-framework adapter
    lacks its own durable attempt ledger and must not be used for an effect
    requiring crash/reconciliation guarantees.
    """
    def __init__(self,
                 authority_check: Callable[[Job, EffectRequest, str], bool],
                 owner_execute: Callable[[EffectRequest], Any]):
        self._authority_check = authority_check
        self._owner_execute = owner_execute

    def execute(self, job: Job, request: EffectRequest, approval: str) -> Any:
        if job.status is not Status.COMPLETED:
            raise ContractError("incomplete computation cannot request effect")
        strict_json_copy(dict(request.payload))
        if not request.kind or not request.resource or not approval:
            raise ContractError("missing operation, resource, or approval")
        if not self._authority_check(job, request, approval):
            raise ContractError("independent authority refused the effect")
        return self._owner_execute(request)
