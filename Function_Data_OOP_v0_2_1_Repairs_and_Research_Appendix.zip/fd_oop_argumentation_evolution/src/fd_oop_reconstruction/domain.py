"""Early Function–Data concepts: entity operations and predicate-based inference.

This module is a deliberately modest interpretation of the transcripts. It
never infers permission or a semantic goal from Python type compatibility.
"""
from dataclasses import dataclass
from typing import Any, Callable, Mapping
from .original import ContractError, ExecutionRegistry, Job, strict_json_copy


@dataclass(frozen=True)
class DomainRule:
    name: str
    contract_identity: str
    predicate: Callable[[Mapping[str, Any]], bool]


class DomainInference:
    """Rule-based, non-authoritative selection; ambiguity is a refusal."""
    def __init__(self, rules: tuple[DomainRule, ...]):
        self.rules = rules

    def suggest(self, observation: Mapping[str, Any]) -> str:
        snapshot = strict_json_copy(dict(observation))
        matches = [r.contract_identity for r in self.rules if r.predicate(snapshot)]
        if len(matches) != 1:
            raise ContractError(f"inference requires unique match; found {len(matches)}")
        return matches[0]


class EntityOperations:
    """Map domain-facing operation names to registered Function–Data contracts."""
    def __init__(self, operations: Mapping[str, str], registry: ExecutionRegistry):
        self._operations = dict(operations)
        self._registry = registry
        for contract in self._operations.values():
            registry.catalog.resolve(contract)

    def begin(self, operation: str, payload: Mapping[str, Any]) -> Job:
        if operation not in self._operations:
            raise ContractError(f"entity operation not registered: {operation}")
        return self._registry.create(self._operations[operation], payload)
