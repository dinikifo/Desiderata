# Function–Data OOP v0.2.1 — Argumentation-Governed Agentic Type Evolution

**v0.2.1 repairs the external review findings F1–F11**. See [Repair log](docs/REVIEW_REPAIR_LOG.md) and [Open questions and unresolved issues](docs/OPEN_QUESTIONS_AND_ISSUES.md). The first version remains the preserved research baseline; this is a working patch, not a production-ready governance boundary. 103 tests pass, including 18 new adversarial regressions, with three working demos.

This version **extends** the earlier working original and agentic Function–Data reconstruction. It adds a structured Toulmin discussion over JSON data/metadata transformations; persisted before/candidate/accepted-after snapshots and annotations; runtime type refinement with pinned schemas; whole-method reflection; and separately reviewed knowledge distillation.

**Quick start (Python 3.10+, standard library only):**

```bash
PYTHONPATH=src python -m fd_oop_reconstruction.demo original
PYTHONPATH=src python -m fd_oop_reconstruction.demo agentic
PYTHONPATH=src python -m fd_oop_reconstruction.demo evolution
PYTHONPATH=src python -m unittest discover -s tests -v
```

See **[Argumentation Evolution Architecture](docs/ARGUMENTATION_EVOLUTION.md)** for the complete model, API example, safeguards, limitations, and research questions. This is an experimental research reconstruction, not a recovered historical source codebase or formal gradual typing implementation.

## v0.2 implementation and v0.2.1 repairs

| Module | Purpose |
|---|---|
| `evolution.py` | Toulmin JSON arguments (including opposing claims); persistent immutable proposals/decisions, genesis + hash chain, independent review, schema constraints, pinned FD execution |
| `evolution_agent.py` | Goal-assignment-aware agent change proposals, with host-controlled approval |
| `distillation.py` | Reflection across all catalog methods, current JSON data/metadata and complete change histories; extracts candidate cross-method knowledge |
| `knowledge.py` | Separate submission, independent review and evidence-linked acceptance of candidate distilled rules; never self-installs rules |
| `evolution_demo.py` | Runnable combined agentic evolution + native effect + reviewed distillation |
| `tests/test_evolution*.py`, `tests/test_knowledge.py` | Persistence, race/rollback, type constraints, agent integration and reflection tests |

---

# Function–Data OOP ↔ Agentic Function–Data: Python reconstruction

A **runnable, standard-library-only research reconstruction** of two architectures described in the `zetel.39.txt` / `zetel.40.txt` conversation archive:

1. **Original Function–Data OOP kernel** — explicitly registered function/data pairs, JSON-backed state, metadata-defined transition graphs, a committed checkpoint history, durability, rule-based domain inference, independent acceptance and governed recovery.
2. **Agentic Function–Data extension** — a planning/preparation agent built on the same kernel, backed by separate goal assignment, native-style authorization, resource ownership, effect reconciliation, evidence-based acceptance, and historical observations.

**Important: this is not a copy of the historical Function–Data v1.9 source, the Round 26 System Zettel implementation, or the original G2–G7 experimental source.** The supplied ZIP contains descriptions of those codebases, not the complete historical implementations. The class names and invariants identified in discussion are followed where possible, but many method signatures and internals here are new reconstruction decisions. See [Traceability](docs/TRACEABILITY.md).

## Quick start

From the root of this project, using Python **3.10+**:

```bash
PYTHONPATH=src python -m fd_oop_reconstruction.demo original
PYTHONPATH=src python -m fd_oop_reconstruction.demo agentic
PYTHONPATH=src python -m unittest discover -s tests -v
```

No pip installation or external package is needed. Alternatively install with `python -m pip install -e .` if your environment has setuptools.

## Original Function–Data design

```text
     Domain rules / EntityOperations   (suggest operations, no authority)
                        |
                        v
     ContractCatalog: identity = name@version
              | one function : one data class
              v
     FunctionPair(Metadata, JsonData subclass, function)
              |
              v
     ExecutionRegistry   [pure/replay-safe work ONLY]
       | Step + Intent       | metadata transition validation
       |                     | strict detached JSON data
       +-----> SQLiteJobStore: CAS revisions + durable events
                             |
                 DomainSupervisor: inspection/recovery advice
                             |
                 AcceptanceGateway: independent verifier
                             |
                  GuardedEffectGateway (optional external port)
```

### Key constructs

| File | Elements | Behavior |
|---|---|---|
| `original.py` | `strict_json_copy`, `JsonData` | JSON-only state, defensive copy, no mutable input aliasing |
| `original.py` | `FunctionPair`, `Metadata`, `ContractCatalog` | One data subclass per callable and unique versioned contract identity |
| `original.py` | `Step`, `Intent`, `Status` | Explicit proposed transition; `YIELD`, `PARAMETER`, `COMPLETE`, `STOP`, `ERROR` |
| `original.py` | `ExecutionRegistry`, `SQLiteJobStore` | Commit state only after validating transition and data; append events; reject stale writers |
| `original.py` | `AcceptanceGateway`, `Evidence` | `COMPLETED` is not synonymous with accepted |
| `original.py` | `DomainSupervisor`, `RecoveryManager` | Diagnosis and separately authorized retries of pure failed computations |
| `domain.py` | `DomainRule`, `DomainInference`, `EntityOperations` | Predicate-based selection, explicit refusal when zero/multiple rules match |
| `effects.py` | `GuardedEffectGateway` | Minimal effect port that refuses without an external authority decision |

The **original framework reconstruction** is in `original.py`, `domain.py` and `effects.py`. This includes a condensed conceptual core and later v1.9-like durability/acceptance features to make it executable. It is **not** a faithful staging of each historical version.

### Original code example

```python
from fd_oop_reconstruction import (
    JsonData, Metadata, FunctionPair, Step, Intent,
    ContractCatalog, SQLiteJobStore, ExecutionRegistry,
)

class SumData(JsonData):
    pass

def sum_values(data: SumData) -> Step:
    return Step("DONE", {"sum": sum(data.payload["values"])}, Intent.COMPLETE)

catalog = ContractCatalog()
catalog.register(FunctionPair(
    Metadata("math.sum", "1.0", "START", {"START": ("DONE",)}, frozenset({"DONE"})),
    SumData, sum_values,
))
engine = ExecutionRegistry(catalog, SQLiteJobStore("fd_work.db"))
job = engine.create("math.sum@1.0", {"values": [2, 3]})
finished = engine.advance(job.job_id)
assert finished.payload["sum"] == 5
```

## Agentic Function–Data design

```text
       OPERATOR / HOST                         FD AGENT
  goal assignment and source               dedicated PrepareWorkData
            |                                    |
            |       source snapshot       NEW -> PREPARED -> SEALED
            +----------------------------------->|
                                                 |
                                     versioned, durable FD job
                                                 |
                                           pure PROPOSAL
                                                 |
                           host verifies sealed FD job + pin + assignment
                                                 |
         OPERATOR approval (separate) ---> NATIVE AUTHORITY
                                                 |
                                  one-use approval + native attempt
                                                 |
                                        VAULT RESOURCE OWNER
                                    atomic source check/write/receipt
                                                 |
                               effect SUCCESS / REJECTED / UNKNOWN
                                                 |
                             no automatic replay if effect outcome unknown
                                                 |
                                 reconciliation from owner's receipt
                                                 |
                                INDEPENDENT OUTCOME ORACLE
                                  ACCEPTED / REJECTED / INCONCLUSIVE
                                                 |
                                   METHOD HISTORY (observations)
```

`agentic.py` implements the following distinct responsibilities:

- **`FDAgent`**: records source-bound goal preparation in a durable Function–Data job and emits a sealed proposal. Cannot call native effect APIs as a method of this class.
- **`GoalAssignments`**: keeps persistent, revisioned, host-issued goal bindings. Changes invalidate prepared work.
- **`VaultOwner`**: owns note revisions, source pins, published artifacts and owner-transactional effect receipts. This is a **local illustrative stand-in** for the native System Zettel Vault.
- **`NativeAuthority`**: independently rechecks the FD job, goal assignment, source content/revision and exact proposal; records one-use approval, durable attempt ID, and effect status. Does **not** let a Function–Data checkpoint stand in for native approval.
- **`IndependentOutcomeOracle`**: checks that the owner can attest the artifact and that an explicitly defined goal predicate holds. An artifact write can succeed while outcome assessment is rejected or inconclusive.
- **`MethodMemory`**: persists observations across goals. It does not claim autonomous adaptation or proven learning.

The **`NEW → PREPARED → SEALED`** two-stage FD workflow is based on the G4 discussion. The native-delegation boundary derives from G3; persistent goal reassignment/history is inspired by G5, without pretending to reproduce all G5–G7 mechanisms.

### Agentic code example

```python
from fd_oop_reconstruction.agentic import (
    VaultOwner, GoalAssignments, FDAgent, NativeAuthority,
    IndependentOutcomeOracle, Goal,
)

vault = VaultOwner("vault.db")
assignments = GoalAssignments("assignments.db")
agent = FDAgent("research-agent", "fd.db", assignments)
native = NativeAuthority("native.db", vault, assignments, agent.store)

pin = vault.put_note("source", "An observable claim.")  # HOST-owned fixture
purpose = Goal("g1", "Preserve observed source", "source", "record", "observable claim")
assignments.assign("research-agent", purpose.goal_id, "operator")  # HOST
job = agent.start(purpose, pin)
agent.resume(job.job_id)
agent.resume(job.job_id)
proposal = agent.proposal(job.job_id)

approval = native.operator_approve(proposal, operator_id="operator")  # HOST, not agent
effect = native.execute(proposal, approval)
outcome = IndependentOutcomeOracle(vault).review(purpose, proposal, effect)
print(effect.status, outcome.assessment)
```

The `demo agentic` command intentionally injects a simulated crash *after* the resource owner commits, showing an `UNKNOWN` native attempt subsequently reconciled to `SUCCESS` using an owner receipt. This is a test of **uncertainty handling**, not an exactly-once distributed transaction.

## What the tests verify

- Strict data validation and detached input snapshots.
- One-to-one function/data registration and illegal-transition rejection.
- Durable `START → COUNTED → DONE` and `NEW → PREPARED → SEALED` recovery.
- Atomic compare-and-swap job revisions, terminal-job refusal.
- `COMPLETED` without automatic acceptance; independent evidence required.
- Predicate inference refusing ambiguity and externally approved recovery.
- Host-issued goal assignments, revision changes, and source pin enforcement.
- Rejection of forged proposal IDs, forged source excerpts, mismatched approval tokens, and replayed approvals.
- Fail-closed behavior for changed sources, unknown owner effects, and crash-after-write reconciliation.
- Successful resource effect with **rejected** or **inconclusive** goal assessment.
- Persistent method history across two separately assigned goals.

## Major limitations — do not treat as production controls

1. **Not original historical source**: the class names are historically grounded, but method contracts, SQLite schema, source format, status categories, and host APIs are reconstructed.
2. **No secure isolation**: all actors run in one Python process. Any adversary with arbitrary Python execution or direct filesystem/database access could bypass the simulated approvals. `operator_id` is a label, **not authenticated identity**.
3. **No LLM, HTN, QSECD or genuine autonomous planning**: the agent's method is a deterministic source-bound draft operation so the lifecycles can be tested objectively.
4. **No real Round 26, Zettelkasten Vault, or institutional credential service**: host, authority and Vault are local illustrative substitutes.
5. **No general distributed transactions / exactly-once effects**: owner-local writes are transactional and idempotent, but native intent and owner write live in separate DBs. Uncertainty is explicitly preserved. Reconciliation only establishes success from a matching receipt.
6. **Not independent evidence authentication**: the oracle checks defined predicates against the owner's stored records. It cannot determine semantic truth or prevent a dishonest/compromised owner.
7. **No secure dynamic Python plugin system or sandbox**: all registered workers are trusted by their caller to be side-effect-free and deterministic. The runtime cannot prove Python functions are pure.
8. **No automatic self-healing or verified performance improvement**: domain rules make advice; history stores outcomes. Neither changes goals, policies, or code without host-mediated action.
9. **No robust multi-tenant/production controls**: no authenticated principals, rate limits, monitoring, host OS process hardening, secret storage, or formal protocol specification.

For a real implementation, the next phase should be **reference-source recovery and behavioral differential testing** against the frozen v1.9 implementation and the native Round 26/FD-agent sources, rather than treating this reimplementation as a drop-in replacement.

## Project structure

```text
src/fd_oop_reconstruction/
  original.py     original FD contracts, execution, persistence, acceptance, recovery
  domain.py       early entity operation dictionary and rule-based inference
  effects.py      guarded effect abstraction
  agentic.py      separate agent, goal ledger, authority, owner and oracle
  demo.py         two standalone walkthroughs
  __init__.py     selected public exports
tests/
  test_original.py
  test_agentic.py
docs/
  TRACEABILITY.md
```
