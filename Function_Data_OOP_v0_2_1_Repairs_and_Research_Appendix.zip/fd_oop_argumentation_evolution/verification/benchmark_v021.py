from tempfile import TemporaryDirectory
from pathlib import Path
import time
from fd_oop_reconstruction import (ContractCatalog, FunctionPair, Metadata, JsonData, Step,
                                    Intent, EvolutionLedger, TypeEvolutionController)
class D(JsonData): pass
def f(d: D) -> Step: return Step('DONE', {'x': d.payload['x']}, Intent.COMPLETE)
arg = {'claim':'x should be recorded', 'grounds':['observed x'], 'warrant':'required by operation'}
with TemporaryDirectory() as root:
    c=ContractCatalog(); c.register(FunctionPair(Metadata('f','1','START',{'START':('DONE',)},frozenset({'DONE'})),D,f))
    e=EvolutionLedger(str(Path(root)/'ev.db')); ctrl=TypeEvolutionController(c,e,lambda reviewer,p:True)
    ctrl.register_object('obj','f@1',{'x':1},{'type':'object','properties':{'x':{'type':'integer'}},'required':['x']})
    for n in range(1,121):
        t0=time.perf_counter()
        p=ctrl.propose('obj',proposer='agent',expected_revision=n-1,arguments=[arg],data={'x':n+1})
        ctrl.review(p.proposal_id,reviewer='operator',approve=True,reason='test')
        ms=(time.perf_counter()-t0)*1000
        if n in (20,60,120):
            t=time.perf_counter();v=e.verify_history('obj');vm=(time.perf_counter()-t)*1000
            print(n, 'propose+review_ms',round(ms,3),'verify_ms',round(vm,3), 'status',v.status.value)
