"""Reproduce selected mutation tests against isolated working-copy mutants."""
from pathlib import Path
import os, shutil, subprocess, sys, tempfile
root=Path(__file__).resolve().parents[1]
mutations=[
 ('M1 unknown verdict', 'evolution.py', 'return HistoryVerdict(HistoryStatus.NO_SUCH_OBJECT, "unknown object id")', 'return HistoryVerdict(HistoryStatus.BROKEN, "unknown object id")','test_f1_unknown_object'),
 ('M2 deleted row escapes', 'evolution.py', 'return HistoryVerdict(HistoryStatus.UNCHECKABLE, "genesis exists but current object row is missing")', 'raise KeyError(object_id)','test_f2_current_deleted'),
 ('M3 stale reason erased', 'evolution.py', 'f"NOT APPLIED: base revision {p.base_revision}', 'f"base revision {p.base_revision}','test_f3_stale_reason'),
 ('M4 eligibility lapsed mislabeled', 'evolution.py', 'override = EvolutionDecisionStatus.REVIEW_DUE\n            validation.setdefault("eligibility", "lapsed")', 'override = EvolutionDecisionStatus.REJECTED\n            validation.setdefault("eligibility", "lapsed")', 'test_f4_eligibility_lapse'),
 ('M6 authority failure unrecorded', 'evolution.py', 'self.ledger.record_review_attempt(attempt_id, proposal_id, reviewer,\n                          ReviewAttemptStatus.UNDETERMINED, type(exc).__name__)', 'pass  # mutant removes durable authority failure', 'test_f6_authority_unavailable'),
 ('M10 missing index', 'evolution.py', 'CREATE INDEX IF NOT EXISTS evolution_decisions_object_idx\n                ON evolution_decisions(object_id);', '/* intentionally removed decision index */', 'test_f10_index_is_used'),
 ('M5 fake validation pass', 'evolution.py', '"argument_structure": "checked_at_proposal"', '"argument_structure": "passed"','test_f5_argument_structure'),
 ('M7 collapsed applicability', 'knowledge.py', '"applicability": status.value,', '"applicability": Applicability.SUPERSEDED.value,','test_f7_accepted_knowledge'),
 ('M8 missing already decided', 'knowledge.py', 'if db.execute("SELECT 1 FROM knowledge_decisions WHERE submission_id=?",', 'if False and db.execute("SELECT 1 FROM knowledge_decisions WHERE submission_id=?",','test_f8_parallel_review'),
 ('M9 no partial reflection', 'distillation.py', '                continue\n            obj = self.ledger.get(object_id)', '                raise ValueError("bad object")\n            obj = self.ledger.get(object_id)', 'test_f9_reflection_partial'),
 ('M11 ignored schema safeguard', 'evolution.py', 'if not schema_narrows_or_equals(p.candidate_metadata["schema"],', 'if False and not schema_narrows_or_equals(p.candidate_metadata["schema"],', 'test_f11_schema_relaxation'),
]
for label,filename,old,new,test in mutations:
    with tempfile.TemporaryDirectory() as d:
        target=Path(d)/'project'
        shutil.copytree(root,target,ignore=shutil.ignore_patterns('__pycache__'))
        f=target/'src'/'fd_oop_reconstruction'/filename
        text=f.read_text()
        assert text.count(old)==1,(label,text.count(old))
        f.write_text(text.replace(old,new,1))
        env={**os.environ,'PYTHONPATH':str(target/'src')}
        proc=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_review_repairs.py','-k',test],cwd=target,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20)
        if proc.returncode == 0:
            print('UNEXPECTED SURVIVAL',label,proc.stdout[-150:]);sys.exit(1)
        print('KILLED',label)
print('MUTATION_CHECKS_PASSED',len(mutations))
