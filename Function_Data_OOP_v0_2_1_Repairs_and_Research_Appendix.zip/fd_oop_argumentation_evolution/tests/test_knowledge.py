"""Distilled knowledge is proposed, independently reviewed, and never auto-applied."""
from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from fd_oop_reconstruction import (
    ContractCatalog, EvolutionLedger, TypeEvolutionController, FunctionPair, Metadata,
    JsonData, Intent, Step, ReflectionDistiller, KnowledgeLedger, EvolutionError,
)


class AData(JsonData):
    pass


class BData(JsonData):
    pass


def op_a(d: AData) -> Step:
    return Step("DONE", {"result": d.payload["revision"]}, Intent.COMPLETE)


def op_b(d: BData) -> Step:
    return Step("DONE", {"result": d.payload["revision"]}, Intent.COMPLETE)


class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        temp = TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        self.catalog = ContractCatalog()
        for name, data_type, func in (("a", AData, op_a), ("b", BData, op_b)):
            self.catalog.register(FunctionPair(Metadata(name, "1", "START", {"START": ("DONE",)},
                            frozenset({"DONE"})), data_type, func))
        self.ledger = EvolutionLedger(str(root / "evolution.db"))
        self.ctrl = TypeEvolutionController(self.catalog, self.ledger,
                                           lambda reviewer, p: reviewer == "operator")
        common = {"type": "object", "properties": {"revision": {"type": "integer"}}}
        self.ctrl.register_object("o1", "a@1", {"revision": 1}, common)
        self.ctrl.register_object("o2", "b@1", {"revision": 1}, common)
        self.candidate = ReflectionDistiller(self.catalog, self.ledger).reflect().candidates[0]
        self.kb = KnowledgeLedger(str(root / "knowledge.db"), self.ledger,
                                  lambda reviewer, p: reviewer == "operator")

    def test_no_automatic_promotions(self):
        self.assertEqual(self.kb.accepted(), [])
        p = self.kb.propose(self.candidate, proposer="agent")
        self.assertIsNone(self.kb.decision(p.submission_id))
        self.assertEqual(self.kb.accepted(), [])

    def test_accepted_knowledge_with_test_reference(self):
        p = self.kb.propose(self.candidate, proposer="agent")
        d = self.kb.review(p.submission_id, reviewer="operator", approve=True,
                           rationale="reviewed", test_refs=("test:knowledge-shape-1",))
        self.assertEqual(d.status, "ACCEPTED")
        self.assertEqual(len(self.kb.accepted()), 1)
        self.assertEqual(self.ledger.get("o1").revision, 0)

    def test_self_review_refused(self):
        p = self.kb.propose(self.candidate, proposer="agent")
        with self.assertRaises(EvolutionError):
            self.kb.review(p.submission_id, reviewer="agent", approve=True,
                           rationale="me", test_refs=("test",))

    def test_unauthorized_review_refused(self):
        p = self.kb.propose(self.candidate, proposer="agent")
        with self.assertRaises(EvolutionError):
            self.kb.review(p.submission_id, reviewer="stranger", approve=True,
                           rationale="me", test_refs=("test",))

    def test_acceptance_requires_test_references(self):
        p = self.kb.propose(self.candidate, proposer="agent")
        d = self.kb.review(p.submission_id, reviewer="operator", approve=True,
                           rationale="me")
        self.assertEqual(d.status, "REJECTED")
        self.assertIn("independent test", d.rationale)

    def test_rejected_knowledge_preserved(self):
        p = self.kb.propose(self.candidate, proposer="agent")
        self.assertEqual(self.kb.review(p.submission_id, reviewer="operator", approve=False,
                                        rationale="insufficient evidence").status, "REJECTED")
        self.assertEqual(self.kb.accepted(), [])

    def test_stale_evidence_does_not_promote(self):
        p = self.kb.propose(self.candidate, proposer="agent")
        proposal = self.ctrl.propose("o1", proposer="agent", expected_revision=0,
                    arguments=[{"claim": "revision was observed", "grounds": ["snapshot"],
                                "warrant": "observed fields can be typed"}], data={"revision": 3})
        self.ctrl.review(proposal.proposal_id, reviewer="operator", approve=True, reason="new version")
        self.assertEqual(self.kb.review(p.submission_id, reviewer="operator", approve=True,
                                        rationale="now stale", test_refs=("test",)).status, "STALE")
        self.assertEqual(self.kb.accepted(), [])

    def test_promotion_with_counterexamples_refused(self):
        from fd_oop_reconstruction.distillation import CandidateKnowledge
        candidate = CandidateKnowledge("counter", "REPEATED_FIELD_SCHEMA", "test", ("o1", "o2"), (),
                                       ("other-system",), ("counterexample",))
        p = self.kb.propose(candidate, proposer="agent")
        d = self.kb.review(p.submission_id, reviewer="operator", approve=True,
                           rationale="ignoring contradiction", test_refs=("test",))
        self.assertEqual(d.status, "REJECTED")
        self.assertIn("counterexamples", d.rationale)


if __name__ == "__main__":
    unittest.main()
