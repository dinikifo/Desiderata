"""Verify real agent use of evolved schemas while native authority stays separate."""
from pathlib import Path
from fd_oop_reconstruction.original import sql_conn
from tempfile import TemporaryDirectory
import unittest

from fd_oop_reconstruction.agentic import FDAgent, Goal, GoalAssignments, VaultOwner
from fd_oop_reconstruction.agentic import build_agent_catalog
from fd_oop_reconstruction.evolution import EvolutionLedger, TypeEvolutionController, SchemaError
from fd_oop_reconstruction.evolution_demo import run as evolution_demo


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)

    def test_end_to_end_evolved_agent_native_effect_and_knowledge(self):
        output = evolution_demo(self.path)
        self.assertEqual(output["native_effect"], "SUCCESS")
        self.assertEqual(output["independent_goal_assessment"], "ACCEPTED")
        self.assertEqual(output["reviewed_knowledge_decision"], "ACCEPTED")
        self.assertEqual(output["accepted_knowledge_count"], 1)
        self.assertEqual(output["accepted_evolution_decisions"], ["ACCEPTED", "ACCEPTED"])
        self.assertEqual(output["pinned_job_object_revision"], 1)
        self.assertEqual({x["kind"] for x in output["distilled_candidate_knowledge"]},
                         {"REPEATED_FIELD_SCHEMA", "REPEATED_ACCEPTED_ARGUMENT"})

    def test_governed_fdagent_refuses_source_revision_outside_new_type(self):
        ledger = EvolutionLedger(str(self.path / "evolution.db"))
        catalog = build_agent_catalog()
        ctrl = TypeEvolutionController(catalog, ledger, lambda actor, p: actor == "operator")
        ctrl.register_object("prepare", "fd_agent.prepare_work@0.1.0", {"source_revision": 2},
                 {"type": "object", "properties": {
                     "source_revision": {"type": "integer", "minimum": 2}},
                  "required": ["source_revision"]})
        vault = VaultOwner(self.path / "vault.db")
        pin = vault.put_note("src", "text")  # owner revision 1, less than min 2
        assignments = GoalAssignments(self.path / "assignments.db")
        assignments.assign("agent", "goal", "operator")
        agent = FDAgent("agent", self.path / "fd.db", assignments,
                        evolution_ledger=ledger, evolving_object_id="prepare")
        with self.assertRaises(SchemaError):
            agent.start(Goal("goal", "test", "src", "out", "text"), pin)

    def test_current_snapshot_tampering_detected_by_genesis(self):
        ledger = EvolutionLedger(str(self.path / "evolution.db"))
        catalog = build_agent_catalog()
        ctrl = TypeEvolutionController(catalog, ledger, lambda actor, p: actor == "operator")
        ctrl.register_object("prepare", "fd_agent.prepare_work@0.1.0", {"source_revision": 1},
                 {"type": "object", "properties": {"source_revision": {"type": "integer"}}})
        self.assertTrue(ledger.verify_history("prepare"))
        with sql_conn(ledger.path) as db:
            db.execute("UPDATE evolution_objects SET data_json=? WHERE object_id=?",
                       ('{"source_revision":999}', "prepare"))
        self.assertFalse(ledger.verify_history("prepare"))


if __name__ == "__main__":
    unittest.main()
