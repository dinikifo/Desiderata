import math
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from fd_oop_reconstruction.original import (
    JsonData, Metadata, FunctionPair, ContractCatalog, Step, Intent, Status,
    ContractError, ConcurrencyError, AcceptanceError, SQLiteJobStore,
    ExecutionRegistry, AcceptanceGateway, Evidence, DomainSupervisor,
    strict_json_copy, RecoveryManager, RecoveryPermit,
)
from fd_oop_reconstruction.effects import GuardedEffectGateway, EffectRequest
from fd_oop_reconstruction.domain import DomainRule, DomainInference, EntityOperations


class IncrementData(JsonData):
    pass


def increment(data: IncrementData) -> Step:
    if data.checkpoint == 'START':
        return Step('COUNTED', {'count': data.payload['count'] + 1}, Intent.YIELD)
    return Step('DONE', {'doubled': data.payload['count'] * 2}, Intent.COMPLETE)


class AlternateData(JsonData):
    pass


def alternate(data: AlternateData) -> Step:
    return Step('DONE', {'value': 5}, Intent.COMPLETE)


class BadData(JsonData):
    pass


class RepairData(JsonData):
    pass


def repairable(data: RepairData) -> Step:
    if data.payload['value'] < 0:
        return Step(intent=Intent.ERROR, diagnostic='value must be nonnegative')
    return Step('DONE',{'result':data.payload['value']+1},Intent.COMPLETE)



def bad(data: BadData) -> Step:
    return Step('NEVER', {'x': 4}, Intent.COMPLETE)


class ParameterData(JsonData):
    pass


def ask_params(data: ParameterData) -> Step:
    if data.checkpoint == 'START':
        return Step('WAIT', {}, Intent.PARAMETER)
    return Step('DONE', {'received': data.payload['answer']}, Intent.COMPLETE)


class OriginalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'fd.sqlite'
        self.catalog = ContractCatalog()
        self.pair = FunctionPair(Metadata('increment', '1.0', 'START',
                {'START': ('COUNTED',), 'COUNTED': ('DONE',)}, frozenset({'DONE'})),
                IncrementData, increment)
        self.catalog.register(self.pair)
        self.store = SQLiteJobStore(self.path)
        self.reg = ExecutionRegistry(self.catalog, self.store)

    def test_json_is_detached(self):
        original = {'x': [1]}
        obj = JsonData(original)
        original['x'].append(2)
        self.assertEqual(obj.payload, {'x': [1]})
        snapshot = obj.snapshot()
        snapshot['x'].append(3)
        self.assertEqual(obj.payload['x'], [1])

    def test_json_rejects_invalid_and_nan(self):
        with self.assertRaises(ContractError):
            strict_json_copy({4: 'bad'})
        with self.assertRaises(ContractError):
            strict_json_copy({'x': math.nan})
        with self.assertRaises(ContractError):
            strict_json_copy({'x': set()})
        a = []
        a.append(a)
        with self.assertRaises(ContractError):
            strict_json_copy(a)

    def test_function_annotation_must_match_data_class(self):
        with self.assertRaises(ContractError):
            FunctionPair(Metadata('wrong','1','START',{'START':('DONE',)},
                     frozenset({'DONE'})), AlternateData, increment)

    def test_metadata_transition_graph_is_immutable(self):
        transitions={'START': ['DONE']}
        m=Metadata('immutable','1','START',transitions,frozenset({'DONE'}))
        transitions['START'].append('FORGED')
        self.assertFalse(m.allows('START','FORGED'))
        with self.assertRaises(TypeError):
            m.transitions['START']=('FORGED',)

    def test_dedicated_class_required(self):
        with self.assertRaises(ContractError):
            FunctionPair(self.pair.metadata, JsonData, increment)

    def test_pair_one_to_one(self):
        with self.assertRaises(ContractError):
            self.catalog.register(FunctionPair(Metadata('increment2','1','START',
                {'START': ('DONE',)},frozenset({'DONE'})), IncrementData, alternate))
        with self.assertRaises(ContractError):
            self.catalog.register(self.pair)

    def test_checkpoint_and_recovery_from_disk(self):
        job = self.reg.create('increment@1.0', {'count': 1})
        next_job = self.reg.advance(job.job_id, expected_revision=0)
        self.assertEqual((next_job.checkpoint,next_job.status, next_job.revision),
                         ('COUNTED', Status.YIELDED, 1))
        restarted = ExecutionRegistry(self.catalog, SQLiteJobStore(self.path))
        finished = restarted.advance(job.job_id, expected_revision=1)
        self.assertEqual(finished.payload, {'count': 2, 'doubled': 4})
        self.assertEqual(finished.status, Status.COMPLETED)
        self.assertEqual(len(self.store.history(job.job_id)), 3)

    def test_stale_revision_fenced(self):
        job = self.reg.create('increment@1.0', {'count': 1})
        self.reg.advance(job.job_id)
        with self.assertRaises(ConcurrencyError):
            self.reg.advance(job.job_id, expected_revision=0)

    def test_terminal_is_not_replayed(self):
        job = self.reg.create('increment@1.0', {'count': 1})
        self.reg.advance(job.job_id)
        self.reg.advance(job.job_id)
        with self.assertRaises(ContractError):
            self.reg.advance(job.job_id)

    def test_illegal_transition_records_failure_and_never_commits_patch(self):
        self.catalog.register(FunctionPair(Metadata('bad','1','START',
            {'START': ('DONE',)}, frozenset({'DONE'})), BadData, bad))
        job = self.reg.create('bad@1', {'safe': True})
        with self.assertRaises(ContractError):
            self.reg.advance(job.job_id)
        after = self.store.get(job.job_id)
        self.assertEqual(after.status, Status.FAILED)
        self.assertEqual(after.payload, {'safe': True})

    def test_acceptance_separate(self):
        job = self.reg.create('increment@1.0', {'count': 1})
        self.reg.advance(job.job_id)
        done = self.reg.advance(job.job_id)
        gateway = AcceptanceGateway(self.store)
        self.assertFalse(gateway.accepted(job.job_id))
        evidence = Evidence(job.job_id, done.revision, 'independent-oracle','worker',{'is_correct':True})
        self.assertFalse(gateway.evaluate(evidence,lambda j,e: False))
        self.assertFalse(gateway.accepted(job.job_id))
        self.assertTrue(gateway.evaluate(evidence,lambda j,e: j.payload['doubled']==4 and e['is_correct']))
        self.assertTrue(gateway.accepted(job.job_id))

    def test_refuse_self_attestation_and_stale_evidence(self):
        job = self.reg.create('increment@1.0', {'count': 1})
        self.reg.advance(job.job_id)
        done = self.reg.advance(job.job_id)
        gate = AcceptanceGateway(self.store)
        with self.assertRaises(AcceptanceError):
            gate.evaluate(Evidence(job.job_id, 0, 'oracle','worker',{}),lambda j,e: True)
        with self.assertRaises(AcceptanceError):
            gate.evaluate(Evidence(job.job_id, done.revision, 'worker','worker',{}),lambda j,e: True)

    def test_parameter_control(self):
        self.catalog.register(FunctionPair(Metadata('ask','1','START',
            {'START':('WAIT',),'WAIT':('DONE',)},frozenset({'DONE'})), ParameterData, ask_params))
        job = self.reg.create('ask@1', {})
        waiting = self.reg.advance(job.job_id)
        self.assertEqual(waiting.status, Status.PARAMETERS_REQUIRED)
        with self.assertRaises(ContractError):
            self.reg.advance(job.job_id)
        done = self.reg.advance(job.job_id, parameters={'answer':42})
        self.assertEqual(done.payload['received'],42)

    def test_entity_ops_and_domain_inference(self):
        entity = EntityOperations({'count': 'increment@1.0'},self.reg)
        job = entity.begin('count', {'count':3})
        self.assertEqual(job.status, Status.NEW)
        inf = DomainInference((DomainRule('countable','increment@1.0',lambda p:'count' in p),))
        self.assertEqual(inf.suggest({'count':3}), 'increment@1.0')
        with self.assertRaises(ContractError):
            inf.suggest({'other':1})
        ambiguous = DomainInference((DomainRule('a','increment@1.0',lambda p:True),
                                    DomainRule('b','increment@1.0',lambda p:True)))
        with self.assertRaises(ContractError):
            ambiguous.suggest({})

    def test_recovery_requires_host_permission_and_safe_effect_state(self):
        self.catalog.register(FunctionPair(Metadata('bad','1','START',
            {'START': ('DONE',)}, frozenset({'DONE'})), BadData, bad))
        job = self.reg.create('bad@1', {'safe':True})
        with self.assertRaises(ContractError):
            self.reg.advance(job.job_id)
        failed = self.store.get(job.job_id)
        permit = RecoveryPermit(job.job_id,failed.revision,'operator','correct inputs')
        manager = RecoveryManager(self.store, lambda p: p.operator_id == 'approved-operator')
        with self.assertRaises(ContractError):
            manager.recover(permit)
        manager = RecoveryManager(self.store, lambda p: True)
        with self.assertRaises(ContractError):
            manager.recover(permit, external_effect_uncertain=True)
        reset = manager.recover(permit,corrected_input={'safe':False})
        self.assertEqual(reset.status, Status.YIELDED)
        self.assertEqual(reset.checkpoint,'START')
        self.assertEqual(reset.payload['safe'],False)

    def test_recovery_can_correct_inputs_without_autonomous_self_healing(self):
        self.catalog.register(FunctionPair(Metadata('repair','1','START',
            {'START': ('DONE',)},frozenset({'DONE'})),RepairData,repairable))
        job=self.reg.create('repair@1',{'value':-1})
        failed=self.reg.advance(job.job_id)
        self.assertEqual(failed.status,Status.FAILED)
        permit=RecoveryPermit(job.job_id, failed.revision, 'operator', 'fix validated input')
        manager=RecoveryManager(self.store,lambda p:p.operator_id=='operator')
        restored=manager.recover(permit,corrected_input={'value':9})
        done=self.reg.advance(restored.job_id)
        self.assertEqual(done.payload['result'],10)
        self.assertEqual(done.status,Status.COMPLETED)

    def test_guarded_effect_gateway_does_not_self_approve(self):
        job = self.reg.create('increment@1.0', {'count': 3})
        self.reg.advance(job.job_id)
        done = self.reg.advance(job.job_id)
        writes = []
        gateway = GuardedEffectGateway(lambda j,e,t:t=='host-approved',
                                       lambda e:writes.append(e.resource))
        request = EffectRequest('publish','artifact',{'note':'x'})
        with self.assertRaises(ContractError):
            gateway.execute(done,request,'invented-token')
        self.assertEqual(writes, [])
        gateway.execute(done,request,'host-approved')
        self.assertEqual(writes,['artifact'])

    def test_supervisor_does_not_self_authorize(self):
        job = self.reg.create('increment@1.0',{'count':1})
        advice = DomainSupervisor().inspect(job,external_effect_uncertain=True)
        self.assertEqual(advice.proposed_action,'HALT_AND_RECONCILE')
        self.assertTrue(advice.requires_approval)


if __name__=='__main__':
    unittest.main()
