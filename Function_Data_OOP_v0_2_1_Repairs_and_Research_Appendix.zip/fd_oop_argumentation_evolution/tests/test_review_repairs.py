"""Adversarial tests reproducing the 2026-11-06 external review findings F1–F11.

These test behavior, not just the presence of names. For mutation evidence see
`docs/REVIEW_REPAIR_LOG.md` and the supplied PACKAGE_REVIEW_2026-11-06.md.
"""
from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
import sqlite3
import unittest

from fd_oop_reconstruction import (
    ContractCatalog, FunctionPair, Metadata, JsonData, Intent, Step,
    EvolutionLedger, TypeEvolutionController, EvolutionError,
    HistoryStatus, ReflectionDistiller, KnowledgeLedger, Applicability,
)
from fd_oop_reconstruction.original import sql_conn
from fd_oop_reconstruction.distillation import CandidateKnowledge


class DataA(JsonData):
    pass


class DataB(JsonData):
    pass


def foo(d: DataA) -> Step:
    return Step("DONE", {"n": d.payload["n"]}, Intent.COMPLETE)


def bar(d: DataB) -> Step:
    return Step("DONE", {"n": d.payload["n"]}, Intent.COMPLETE)


ARG = {"claim": "n is observed as integer", "grounds": ["source observation"],
       "warrant": "integer operations require integer inputs"}


class RepairTests(unittest.TestCase):
    def setUp(self):
        td = TemporaryDirectory()
        self.addCleanup(td.cleanup)
        root = Path(td.name)
        self.c = ContractCatalog()
        for name, dt, f in (("a", DataA, foo), ("b", DataB, bar)):
            self.c.register(FunctionPair(Metadata(name, "1", "START", {"START": ("DONE",)},
                                frozenset({"DONE"})), dt, f))
        self.ev = EvolutionLedger(str(root / "ev.db"))
        self.ctrl = TypeEvolutionController(self.c, self.ev, lambda reviewer, p: reviewer == "operator")
        self.schema = {"type": "object", "properties": {"n": {"type": "integer", "minimum": 1}},
                       "required": ["n"]}
        self.ctrl.register_object("o1", "a@1", {"n": 1}, self.schema)
        self.ctrl.register_object("o2", "b@1", {"n": 2}, self.schema)
        self.kb = KnowledgeLedger(str(root / "kb.db"), self.ev, lambda reviewer, p: reviewer == "operator")

    def proposal(self, oid="o1", *, value=3, metadata=None):
        return self.ctrl.propose(oid, proposer="agent", expected_revision=self.ev.get(oid).revision,
                                 arguments=[ARG], data={"n": value}, metadata=metadata)

    def approve(self, proposal):
        return self.ctrl.review(proposal.proposal_id, reviewer="operator", approve=True, reason="validated")

    def knowledge_proposal(self, *, counterexamples=()):
        candidate = CandidateKnowledge("test", "REPEATED_FIELD_SCHEMA", "n is integer",
             ("o1", "o2"), (), tuple(counterexamples), ("limited",))
        return self.kb.propose(candidate, proposer="agent")

    def test_f1_unknown_object_is_not_tampering(self):
        v = self.ev.verify_history("missing")
        self.assertEqual(v.status, HistoryStatus.NO_SUCH_OBJECT)
        with self.assertRaisesRegex(EvolutionError, "NO_SUCH_OBJECT"):
            self.ctrl.propose("missing", proposer="agent", expected_revision=0,
                              arguments=[ARG], data={"n": 1})

    def test_f2_current_deleted_is_total_uncheckable(self):
        with sql_conn(self.ev.path) as db:
            db.execute("DELETE FROM evolution_objects WHERE object_id='o1'")
        verdict = self.ev.verify_history("o1")
        self.assertEqual(verdict.status, HistoryStatus.UNCHECKABLE)
        self.assertIn("missing", verdict.detail)

    def test_f3_stale_reason_and_applied_record_match(self):
        a, b = self.proposal(value=4), self.proposal(value=5)
        self.approve(a)
        stale = self.approve(b)
        self.assertEqual(stale.status, "STALE")
        self.assertIn("NOT APPLIED", stale.reason)
        self.assertEqual(stale.validation["applied"], "no")
        self.assertEqual(stale.validation["stale_against"], 0)
        self.assertEqual(stale.validation["reviewer_approval_intent"], True)
        self.assertTrue(self.ev.verify_history("o1"))

    def test_f4_eligibility_lapse_is_review_due(self):
        ctrl = TypeEvolutionController(self.c, self.ev, lambda reviewer, p: True,
                                        eligibility_check=lambda p: False)
        p = self.proposal()
        d = ctrl.review(p.proposal_id, reviewer="operator", approve=True, reason="would approve")
        self.assertEqual(d.status, "REVIEW_DUE")
        self.assertEqual(d.validation["eligibility"], "lapsed")
        self.assertEqual(self.ev.get("o1").revision, 0)

    def test_f5_argument_structure_is_attributed_to_proposal_stage(self):
        p = self.proposal()
        d = self.ctrl.review(p.proposal_id, reviewer="operator", approve=False, reason="insufficient")
        self.assertEqual(d.validation["argument_structure"], "checked_at_proposal")
        self.assertEqual(d.validation["schema"], "not_run")

    def test_f6_authority_unavailable_leaves_durable_attempt_and_pending_proposal(self):
        p = self.proposal()
        ctrl = TypeEvolutionController(self.c, self.ev,
                                       lambda reviewer, change: 1 / 0)
        with self.assertRaisesRegex(EvolutionError, "undetermined"):
            ctrl.review(p.proposal_id, reviewer="operator", approve=True, reason="approved")
        self.assertIsNone(self.ev.decision(p.proposal_id))
        self.assertEqual([x["status"] for x in self.ev.review_attempts(p.proposal_id)],
                         ["STARTED", "UNDETERMINED"])

    def test_f7_accepted_knowledge_four_way_applicability(self):
        p = self.knowledge_proposal()
        self.kb.review(p.submission_id, reviewer="operator", approve=True,
                       rationale="independent review", test_refs=("t1",))
        self.assertEqual(self.kb.accepted()[0]["applicability"], Applicability.APPLICABLE)
        self.approve(self.proposal(value=5))
        self.assertEqual(self.kb.accepted()[0]["applicability"], Applicability.SUPERSEDED)
        with sql_conn(self.ev.path) as db:
            db.execute("DELETE FROM evolution_objects WHERE object_id='o2'")
        self.assertEqual(self.kb.accepted()[0]["applicability"], Applicability.EVIDENCE_GONE)
        self.assertEqual(self.kb.accepted()[0]["applicability_details"]["o2"]["status"],
                         "EVIDENCE_GONE")
        # Restore the source and intentionally corrupt a current row.
        with sql_conn(self.ev.path) as db:
            db.execute("INSERT INTO evolution_objects VALUES(?,?,?,?,?)",
                       ("o2", "b@1", 0, '{"n":2}',
                        '{"operation":{},"schema":{},"description":"","tags":[]}'))
        self.assertEqual(self.kb.accepted()[0]["applicability"], Applicability.EVIDENCE_UNVERIFIABLE)

    def test_f8_atomic_double_review_reports_domain_error(self):
        p = self.knowledge_proposal()
        self.kb.review(p.submission_id, reviewer="operator", approve=True,
                       rationale="approved", test_refs=("test",))
        with self.assertRaisesRegex(EvolutionError, "already decided"):
            self.kb.review(p.submission_id, reviewer="operator", approve=True,
                           rationale="again", test_refs=("test",))
        self.assertEqual(self.kb.decision(p.submission_id).status, "ACCEPTED")

    def test_f8_parallel_review_only_one_atomic_decision(self):
        from concurrent.futures import ThreadPoolExecutor
        from threading import Barrier
        gate = Barrier(2)
        kb = KnowledgeLedger(self.kb.path, self.ev,
                             lambda reviewer, proposal: gate.wait(timeout=5) >= 0)
        p = self.knowledge_proposal()
        def do_review():
            try:
                return kb.review(p.submission_id, reviewer="operator", approve=True,
                                 rationale="parallel review", test_refs=("test",)).status
            except EvolutionError as exc:
                return str(exc)
        with ThreadPoolExecutor(max_workers=2) as pool:
            a = pool.submit(do_review)
            b = pool.submit(do_review)
            statuses = {a.result(timeout=10), b.result(timeout=10)}
        self.assertEqual(statuses, {"ACCEPTED", "knowledge proposal was already decided"})
        self.assertEqual(kb.decision(p.submission_id).status, "ACCEPTED")

    def test_f8_stale_with_counterexamples_records_a_decision(self):
        p = self.knowledge_proposal(counterexamples=("counter1",))
        self.approve(self.proposal(value=4))
        d = self.kb.review(p.submission_id, reviewer="operator", approve=True,
                           rationale="would approve", test_refs=("test",))
        self.assertEqual(d.status, "STALE")
        self.assertIn("NOT APPLIED", d.rationale)

    def test_f9_reflection_partial_report_and_exclusion(self):
        with sql_conn(self.ev.path) as db:
            db.execute("UPDATE evolution_objects SET data_json='{}' WHERE object_id='o2'")
        report = ReflectionDistiller(self.c, self.ev).reflect()
        self.assertEqual(tuple(x["object_id"] for x in report.objects), ("o1",))
        self.assertEqual(report.exclusions[0]["object_id"], "o2")
        self.assertEqual(report.exclusions[0]["status"], "BROKEN")
        self.assertFalse(report.as_json()["coverage_complete"])

    def test_f9_partial_coverage_blocks_knowledge_promotion(self):
        self.ctrl.register_object("o3", "b@1", {"n": 3}, self.schema)
        with sql_conn(self.ev.path) as db:
            db.execute("UPDATE evolution_objects SET data_json='{}' WHERE object_id='o3'")
        report = ReflectionDistiller(self.c, self.ev).reflect()
        self.assertTrue(report.candidates)
        self.assertTrue(all(c.status == "BLOCKED_INCOMPLETE_COVERAGE" for c in report.candidates))
        with self.assertRaisesRegex(EvolutionError, "incomplete registry coverage"):
            self.kb.propose(report.candidates[0], proposer="agent")

    def test_f10_index_is_used_for_decision_lookup(self):
        self.approve(self.proposal())
        with sql_conn(self.ev.path) as db:
            names = {r[1] for r in db.execute("PRAGMA index_list('evolution_decisions')")}
            self.assertIn("evolution_decisions_object_idx", names)
            plan = " ".join(str(r) for r in db.execute("EXPLAIN QUERY PLAN SELECT * FROM evolution_decisions WHERE object_id='o1'"))
            self.assertIn("INDEX", plan)

    def test_f11_schema_relaxation_fails_closed_by_default(self):
        metadata = self.ev.get("o1").metadata
        metadata["schema"]["properties"]["n"] = {"type": "any"}
        p = self.proposal(metadata=metadata)
        d = self.approve(p)
        self.assertEqual(d.status, "REVIEW_DUE")
        self.assertEqual(d.validation["protected_schema"], "additional_review_required")
        self.assertEqual(self.ev.get("o1").metadata["schema"]["properties"]["n"]["type"], "integer")

    def test_f11_direct_ledger_commit_still_enforces_schema_protection(self):
        meta = self.ev.get("o1").metadata
        meta["schema"]["properties"]["n"] = {"type": "any"}
        p = self.proposal(metadata=meta)
        with self.assertRaisesRegex(EvolutionError, "higher-authority attestation"):
            self.ev.decide(p, reviewer="operator", approve=True,
                           reason="direct bypass attempted", validation={"schema": "passed"})
        self.assertEqual(self.ev.get("o1").revision, 0)

    def test_f11_distinct_higher_reviewer_can_authorize_relaxation(self):
        ctrl = TypeEvolutionController(self.c, self.ev, lambda reviewer, p: reviewer == "operator",
                   authorize_sensitive_review=lambda reviewer, p: reviewer == "supervisor")
        metadata = self.ev.get("o1").metadata
        metadata["schema"]["properties"]["n"] = {"type": "any"}
        p = self.proposal(metadata=metadata)
        d = ctrl.review(p.proposal_id, reviewer="operator", approve=True,
                        reason="evidence warrants compatibility break", elevated_reviewer="supervisor")
        self.assertEqual(d.status, "ACCEPTED")
        self.assertEqual(d.validation["elevated_reviewer"], "supervisor")
        self.assertEqual(self.ev.get("o1").revision, 1)

    def test_append_only_correction_preserves_original_decision(self):
        p = self.proposal()
        d = self.approve(p)
        self.ev.append_correction(p.proposal_id, reviewer="auditor", rationale="clarification",
                                  corrected_interpretation="reason has narrower scope")
        self.assertEqual(self.ev.decision(p.proposal_id), d)
        self.assertEqual(len(self.ev.corrections(p.proposal_id)), 1)

    def test_knowledge_authority_unavailable_durable(self):
        p = self.knowledge_proposal()
        kb = KnowledgeLedger(self.kb.path, self.ev, lambda reviewer, proposal: 1 / 0)
        with self.assertRaisesRegex(EvolutionError, "undetermined"):
            kb.review(p.submission_id, reviewer="operator", approve=True,
                      rationale="maybe", test_refs=("test",))
        self.assertIsNone(kb.decision(p.submission_id))
        self.assertEqual(kb.review_attempts(p.submission_id)[-1]["status"], "UNDETERMINED")


if __name__ == "__main__":
    unittest.main()
