"""Contract, governance, durability and reflection regression suite."""
from __future__ import annotations

from pathlib import Path
import sqlite3
from fd_oop_reconstruction.original import sql_conn
from tempfile import TemporaryDirectory
import unittest

from fd_oop_reconstruction import (
    ContractCatalog, ContractError, ConcurrencyError, EvolutionError,
    EvolutionLedger, FunctionPair, JsonData, Metadata, SchemaError, Step,
    Intent, SQLiteJobStore, ToulminArgument, TypeEvolutionController,
    VersionedExecutionRegistry, ReflectionDistiller, object_metadata, validate_json,
    AgenticEvolutionService, agentic_evolution_controller, GoalAssignments,
)


class CounterData(JsonData):
    pass


def count_up(data: CounterData) -> Step:
    if data.checkpoint == "START":
        return Step("COUNTED", {"count": data.payload["count"] + 1}, Intent.YIELD)
    return Step("DONE", {"result": data.payload["count"] * 2}, Intent.COMPLETE)


class OtherCounterData(JsonData):
    pass


def other_count(data: OtherCounterData) -> Step:
    return Step("DONE", {"result": data.payload["count"] + 5}, Intent.COMPLETE)


class UnsafeCounterData(JsonData):
    pass


def unsafe_count(data: UnsafeCounterData) -> Step:
    return Step("DONE", {"count": "wrong_type"}, Intent.COMPLETE)


ARG = {"claim": "A numeric revision should use an integer constraint.",
       "grounds": ["Observed numeric revisions across methods"],
       "warrant": "Revision arithmetic depends on integer semantics",
       "backing": ["Local validation test"], "qualifier": "provisional",
       "rebuttals": ["External source identifiers might use strings"],
       "evidence_refs": ["test-run:01"]}


class EvolutionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        p = Path(self.tmp.name)
        self.catalog = ContractCatalog()
        self.catalog.register(FunctionPair(Metadata("count", "1", "START",
                    {"START": ("COUNTED",), "COUNTED": ("DONE",)},
                    frozenset({"DONE"})), CounterData, count_up))
        self.catalog.register(FunctionPair(Metadata("other", "1", "START",
                    {"START": ("DONE",)}, frozenset({"DONE"})),
                    OtherCounterData, other_count))
        self.catalog.register(FunctionPair(Metadata("unsafe", "1", "START",
                    {"START": ("DONE",)}, frozenset({"DONE"})),
                    UnsafeCounterData, unsafe_count))
        self.ledger = EvolutionLedger(str(p / "evolution.db"))
        self.controller = TypeEvolutionController(
            self.catalog, self.ledger,
            authorize_review=lambda reviewer, proposal: reviewer == "operator")
        self.store = SQLiteJobStore(p / "jobs.db")
        self.runtime = VersionedExecutionRegistry(self.catalog, self.store, self.ledger)
        self.controller.register_object("o1", "count@1", {"count": 1},
                       {"type": "object", "properties": {"count": {"type": "any"}},
                        "required": ["count"]}, description="Count data")

    def proposal(self, *, object_id="o1", expected_revision=0, data=None,
                 metadata=None, arguments=None, notes=None):
        value = self.ledger.get(object_id)
        return self.controller.propose(object_id, proposer="agent", expected_revision=expected_revision,
                       arguments=[ARG] if arguments is None else arguments,
                       data={"count": 2} if data is None else data, metadata=metadata,
                       notes=["Changed after test evidence"] if notes is None else notes)

    def accept(self, p):
        return self.controller.review(p.proposal_id, reviewer="operator", approve=True,
                                      reason="independent review")

    def test_toulmin_json_round_trip(self):
        a = ToulminArgument.from_json(ARG)
        self.assertEqual(a.as_json(), ARG)
        self.assertEqual(a.qualifier, "provisional")

    def test_argumentation_thread_preserves_opposition(self):
        support = {**ARG, "argument_id": "support1", "stance": "support"}
        opposition = {"argument_id": "against1", "stance": "oppose", "responds_to": "support1",
                      "claim": "Opaque revisions also exist", "grounds": ["other service contract"],
                      "warrant": "An integer-only constraint is not universal"}
        p = self.proposal(arguments=[support, opposition])
        d = self.accept(p)
        self.assertEqual(d.validation["opposing_arguments"], 1)
        self.assertEqual(d.validation["supporting_arguments"], 1)
        self.assertEqual(self.ledger.history("o1")[0]["arguments"][1]["stance"], "oppose")
        self.assertEqual(self.ledger.history("o1")[0]["arguments"][1]["responds_to"], "support1")

    def test_argument_thread_rejects_unknown_or_self_reference(self):
        a = {**ARG, "argument_id": "a", "responds_to": "a"}
        with self.assertRaises(EvolutionError):
            self.proposal(arguments=[a])
        a["responds_to"] = "missing"
        with self.assertRaises(EvolutionError):
            self.proposal(arguments=[a])

    def test_opposition_only_proposal_refused(self):
        a = {**ARG, "stance": "oppose"}
        with self.assertRaises(EvolutionError):
            self.proposal(arguments=[a])

    def test_no_schema_evolution_on_corrupted_history(self):
        with sql_conn(self.ledger.path) as db:
            db.execute("UPDATE evolution_objects SET data_json=? WHERE object_id='o1'",
                       ('{"count":999}',))
        with self.assertRaises(EvolutionError):
            self.proposal()
        reflection = ReflectionDistiller(self.catalog, self.ledger).reflect()
        self.assertEqual(reflection.candidates, ())
        self.assertEqual(reflection.exclusions[0]["status"], "BROKEN")

    def test_toulmin_requires_ground_and_warrant(self):
        for key, value in [("grounds", []), ("warrant", ""), ("claim", "")]:
            a = {**ARG, key: value}
            with self.subTest(key=key), self.assertRaises(EvolutionError):
                ToulminArgument.from_json(a)

    def test_toulmin_reject_unknown_key(self):
        with self.assertRaises(EvolutionError):
            ToulminArgument.from_json({**ARG, "secret": "x"})

    def test_propose_requires_arguments(self):
        with self.assertRaises(EvolutionError):
            self.proposal(arguments=[])

    def test_annotation_list_rejects_non_string(self):
        with self.assertRaises(EvolutionError):
            self.proposal(notes=[3])

    def test_noop_proposal_refused(self):
        with self.assertRaises(EvolutionError):
            self.proposal(data={"count": 1})

    def test_pre_and_post_snapshot_are_distinct_and_detached(self):
        p = self.proposal()
        p.candidate_data["count"] = 400   # returned object is NOT the database
        result = self.accept(self.ledger.proposal(p.proposal_id))
        self.assertEqual(result.status, "ACCEPTED")
        e = self.ledger.history("o1")[0]
        self.assertEqual(e["before"]["data"], {"count": 1})
        self.assertEqual(e["after"]["data"], {"count": 2})
        self.assertEqual(e["arguments"][0]["claim"], ARG["claim"])
        self.assertEqual(e["notes"], ["Changed after test evidence"])
        self.assertTrue(self.ledger.verify_history("o1"))

    def test_reject_preserves_proposal_but_not_applied_after(self):
        p = self.proposal()
        decision = self.controller.review(p.proposal_id, reviewer="operator",
                                          approve=False, reason="insufficient evidence")
        self.assertEqual(decision.status, "REJECTED")
        self.assertEqual(self.ledger.get("o1").revision, 0)
        h = self.ledger.history("o1")[0]
        self.assertIsNone(h["after"])
        self.assertEqual(h["candidate"]["data"], {"count": 2})
        self.assertTrue(self.ledger.verify_history("o1"))

    def test_no_self_approval(self):
        p = self.proposal()
        with self.assertRaises(EvolutionError):
            self.controller.review(p.proposal_id, reviewer="agent", approve=True, reason="approve")
        self.assertIsNone(self.ledger.decision(p.proposal_id))

    def test_review_authority_gate(self):
        p = self.proposal()
        with self.assertRaises(EvolutionError):
            self.controller.review(p.proposal_id, reviewer="stranger", approve=True, reason="approve")
        self.assertEqual(self.ledger.get("o1").revision, 0)

    def test_stale_proposal_cannot_overwrite_accepted_state(self):
        p = self.proposal()
        another = self.proposal(data={"count": 99})
        self.accept(p)
        d = self.accept(another)
        self.assertEqual(d.status, "STALE")
        self.assertEqual(self.ledger.get("o1").data, {"count": 2})
        self.assertTrue(self.ledger.verify_history("o1"))

    def test_stale_base_rejected_during_proposal(self):
        self.accept(self.proposal())
        with self.assertRaises(ConcurrencyError):
            self.proposal(expected_revision=0)

    def test_multiple_proposals_with_same_revision_one_wins(self):
        a = self.proposal(data={"count": 2})
        b = self.proposal(data={"count": 3})
        self.accept(b)
        self.assertEqual(self.accept(a).status, "STALE")
        self.assertEqual(self.ledger.get("o1").revision, 1)

    def test_double_decision_forbidden(self):
        p = self.proposal()
        self.accept(p)
        with self.assertRaises(EvolutionError):
            self.accept(p)

    def test_metadata_schema_is_evolvable(self):
        obj = self.ledger.get("o1")
        meta = obj.metadata
        meta["schema"]["properties"]["count"] = {"type": "integer", "minimum": 0}
        p = self.proposal(data={"count": 2}, metadata=meta)
        self.assertEqual(self.accept(p).status, "ACCEPTED")
        self.assertEqual(self.ledger.get("o1").metadata["schema"]["properties"]["count"],
                         {"type": "integer", "minimum": 0})

    def test_executable_graph_cannot_be_modified_via_metadata(self):
        meta = self.ledger.get("o1").metadata
        meta["operation"]["transitions"]["START"] = ["UNSAFE"]
        p = self.proposal(metadata=meta)
        d = self.accept(p)
        self.assertEqual(d.status, "REJECTED")
        self.assertEqual(d.validation["schema"], "failed")
        self.assertEqual(self.ledger.get("o1").revision, 0)

    def test_invalid_candidate_data_is_rejected_by_independent_validation(self):
        meta = self.ledger.get("o1").metadata
        meta["schema"]["properties"]["count"] = {"type": "integer"}
        p = self.proposal(data={"count": "no"}, metadata=meta)
        self.assertEqual(self.accept(p).status, "REJECTED")
        self.assertIn("count", self.ledger.history("o1")[0]["reason"])

    def test_schema_unknown_keyword_fails_closed(self):
        with self.assertRaises(SchemaError):
            validate_json({}, {"type": "object", "magicalCheck": True})

    def test_bool_is_not_integer(self):
        with self.assertRaises(SchemaError):
            validate_json(True, {"type": "integer"})

    def test_schema_required_and_additional_properties(self):
        s = {"type": "object", "required": ["x"],
             "properties": {"x": {"type": "string"}}, "additionalProperties": False}
        validate_json({"x": "ok"}, s)
        with self.assertRaises(SchemaError):
            validate_json({"x": "ok", "y": 1}, s)
        with self.assertRaises(SchemaError):
            validate_json({}, s)

    def test_schema_array_enum_bounds(self):
        s = {"type": "array", "items": {"type": "integer", "minimum": 1, "enum": [1, 2, 3]}}
        validate_json([1, 2], s)
        with self.assertRaises(SchemaError):
            validate_json([0], s)
        with self.assertRaises(SchemaError):
            validate_json([4], s)

    def test_new_jobs_use_new_schema(self):
        meta = self.ledger.get("o1").metadata
        meta["schema"]["properties"]["count"] = {"type": "integer", "minimum": 0}
        self.accept(self.proposal(metadata=meta))
        with self.assertRaises(SchemaError):
            self.runtime.create_for_object("o1", payload={"count": "not an int"})
        job = self.runtime.create_for_object("o1")
        self.assertEqual(self.ledger.job_binding(job.job_id)[1], 1)
        self.runtime.advance(job.job_id)
        done = self.runtime.advance(job.job_id)
        self.assertEqual(done.payload["result"], 6)

    def test_old_running_job_keeps_pinned_schema(self):
        # Preexisting job can continue under its original schema after evolution.
        job = self.runtime.create_for_object("o1")
        self.assertEqual(self.ledger.job_binding(job.job_id)[1], 0)
        meta = self.ledger.get("o1").metadata
        meta["schema"]["properties"]["count"] = {"type": "integer", "minimum": 0}
        self.accept(self.proposal(metadata=meta))
        self.assertEqual(self.ledger.job_binding(job.job_id)[1], 0)
        self.runtime.advance(job.job_id)
        self.assertEqual(self.runtime.advance(job.job_id).payload["result"], 4)

    def test_guard_blocks_bad_worker_output_before_commit(self):
        self.controller.register_object("bad", "unsafe@1", {"count": 1},
                       {"type": "object", "properties": {"count": {"type": "integer"}},
                        "required": ["count"]})
        job = self.runtime.create_for_object("bad")
        with self.assertRaises(SchemaError):
            self.runtime.advance(job.job_id)
        self.assertEqual(self.store.get(job.job_id).status.value, "FAILED")
        self.assertEqual(self.store.get(job.job_id).payload, {"count": 1})

    def test_unbound_job_cannot_use_typed_facade(self):
        legacy_job = self.runtime.engine.create("count@1", {"count": 1})
        with self.assertRaises(EvolutionError):
            self.runtime.advance(legacy_job.job_id)

    def test_ledger_restart_persistence(self):
        self.accept(self.proposal())
        reopened = EvolutionLedger(self.ledger.path)
        self.assertEqual(reopened.get("o1").revision, 1)
        self.assertTrue(reopened.verify_history("o1"))
        self.assertEqual(len(reopened.history("o1")), 1)

    def test_proposal_and_decision_tables_reject_mutation(self):
        p = self.proposal()
        self.accept(p)
        with sql_conn(self.ledger.path) as db:
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("UPDATE evolution_decisions SET reason='forged' WHERE proposal_id=?",
                           (p.proposal_id,))
        with sql_conn(self.ledger.path) as db:
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("DELETE FROM evolution_proposals WHERE proposal_id=?", (p.proposal_id,))

    def test_reflection_enumerates_complete_catalog(self):
        report = ReflectionDistiller(self.catalog, self.ledger).reflect()
        self.assertEqual({x["contract"] for x in report.methods}, {"count@1", "other@1", "unsafe@1"})
        self.assertEqual(report.objects[0]["object_id"], "o1")

    def test_cross_method_repeated_schema_candidate(self):
        schema = {"type": "object", "properties": {"count": {"type": "integer"}},
                  "required": ["count"]}
        self.controller.register_object("o2", "other@1", {"count": 2}, schema)
        meta = self.ledger.get("o1").metadata
        meta["schema"] = schema
        self.accept(self.proposal(metadata=meta))
        candidates = ReflectionDistiller(self.catalog, self.ledger).reflect().candidates
        self.assertTrue(any(c.kind == "REPEATED_FIELD_SCHEMA" and
                            set(c.supporting_objects) == {"o1", "o2"} for c in candidates))
        self.assertTrue(all(c.status == "NEEDS_INDEPENDENT_REVIEW" for c in candidates))

    def test_cross_method_repeated_claim_candidate(self):
        self.controller.register_object("o2", "other@1", {"count": 2},
                       {"type": "object", "properties": {"count": {"type": "any"}}})
        self.accept(self.proposal())
        self.accept(self.proposal(object_id="o2", data={"count": 3}))
        candidates = ReflectionDistiller(self.catalog, self.ledger).reflect().candidates
        result = [c for c in candidates if c.kind == "REPEATED_ACCEPTED_ARGUMENT"]
        self.assertEqual(len(result), 1)
        self.assertEqual(len(result[0].supporting_events), 2)
        self.assertTrue(result[0].limitations)

    def test_different_contracts_required_for_distillation(self):
        self.controller.register_object("o3", "count@1", {"count": 2},
                       {"type": "object", "properties": {"count": {"type": "any"}}})
        self.assertEqual(ReflectionDistiller(self.catalog, self.ledger).reflect().candidates, ())

    def test_conflicting_field_constraints_reported(self):
        schema = {"type": "object", "properties": {"count": {"type": "integer"}}}
        self.controller.register_object("o2", "other@1", {"count": 2}, schema)
        self.controller.register_object("o3", "unsafe@1", {"count": 5},
                       {"type": "object", "properties": {"count": {"type": "integer"}}})
        candidates = ReflectionDistiller(self.catalog, self.ledger).reflect().candidates
        field = next(c for c in candidates if c.kind == "REPEATED_FIELD_SCHEMA")
        self.assertIn("o1", field.counterexamples)

    def test_agent_goal_assignment_fences_proposal_commit(self):
        assignments = GoalAssignments(str(Path(self.tmp.name) / "assignments.db"))
        assignments.assign("agent", "goal-1", "operator")
        governed = agentic_evolution_controller(self.catalog, self.ledger, assignments,
                          authorize_review=lambda reviewer, p: reviewer == "operator")
        service = AgenticEvolutionService("agent", assignments, governed,
                                         ReflectionDistiller(self.catalog, self.ledger))
        p = service.propose_for_goal("goal-1", "o1", expected_revision=0,
                                     arguments=[ARG], data={"count": 3}, notes=["goal context"])
        assignments.revoke("agent", "goal-1")
        d = governed.review(p.proposal_id, reviewer="operator", approve=True, reason="otherwise valid")
        self.assertEqual(d.status, "REVIEW_DUE")
        self.assertEqual(self.ledger.get("o1").revision, 0)

    def test_agent_proposes_but_cannot_commit(self):
        assignments = GoalAssignments(str(Path(self.tmp.name) / "assignments2.db"))
        assignments.assign("agent", "goal-1", "operator")
        governed = agentic_evolution_controller(self.catalog, self.ledger, assignments,
                          authorize_review=lambda reviewer, p: reviewer == "operator")
        service = AgenticEvolutionService("agent", assignments, governed,
                                         ReflectionDistiller(self.catalog, self.ledger))
        p = service.propose_for_goal("goal-1", "o1", expected_revision=0,
                                     arguments=[ARG], data={"count": 3})
        self.assertFalse(hasattr(service, "approve"))
        self.assertFalse(hasattr(service, "review"))
        self.assertEqual(governed.review(p.proposal_id, reviewer="operator", approve=True,
                                         reason="approved").status, "ACCEPTED")
        self.assertEqual(service.reflect().objects[0]["revision"], 1)


if __name__ == "__main__":
    unittest.main()
