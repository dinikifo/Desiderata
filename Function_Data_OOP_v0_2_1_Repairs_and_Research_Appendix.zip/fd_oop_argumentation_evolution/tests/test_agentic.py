from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import unittest

from fd_oop_reconstruction.agentic import (
    VaultOwner, GoalAssignments, FDAgent, NativeAuthority, Goal,
    MethodMemory, IndependentOutcomeOracle, AuthorityError, SourceChanged,
    AttemptStatus, Assessment, SourcePin, Proposal,
)
from fd_oop_reconstruction.original import Status, ContractError, ConcurrencyError, sql_conn


class AgenticTests(unittest.TestCase):
    def setUp(self):
        temp = TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.dir = Path(temp.name)
        self.vault = VaultOwner(self.dir/'vault.db')
        self.assignments = GoalAssignments(self.dir/'assignments.db')
        self.agent = FDAgent('agent-01', self.dir/'fd.db',self.assignments)
        self.native = NativeAuthority(self.dir/'native.db', self.vault, self.assignments, self.agent.store)
        self.oracle = IndependentOutcomeOracle(self.vault)
        self.memory = MethodMemory(self.dir/'memory.db')
        self.goal = Goal('goal-01','Record verifiable source evidence','source-note',
                         'output-note','Key observation')
        self.pin = self.vault.put_note('source-note','Key observation: 42')
        self.assignments.assign('agent-01','goal-01','host-operator')

    def prepare(self):
        job = self.agent.start(self.goal,self.pin)
        self.agent.resume(job.job_id)
        done = self.agent.resume(job.job_id)
        self.assertEqual(done.status,Status.COMPLETED)
        self.assertEqual(done.checkpoint,'SEALED')
        return job.job_id,self.agent.proposal(job.job_id)

    def test_full_workflow_separation(self):
        jid, proposal = self.prepare()
        self.assertFalse(hasattr(self.agent,'execute'))
        self.assertEqual(self.agent.store.history(jid),[(0,'NEW','NEW'),(1,'PREPARED','YIELDED'),
                                                        (2,'SEALED','COMPLETED')])
        token = self.native.operator_approve(proposal,operator_id='operator-1')
        attempt = self.native.execute(proposal,token)
        self.assertEqual(attempt.status, AttemptStatus.SUCCESS)
        outcome = self.oracle.review(self.goal,proposal,attempt)
        self.assertEqual(outcome.assessment,Assessment.ACCEPTED)
        self.memory.record('agent-01',self.goal.goal_id,jid,outcome)
        self.assertEqual(len(self.memory.history('agent-01')),1)

    def test_no_assignment_means_no_work(self):
        self.assignments.revoke('agent-01','goal-01')
        with self.assertRaises(AuthorityError):
            self.agent.start(self.goal,self.pin)

    def test_reassignment_invalidates_prepared_work(self):
        job = self.agent.start(self.goal,self.pin)
        self.agent.resume(job.job_id)
        self.assignments.assign('agent-01','goal-01','different-operator')
        with self.assertRaises(AuthorityError):
            self.agent.resume(job.job_id)

    def test_reassignment_invalidates_sealed_proposal(self):
        jid,p = self.prepare()
        self.assignments.assign('agent-01','goal-01','operator-2')
        with self.assertRaises(AuthorityError):
            self.agent.proposal(jid)
        with self.assertRaises(AuthorityError):
            self.native.operator_approve(p,operator_id='operator-1')

    def test_false_source_excerpt_rejected_even_if_digest_is_real(self):
        forged_source = SourcePin(self.pin.note_id, self.pin.revision, self.pin.digest,
                                  'Unverified invented assertion')
        job = self.agent.start(self.goal, forged_source)
        self.agent.resume(job.job_id)
        self.agent.resume(job.job_id)
        fake = self.agent.proposal(job.job_id)
        with self.assertRaises(AuthorityError):
            self.native.operator_approve(fake,operator_id='operator-1')

    def test_proposal_needs_actual_fd_checkpoint(self):
        _, proposal = self.prepare()
        forged = replace(proposal,fd_job_id='made-up-job')
        with self.assertRaises(AuthorityError):
            self.native.operator_approve(forged,operator_id='operator-1')

    def test_reserved_attempt_survives_crash_and_is_reconciled(self):
        _, proposal = self.prepare()
        token = self.native.operator_approve(proposal,operator_id='operator-1')
        # Simulate a hard process crash after the reservation was durable but
        # before the Python handler could invoke its resource owner.
        h = hashlib.sha256(token.encode()).hexdigest()
        with sql_conn(self.native.path) as db:
            db.execute('UPDATE approvals SET used=1 WHERE token_hash=?',(h,))
            db.execute("INSERT INTO attempts VALUES(?,?,?,?,?,?)",
                       ('simulated-reservation',proposal.identity,h,'RESERVED','',None))
        recovered = self.native.reconcile('simulated-reservation')
        self.assertEqual(recovered.status, AttemptStatus.UNKNOWN)
        with self.assertRaises(AuthorityError):
            self.native.execute(proposal,token)

    def test_source_change_refuses_approval(self):
        _,p = self.prepare()
        self.vault.put_note('source-note','Changed observation')
        with self.assertRaises(SourceChanged):
            self.native.operator_approve(p,operator_id='operator-1')

    def test_source_change_after_approval_refuses_execution(self):
        _,p = self.prepare()
        token = self.native.operator_approve(p,operator_id='operator-1')
        self.vault.put_note('source-note','Changed observation')
        with self.assertRaises(SourceChanged):
            self.native.execute(p,token)
        with self.assertRaises(KeyError):
            self.vault.read_note('output-note')

    def test_forged_token_and_tampered_proposal(self):
        _,p = self.prepare()
        with self.assertRaises(AuthorityError):
            self.native.execute(p,'made-up-token')
        token = self.native.operator_approve(p,operator_id='operator-1')
        with self.assertRaises(AuthorityError):
            self.native.execute(replace(p,target_id='unapproved-output'),token)
        # Still valid token for exact original binding
        ok = self.native.execute(p,token)
        self.assertEqual(ok.status,AttemptStatus.SUCCESS)

    def test_approval_cannot_be_replayed(self):
        _,p = self.prepare()
        token = self.native.operator_approve(p,operator_id='operator-1')
        attempt = self.native.execute(p,token)
        self.assertEqual(attempt.status,AttemptStatus.SUCCESS)
        with self.assertRaises(AuthorityError):
            self.native.execute(p,token)
        self.assertEqual(self.vault.read_note('output-note').revision,1)

    def test_unknown_effect_halts_and_reconciles(self):
        _,p = self.prepare()
        token = self.native.operator_approve(p,operator_id='operator-1')
        ambiguous = self.native.execute(p,token,simulate_crash_after_commit=True)
        self.assertEqual(ambiguous.status,AttemptStatus.UNKNOWN)
        self.assertEqual(self.oracle.review(self.goal,p,ambiguous).assessment,Assessment.INCONCLUSIVE)
        with self.assertRaises(AuthorityError):
            self.native.execute(p,token)
        recovered = NativeAuthority(self.dir/'native.db',self.vault,self.assignments,self.agent.store)
        reconciled = recovered.reconcile(ambiguous.attempt_id)
        self.assertEqual(reconciled.status,AttemptStatus.SUCCESS)
        self.assertEqual(self.oracle.review(self.goal,p,reconciled).assessment,Assessment.ACCEPTED)

    def test_missing_owner_receipt_is_still_unknown(self):
        _,p = self.prepare()
        token = self.native.operator_approve(p,operator_id='operator-1')
        # Force a before-commit error by creating same target through operator fixture
        self.vault.put_note('output-note','unrelated existing artifact')
        ambiguous = self.native.execute(p,token)
        self.assertEqual(ambiguous.status,AttemptStatus.UNKNOWN)
        self.assertEqual(self.native.reconcile(ambiguous.attempt_id).status,AttemptStatus.UNKNOWN)

    def test_independent_oracle_may_reject_successful_effect(self):
        _,p = self.prepare()
        token = self.native.operator_approve(p,operator_id='operator-1')
        attempt = self.native.execute(p,token)
        other_goal = replace(self.goal, required_text='a claim never present')
        outcome = self.oracle.review(other_goal,p,attempt)
        self.assertEqual(outcome.assessment,Assessment.REJECTED)
        self.assertEqual(attempt.status,AttemptStatus.SUCCESS)

    def test_inconclusive_without_acceptance_criterion(self):
        _,p = self.prepare()
        token = self.native.operator_approve(p,operator_id='operator-1')
        attempt = self.native.execute(p,token)
        no_oracle = replace(self.goal,required_text='')
        self.assertEqual(self.oracle.review(no_oracle,p,attempt).assessment,Assessment.INCONCLUSIVE)

    def test_artifact_changed_after_publish_rejected(self):
        _,p = self.prepare()
        token = self.native.operator_approve(p,operator_id='operator-1')
        attempt = self.native.execute(p,token)
        self.vault.put_note('output-note','tampered')
        self.assertEqual(self.oracle.review(self.goal,p,attempt).assessment,Assessment.REJECTED)

    def test_restarted_agent_reuses_checkpoint(self):
        job = self.agent.start(self.goal,self.pin)
        self.agent.resume(job.job_id)
        restarted = FDAgent('agent-01',self.dir/'fd.db',self.assignments)
        done = restarted.resume(job.job_id)
        self.assertEqual(done.status,Status.COMPLETED)
        self.assertEqual(restarted.proposal(job.job_id).fd_revision,2)

    def test_explicit_second_goal_reuse_does_not_imply_better_results(self):
        first,p = self.prepare()
        token = self.native.operator_approve(p,operator_id='operator-1')
        a = self.native.execute(p,token)
        self.memory.record('agent-01','goal-01',first,self.oracle.review(self.goal,p,a))
        second_goal = Goal('goal-02','Preserve another source','source-note','output-02','Key observation')
        self.assignments.assign('agent-01','goal-02','host-operator')
        another = self.agent.start(second_goal,self.pin)
        self.agent.resume(another.job_id)
        self.agent.resume(another.job_id)
        p2 = self.agent.proposal(another.job_id)
        token2 = self.native.operator_approve(p2,operator_id='operator-1')
        a2 = self.native.execute(p2,token2)
        self.memory.record('agent-01','goal-02',another.job_id,
                           self.oracle.review(second_goal,p2,a2))
        self.assertEqual([x[0] for x in self.memory.history('agent-01')],['goal-01','goal-02'])


if __name__=='__main__':
    unittest.main()
