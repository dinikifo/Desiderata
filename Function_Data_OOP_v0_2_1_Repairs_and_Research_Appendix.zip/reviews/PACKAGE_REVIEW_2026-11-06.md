# Review — Function–Data OOP: Code & Consolidated Research

**Package:** `204b982e-Function_Data_OOP_Code_and_Consolidated_Research.zip`
**Reviewed:** 2026-11-06. **Contents:** `fd_oop_argumentation_evolution/` (2,298 source lines,
1,026 test lines, 11 modules) and a 5,321-word research paper in `.docx`.

**Method:** static read of all 11 modules and 5 test files; the suite and all three demos
executed; nine seams probed with scripts written outside the extracted tree. Every finding
below was reproduced, not inferred. Probe transcripts are quoted inline.

---

## Disposition

**The package is sound and the research discipline is better than most published work of
this kind.** 85 tests pass in 2.0 s; all three demos run; no network, `exec`, `subprocess`
or out-of-tempdir writes anywhere; `TRACEABILITY.md` separates what is historically
grounded from what is invented, and separates v0.1 from v0.2; the paper's §9.2 states what
must *not* be claimed; the schema validator rejects unknown keywords rather than ignoring
them, and correctly refuses `True` against `enum: [1]` and `1.0` against `enum: [1]`.

**One systematic defect runs through the v0.2 modules**, and it is the defect class this
whole project has spent a month learning to find:

> **v0.2 abandoned the closed-vocabulary discipline that v0.1 already implements, 200 lines
> away in the same package.**

`agentic.py` (v0.1) has `class AttemptStatus(str, Enum)` with
`RESERVED | SUCCESS | UNKNOWN | REJECTED`, and `class Assessment(str, Enum)` with
`ACCEPTED | REJECTED | INCONCLUSIVE`, each paired with a `diagnostic` field that carries
the reason. `evolution.py` and `knowledge.py` (v0.2) have bare string literals, no Enum, no
third state, and the chain integrity check returns a **bare `bool`**.

The paper already specifies the repair. §2.4, "Three orthogonal statuses":

| Axis | Vocabulary |
|---|---|
| Epistemic | Supported / contested / defeated / **unknown** |
| Governance | Proposed / authorized / rejected / **review due** |
| Operational | Inactive / active / suspended / superseded |

The code implements **one** axis with **three** values — `ACCEPTED | REJECTED | STALE` —
collapsing governance and epistemic state and representing `unknown` nowhere. Every finding
F1–F9 below is an instance of a value that needed one of the paper's missing axes and got a
boolean instead. That is a good position to be in: the design document is ahead of the
implementation, and one change closes nine findings.

Grep confirms no closed vocabulary is exported anywhere in `src/`: no `Enum` in the v0.2
modules, no `Literal[...]`, no `STATUSES` or `KINDS` tuple. No consumer can assert
exhaustiveness over any v0.2 status.

---

## Findings

| ID | Finding | Severity | Status |
|---|---|---|---|
| **F1** | `verify_history` reports an unknown object as a broken chain | High | reproduced |
| **F2** | `verify_history` raises `KeyError` instead of returning, on a reachable state | High | reproduced |
| **F3** | A `STALE` decision permanently records the reviewer's *approval* reason | High | reproduced |
| **F4** | An eligibility lapse and a substantive rejection share one status | Medium | reproduced |
| **F5** | `validation["argument_structure"] = "passed"` is a constant, not a result | Medium | reproduced |
| **F6** | An authority callback that cannot decide leaves no durable trace | High | reproduced |
| **F7** | `currently_applicable` collapses evolved / deleted / **tampered** into `false` | **High** | reproduced |
| **F8** | `KnowledgeLedger.review` is held to a lower standard than `EvolutionLedger.decide` | Medium | reproduced |
| **F9** | `reflect()` aborts the whole registry report on the first damaged object | Medium | reproduced |
| **F10** | `verify_history` is O(n) per call and called twice per review → quadratic | Medium | measured |
| **F11** | Invariant 5 of §7.2 has no implementation | Medium | verified absent |

None of F3–F9 is covered by the test suite: `currently_applicable`, `argument_structure`,
`not_run`, "already decided" and eligibility appear **0 times** in `tests/`, and
`verify_history` is asserted only `True`/`False` on healthy and corrupted chains — never on
an unknown object.

---

### F1 · F2 — the integrity check is not total

`EvolutionLedger.verify_history(object_id) -> bool` has **three** reachable outcomes and two
return values.

```
verify_history('nope')        -> False          # object does not exist
verify_history('o1')          -> True
propose on unknown object     -> EvolutionError: invalid evolution history; refuse further changes
```

A mistyped `object_id` produces a **tampering diagnosis**. `TypeEvolutionController.propose`
calls `verify_history` first (line 592) and raises `"invalid evolution history; refuse
further changes"` — which is the correct message for a broken hash chain and the wrong
message for a typo. An operator who sees it will go looking for an attacker. This is
`NO_SUCH_POST` versus `NAMESPACE_UNAVAILABLE`, in the module where the stakes are highest.

F2 is worse, because the function is not total at all. `verify_history` catches `KeyError`
from `genesis()` (line 505) but line 539 then calls `self.get(object_id)`, which raises
`KeyError` for a missing object row. `evolution_genesis` is trigger-protected against
DELETE; **`evolution_objects` is not**, and must not be, since it is CAS-updated. So:

```
DELETE evolution_genesis      -> blocked: IntegrityError: immutable genesis
DELETE evolution_objects      -> 1 row(s) deleted, no trigger
verify_history('o1')          -> RAISED KeyError: 'o1'
```

A `bool`-returning integrity check raising on a reachable state. It escapes `review()` too:
the `try` at line 622 catches `(ContractError, ValueError)`, and `KeyError` is neither — so
the exception propagates after the proposal has been read and before any decision is
recorded, leaving no trace that a review was attempted.

**Repair.** Return a value, not a bit:

```python
class HistoryStatus(str, Enum):
    VERIFIED      = "VERIFIED"       # chain checks out
    BROKEN        = "BROKEN"         # a digest or revision does not match
    NO_SUCH_OBJECT = "NO_SUCH_OBJECT"
    UNCHECKABLE   = "UNCHECKABLE"    # genesis present, object row gone; DB unreadable

@dataclass(frozen=True)
class HistoryVerdict:
    status: HistoryStatus
    detail: str = ""        # which decision, which digest, which exception
```

`verify_history` must raise for no input. Then `propose` and `review` refuse on
`BROKEN`/`UNCHECKABLE` with the right message, and report `NO_SUCH_OBJECT` as what it is.

---

### F3 — the immutable record contradicts itself

`EvolutionLedger.decide` line 451:

```python
status = "ACCEPTED" if approve and same_base else ("STALE" if not same_base else "REJECTED")
```

When `approve=True` and the base has moved, the status becomes `STALE` — and `reason` is
stored **unmodified**, still carrying the approval text.

```
first  -> ACCEPTED
second -> STALE
second's permanently recorded reason:
    'Validated schema and independently reviewed arguments'
second's validation: {"argument_structure": "passed", "operation_contract": "unchanged",
                      "opposing_arguments": 0, "schema": "passed", "supporting_arguments": 1}
```

A permanent row says `STALE` while its reason and its validation block both read as an
acceptance. `evolution_decisions` is frozen by trigger against UPDATE and DELETE, so **this
cannot be corrected afterwards** — the design's immutability guarantee preserves the
misleading record as faithfully as a correct one.

Compare the handling of `eligibility_check` 36 lines earlier, which gets this right by
prefixing the reason (line 615). The `STALE` path needed the same treatment and did not get
it.

**Repair.** On `STALE`, record both: the reviewer's verdict as given, and the system's
reason for not applying it.

```python
if status == "STALE":
    reason = (f"not applied: object moved to revision {revision} after this proposal "
              f"was raised against {p.base_revision}; reviewer's verdict was "
              f"{'approve' if approve else 'reject'}: {reason}")
    validation = {**validation, "applied": "no", "stale_against": p.base_revision}
```

---

### F4 · F5 — the validation block overstates and under-distinguishes

```
reviewer said no      -> status='REJECTED'  validation.schema='not_run'
eligibility lapsed    -> status='REJECTED'  validation.schema='not_run'
    only the free-text reason separates them: 'assignment or context no longer eligible: looks right'
```

A query over `evolution_decisions` by status cannot separate "the reviewer judged this
wrong" from "the goal assignment lapsed before the review landed." Those call for different
actions — the second is re-proposable once the assignment is restored. The paper's
governance axis has `review due` for exactly this.

F5: `validation["argument_structure"] = "passed"` is assigned at line 617 **before any
check runs**, and survives into the record on every path, including a flat rejection where
no reviewer-side validation executed at all:

```
rejected without any reviewer-side check running:
    {"argument_structure": "passed", "opposing_arguments": 0, "schema": "not_run",
     "supporting_arguments": 1}
```

Structural checking *did* happen — in `ToulminArgument.__post_init__` and in
`ledger.propose` — but at proposal time, by a different actor. The decision record now
attributes it to the reviewer's validation pass. A hardcoded `"passed"` is the same defect
as a hardcoded `"failed"`, and the adjacent `schema: "not_run"` shows the author knew the
three-state idiom and applied it one key over. Set `argument_structure` to `"checked_at_proposal"`,
or re-run the check and record the result.

---

### F6 — an authority callback that cannot decide

`if not self.authorize_review(reviewer, p)` (line 612). Two outcomes modeled, three
reachable: authorized, refused, **could not determine**.

```
review() -> TimeoutError: directory unreachable
decision recorded?  -> None
```

The docs are candid that `operator_id` is a label and not a credential — but that is about
authority *strength*, not about the totality of the callback's outcome. A real deployment
will back this with something that can be unavailable. Today an unavailable authority
produces an escaped exception and **no durable trace that a review was attempted**, in a
system whose entire purpose is an auditable decision record.

**Repair.** Wrap the callback, and record the attempt:

```python
try:
    authorized = self.authorize_review(reviewer, p)
except Exception as exc:
    return self.ledger.decide(p, reviewer=reviewer, approve=False,
        reason=f"authority undetermined: {type(exc).__name__}: {exc}",
        validation={**validation, "authorization": "undetermined"})
```

with a `status` of `UNDETERMINED` once the vocabulary exists, so it is not mistaken for a
rejection on the merits.

---

### F7 — the sharpest finding: provenance reporting loses the alarm

`KnowledgeLedger.accepted()`, lines 142–146:

```python
try:
    currently_applicable = all(self._fingerprint(oid) == fingerprint
                               for oid, fingerprint in p.source_snapshots.items())
except (KeyError, EvolutionError):
    currently_applicable = False
```

Four conditions, one bit:

```
untouched                      -> currently_applicable = True
object legitimately evolved    -> currently_applicable = False
object row DELETED             -> currently_applicable = False
decision chain CORRUPTED       -> currently_applicable = False
```

A reviewer reading `currently_applicable: false` cannot tell *"this rule is stale because
the schema moved on"* — routine, expected, the system working — from *"the evidence this
rule rests on has been tampered with."* The second is an incident. They are the same bit.

And the collapse is two levels deep: the `EvolutionError` arm fires because `_fingerprint`
calls `verify_history`, whose `False` already conflated F1's unknown-object case with a
broken chain. Four real conditions reach one boolean through two separate lossy seams, in
the module whose sole purpose is epistemic provenance.

This is the module where the defect matters most, because the paper's §4.1 names
**"epistemic self-sealing"** as a deeper objection the design must answer. A provenance
check that cannot distinguish tampering from ordinary drift is how self-sealing happens
quietly.

**Repair.**

```python
class Applicability(str, Enum):
    APPLICABLE   = "APPLICABLE"
    SUPERSEDED   = "SUPERSEDED"      # evidence object evolved; fingerprints differ
    EVIDENCE_GONE = "EVIDENCE_GONE"  # supporting object no longer exists
    EVIDENCE_UNVERIFIABLE = "EVIDENCE_UNVERIFIABLE"  # its chain does not verify — INCIDENT
```

with a per-object detail map, so the row names which object and why. Keep
`currently_applicable` as a derived convenience if callers need it, computed from the
vocabulary rather than replacing it.

---

### F8 — two ledgers, two standards

`EvolutionLedger.decide` and `KnowledgeLedger.review` do the same job with materially
different rigour:

| | `EvolutionLedger.decide` | `KnowledgeLedger.review` |
|---|---|---|
| transaction | `BEGIN IMMEDIATE` | none |
| already-decided check | explicit, raises `EvolutionError` | **absent** |
| staleness re-check | inside the transaction | outside, then a separate `INSERT` |
| double decision | `EvolutionError("proposal was already decided")` | `IntegrityError: UNIQUE constraint failed` |

```
first  review -> ACCEPTED
second review -> IntegrityError: UNIQUE constraint failed: knowledge_decisions.submission_id
```

A raw `sqlite3` error crossing the domain boundary. And because the fingerprint re-check
(line 122) and the `INSERT` (line 130) run on different connections with no transaction
spanning them, the staleness verdict is TOCTOU — exactly the race `decide` was written to
close.

There is also an ordering defect. Lines 118–126 run the counterexample and test-reference
checks **before** computing staleness, so:

```
a STALE proposal that also has counterexamples:
  RAISED EvolutionError: unresolved counterexamples prevent knowledge promotion
  durable record of the attempt? -> None
```

A stale submission *without* counterexamples records `STALE`. The same staleness *with*
counterexamples records nothing at all. Accumulate the refusal reasons and record one
decision, rather than returning on the first — the same correction the project's own plan
file prescribes for `goal.py:66`.

---

### F9 — whole-registry reflection is not total

`ReflectionDistiller.reflect`, lines 74–76:

```python
for obj in self.ledger.objects():
    if not self.ledger.verify_history(obj.object_id):
        raise ValueError(f"invalid evolution history for {obj.object_id}")
```

One damaged object aborts the entire report. The distiller cannot say "here are the
candidates from the eleven healthy objects; object #7 could not be verified" — it says
nothing. This is the same non-totality that `Resolver._fetch` exists to fix in
PERSONAL.WIKI: a bulk scan must not abort because one member is damaged.

Note also `ValueError`, not `EvolutionError`, in a module whose siblings raise the domain
type. Someone already noticed the leak and papered over it locally —
`TypeEvolutionController.review` catches `(ContractError, ValueError)` at line 632 — rather
than fixing the type. Collect per-object verdicts, report the unverifiable ones alongside
the candidates, and exclude them from support counts.

---

### F10 — quadratic by construction

`verify_history` scans `evolution_decisions` with no index on `object_id`, and calls
`self.proposal(row[0])` **inside the loop** — one new SQLite connection and query per
decision. It is called once in `propose` and once in `review`, so every state change costs
O(decisions).

```
 accepted  propose+review ms  verify_history ms  history() ms
       20               17.2                6.7           5.5
       60               41.8               18.0          15.6
      120               75.9               34.5          32.4
```

Cleanly linear per operation, so quadratic in total. Extrapolating: ~600 ms per
propose+review at 1,000 decisions, ~6 s at 10,000. `EXPLAIN QUERY PLAN` confirms
`SCAN evolution_decisions` — the only indexes present are the implicit primary keys.

Three fixes, cheapest first: add `CREATE INDEX ... ON evolution_decisions(object_id, rowid)`
and the same on `evolution_proposals(object_id)`; join the proposal rows in one query
instead of N+1; and cache the verified chain head so an unchanged chain is not re-walked on
every proposal.

---

### F11 — an invariant with no implementation

§7.2 invariant 5: *"Protected authorization criteria and root evidence semantics cannot be
weakened through ordinary metadata evolution."*

Grep finds no `protect`, `immutable_criteria`, `non_relax`, or equivalent concept anywhere
in `src/`. `_check_metadata` pins `meta["operation"]` against the registered contract — so
the *executable* contract cannot change, which is invariant 3 and is well enforced. But
`metadata["schema"]` can be freely **relaxed** by an ordinary accepted proposal:
`{"type": "integer", "minimum": 1}` → `{"type": "any"}` is a valid change requiring exactly
the same single reviewer as a tightening. `ARGUMENTATION_EVOLUTION.md` acknowledges this
("it can also be revised, relaxed, or replaced following review"), so it is disclosed — but
invariant 5 reads as a guarantee and there is nothing behind it.

This is the paper's own §4.1 **"higher-order governance drift"**: *"an authorized sequence
of changes could gradually weaken the acceptance criteria themselves."* The code has no
mechanism that would notice. Either implement a protected metadata region that requires a
distinct, higher authority to relax, or restate invariant 5 as a proposal rather than an
invariant.

---

## What is right, and worth not losing

These are load-bearing and should survive any refactor:

- **`validation["schema"] = "not_run"`** — the correct three-state idiom, in the right
  place. The defect is that its neighbours are not held to it.
- **`AttemptStatus.UNKNOWN` and `Assessment.INCONCLUSIVE`** with a `diagnostic` field —
  v0.1's closed vocabularies, and the model the v0.2 repair should copy.
- **`min_support` counts distinct *contracts*, not snapshots** (`distillation.py:52`) — this
  is §7.2 invariant 2 correctly implemented, and it is the kind of thing usually got wrong.
- **Opposing arguments are preserved and excluded from distillation** (`distillation.py:90`,
  *"An accepted change does not endorse opposing claims"*) — invariant 8, implemented.
- **`decide` re-checks `same_base` inside `BEGIN IMMEDIATE`** — the TOCTOU between
  validation and commit is correctly closed, and produces `STALE` rather than a bad accept.
- **`advance` fences unbound jobs even when terminal** (`evolution.py:669`) — fail-closed,
  and the comment says why.
- **`check_schema` rejects unknown keywords** rather than ignoring them, uses `type()` not
  `isinstance()` so `bool` is not an `integer`, and bounds recursion at 24.
- **`TRACEABILITY.md`** separates grounded from invented, and v0.1 from v0.2, by name. It is
  the strongest document in the package.
- **§9.2 "What should not be claimed"** — a claim ceiling written before the claims.

---

## Test obligations

Each stated as a mutation the suite must catch. None of these is currently covered.

| # | Mutate | A test must fail |
|---|---|---|
| M-1 | `verify_history` returns `False` for an unknown object instead of `NO_SUCH_OBJECT` | unknown-object verdict test |
| M-2 | Restore the bare `self.get()` so `KeyError` escapes | totality test: genesis present, object row deleted |
| M-3 | `STALE` stores the reviewer's reason unmodified | stale-record-reason test |
| M-4 | An eligibility lapse records plain `REJECTED` | governance-axis test |
| M-5 | `argument_structure` hardcoded `"passed"` | validation-block test on a flat rejection |
| M-6 | Authority callback raises; nothing recorded | durable-attempt test with a raising callback |
| M-7 | `currently_applicable` collapses the four conditions | four-way applicability test, one case each |
| M-8 | Remove the already-decided check from `KnowledgeLedger.review` | double-review raises `EvolutionError`, not `IntegrityError` |
| M-9 | Counterexample check runs before the staleness check | stale-with-counterexamples records a decision |
| M-10 | `reflect()` raises on the first unverifiable object | partial-report test over a registry with one damaged object |
| M-11 | Drop the `evolution_decisions(object_id)` index | assert `EXPLAIN QUERY PLAN` uses an index, not `SCAN` |

Two suite-level rules worth adopting, both from this project's own gate: every test is shown
to fail against its mutation before it is accepted, and any `xfail` is `strict=True`.

---

## Recommended order

1. **Define the vocabularies** — `HistoryStatus`, `Applicability`, and a decision status
   carrying the paper's governance axis, each as a `(str, Enum)` with a `detail`/`diagnostic`
   field, following `agentic.py:320`. This is the change that closes F1, F2, F4, F6, F7 and
   F9 at once.
2. **F3 and F5** — two small, independent record-integrity fixes. Do these before any more
   decisions are written, because `evolution_decisions` is frozen and misleading rows are
   permanent.
3. **F8** — bring `KnowledgeLedger.review` up to `decide`'s standard: one
   `BEGIN IMMEDIATE`, an explicit already-decided check, accumulated refusal reasons.
4. **F10** — two indexes and one join.
5. **F11** — decide whether invariant 5 is an invariant or a proposal, and make the document
   and the code agree either way.

---

## What this review did not check

- **The research paper's prior-art claims.** §3 cites [R1–R19]; I did not verify the
  citations or assess novelty. The review is of the code and of the code's agreement with
  the paper's own specifications.
- **`original.py`, `domain.py`, `effects.py`, `agentic.py` in depth.** Read for the v0.1
  patterns cited above and for the seams `evolution.py` depends on; not reviewed line by
  line. The 85 tests cover them and pass.
- **Adversarial analysis.** The package disclaims in-process isolation repeatedly and
  correctly; I took that at its word rather than demonstrating bypasses, except where a
  bypass was needed to reach a legitimate failure state (F2, F7).
- **The `.docx` as a document.** Structure, headings and the sections quoted were read;
  formatting, figures and the bibliography were not.
